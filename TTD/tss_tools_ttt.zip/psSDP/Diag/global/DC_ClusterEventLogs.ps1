﻿#************************************************
# DC_ClusterEventLogs.ps1
# Version 2.0.2
# Date: 11-30-2009
# Author: Andre Teixeira - andret@microsoft.com
# Description: This script calls TS_GetEvents.ps1 to export cluster-related event logs
#************************************************

if($debug -eq $true){[void]$shell.popup("Run DC_ClusterEventLogsLogs.ps1")}

Import-LocalizedData -BindingVariable ClusterEventLogsStrings

if ($OSVersion.Major -ge 6) #Vista and newer
{
	$ClusterServiceKey="HKLM:\SYSTEM\CurrentControlSet\Services\ClusDisk"

	if (Test-Path $ClusterServiceKey) 
	{
		$EventLogNames = wevtutil.exe el | Select-String "Microsoft-Windows-FailoverClustering(?!\SDiagnostic)"
		if ($EventLogNames -ne $null)
		{
			Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $ClusterEventLogsStrings.ID_ClusterRelatedEvtLogs
		}
		#_# adding Storage Eventlogs
		$EventLogNamesStorage = wevtutil.exe el | Select-String "Microsoft-Windows-Storage(?!\SDiagnostic)"
		if ($null -ne $EventLogNames)
		{
			Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNamesStorage -SectionDescription $ClusterEventLogsStrings.ID_ClusterRelatedEvtLogsStorage
		}

		$NetworkProfileLogName="Microsoft-Windows-NetworkProfile/Operational"
		Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $NetworkProfileLogName
	}
	else
	{
		"Machine is not a cluster node" | WriteTo-StdOut -ShortFormat
	}
}
