﻿#************************************************
# TS_DetectLowPathMTU.ps1
# Version 1.0
# Date: 02/06/2014
# Author: BBenson
# Description:  
# Rule number:  262755
# Rule ID:  d2aaab92-c906-4b3e-a4e5-67244c49c422
# Rule URL:  https://kse.microsoft.com/Contribute/Idea/de6654f5-8b05-4f97-b67b-f9ad51bc78ab
# Purpose:
#  1. Determine which network adapters are of type Ethernet with "netsh int ipv4 show int"
#  2. RootCause detected if any Ethernet adapter has a PMTU less than 1500 in the output of "netsh int ipv4 show destinationcache"
#************************************************
# 2019-03-17 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptStrings
Write-DiagProgress -Activity $ScriptStrings.ID_DetectLowPathMTU_Activity -Status $ScriptStrings.ID_DetectLowPathMTU_Status


#WV/WS2008+
if ($OSVersion.Build -gt 6000)
{

	$RootCauseDetected = $false
	$RootCauseName = "RC_DetectLowPathMTU"
	$InformationCollected = new-object PSObject


	# ***************************
	# Data Gathering
	# ***************************


	#-----ipv4
	$OutputFileIPv4 = "DetectLowPathMTU_netsh-int-ipv4-show-int.TXT"
	$NetSHCommandToExecute = "int ipv4 show int"
	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFileIPv4 "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false

	$netshIPv4MTUSettings = Get-Content $OutputFileIPv4
	[int]$netshIPv4MTUSettingsLen = $netshIPv4MTUSettings.length


	#==========
	# New section for detecting Ethernet adapters
	#==========
	$NetworkAdapterWMIQuery = "select * from win32_networkadapter"
	$NetworkAdapterWMI = get-wmiobject -query $NetworkAdapterWMIQuery
	$NetworkAdapterWMILen = $NetworkAdapterWMI.length
	# Creating NetAdapter psobject
		$NetAdapterObj = New-Object psobject
	$EtherAdapterNum = 0

	#==========
	# Read entire output file with contents from "netsh int ipv4 show int" into a PSObject.
	#==========

	# Creating IPv4MtuObj psobject
		$ipObj = New-Object psobject
		
	# find the line after the line of dashes
	for ($i=0;$i -le $netshIPv4MTUSettingsLen;$i++)
	{
		#lines of interest after line that starts with dashes
		$line = $null
		$line = $netshIPv4MTUSettings[$i]
		# Handling the first few lines by finding the line that starts with dashes
		if ($line -match "---")
		{
			$dashline = $i
			$i++	#increment past the line of dashes

			# all lines interesting after dash line
			for ($j=1;$j -le $netshIPv4MTUSettingsLen;$j++)
			{
				#first line of interest
				$line = $null
				$line = $netshIPv4MTUSettings[$i]
				
				if ($line -eq "")
				{
					break
				}
				
				$delimiter = " "
				$arrLine = [Regex]::Split($line, $delimiter)
				$arrLineLen = $arrLine.length			
				
				$Idx = ""
				$Met = ""
				$MTU = ""
				$State = ""
				$Name = ""
				$headerCounter = 0
				for ($k=0;$k -le $arrLineLen;$k++)
				{
					
					#if non zero value, increment counter and proceed
					if ($arrLine[$k] -ne "")
					{
						#if headerCounter has been incremented, assign it to a variable.
						if ($headerCounter -eq 0)	{ $Idx   = $arrLine[$k] }
						if ($headerCounter -eq 1)	{ $Met   = $arrLine[$k] }
						if ($headerCounter -eq 2)	{ $MTU   = $arrLine[$k] }
						if ($headerCounter -eq 3)	{ $State = $arrLine[$k] }
						if ($headerCounter -eq 4)
						{
							$Name  = $arrLine[$k]
							do
							{
								$k++
								$Name  = $Name + " " + $arrLine[$k]
							} while($k -le $arrLineLen)
						}
						$headerCounter++
					}
				}	
				# define object
					$psobj = New-Object psobject @{
					"Idx" = $Idx
					"Met" = $Met
					"MTU" = $MTU
					"State" = $State
					"Name" = $Name
					}
				
				#create object				
					New-Variable -Name ('Int' + $Idx) -Value $psobj -Force

				#add member
					Add-Member -InputObject $ipObj -MemberType NoteProperty -Name "Int$Idx" -Value (get-variable -name Int$Idx).value -Force

				#increment counter
				$i++
			}
		}

		#-----finding each interface in ipObj
		$ipObjFile = "ipObj.TXT"
		$ipObj | fl | Out-File $ipObjFile

		$ipObjTxt = Get-Content $ipObjFile
		[int]$ipObjTxtLen = $ipObjTxt.length
		# "number of interfaces: " + $ipObjTxtLen

		# loop through the lines of output, finding each interface number

		for ($i=1;$i -le $ipObjTxtLen-1;$i++)
		{
			#==========
			# Find Ethernet adapters with a LinkMTU of 1514
			#==========
			$netshIPv4PMTU = $null
			if ($ipObjTxt[$i] -ne "")
			{
				$line = $ipObjTxt[$i] 
				$delimiter = ":"
				$arrLine = [Regex]::Split($line, $delimiter)
				[string]$intID = ([string]$arrLine[0]).TrimEnd()
				[string]$intName = ($ipObj.$intID.name).TrimEnd()
			}
		}
	}


	#-----finding each interface in ipObj
	$ipObjFile = "ipObj.TXT"
	$ipObj | fl | Out-File $ipObjFile

	$ipObjTxt = Get-Content $ipObjFile
	[int]$ipObjTxtLen = $ipObjTxt.length
	# "number of interfaces: " + $ipObjTxtLen

	# loop through the lines of output, finding each interface number

	for ($i=1;$i -le $ipObjTxtLen-1;$i++)
	{
		#==========
		# Find adapters from "netsh int ipv4 show int"
		#==========
		$netshIPv4PMTU = $null
		if ($ipObjTxt[$i] -ne "")
		{
			$line = $ipObjTxt[$i] 
			$delimiter = ":"
			$arrLine = [Regex]::Split($line, $delimiter)
			#"arrLine0: " + [string]$arrLine[0]
			[string]$intID = ([string]$arrLine[0]).TrimEnd()
			[string]$intName = ($ipObj.$intID.name).TrimEnd()


		#==========
		# Find Ethernet adapters that have less than 1500 bytes
		#==========
		
		
			#==========
			# Create output file with contents from "netsh int ipv4 show destinationcache IdxNumber".
			#==========
			[int]$IdxNumber = $ipObj.$intID.Idx
			$OutputFileIPv4PMTU = "TCPIP_netsh-int-ipv4-show-destinationcache-$IdxNumber.TXT"
			#"filename: " + $OutputFileIPv4PMTU

			$NetSHCommandToExecute = "int ipv4 show destinationcache " + $IdxNumber
			$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFileIPv4PMTU "
			RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
			# "[info] Created the output for Interface$IdxNumber" | WriteTo-Stdout

			

			#==========
			# Read entire output file with contents from "netsh int ipv4 show destinationcache IdxNumber" into a PSObject.
			#==========
			$netshIPv4PMTU = Get-Content $OutputFileIPv4PMTU
			[int]$netshIPv4PMTULen = $netshIPv4PMTU.length		

		
			#==========
			# Create output file with contents from "netsh int ipv4 show destinationcache IdxNumber".
			#   	MTU reference: $ipObj.$intID.idx
			#		WMI reference: $NetworkAdapterWMI[$i].InterfaceIndex
			#		For each Ethernet adapter, detect any PMTU values below 1500.
			#==========
			
			for ($wmiAdapterCount=0;$wmiAdapterCount -le $NetworkAdapterWMILen;$wmiAdapterCount++)
			{
				if ( ($NetworkAdapterWMI[$wmiAdapterCount].AdapterType -eq "Ethernet 802.3") -and (($ipObj.$intID.idx -eq $NetworkAdapterWMI[$wmiAdapterCount].InterfaceIndex)) )
				{
					#"==========WMI output==========" 
					#$NetworkAdapterWMI[$wmiAdapterCount]
					$NetAdapterWMIID = $NetworkAdapterWMI[$wmiAdapterCount].DeviceID #Index
					# "AdapterType= Ethernet 802.3 with InterfaceIndex of  :" + $NetworkAdapterWMI[$wmiAdapterCount].InterfaceIndex
					# "                                   with Index of   :" + $NetworkAdapterWMI[$wmiAdapterCount].Index
					# "                                 with DeviceID of  :" + $NetAdapterWMIID
					
					#create array here that contains the Ethernet adapters.
					$EtherAdapterNum = $EtherAdapterNum + 1
					#"Number of Ethernet Adapters: " + $EtherAdapterNum
					Add-Member -InputObject $NetAdapterObj -MemberType NoteProperty -Name "$NetAdapterWMIID" -Value ($NetAdapterWMIID)



					
					#==========
					# Parse the output file to determine if there are any PMTU values below 1500.
					#==========
					
					# Creating IPv4MtuObj psobject
					$pmtuObj = New-Object psobject
					
					#"==========Check IPv4 DestinationCache for PMTU < 1500=========="
					#"lines in destinationcache file: " + $netshIPv4PMTULen
					
					# find the line after the line of dashes
					for ($j=0;$j -le $netshIPv4PMTULen;$j++)
					{
						#lines of interest after line that starts with dashes
						$line = $null
						$line = $netshIPv4PMTU[$j]
						# Handling the first few lines by finding the line that starts with dashes
						if ($line -match "---")
						{
							$dashline = $j
							$j++	#increment past the line of dashes

							# all lines interesting after dash line
							for ($l=1;$l -le $netshIPv4PMTULen;$l++)
							{
								#first line of interest
								$line = $null
								$line = $netshIPv4PMTU[$j]
								
								if ($line -eq "")
								{
									break
								}
								
								$delimiter = " "
								$arrLine = [Regex]::Split($line, $delimiter)	

								$PMTU = ""
								$DestAddress = ""
								$NextHop = ""
								$headerCounter = 0
								for ($k=0;$k -le $arrLineLen;$k++)
								{
									#if non zero value, increment counter and proceed
									if ($arrLine[$k] -ne "")
									{
										#if headerCounter has been incremented, assign it to a variable.
										if ($headerCounter -eq 0)	{ $PMTU = $arrLine[$k] }
										if ($headerCounter -eq 1)	{ $DestAddress = $arrLine[$k] }
										if ($headerCounter -eq 2)	{ $NextHop = $arrLine[$k] }
										if ($headerCounter -eq 3)	{ $What = $arrLine[$k] }
										$headerCounter++
									}
								}
							
								# define object
								$psobj = New-Object psobject @{
								"PMTU" = $PMTU
								"DestAddress" = $DestAddress
								"NextHop" = $NextHop
								}
								
								#create variable				
									New-Variable -Name ('PMTU' + $PMTU) -Value $psobj -Force

								#add member
									Add-Member -InputObject $pmtuObj -MemberType NoteProperty -Name "Int$Idx" -Value (get-variable -name PMTU$PMTU).value -Force
								
								if ($PMTU -lt 1500)
								{
									# Problem detected.
									$RootCauseDetected = $true
									[int]$currentInterface = $ipObj.$intID.idx
									add-member -inputobject $InformationCollected  -membertype noteproperty -name "Interface $currentInterface" -value "Low Path MTU detected for connections on this adapter"

									"[info] Root Cause Detected: Low PMTU" | WriteTo-Stdout					
									<#
									"   Interface  :  " + $NetworkAdapterWMI[$wmiAdapterCount].InterfaceIndex
									"   PMTU <1500 :  " + $PMTU
									"   DestAddress: " + $DestAddress
									# "   NextHop    : " + $NextHop
									#>
								}
								
								#increment counter
								$j++					
							}
						}	
					}				
				}
			}
		}
	}



	# **************
	# Detection Logic
	# **************

	#Check to see if rule is applicable to this computer
	if ($RootCauseDetected -eq $true)
	{
		Write-GenericMessage -RootCauseId $RootCauseName -PublicContentURL "http://support.microsoft.com/kb/314496" -InformationCollected $InformationCollected -Verbosity "Error" -Visibility 4 -SupportTopicsID 8041 -Component "Networking"  	
	}



	# *********************
	# Root Cause processing
	# *********************

	if ($RootCauseDetected)
		{
		 # Red/ Yellow Light
		 Update-DiagRootCause -id $RootCauseName -Detected $true
		}
		else
		{
		 # Green Light
		 Update-DiagRootCause -id $RootCauseName -Detected $false
		}

}
