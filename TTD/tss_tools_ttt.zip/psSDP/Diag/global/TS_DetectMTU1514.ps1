﻿#************************************************
# TS_DetectMTU1514.ps1
# Version 1.0
# Date: 02/06/2014
# Author: BBenson
# Description:  Detect if LinkMTU is set to 1514.
# Rule number:  262751
# Rule ID:  7a316c95-272b-4207-983d-57acb91d0eea
# Rule URL:  https://kse.microsoft.com/Contribute/Idea/1456f71b-f3ff-4247-ade1-d47b8ff1a4e6
# Purpose:
#  1. Determine which network adapters are of type Ethernet with "netsh int ipv4 show int"
#  2. RootCause detected if LinkMTU is set to 1514.
#************************************************
# 2019-03-17 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptStrings
Write-DiagProgress -Activity $ScriptStrings.ID_DetectMTU1514_Activity -Status $ScriptStrings.ID_DetectMTU1514_Status

$RootCauseDetected = $false
$RootCauseName = "RC_DetectMTU1514"
$InformationCollected = new-object PSObject



# ***************************
# Data Gathering
# ***************************


#-----ipv4
$OutputFileIPv4 = "DetectMTU1514_netsh-int-ipv4-show-int.TXT"
$NetSHCommandToExecute = "int ipv4 show int"
$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFileIPv4 "
RunCmD -commandToRun $CommandToExecute  -CollectFiles $false

$netshIPv4MTUSettings = Get-Content $OutputFileIPv4
[int]$netshIPv4MTUSettingsLen = $netshIPv4MTUSettings.length


#==========
# Read entire output file with contents from "netsh int ipv4 show int" into a PSObject.
#==========

# Creating IPv4MtuObj psobject
	$ipObj = New-Object psobject
	
# find the line after the line of dashes
for ($i=0;$i -le $netshIPv4MTUSettingsLen;$i++)
{
	#lines of interest after line that starts with dashes
	$line = $null
	$line = $netshIPv4MTUSettings[$i]
	# Handling the first few lines by finding the line that starts with dashes
	if ($line -match "---")
	{
		$dashline = $i
		$i++	#increment past the line of dashes

		# all lines interesting after dash line
		for ($j=1;$j -le $netshIPv4MTUSettingsLen;$j++)
		{
			#first line of interest
			$line = $null
			$line = $netshIPv4MTUSettings[$i]
			
			if ($line -eq "")
			{
				break
			}
			
			$delimiter = " "
			$arrLine = [Regex]::Split($line, $delimiter)
			$arrLineLen = $arrLine.length			
			
			$Idx = ""
			$Met = ""
			$MTU = ""
			$State = ""
			$Name = ""
			$headerCounter = 0
			for ($k=0;$k -le $arrLineLen;$k++)
			{
				
				#if non zero value, increment counter and proceed
				if ($arrLine[$k] -ne "")
				{
					#if headerCounter has been incremented, assign it to a variable.
					if ($headerCounter -eq 0)	{ $Idx   = $arrLine[$k] }
					if ($headerCounter -eq 1)	{ $Met   = $arrLine[$k] }
					if ($headerCounter -eq 2)	{ $MTU   = $arrLine[$k] }
					if ($headerCounter -eq 3)	{ $State = $arrLine[$k] }
					if ($headerCounter -eq 4)
					{
						$Name  = $arrLine[$k]
						do
						{
							$k++
							$Name  = $Name + " " + $arrLine[$k]
						} while($k -le $arrLineLen)
					}
					$headerCounter++
				}
			}	
			# define object
				$psobj = New-Object psobject @{
				"Idx" = $Idx
				"Met" = $Met
				"MTU" = $MTU
				"State" = $State
				"Name" = $Name
				}
			
			#create object				
				New-Variable -Name ('Int' + $Idx) -Value $psobj -Force

			#add member
				Add-Member -InputObject $ipObj -MemberType NoteProperty -Name "Int$Idx" -Value (get-variable -name Int$Idx).value -Force

			#increment counter
			$i++
		}
	}

	#-----finding each interface in ipObj
	$ipObjFile = "ipObj.TXT"
	$ipObj | fl | Out-File $ipObjFile

	$ipObjTxt = Get-Content $ipObjFile
	[int]$ipObjTxtLen = $ipObjTxt.length
	# "number of interfaces: " + $ipObjTxtLen

	# loop through the lines of output, finding each interface number

	for ($i=1;$i -le $ipObjTxtLen-1;$i++)
	{
		#==========
		# Find Ethernet adapters with a LinkMTU of 1514
		#==========
		$netshIPv4PMTU = $null
		if ($ipObjTxt[$i] -ne "")
		{
			$line = $ipObjTxt[$i] 
			$delimiter = ":"
			$arrLine = [Regex]::Split($line, $delimiter)
			[string]$intID = ([string]$arrLine[0]).TrimEnd()
			[string]$intName = ($ipObj.$intID.name).TrimEnd()

			if ($ipObj.$intID.mtu -eq 1514)
			{
				#Problem detected.
				$RootCauseDetected = $true
				[int]$currentInterface = $ipObj.$intID.idx
				add-member -inputobject $InformationCollected  -membertype noteproperty -name "Interface $currentInterface" -value "MTU=1514"
			}
		}
	}
}





# **************
# Detection Logic
# **************

#Check to see if rule is applicable to this computer
if ($RootCauseDetected -eq $true)
{
    Write-GenericMessage -RootCauseId $RootCauseName -PublicContentURL "http://support.microsoft.com/kb/314496" -InformationCollected $InformationCollected -Verbosity "Error" -Visibility 4 -SupportTopicsID 8041 -Component "Networking"  	
}





# *********************
# Root Cause processing
# *********************

if ($RootCauseDetected)
	{
	 # Red/ Yellow Light
	 Update-DiagRootCause -id $RootCauseName -Detected $true
	}
	else
	{
	 # Green Light
	 Update-DiagRootCause -id $RootCauseName -Detected $false
	}
