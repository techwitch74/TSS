﻿
PARAM(	$MaxFileSize=400, 
		$MaximumAge="",
		$MaxFilesToCopy=3, 
		$CopyOnlyUserDumpsFrom="",
		$SkipAlertsForCategories="",
		[switch]$CopyUserDumps, 
		[switch]$CopyMachineMemoryDump,
		[switch]$CopyMachineMiniDumps,
		[switch]$CopyWERMinidumps,
		[switch]$CopyWERFulldumps,
		[switch]$CopyTDRDumps)

# 2019-03-17 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}
. ./utils_cts.ps1
#Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}

	Import-LocalizedData -BindingVariable DumpCollectorStrings

	Write-DiagProgress -Activity $DumpCollectorStrings.ID_MemoryDumpRelated -Status $DumpCollectorStrings.ID_MemoryDumpCollecting
	
	$ScriptArguments="/GenerateScriptedDiagxmlAlerts "
	if ($CopyUserDumps) {$ScriptArguments += "/CopyUserDumps "}
	if ($CopyMachineMemoryDump) {$ScriptArguments += "/CopyMachineMemoryDump "}
	if ($CopyWERMinidumps) {$ScriptArguments += "/CopyWERMinidumps "}
	if ($CopyWERFulldumps) {$ScriptArguments += "/CopyWERFulldumps "}
	if ($CopyTDRDumps.IsPresent) {$ScriptArguments += "/CopyTDRDumps "}
	if ($CopyMachineMiniDumps) {$ScriptArguments += "/CopyMachineMiniDumps "}
	if ($MaximumAge -ne "") {$ScriptArguments += "/MaxAge:$MaximumAge "}
	if ($MaxFileSize -ne "") {$ScriptArguments += "/MaxSize:$MaxFileSize "}
	if ($MaxFilesToCopy -ne 3) {$ScriptArguments += "/MaxFiles:$MaxFilesToCopy "}
	if ($CopyOnlyUserDumpsFrom -ne "") {
		$CopyUserDumpsFromScriptArgument = ""
		ForEach ($CopyOnlyUserDumpsFromProcess in $CopyOnlyUserDumpsFrom) {
			$CopyUserDumpsFromScriptArgument = $CopyUserDumpsFromScriptArgument + $CopyOnlyUserDumpsFromProcess + ", "
		}			
		$ScriptArguments += "/onlycopyuserdumpsfrom:`"$CopyUserDumpsFromScriptArgument`" "
	}
	if ($SkipAlertsForCategories -ne "") {
		$SkipAlertsForCategoriesArgument = ""
		ForEach ($SkipAlertsForCategory in $SkipAlertsForCategories) {
			$SkipAlertsForCategoriesArgument += $SkipAlertsForCategory + ", "
		}			
		$ScriptArguments +="/dontalertcategories:$SkipAlertsForCategoriesArgument "
	}
	
	if ($OSArchitecture -ne 'ARM')
	{	#$ScriptArguments += "/cdbpath:$pwd\cdb.exe /debuginfo" 	
		$ScriptArguments += "/cdbpath:$Global:ToolsPath\cdb.exe /debuginfo" 	}
	else
	{
	 	'Skipping DebugInfo since {Cdb.exe} is not supported in ' + $OSArchitecture + ' architecture.' | WriteTo-StdOut
	}
	
	$CommandToExecute = "cscript.exe DumpCollector.VBS $ScriptArguments"
	if($debug -eq $true){[void]$shell.popup("Command line: $CommandToExecute")}
	
	[Array] $OutputFiles = $Computername + "_DumpReport.htm"
	$OutputFiles += $Computername + "_DumpReport.txt"

	RunCmD -commandToRun $CommandToExecute -sectionDescription $DumpCollectorStrings.ID_MemoryDumpRelatedInfo -filesToCollect $OutputFiles -fileDescription $DumpCollectorStrings.ID_MemoryDumpReport 
	
	if (test-path "*_dmp_*.*") {
		$FilestobeCollected = Get-ChildItem  "*_dmp_*.*"
		$FilestobeCollected | ForEach-object -process {
			$FileName = Split-Path $_.Name -leaf
			$FileExtension = $_.extension.ToLower()
			$ReportDisplayName = ($DumpCollectorStrings.ID_MemoryDumpFile + " (" + (FormatBytes($_.Length)) +")")
			Update-DiagReport -Id $DumpCollectorStrings.ID_MemoryDumpRelatedInfo -Name $ReportDisplayName -File $_.Name
		}
	}

$DumpCollectorAlertXMLFileName = $Pwd.Path + "\" + $Computername + "_DumpReportAlerts.XML"

if (test-path $DumpCollectorAlertXMLFileName) {	
	Update-DiagRootCause -id RC_DumpCollector -Detected $true
}

#Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
