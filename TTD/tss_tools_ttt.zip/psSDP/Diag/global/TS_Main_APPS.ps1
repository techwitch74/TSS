﻿# see  https://support.microsoft.com/en-gb/help/2777618/sdp-3-fb1bd57c-43b4-4236-973b-cb4fdbc0f3e8-windows-store-in-box-applic

# Load Common Library
#_#$debug = $false

. ./utils_cts.ps1


$FirstTimeExecution = FirstTimeExecution

"FirstTimeExecution = $FirstTimeExecution" | WriteTo-StdOut
if ($FirstTimeExecution) {

	# Auto Added Commands [AutoAdded]
	.\TS_AutoAddCommands_APPS.ps1
	EndDataCollection

} else {
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
}
