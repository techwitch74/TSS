﻿#************************************************
# DC_NetworkAdapters-Component.ps1
# Version 1.0 Dumped the registry key where adapter information is stored, and added Powershell Cmdlets (via JoelCh)
# Version 1.1 Added registry output for the CurrentControlSet\Control class ID for Adapters.
# Version 1.2: Altered the runPS function to correct a column width issue.
# Version 1.3.07.31.2014: Added the detailed output for Get-NetAdapterBinding -AllBindings.
# Version 1.4.08.08.2014: Added regkey "HKLM\SYSTEM\CurrentControlSet\Control\Network" to reg output so we can correlate GUIDs to Interface names.
# Version 1.5.08.11.2014: Added "Network Adapter to GUID Mappings" section using output from "HKLM:\SYSTEM\CurrentControlSet\Control\Network"
# Date: 2013-2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: 
# Called from: Networking Diags
#*******************************************************
#2019-08-31 WalterE

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}


function RunPS ([string]$RunPScmd="", [switch]$ft, [switch]$noHeader)
{
	if ($noHeader)
	{
	}
	else
	{
		$RunPScmdLength = $RunPScmd.Length
		"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
		"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
		"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	}
		
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}


	Import-LocalizedData -BindingVariable ScriptVariable
	Write-DiagProgress -Activity $ScriptVariable.ID_ctsNetAdapters -Status $ScriptVariable.ID_ctsNetAdaptersDescription #_#


$sectionDescription = "Network Adapters"

# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$outputFile = $Computername + "_NetworkAdapters_info_pscmdlets.TXT"
"===================================================="		| Out-File -FilePath $OutputFile -append
"Network Adapter Powershell Cmdlets"						| Out-File -FilePath $OutputFile -append
"===================================================="		| Out-File -FilePath $OutputFile -append
"Overview"													| Out-File -FilePath $OutputFile -append
"----------------------------------------------"			| Out-File -FilePath $OutputFile -append
"Network Adapter Powershell Cmdlets"						| Out-File -FilePath $OutputFile -append
"   1. Get-NetAdapter"										| Out-File -FilePath $OutputFile -append
"   2. Get-NetAdapter -IncludeHidden"						| Out-File -FilePath $OutputFile -append
"   3. Get-NetAdapterAdvancedProperty"						| Out-File -FilePath $OutputFile -append
"   4. Get-NetAdapterBinding -AllBindings -IncludeHidden | select Name, InterfaceDescription, DisplayName, ComponentID, Enabled"	| Out-File -FilePath $OutputFile -append
"   5. Get-NetAdapterChecksumOffload"						| Out-File -FilePath $OutputFile -append
"   6. Get-NetAdapterEncapsulatedPacketTaskOffload"			| Out-File -FilePath $OutputFile -append
"   7. Get-NetAdapterHardwareInfo"							| Out-File -FilePath $OutputFile -append
"   8. Get-NetAdapterIPsecOffload"							| Out-File -FilePath $OutputFile -append
"   9. Get-NetAdapterLso"									| Out-File -FilePath $OutputFile -append
"  10. Get-NetAdapterPowerManagement"						| Out-File -FilePath $OutputFile -append
"  11. Get-NetAdapterQos"									| Out-File -FilePath $OutputFile -append
"  12. Get-NetAdapterRdma"									| Out-File -FilePath $OutputFile -append
"  13. Get-NetAdapterRsc"									| Out-File -FilePath $OutputFile -append
"  14. Get-NetAdapterRss"									| Out-File -FilePath $OutputFile -append
"  15. Get-NetAdapterSriov"									| Out-File -FilePath $OutputFile -append
"  16. Get-NetAdapterSriovVf"								| Out-File -FilePath $OutputFile -append
"  17. Get-NetAdapterStatistics"							| Out-File -FilePath $OutputFile -append
"  18. Get-NetAdapterVmq"									| Out-File -FilePath $OutputFile -append
"  19. Get-NetAdapterVmqQueue"								| Out-File -FilePath $OutputFile -append
"  20. Get-NetAdapterVPort"									| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"		| Out-File -FilePath $OutputFile -append
"Network Adapter Details For NON-HIDDEN Adapters (formatted list, non-hidden)"	| Out-File -FilePath $OutputFile -append
"   1. Get-NetAdapter | fl *"	| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"		| Out-File -FilePath $OutputFile -append
"Network Adapter Details For HIDDEN Adapters (formatted list, ONLY hidden)"	| Out-File -FilePath $OutputFile -append
"   1. Get-NetAdapter -IncludeHidden (parsed to show hidden only)"	| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"			| Out-File -FilePath $OutputFile -append
"Network Adapter to GUID Mappings"								| Out-File -FilePath $OutputFile -append
"  Using regkey HKLM:\SYSTEM\CurrentControlSet\Control\Network"	| Out-File -FilePath $OutputFile -append
"===================================================="			| Out-File -FilePath $OutputFile -append
"`n`n`n`n`n"	| Out-File -FilePath $OutputFile -append

"__ value of Switch noNetAdapters: $Global:noNetAdapters  - 'True' will suppress output for Get-NetAdapterStatistics.`n`n"	| Out-File -FilePath $OutputFile -append


if ($bn -gt 9000)
{
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Network Adapter Powershell Cmdlets"					| Out-File -FilePath $OutputFile -append	
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" 	| Out-File -FilePath $OutputFile -append
	"-------------------------------"	| Out-File -FilePath $OutputFile -append
	"Get-NetAdapter (formatted table)"	| Out-File -FilePath $OutputFile -append
	"-------------------------------"	| Out-File -FilePath $OutputFile -append
	$networkAdapters = get-netadapter
	$networkAdaptersLen = $networkAdapters.length
	"Number of Network Adapters (output from get-netadapter; does not include hidden adapters): " + $networkAdaptersLen	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	runPS "Get-NetAdapter"				-ft -noheader	# W8/WS2012, W8.1/WS2012R2	# ft

	"-------------------------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	"Get-NetAdapter -IncludeHidden (formatted table, hidden)"	| Out-File -FilePath $OutputFile -append
	"-------------------------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	$networkAdaptersWithHidden = Get-NetAdapter -IncludeHidden
	$networkAdaptersWithHiddenLen = $networkAdaptersWithHidden.length
	$hiddenNetworkAdaptersLen = 0
	foreach ($adapter in $networkAdaptersWithHidden)
	{
		if ($adapter.Hidden -eq $true)
		{ $hiddenNetworkAdaptersLen++ }
	}
	"Number of Network Adapters (output from get-netadapter; does not include hidden adapters): " + $networkAdaptersLen	| Out-File -FilePath $OutputFile -append
	"Number of Network Adapters (including hidden adapters) : " + $networkAdaptersWithHiddenLen	| Out-File -FilePath $OutputFile -append

	"`n"	| Out-File -FilePath $OutputFile -append
	runPS "Get-NetAdapter -IncludeHidden"						-ft -noheader	# W8/WS2012, W8.1/WS2012R2	# ft
	runPS "Get-NetAdapterAdvancedProperty"						-ft # W8/WS2012, W8.1/WS2012R2	# ft	
	runPS "Get-NetAdapterBinding -AllBindings -IncludeHidden | select Name, InterfaceDescription, DisplayName, ComponentID, Enabled"	-ft # W8/WS2012, W8.1/WS2012R2	# ft
	runPS "Get-NetAdapterChecksumOffload"						-ft # W8/WS2012, W8.1/WS2012R2	# ft	
	runPS "Get-NetAdapterEncapsulatedPacketTaskOffload"			-ft # W8/WS2012, W8.1/WS2012R2	# ft	
	runPS "Get-NetAdapterHardwareInfo"							-ft # W8/WS2012, W8.1/WS2012R2	# ft	
	runPS "Get-NetAdapterIPsecOffload"							-ft # W8/WS2012, W8.1/WS2012R2	# ft	
	runPS "Get-NetAdapterLso"									-ft # W8/WS2012, W8.1/WS2012R2	# ft	
	runPS "Get-NetAdapterPowerManagement"							# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Get-NetAdapterQos"										# W8/WS2012, W8.1/WS2012R2	# unknown
	runPS "Get-NetAdapterRdma"										# W8/WS2012, W8.1/WS2012R2	# unknown
	runPS "Get-NetAdapterRsc"									-ft # W8/WS2012, W8.1/WS2012R2	# ft
	runPS "Get-NetAdapterRss"										# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Get-NetAdapterSriov"										# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Get-NetAdapterSriovVf"									# W8/WS2012, W8.1/WS2012R2	# unknown

	#_# Get-NetAdapterStatistics output hangs the report on some VPN/AoVpn scenarios, e.g. on 'Cisco AnyConnect Secure Mobility Client' or 4G
	#----------Check if Cisco AnyConnect is installed, run Get-NetAdapterStatistics only if not detected.
	#_# ToDo: check for Cellular                     Dell Wireless 5809e Gobi™ 4G LTE Mobile Broadband Card       
	$AnyConnectKey = "HKLM:\SYSTEM\CurrentControlSet\Services\vpnagent"
	if (-Not (Test-Path $AnyConnectKey)) 
	{
		if ($Global:noNetAdapters -ne $true) {
			write-host "... running Get-NetAdapterStatistics, hint: use .\Get-psSDP Net -noNetAdapters, if stuck here"
			runPS "Get-NetAdapterStatistics"							-ft # W8/WS2012, W8.1/WS2012R2	# ft

		}#_# end noNetAdapters
	}
	
	runPS "Get-NetAdapterVmq"									-ft # W8/WS2012, W8.1/WS2012R2	# ft
	runPS "Get-NetAdapterVmqQueue"								-ft # W8/WS2012, W8.1/WS2012R2	# ft
	runPS "Get-NetAdapterVPort"										# W8/WS2012, W8.1/WS2012R2	# unknown
	"`n`n`n`n`n"	| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Network Adapter Details For NON-HIDDEN Adapters (formatted list, non-hidden)"	| Out-File -FilePath $OutputFile -append
	"   1. Get-NetAdapter | fl *"	| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Number of Network Adapters (output from get-netadapter; does not include hidden adapters): " + $networkAdaptersLen	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	runPS "Get-NetAdapter | fl *"				# W8/WS2012, W8.1/WS2012R2	# fl
	"`n`n`n`n`n"	| Out-File -FilePath $OutputFile -append
	
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Network Adapter Details For HIDDEN Adapters (formatted list, ONLY hidden)"	| Out-File -FilePath $OutputFile -append
	"   1. Get-NetAdapter -IncludeHidden (parsed to show hidden only)"	| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Number of Hidden Network Adapters: " + $hiddenNetworkAdaptersLen	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	foreach ($adapter in $networkAdaptersWithHidden)
	{
		if ($adapter.Hidden -eq $true)
		{
			"-------------------------------"	| Out-File -FilePath $OutputFile -append
			$adapter | fl * 	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
		}
	}
	"`n`n`n`n`n"	| Out-File -FilePath $OutputFile -append

}
else
{
	"The Windows OS version is W2008.R2 or earlier. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}


"===================================================="			| Out-File -FilePath $OutputFile -append
"Network Adapter to GUID Mappings"								| Out-File -FilePath $OutputFile -append
"  Using regkey HKLM:\SYSTEM\CurrentControlSet\Control\Network"	| Out-File -FilePath $OutputFile -append
"===================================================="			| Out-File -FilePath $OutputFile -append
if ($bn -ge 6000)
{
	$networkRegKeyPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Network"
	if (test-path $networkRegKeyPath) 
	{
		#$networkNameToGUIDObj = new-object PSObject

		$networkRegKey = Get-ItemProperty -Path $networkRegKeyPath
		$networkGUIDRegKey = Get-ChildItem -Path $networkRegKeyPath

		foreach ($netChildGUID in $networkGUIDRegKey)
		{
			$netChildGUIDName = $netChildGUID.PSChildName
			if ( ($netChildGUIDName.StartsWith("`{4D36E972")) -or ($netChildGUIDName.StartsWith("`{4d36E972")) )
			{
				# "Network Subkey GUID: $netChildGUIDName"
				$netChildGUIDRegKeyPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Network\$netChildGUIDName"
				$netConnectionGUIDs = Get-ChildItem -Path $netChildGUIDRegKeyPath
				foreach ($netConnectionGUID in $netConnectionGUIDs)
				{
					$netConnectionGUIDName = $netConnectionGUID.PSChildName
					if ($netConnectionGUIDName.StartsWith("`{"))
					{
						$netConnectionNameRegkey = "HKLM:\SYSTEM\CurrentControlSet\Control\Network\$netChildGUIDName\$netConnectionGUIDName\Connection"
						if (test-path $netConnectionNameRegkey)
						{
							$netConnectionName = (Get-ItemProperty -Path $netConnectionNameRegkey).Name
							" Connection Name    : " + $netConnectionName	| Out-File -FilePath $OutputFile -append
							" Connection GUID    : " + $netConnectionGUIDName	| Out-File -FilePath $OutputFile -append
							"`n" | Out-File -FilePath $OutputFile -append
						}
					}
				}
			}
		}
	}
}
else
{
	"The Windows OS version is W2003 or earlier. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}
"`n`n`n`n`n"	| Out-File -FilePath $OutputFile -append

CollectFiles -filesToCollect $OutputFile -fileDescription "Network Adapter Information" -SectionDescription $sectionDescription



#----------Registry
$OutputFile= $Computername + "_NetworkAdapters_reg_output.TXT"
$CurrentVersionKeys =   "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002BE10318}",
						"HKLM\SYSTEM\CurrentControlSet\Control\Network"
RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "Network Adapter registry information" -SectionDescription $sectionDescription



