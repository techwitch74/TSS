﻿#************************************************
# DC_SummaryReliability.ps1
# Version 0.1
# Date: 3/19/2012
# By Craig Landis (clandis@microsoft.com)
#************************************************
# 2019-03-17 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}


Import-LocalizedData -BindingVariable SummaryReliabilityStrings -FileName DC_SummaryReliability -UICulture en-us
			
Write-DiagProgress -Activity $SummaryReliabilityStrings.ID_SummaryReliability -Status $SummaryReliabilityStrings.ID_SummaryReliabilityObtaining

$sectionDescription = "Summary - Reliability"

$OutputFile = ($ComputerName + "__SUMMARY_*.txt")

$Diag_ID = Get-DiagID

if ($Diag_ID -eq "DIAG_CTSWindowsSetup")
{
	$CommandToExecute = "cscript.exe SummaryReliability.vbs /sdp /SetupSDPManifest"
}
else
{
	$CommandToExecute = "cscript.exe SummaryReliability.vbs /sdp"
}

RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription "Summary"

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
