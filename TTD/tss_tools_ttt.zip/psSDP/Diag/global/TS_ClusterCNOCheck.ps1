﻿#************************************************
# Rule ID 29 from http://sharepoint/sites/diag/Rules/_layouts/listform.aspx?PageType=4&ListId=%7b1F944AAF-10B3-4442-8AA8-4A1EF2B0F5F8%7d&ID=29&ContentTypeID=0x0100969570CC59987E4BADAD7118A311DB4D
#************************************************
# TS_ClusterCNOCheck.ps1
# 2019-03-17 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

	
Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_FailoverClusterCNO -Status $ScriptVariable.ID_FailoverClusterCNODesc
$RootCauseDetected = $false

# ***********
# Script Logic
# ***********

#Check if machine is a Failover Cluster Node, and if so, we determine the Cluster Name Object (CNO) computer object name
#

$RootCauseName = "RC_ClusterCNOCheck"

if (($OSVersion.Build -gt 6000) -and (Test-Path "HKLM:\Cluster"))
{
	"Cluster Detected" | WriteTo-StdOut -ShortFormat
	$CNODisabled = $false
	$CNODoesNotExist = $false

	$ACCOUNTDISABLE = 2 #http://support.microsoft.com/kb/305144

	$CNO = (Get-ItemProperty "HKLM:\Cluster").ClusterName
	#
	# If the machine is a node in a Failover Cluster, we check to see if the CNO is present in AD
	#
	
	"CNO: $CNO" | WriteTo-StdOut -ShortFormat

	If ($CNO -ne $Null)
	{ 

		$Return_Object = new-object PSObject

		#		
		# First run a query against the local computer name to make sure this machine can connect to a DC and run queries to look for computer objects
		#
		
		$LocalComputerName = $Env:COMPUTERNAME
		
		$LDAPQueryResults = Run-LDAPSearch -Filter "(&(objectCategory=computer)(name=$LocalComputerName))"
		
		if ($LDAPQueryResults -ne $null)
		{
			$LDAPQueryResults = Run-LDAPSearch -Filter "(&(objectCategory=computer)(name=$CNO))"
				
			#		
			# If the CNO is missing, we pop up these alert messages	
			#
			
			If ($LDAPQueryResults -ne $Null)
			{

				$UserAccountControl = $Results.Properties.Item("UserAccountControl")[0]
				
				"UserAccountControl current value: $UserAccountControl" | WriteTo-StdOut -ShortFormat
							
				If (($UserAccountControl -bor $ACCOUNTDISABLE) -eq $UserAccountControl)
				{
					$CNODisabled = $true
				}
			} 
			else 
			{
				$CNODoesNotExist = $true
			}
			
			"CNODoesNotExist: $CNODoesNotExist" | WriteTo-StdOut -ShortFormat
			"CNODisabled: $CNODisabled" | WriteTo-StdOut -ShortFormat

			if (($CNODoesNotExist) -or ($CNODisabled))
			{
				$RootCauseDetected = $true
				
				add-member -inputobject $Return_Object -membertype noteproperty -name "Cluster Name Object" -value $CNO
				add-member -inputobject $Return_Object -membertype noteproperty -name "Exist in Active Directory" -value (-not $CNODoesNotExist)
				add-member -inputobject $Return_Object -membertype noteproperty -name "Computer Account Disabled" -value $CNODisabled
			}
			else
			{
				Update-DiagRootCause -id $RootCauseName -Detected $false
			}
		}
		else 
		{
			"ERROR: Domain Controller could not be contacted"  | WriteTo-StdOut -ShortFormat
		}

	}

	# *********************
	# Root Cause processing
	# *********************

	if ($RootCauseDetected)
	{

		Update-DiagRootCause -id $RootCauseName -Detected $true
		Write-GenericMessage -RootCauseId $RootCauseName -PublicContentURL "http://support.microsoft.com/kb/950805" -Verbosity "Error" -InformationCollected $Return_Object -Visibility 4 -Component "FailoverCluster" -SupportTopicsID 8008 -MessageVersion 2
	}
	else
	{
		Update-DiagRootCause -id $RootCauseName -Detected $false
	}
}
