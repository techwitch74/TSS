﻿#************************************************
# DC_NetworkingDiagnostic.ps1
# Version 1.0.2006: The Networking Diagnostic was created in 2006 with SDPv1 and SDPv2.
# Version 1.1.2009: The Networking Diagnostic was moved to SDP3.
# Version 1.2.2009-2014: Many updates to all the static data collection scripts.
# Version 2.0.08.27.14: Republish 05.03.19.
# Date: 2006-2019
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Creates an output file showing the version of the Networking Diagnostic
# Called from: Networking Diagnostic, psSDP
#*******************************************************
# 2019-05-04 WalterE added to psSDP #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable

$sectionDescription = "Diagnostic Version"
$OutputFile= "DiagnosticVersion.TXT"
"`n"										| Out-File -FilePath $OutputFile -append
"Diagnostic  : psSDP Diagnostic v2019.05.04"			| Out-File -FilePath $OutputFile -append
"Publish Date: 04.May.2019"					| Out-File -FilePath $OutputFile -append
"`n"										| Out-File -FilePath $OutputFile -append
"`n"										| Out-File -FilePath $OutputFile -append
"`n"										| Out-File -FilePath $OutputFile -append
CollectFiles -filesToCollect $OutputFile -fileDescription "Diagnostic Version" -SectionDescription $sectionDescription	
