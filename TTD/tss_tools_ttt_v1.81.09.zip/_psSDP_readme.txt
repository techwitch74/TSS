README:
=======
To start SDP data collection, run in an elevated PowerShell CMD
 .\get-psSDP.ps1 [Net|Dom|CTS|Print|HyperV|Setup|Cluster|Mini|Nano]
 
 Example for collecting SDP Networking Diagnostic:
  .\get-psSDP.ps1 Net

 Example for SDP Basic data collection:
  .\get-psSDP.ps1 Mini
 
 Example for SDP Net without zipping results:
  .\get-psSDP.ps1 Net NoCab
   
If you encounter an error that running scripts is disabled, run 
  Set-ExecutionPolicy -ExecutionPolicy Bypass -force -Scope Process
and verify with 'Get-ExecutionPolicy -List' that no ExecutionPolicy with higher precedence is blocking execution of this script.
Then run ".\Get-psSDP.ps1 <speciality-of-SDP>" again.

Alternate method#1: run in elevated CMD "tss_PS1sign.cmd Get-psSDP"
Alternate method#2: if scripts are blocked by Policy, run in elevated Powershell: 
  Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value ByPass

Action: 
-------
Send us the resulting file psSDP_<tec>_%computername%_<date>.zip


Powershell ExecutionPolicy
--------------------------
.	Make sure script execution is allowed in PowerShell
a.	Run: 

  Get-ExecutionPolicy 
  or
  Get-ExecutionPolicy -List

b.	If the policy comes back AllSigned, Default, or Restricted then scripting needs to be enabled.
c.	Save the above output to restore the policy when troubleshooting is complete
d.	Run: 

  Set-ExecutionPolicy -ExecutionPolicy Unrestricted

More Help
---------
run the command below to get more help
  get-help .\get-psSDP.ps1 -detailed