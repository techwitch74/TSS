<# Name: tss_stop_condition_script.ps1 [-Folderpath -TestCondition -PollIntervalInSec] [-BranchCache or -BC] [-PortLoc] [-PortDest] [-SvcName] [-ServerName] [-ShareName] [-FilePath] [-ProcessName] [-DomainName] [-WaitTimeInSec] [-reg_keyLoc] [-reg_keyName] [-reg_ExpectedValue] 
Purpose: use this PowerShell script in combination with 'TSS Stop:ps1' as a stop trigger for data collection
Examples:
1.  until the system stops listening on local TCP 0.0.0.0:135

:: Purpose:  script to process individual stop condition and then end the 'tss ... ' repro section
::
:: Script input parameters: 
:: 	%1 _Folderpath		- path for output data
:: 	%2 _TestCond		- Name of predefined or custom Test condition, Examples below (BranchCache|BC|Dfs|FileExist|HTTP|PortDest|PortLoc|Process|RDP|Reg|Smb|Svc|WINRM|custom)
:: 	%3 _PollInterval 	- Interval in seconds to check, default is 8 seconds
:: 	%4 _StopFileExists	- Filename for termination condition

#>


<# 
.SYNOPSIS
	Script to process individual stop condition and then end the 'tss .. Stop:ps1:... ' repro section, if a failure happens

.DESCRIPTION
	Script will process individual stop condition, choose from BranchCache|BC|Dfs|FileExist|HTTP|LDAP|PortDest|PortLoc|Process|RDP|Reg|Smb|Svc|WINRM|Share|custom
	i.e. 'FileExist' will stop if a file with specification <_FilePath> exists on \\ServerName\ShareName\<_FilePath>
	'Reg' requires additional Registry key definition ($reg_keyLoc and $reg_keyName) within this script param section
	Prior to checking the Reg-test-condition it will the run extra repro steps if script tss_custom_repro_steps.ps1 exists in currrent folder

.PARAMETER Folderpath
	Specify a path for output data, i.e. C:\MS_DATA
	
.PARAMETER TestCondition
	Name of predefined or custom Test condition, Specify one of the predefined test Examples (BranchCache|BC|Dfs|FileExist|HTTP|LDAP|PortDest|PortLoc|Process|RDP|Smb|Svc|WINRM|Share|custom)
	
.PARAMETER PollIntervalInSec
	Specify an interval in seconds for test-condition checks, default is 8 seconds
	
.PARAMETER BranchCache or BC
	Specify a threshold to watch for, BCpercent=120 or BCpercent=180, to be configured in \config\tss_stop_condition_script.ps1
.PARAMETER FilePath

.PARAMETER PortLoc
	Specify a local TCP port number to watch for, if local port is still listening
.PARAMETER PortDest
	Specify a Destination TCP port number to watch for,	if remote system is still listening
.PARAMETER SvcName
	Verify if the service with serviceName is running
.PARAMETER ServerName
	Server Name to be tested, default LocalHost
.PARAMETER ShareName
	SMB Share Name to be tested
.PARAMETER ProcessName
	Process Name to be tested. Verify if the Process is running
.PARAMETER DomainName
	Domain Name to be tested. Verify if 'nltest /DSGETDC:$DomainName' returns result
.PARAMETER WaitTimeInSec
	Force a wait time in seconds after a stop condition is met, this will instruct tss to stop x seconds later.

.PARAMETER reg_keyLoc
	Define the registry path here
.PARAMETER reg_keyName
	Define the key name here
.PARAMETER reg_ExpectedValue
	Define the expected reg key lenght value here

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "BranchCache" -PollInterval 5
	Example 1: will stop if MaxCacheSizeAsNumberOfBytes exceeds 120% or 180%, or NrOfDatFilesLimit exceeds limit; checks performed in intervals of PollIntervalInSec
	
.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "PortLoc" -PollInterval 8
	Example 1: will stop if local system is no more listening on TCP port 0.0.0.0:135, checks performed in intervals of 8 seconds, default PortLoc=135

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "PortDest" -PollInterval 8 -ServerName "ServerName"
	Example 2: will stop if remote system "ServerName" is no more listening on TCP ports 135 and 445, checks performed in intervals of 8 seconds, default PortDest=135,445

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "SMB" -ServerName "ServerName"
	Example 3: will stop if server is no more listening on TCP port 445, or not pingable
	Same tests are available for HTTP,RDP,WINRM
	
.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Svc" -SvcName "LanmanServer"
	Example 4: will stop if the specified service is not running, default servcie name is LanmanWorkstation

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Share" -ServerName "ServerName" -ShareName "Contoso-Share"
	Example 5: will stop if the specified ShareName on ServerName is not reachable , default ServerName:LocalHost, ShareName:Contoso-Share

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Process" -ProcessName "notepad"
	Example 6: will stop if the specified ProcessName has stopped

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "LDAP" -DomainName "$env:userdomain"
	Example 7: will stop if  'nltest /DSGETDC:$DomainName' fails

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Reg"
	Example 8: will stop if a registry change condition is true, plz specify your condition in fuction Test_Reg

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "FileExist" -PollInterval 3 -ServerName "ServerName" -ShareName "Contoso-Share" -FilePath "*.tmp*"
	Example 9: will stop if a file with name <_FilePath> exists on \\ServerName\ShareName
	

.LINK
	email waltere
	
#>


param(
	[string]$Folderpath = (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[ValidateSet("BranchCache","BC","Dfs","FileExist","HTTP","LDAP","PortDest","PortLoc","Process","RDP","Reg","Svc","SMB","WINRM","Share","custom")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose from: BranchCache|BC|Dfs|FileExist|HTTP|LDAP|PortDest|PortLoc|Process|RDP|Reg|Smb|Svc|WINRM|Share|custom')]
	[string]$TestCondition = "custom"
	,
	[Int32]$PollIntervalInSec 	= 8,				# repeat stop-condition tests in intervals of x seconds
	[Int32]$ErrorLimit   		= 1,				# stop i fat least x errors happend
	[Int32]$PortLoc 	 		= 135,				# choose a local TCP port number
	[Int32]$BCpercent 	 		= 120,				# for test if Branchcache size breached 120%
	[Int32]$NrOfDatFilesLimit 	= 1024,				# number of maximum Branchcache PeerDistRepub files per folder
	[string]$PortDest,								# choose a remote TCP port number
	[string]$DomainName	 = "$env:userdomain",		# for LDAP test
	[string]$Reg,									# choose a 
	[string]$FilePath 	 = "*.*tmp*",				# choose a FilePath on \\Servername\Sharename
	[string]$SvcName 	 = "LanmanWorkstation",		# choose a service name
	[string]$ServerName  = "LocalHost",				# for SMB test
	[string]$ShareName   = "Contoso-Share",			# for SMB test
	[string]$ProcessName = "notepad",				# choose a process name without '.exe'
	[Int32]$WaitTimeInSec = 0,						# this specifies the forced wait time after stop condition is met
	[string]$reg_keyLoc	  = 'HKLM:\Software\Microsoft\dot3svc\Interfaces\{949B9E32-B3F7-4E65-9A95-7F483A6CDEB8}',	#_# Define the registry path here
	[string]$reg_keyName  = 'Parameters',																			#_# Define the key name here
	[Int32]$reg_ExpectedValue	= 1190																				#_# Define the expected reg key lenght value here
	
)

$VerDate = "2021.02.18.1"

#region  ::::: Configuration parameters ::::::::::::::::::::::::::::::::::::::::::::::
	[Int32]$TST_ERR_LIMIT 	= $ErrorLimit
	#[Int32[]]$PortDest	= $(135,445)
	if ($PortDest) { $Port_Dest	= $($PortDest.split("/")) }

#endregion ::::: Configruation parameters ::::::::::::::::::::::::::::::::::::::::::::::

$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent

#region  ::::: Functions :::::

# :::::::::: Begin of your own/custom condition logic ::::::::::::::::::::::::::::::::::::::::::::::
function Test_custom {
	Write-Log "What is expected/not expected by now?"
	# Example for SMB:
	$TcpTestStatus = ((Test-NetConnection -ComputerName $ServerName -CommonTCPPort SMB -ErrorAction SilentlyContinue).TcpTestSucceeded)
	if ("$TcpTestStatus" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName stopped listening on SMB port 445, result: $TcpTestStatus "}
}
# :::::::::: End of your own/custom condition logic   ::::::::::::::::::::::::::::::::::::::::::::::

function Test_FileExist {
	# Test if a $FilePath specifcation exists on \\$Servername\$Sharename
	$FileExistStatus = Get-ChildItem -filter $FilePath -path \\$Servername\$Sharename
	if ($FileExistStatus) {$Script:StopCondFound=0; Write-Log "File $FileExistStatus.name exists on \\$Servername\$Sharename"; $FileExistStatus | Out-File $LogFileScript -Append}
}

function Test_Reg {
	# 0. run extra repro steps if script tss_custom_repro_steps.ps1 exists in currrent folder
	if ( Test-Path ($ScriptParentPath + "\tss_custom_repro_steps.ps1")) {
		if ($TST_LOOP_CNT -eq 1) { Write-Host "[$TST_LOOP_CNT] $(Get-Date -format "yyMMdd_HHmmss") : invoking repro script $ScriptParentPath\tss_custom_repro_steps.ps1 in a loop every $PollIntervalInSec seconds."} else {Write-Host "[$TST_LOOP_CNT]" -NoNewline }
		& "$ScriptParentPath\tss_custom_repro_steps.ps1" -Folderpath $Script:Folderpath -Loop_Cnt $TST_LOOP_CNT}

	# 1. Test if the given registry path exists
	if (Test-Path $reg_keyLoc) {
		# 2. Test if the registry key exists with a value
		$reg_keyValue		= (Get-ItemProperty -Path $reg_keyLoc).$reg_keyName 
		if (-not ($reg_keyValue -eq $NULL)) {
			$Reg_keyLength	= $reg_keyValue.length
			# 3. Test if a registry key REG_BINARY length has changed from known/expected length
			if ($Reg_keyLength -ne $reg_ExpectedValue) {$Script:StopCondFound=0; Write-Log "[ERROR] $reg_keyName value length $Reg_keyLength is different than $reg_ExpectedValue bytes"}
		} else { $Script:StopCondFound=0; Write-Log "[ERROR] Key $reg_keyLoc\$reg_keyName does not exist"}
	} else { $Script:StopCondFound=0; Write-Log "[ERROR] Path $reg_keyLoc does not exist"}
}

function Test_AskYN {
	Write-Log "work in progress, waiting for user answer Y/N "
	# loop until the user enters N or E
	do
	{
		Start-Sleep $PollIntervalInSec
		$UserInput = Read-Host 'Do you want to continue [Y|N] or E= end'
		if ($UserInput -match 'n') {Write-Log " ...ending loop per User Input: $UserInput "
									break}
	} until ($UserInput -match 'E')
}

function Test_BCpercent {
	# if MaxCacheSizeAsNumberOfBytes reaches 120% or 180% , checks performed in intervals of 5 minutes
	$BCTestStatus =	& "$ScriptParentPath\tss_BCpercentRule.ps1" -Folderpath $Folderpath -BCpercentNr $BCpercent -NrOfDatFilesLimit $NrOfDatFilesLimit #-EA SilentlyContinue
	if ("$BCTestStatus" -eq "False" ) {$Script:StopCondFound=0; Write-Log "Branch Cache test breached limit $BCpercent % or *.dat $NrOfDatFilesLimit, BCTestStatus result: $BCTestStatus "}
	else { Write-Verbose "$(Get-date -Format G) | Result BCpercentRule: $BCTestStatus -- Script:StopCondFound $Script:StopCondFound -- CurrentActiveCacheSize: $((Get-BCDataCache).CurrentActiveCacheSize)" }
} 
function Test_PortLoc {
	# check if system stops listening on local TCP 0.0.0.0:135
	$Script:StopCondFound = Get-NetTCPConnection -State Listen -LocalPort $PortLoc -LocalAddress 0.0.0.0 -EA SilentlyContinue
} 
function Test_PortDest ($Port, $ServerName) {
	# check if remote system stops listening on TCP port 135
	$TcpTestStatus = Test-Netconnection -ComputerName $ServerName -Port $Port -InformationLevel "Detailed" -EA SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "Test-Netconnection $ServerName failed with result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 

function Test_Share {
	# check if \\server\Share is reachable via SMB ; ToDo: note Test-NetConnection requires PS version ??
	$TestStatus = Test-Path \\$ServerName\$ShareName -ErrorAction SilentlyContinue
	if ("$TestStatus" -eq "False" ) {$Script:StopCondFound=0; Write-Log "\\$ServerName\$ShareName not reachable, result: "; $TestStatus | Out-File $LogFileScript -Append}
} 

function Test_SMB {
	# check if server is reachable via SMB port 445; ToDo: note Test-NetConnection requires PS version ??
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort SMB -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName stopped listening on SMB port 445, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 
function Test_HTTP {
	# check if server is reachable via HTTP
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort HTTP -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName is not reachable via HTTP, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
}
function Test_LDAP {
	# check for failing 'nltest /DSGETDC:$DomainName'
	$TestStatus = nltest /DSGETDC:$DomainName /LDAPONLY
	if ($LASTEXITCODE -ne 0 ) {$Script:StopCondFound=0; Write-Log "DC in Domain $DomainName is not reachable via /LDAPONLY, result: $TestStatus - LASTEXITCODE: $LASTEXITCODE "; "$($TestStatus)" | Out-File $LogFileScript -Append}
}
function Test_RDP {
	# check if server is reachable via RDP
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort RDP -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName is not reachable via RDP, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 
function Test_WINRM {
	# check if server is reachable via WINRM
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort WINRM -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName is not reachable via WINRM, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 
function Test_Svc {
	# check if service status is Running  (not Stopped)
	$SvcStatus = ((Get-Service $SvcName -ErrorAction SilentlyContinue).Status)
	Write-Verbose "SvcStatus $SvcName :	$SvcStatus - Found: $($SvcStatus -eq "Running")"
	$Status = ((Get-Service $SvcName -ErrorAction SilentlyContinue).Status)
	if ($Status -ne "Running" ) {$Script:StopCondFound=0; Write-Log "$SvcName stopped running: $Status "}
} 
function Test_Process {
	# check if Process is running 
	$Script:StopCondFound = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue
}

#region  ::::: Helper Functions :::::
function Get-TimeStamp {
	# SYNOPSIS: Returns a timestamp string
	return "$(Get-Date -Format "yyyyMMdd_HHmmss_ffff")"
} # end Get-TimeStamp
function Write-Log {
	# SYNOPSIS: Writes script information to a log file and to the screen when -Verbose is set.
	[CmdletBinding()]param([string]$text, [Switch]$tee = $false, [string]$foreColor = $null, [string]$backColor = "DarkBlue")
	$foreColors = $backColors = "Black","Blue","Cyan","DarkBlue","DarkCyan","DarkGray","DarkGreen","DarkMagenta","DarkRed","DarkYellow","Gray","Green","Magenta","Red","White","Yellow"
	# check the log file, create if missing
	$isPath = Test-Path $LogFileScript
	if (!$isPath) {
		"TSS_stop_condition_script.ps1 v$VerDate Log started on $ENV:ComputerName - $Script:osVer - $Script:osNameLong " 	| Out-File $LogFileScript -Force
		"Local log file path: $LogFileScript" 														| Out-File $LogFileScript -Append
		"PowerShell version:  $Script:PSver " 														| Out-File $LogFileScript -Append
		"Start time (UTC):    $((Get-Date).ToUniversalTime())" 										| Out-File $LogFileScript -Append
		"Start time (Local):  $((Get-Date).ToLocalTime()) $(if ((Get-Date).IsDaylightSavingTime()) {([System.TimeZone]::CurrentTimeZone).DaylightName} else {([System.TimeZone]::CurrentTimeZone).StandardName})`n" | Out-File $LogFileScript -Append
	Write-Verbose "$(Get-Date -Format "HH:mm:ss") Local log file path: $LogFileScript"
  }
  # write to log
  "$(Get-date -Format G) | $text" | Out-File $LogFileScript -Append
  # write text verbosely
  Write-Verbose $text
  if ($tee)
  {
    # make sure the foreground color is valid
    if ($foreColors -contains $foreColor -and $foreColor)
    {
      Write-Host -ForegroundColor $foreColor -BackgroundColor $backColor $text
    } else {
      Write-Host $text
    }
  }
} # end Write-Log
#endregion  ::::: Helper Functions :::::
#endregion  ::::: Functions :::::

#region ::::: CONSTANTS AND VARIABLES :::::
#region  ::::: Variables :::::
[string]$LogFileScript=$Folderpath +"\"+ $ENV:ComputerName + "__Stop-Cond-Log_" + $TestCondition + ".txt"
Write-Verbose "LogFileScript: $LogFileScript"
[Int32]$TST_LOOP_CNT=0
[Int32]$TST_ERROR_CNT=0
#endregion  ::::: Variables :::::

# OS version
#[void]( $Script:OSinfo = (Get-CimInstance Win32_OperatingSystem) )
$Script:osVer = (Get-WmiObject win32_operatingsystem).Version
$Script:osNameLong = $Script:osName = (Get-WmiObject win32_operatingsystem).Name
$Script:osMajVer = [System.Environment]::OSVersion.Version.Major
$Script:osMinVer = [System.Environment]::OSVersion.Version.Minor
$Script:osBldVer = [System.Environment]::OSVersion.Version.Build
$Script:PSver = $PSVersionTable.PSVersion.Major

# OS version name
if ($Script:osMajVer -le 5) {
  [string]$Script:osName = "Unsupported"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 0) {
  [string]$Script:osName = "2008"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 1) {
  [string]$Script:osName = "2008R2"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 2) {
  [string]$Script:osName = "2012"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 3) {
  [string]$Script:osName = "2012R2"
 } elseif ($Script:osMajVer -eq 10) {
  [string]$Script:osName = "10"
 }
#endregion ::::: CONSTANTS AND VARIABLES :::::

#region :::::  Main 
Write-Log -tee -foreColor Green "...v$VerDate - running verification for Test Condition: $TestCondition, check interval: $PollIntervalInSec seconds."

# loop iteration until $TST_ERR_LIMIT is reached
do {
	# loop until stop condition is met
	$Script:StopCondFound=1
	do
	{
		if ($TST_LOOP_CNT -ge 1 ) {Start-Sleep $PollIntervalInSec}
		$TST_LOOP_CNT +=1
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		Write-Verbose "LoopCnt: $TST_LOOP_CNT"
		switch($TestCondition)
			{
			"custom"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: custom test condition"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_custom }
			"Share"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-Path \\$ServerName\$ShareName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Share }
			"BranchCache" { if ($TST_LOOP_CNT -le 1) { Unblock-File -Path tss_BCpercentRule.ps1 -EA SilentlyContinue; Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test tss_BCpercentRule.ps1 Branchcache $BCpercent % breach"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_BCpercent }
			"BC"		{ if ($TST_LOOP_CNT -le 1) { Unblock-File -Path tss_BCpercentRule.ps1 -EA SilentlyContinue; Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test tss_BCpercentRule.ps1 Branchcache $BCpercent % breach"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_BCpercent }
			"Dfs"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: tbd"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_AskYN }
			"FileExist"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: File-Exists condition: \\$Servername\$Sharename\$FilePath"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_FileExist }
			"LDAP"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: nltest /DSGETDC:$DomainName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_LDAP }
			"PortDest"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-Netconnection -ComputerName $ServerName -Port $Port_Dest"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							foreach ($Port in $Port_Dest) {Test_PortDest $Port $ServerName} }
			"PortLoc"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Get-NetTCPConnection -State Listen -LocalPort $Port -LocalAddress 0.0.0.0"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_PortLoc }
			"Process"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Get-Process -Name $ProcessName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Process }
			"Reg"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Registry Change condition Key: $reg_keyName under $reg_keyLoc "} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Reg }
			"Svc"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Get-Service $SvcName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Svc }
			"Smb"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort SMB"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_SMB }
			"HTTP"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort HTTP"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_HTTP }
			"RDP"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort RDP"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_RDP }
			"WINRM"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort WINRM"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_WINRM }
			}
	} until (-NOT $Script:StopCondFound)
	$TST_ERROR_CNT +=1
	Write-Log -tee -foreColor Gray "   Error count: $TST_ERROR_CNT, waiting until count reached limit of: $TST_ERR_LIMIT"
} until ($TST_ERROR_CNT -ge $TST_ERR_LIMIT)

Write-Log -tee -foreColor Red "...v$VerDate - Stop Condition $TestCondition met at: $(Get-Date)"

# additional wait time $WaitTimeInSec after condition is met
if ($WaitTimeInSec -gt 0) { Write-Log -tee "now waiting $WaitTimeInSec seconds..."; Start-Sleep $WaitTimeInSec }
#endregion :::::  Main 



# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAouNi2Z2KxB7Kz
# ugIYBJaKiyZPRURZo/PSSPIU/9JmyqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgx4mRC31d
# xgXvrNVx8WngFYlCaqb0/6h75AfHfImO2AswOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAIZOcrTLIw/QYP8XkuBqKXWVyDOJzNVpludtGPJ1QL7bK/B6FsvXV5uU
# K1Fju6vuNawlPgPKovWN1j61tlk5OWjyGozsXw0F2xkdLbnmJxOXfSZqRU7wDZPb
# 75+TostvRgknrveWpD8j18Xk/sFi2fP0hlC3SmMkpIDYdxPvCrDVcqeaExsftmXH
# KYeKhj37/VPRvSkOs/iK8xpZHdXM3r0XlpexQeKAmNZU9Fg3iaV0Ttdl7JnD6CJa
# Zy0sv2v/+oCa6jIeoIg5yMiTG5UW2tXiYhS7D2/TzN6rplO6R4Z1jxraMjmg8SbV
# 5FlOHfM5F7Anu1aB8In7/TI5bkTGw6ShghL7MIIS9wYKKwYBBAGCNwMDATGCEucw
# ghLjBgkqhkiG9w0BBwKgghLUMIIS0AIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgmrVx9u2/LKtDM3qzgDoFrBQKcloVz1++4IB15mHFaHkCBmDdlevK
# chgTMjAyMTA3MjcwNTQ2MjQuNDcyWjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDkowggT5MIID4aADAgECAhMzAAABPIv9ubM/R5f9AAAAAAE8MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyM1oXDTIyMDExMjE3MjgyM1owgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MTc5RS00
# QkIwLTgyNDYxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCYECrpaQOq9jkOBpC345fQ
# 0IvOpRqK8nEe+jopJc/5XNNqzanq5hrd9wib4RdvpuPj68n5Dm/XZu2vCqnWoxhy
# 3ixrbgS/rg3CS3bqp8Ag1UQg/xAz32TueeTOY1cOelcXRahosIcjlrrkv13AacFX
# m4AbYMCgYM6BzdZKARebc6zEv+4QCy4+1AV8RHQHEOdoj42OJpbFWlHvYKzXuM1A
# H4vmjT9o/fCq2mWD7Ig2/CpaId2gHK6R+S909iK27uVkjVap2/Sb4ATOLJbaVQ+X
# 0+hYbEcCesf93g+tAQXuvA8dH63doK5I5zdZCF5U/3Dibfl7ZCFsU6ks+ph4jJrb
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQU4aFn4soS+jazYT8lGOoYvyZnPEYwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAMvcQjJTdl3luSMzFqRkxRklJ+KWRUUlB
# 3I2KJVWb4Gn6eWdJTiWdC1uxejF2oPX0b+X9QIhi8u1AaV792eEit2lQzqVgPify
# TZGLjzK2Oou4Pj/F58Pp2m6HupGfuNAehln+hSvvIE5ggEnCiv9lVkAJOMlLHF38
# DbPv7pyWs0Lzv2sjZwPHvdhtV8lBtOYsE8Nxznlbsyc80vRnReqm8JQK6Z8xAD4S
# eY8duFFXhciETG2E0bh+/N3mwGnzXJzMbSKAKkzIw6Yxqf+zHzWPFim9DGZwmchq
# +6JBKtb4EGT0EFtfqGCrOPD5O7uPwSdj1apgXqo7Hctx7hcs5qjpwjCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtQwggI9AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAHUt0elneaPLba16Ke63RR3B65OaggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAOSpsdUwIhgPMjAyMTA3MjcwNjEyMzdaGA8yMDIxMDcyODA2MTIzN1owdDA6
# BgorBgEEAYRZCgQBMSwwKjAKAgUA5Kmx1QIBADAHAgEAAgILfjAHAgEAAgIRkzAK
# AgUA5KsDVQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAGOItBJLA6RuOz1M
# Qq/0h2pzMXgGt3/DftHg6hKK/jF89vJYZOrhvWSDNfUOqWTfCdP4VS0Vj9zzrCz0
# KDpbD5XVwCbdBv3HJQ7IZJjb9c9F476mZe1fgyhmTOqO2CqrN2nvTqGlckXlM1g9
# ywxaTvMTAcwkmujROW+51kVmHj/ZMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAE8i/25sz9Hl/0AAAAAATwwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgywjkj6BKWXmS34HbUjqz+LLgKNNCH3jj9wPm/RN6t1AwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCCgSQK6TSS/wOc6qbfUfBGv7YhsPfGYhbgVIYrh
# JuhaRjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# PIv9ubM/R5f9AAAAAAE8MCIEIIKhoW//A40vEm3wVEHPjJRpM53C4RqnY5fw3QfB
# 2uxFMA0GCSqGSIb3DQEBCwUABIIBACFn4hTnWw/L1vz3ps1fin0n5ruGSFmlN+iW
# l1+X2+Ai0+Ggverrk8iEqyVJYeOV6WSwj7E5bdxQz/Mo+hxaPURCw2Y7jKzckr9c
# jGvruyJ0A/AShd/1slzxpFJRIv84TnDcwX5/Oq53oGJ+anZxbiA3DC+cGxbr5m2/
# X9xXGTplq1hcs62meCURQmG94+n+qSaYJS4DD132sz1QYm4gY/TTj5RKlS0xZXpL
# fbT2S3eWdgASoY9UqGVP+O49NBfdqWopIhuV5z8ayJ4fHGCKk9VJM+k85KVZWrii
# 4T1e7mhk98lceGR/cv0p6GTl0E5aynqppEg/gfIE2hEGXF8wxSo=
# SIG # End signature block
