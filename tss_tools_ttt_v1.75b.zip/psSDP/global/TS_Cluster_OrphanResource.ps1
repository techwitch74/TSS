﻿#************************************************
# TS_Cluster_OrphanResource.ps1
# Version 1.0.1
# Date: 10/11/2012
# Author: v-alyao
# Description:  [Idea ID 5258] [Windows] Identifying Cluster Hive orphaned resources located in the dependencies key
# Description:  [Idea ID 5259] [Windows] Identifying Cluster Hive orphaned resources located in the cryto key
# Description:  [Idea ID 5257] [Windows] Identifying Cluster Hive orphaned resources left behind in the contains key
# Rule number:  5258
# Rule number:  5259
# Rule number:  5257
# Rule URL:  http://sharepoint/sites/rules/Rule Submissions/Forms/DispForm.aspx?ID=5258
# Rule URL:  http://sharepoint/sites/rules/Rule Submissions/Forms/DispForm.aspx?ID=5259
# Rule URL:  http://sharepoint/sites/rules/Rule Submissions/Forms/DispForm.aspx?ID=5257
#************************************************

Import-LocalizedData -BindingVariable ScriptStrings

trap [Exception] 
{
	WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[TS_Cluster_OrphanResource.ps1]" -InvokeInfo $MyInvocation
	continue
}
$RuleApplicable = $false
$MissingResourcesRootCauseDetected = $false
$MissingResourcesRootCauseName = "RC_Cluster_OrphanResource"

$MissingCryptoResourceRootCauseDetected = $false
$MissingCryptoResourceRootCauseName = "RC_Cluster_MissingCryptoResource"

$ExtraResourceRootCauseDetected = $false
$ExtraResourceRootCauseName = "RC_Cluster_MissingResource"

$Script:ClusterTempNode ="HKLM:\Cluster_Temp"

Function AppliesToSystem
{
	#Add your logic here to specify on which environments this rule will appy
    if((($OSVersion.Major -eq 6)-and ($OSVersion.Minor -eq 0)) -or   # Windows Server 2008,
     (($OSVersion.Major -eq 6)-and ($OSVersion.Minor -eq 1)))	# Windows 2008 R2
	{
		"[Info] [AppliesToSystem] Current system: Windows Server 2008(R2)"  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
	 	if(Test-Path -Path 'HKLM:\SYSTEM\CurrentControlSet\services\ClusSvc')
		{
			"[Info] [AppliesToSystem] Cluster service is installed."  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
			return $true
		}
		else
		{
			"[Error] [AppliesToSystem] This Rule is blocked. Cluster service is not installed."  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
			return $false
		}
	}
	else
	{
		"[Error] [AppliesToSystem] This rule is blocked. Only applies on Windows Server 2008 or Windows Server 2008 R2"  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
		return $false
	}
}

Function FindMissingResources()
{
	$result = $false
 	$Clresources=$ClusterTempNode + "\Resources"
    $Resources=get-childitem  $Clresources | ForEach-Object {Get-ItemProperty $_.PSPath}
    $ResourceGUIDs=@()
    $Resources | ForEach {$ResourceGUIDs+=$_.PSChildName}
    #
    # Making a list of all the dependencies
    #
    $ClDependencies=$ClusterTempNode + "\dependencies"
    $Dependencies=get-childitem  $ClDependencies | ForEach-Object {Get-ItemProperty $_.pspath}
    #
    # Making a table of all the cluster groups by GUID and friendly name.
    #
    $ClGroups=$ClusterTempNode + "\Groups"
    $CluGroups=get-childitem  $ClGroups | ForEach-Object {Get-ItemProperty $_.pspath}
    $CluGroups | ForEach{
        $once = $true
        $Name = $_.Name
        $PSChildName = $_.PSChildName
        $_.Contains | ForEach{
            if (-not ($ResourceGUIDs -contains $_ ))
            {
				$MissingResourcesInformationCollected = new-object PSObject
                if ($once) 
                {
					Add-member -InputObject $MissingResourcesInformationCollected -Membertype Noteproperty -Name "Group Name" -Value $Name
                    $once = $false
                    $result = $true
                } 
				Add-member -InputObject $MissingResourcesInformationCollected -Membertype Noteproperty -Name "Registry Value Name" -Value $_
                $Contain=$_
				$DependencyRegistryKey = @()
                $Dependencies| ForEach{
                    if ( $Contain -contains $_.dependent)
                    {
						$DependencyRegistryKey += $_.PSChildName
                        $result = $true
                    }
                }
				$DependencyRegistryKeyString=[string]::Join(", ",$DependencyRegistryKey)
				Add-member -InputObject $MissingResourcesInformationCollected -Membertype Noteproperty -Name "Dependency Registry Key" -Value $DependencyRegistryKeyString
            	[void](Add-GenericMessage -Id $MissingResourcesRootCauseName -InformationCollected $MissingResourcesInformationCollected)
			}
			
        }
    }
	return $result
}

Function FindMissingCryptoResource()
{
	$result = $false
	$Clresources=$ClusterTempNode + "\Resources"
    $Resources=get-childitem  $Clresources | ForEach-Object {Get-ItemProperty $_.PSPath}
    $ResourceGUIDs=@()
    $Resources | ForEach {$ResourceGUIDs+=$_.PSChildName}
	
    $CryptoGUIDs = @()
    $Cryptos = $ClusterTempNode + "\CheckPoints"
    $Crypto=get-childitem  $Cryptos 
    $CryptoSplits = $crypto -Split '\\'  

    for ($index = 3; $index -le $CryptoSplits.Length; $index+=4)
    {
        $CryptoGUIDs += $CryptoSplits[$index]
    }

    $index = 0  
    $CryptoGUIDs | foreach{
	    $CryptoResource = $CryptoGUIDs[$index]
	    $foundmatch = $false
	    $ResourceGUIDs | foreach{
	        if ($CryptoResource -eq $_)
	        { 
	           $foundmatch = $true
	        }
	    }
	    if (-not($foundmatch))
	    { 
			$MissingCryptoResourceInformationCollected = new-object PSObject
			Add-member -InputObject $MissingCryptoResourceInformationCollected -Membertype Noteproperty -Name "Crypto Resource" -Value $CryptoResource
	        [void](Add-GenericMessage -Id $MissingCryptoResourceRootCauseName -InformationCollected $MissingCryptoResourceInformationCollected)
			$result = $true
	    }
	    $index++
    }
	return $result
}

Function FounddExtraResource()
{
	$result = $false
    $ClGroups=$ClusterTempNode + "\Groups"
    $CluGroups=get-childitem  $ClGroups | ForEach-Object {Get-ItemProperty $_.pspath}
	
	$Clresources=$ClusterTempNode + "\Resources"
    $Resources=get-childitem  $Clresources | ForEach-Object {Get-ItemProperty $_.PSPath}
    $ResourceGUIDs=@()
    $Resources | ForEach {$ResourceGUIDs+=$_.PSChildName}
	
    $ResourceGUIDs | foreach{
       $Resource_Guid =  $_
       $foundmatch = $false
       $CluGroups | foreach{
          $_.Contains | foreach{
            if ($_ -eq $Resource_Guid) 
            {
               $foundmatch = $true
            }
          }
       }
       if (-not($foundmatch))
       {
	   	$ExtraResourceInformationCollected = new-object PSObject
		 Add-member -InputObject $ExtraResourceInformationCollected -Membertype Noteproperty -Name "Missing Resource Key" -Value $Resource_Guid
	     [void](Add-GenericMessage -Id $ExtraResourceRootCauseName -InformationCollected $ExtraResourceInformationCollected)
		 $result = $true
       }
    }
	return $result
}



Function SetTempClusterName()
{
	if(Test-Path -Path $Script:ClusterTempNode)
	{
		$Script:ClusterTempNode = $Script:ClusterTempNode + "_Temp"
		SetTempClusterName
	}
}

Function LoadTempCluster()
{
	SetTempClusterName
	"[Info] [LoadTempCluster] Get the Temp Cluster Name: $ClusterTempNode"  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
	$CollectedHivName = $Computername + "_reg_Cluster.hiv"
	$CollectedHivPath = [System.IO.Path]::GetFullPath($CollectedHivName)
	$PhysicalHivPath = Join-Path $Env:windir "Cluster\CLUSDB"
	if(-not (Test-Path -Path $CollectedHivPath))
	{
		"[Info] [LoadTempCluster] Cluster Hive did not be collected into package. Collect it."  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
		if(Test-Path -Path "HKLM:\Cluster")
		{
			"[Info] [LoadTempCluster] Collect the Cluster Hive from HKLM\Cluster."  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
			RegSave -RegistryKey "HKLM\Cluster" -OutputFile $CollectedHivName -fileDescription "Cluster Hive"
		}
		elseif(Test-Path -Path $PhysicalHivPath)
		{
			"[Info] [LoadTempCluster] Collect the Cluster Hive from windir\Cluster\CLUSDB."  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
			RunCmD -commandToRun "copy $PhysicalHivPath $CollectedHivPath" -CollectFiles $false
		}
		else
		{
			"[Error] [LoadTempCluster] HKLM\Cluster does not exist and %windir%\Cluster\CLUSDB could not be found. Aborting script." | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
			return $false
		}
	}
	if(Test-Path -Path $CollectedHivPath)
	{
		"[Info] [LoadTempCluster] Load the Cluster Hive into registry as $ClusterTempNode."  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
		$loadTempClusterCommand = "reg load $ClusterTempNode $CollectedHivPath"
		$loadTempClusterCommand = $loadTempClusterCommand.Replace('HKLM:\','HKLM\')
		RunCmD -commandToRun $loadTempClusterCommand -CollectFiles $false
	}
	else
	{
		"[Error] [LoadTempCluster] Copy temp Cluster hive failed. Aborting script" | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
		return $false
	}
	if(Test-Path -Path $ClusterTempNode)
	{
		return $true
	}
	else
	{
		"[Error] [LoadTempCluster] Load temp Cluster hive failed. Aborting script" | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
		return $false
	}
}


#Some time this operation is failed with an error(Access is denied), so try it for 3 times
Function UnloadTempCluster()
{
	"[Info] [UnloadTempCluster] Unload the temp cluster hive"  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
	$index = 0
	while(Test-Path -Path $ClusterTempNode)
	{
	    [gc]::collect()
		$index++
		$unloadTempClusterCommand = "reg unload $ClusterTempNode"
		$unloadTempClusterCommand = $unloadTempClusterCommand.Replace('HKLM:\','HKLM\')
		RunCmD -commandToRun $unloadTempClusterCommand -CollectFiles $false
		if (Test-Path -Path $ClusterTempNode)
		{
		  	if($index -ge 3)
			{
				#write std log
				"[Error] Can't unload the hive $ClusterTempNode" | WriteTo-StdOut -ShortFormat
				break
			}
			else
			{
				"[Warning] $ClusterTempNode could not be unloaded" | writeto-stdout
		 		sleep -Milliseconds 500
			}
		}
	}
}

#Check to see if rule is applicable to this computer
$RuleApplicable = AppliesToSystem

if($RuleApplicable)
{
	if(-not (LoadTempCluster))
	{
		return
	}
}

# *********************
# Root Cause "RC_Cluster_OrphanResource" processing
# *********************
Display-DefaultActivity -Rule -RuleNumber 5258
if ($RuleApplicable)
{
	"[Info] Root Cause RC_Cluster_OrphanResource processing"  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
	$MissingResourcesRootCauseDetected = FindMissingResources
	if ($MissingResourcesRootCauseDetected)
	{
		# Red/ Yellow Light
		Update-DiagRootCause -id $MissingResourcesRootCauseName -Detected $true
	}
	else
	{
		# Green Light
		Update-DiagRootCause -id $MissingResourcesRootCauseName -Detected $false
	}
}

# *********************
# Root Cause "RC_Cluster_MissingCryptoResource" processing
# *********************
Display-DefaultActivity -Rule -RuleNumber 5259
if ($RuleApplicable)
{
	"[Info] Root Cause RC_Cluster_MissingCryptoResource processing"  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
	$MissingCryptoResourceRootCauseDetected = FindMissingCryptoResource
	if ($MissingCryptoResourceRootCauseDetected)
	{
		# Red/ Yellow Light
		Update-DiagRootCause -id $MissingCryptoResourceRootCauseName -Detected $true
		
	}
	else
	{
		# Green Light
		Update-DiagRootCause -id $MissingCryptoResourceRootCauseName -Detected $false
	}
}	

 #*********************
 #Root Cause "RC_Cluster_MissingResource"  processing
 #*********************
Display-DefaultActivity -Rule -RuleNumber 5257
if ($RuleApplicable)
{
	"[Info] Root Cause RC_Cluster_MissingResource processing"  | WriteTo-StdOut -InvokeInfo $MyInvocation -ShortFormat
	$ExtraResourceRootCauseDetected = FounddExtraResource
	if ($ExtraResourceRootCauseDetected)
	{
		# Red/ Yellow Light
		Update-DiagRootCause -id $ExtraResourceRootCauseName -Detected $true
	}
	else
	{
		# Green Light
		Update-DiagRootCause -id $ExtraResourceRootCauseName -Detected $false
	}
}

if($RuleApplicable)
{
	UnloadTempCluster
}
# SIG # Begin signature block
# MIIdzQYJKoZIhvcNAQcCoIIdvjCCHboCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU8k0JBFJxbp1VFLGWBLiaqvq7
# edugghhkMIIEwzCCA6ugAwIBAgITMwAAAJqamxbCg9rVwgAAAAAAmjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwMzMwMTkyMTI5
# WhcNMTcwNjMwMTkyMTI5WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkIxQjctRjY3Ri1GRUMyMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApkZzIcoArX4o
# w+UTmzOJxzgIkiUmrRH8nxQVgnNiYyXy7kx7X5moPKzmIIBX5ocSdQ/eegetpDxH
# sNeFhKBOl13fmCi+AFExanGCE0d7+8l79hdJSSTOF7ZNeUeETWOP47QlDKScLir2
# qLZ1xxx48MYAqbSO30y5xwb9cCr4jtAhHoOBZQycQKKUriomKVqMSp5bYUycVJ6w
# POqSJ3BeTuMnYuLgNkqc9eH9Wzfez10Bywp1zPze29i0g1TLe4MphlEQI0fBK3HM
# r5bOXHzKmsVcAMGPasrUkqfYr+u+FZu0qB3Ea4R8WHSwNmSP0oIs+Ay5LApWeh/o
# CYepBt8c1QIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFCaaBu+RdPA6CKfbWxTt3QcK
# IC8JMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAIl6HAYUhsO/7lN8D/8YoxYAbFTD0plm82rFs1Mff9WBX1Hz
# /PouqK/RjREf2rdEo3ACEE2whPaeNVeTg94mrJvjzziyQ4gry+VXS9ZSa1xtMBEC
# 76lRlsHigr9nq5oQIIQUqfL86uiYglJ1fAPe3FEkrW6ZeyG6oSos9WPEATTX5aAM
# SdQK3W4BC7EvaXFT8Y8Rw+XbDQt9LJSGTWcXedgoeuWg7lS8N3LxmovUdzhgU6+D
# ZJwyXr5XLp2l5nvx6Xo0d5EedEyqx0vn3GrheVrJWiDRM5vl9+OjuXrudZhSj9WI
# 4qu3Kqx+ioEpG9FwqQ8Ps2alWrWOvVy891W8+RAwggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TCCBhAwggP4
# oAMCAQICEzMAAABkR4SUhttBGTgAAAAAAGQwDQYJKoZIhvcNAQELBQAwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMTAeFw0xNTEwMjgyMDMxNDZaFw0xNzAx
# MjgyMDMxNDZaMIGDMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24w
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCTLtrY5j6Y2RsPZF9NqFhN
# FDv3eoT8PBExOu+JwkotQaVIXd0Snu+rZig01X0qVXtMTYrywPGy01IVi7azCLiL
# UAvdf/tqCaDcZwTE8d+8dRggQL54LJlW3e71Lt0+QvlaHzCuARSKsIK1UaDibWX+
# 9xgKjTBtTTqnxfM2Le5fLKCSALEcTOLL9/8kJX/Xj8Ddl27Oshe2xxxEpyTKfoHm
# 5jG5FtldPtFo7r7NSNCGLK7cDiHBwIrD7huTWRP2xjuAchiIU/urvzA+oHe9Uoi/
# etjosJOtoRuM1H6mEFAQvuHIHGT6hy77xEdmFsCEezavX7qFRGwCDy3gsA4boj4l
# AgMBAAGjggF/MIIBezAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wIATAd
# BgNVHQ4EFgQUWFZxBPC9uzP1g2jM54BG91ev0iIwUQYDVR0RBEowSKRGMEQxDTAL
# BgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNjQyKzQ5ZThjM2YzLTIzNTktNDdmNi1h
# M2JlLTZjOGM0NzUxYzRiNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUC
# lTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# b3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUF
# BwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1Ud
# EwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjiDGRDHd1crow7hSS1nUDWvWas
# W1c12fToOsBFmRBN27SQ5Mt2UYEJ8LOTTfT1EuS9SCcUqm8t12uD1ManefzTJRtG
# ynYCiDKuUFT6A/mCAcWLs2MYSmPlsf4UOwzD0/KAuDwl6WCy8FW53DVKBS3rbmdj
# vDW+vCT5wN3nxO8DIlAUBbXMn7TJKAH2W7a/CDQ0p607Ivt3F7cqhEtrO1Rypehh
# bkKQj4y/ebwc56qWHJ8VNjE8HlhfJAk8pAliHzML1v3QlctPutozuZD3jKAO4WaV
# qJn5BJRHddW6l0SeCuZmBQHmNfXcz4+XZW/s88VTfGWjdSGPXC26k0LzV6mjEaEn
# S1G4t0RqMP90JnTEieJ6xFcIpILgcIvcEydLBVe0iiP9AXKYVjAPn6wBm69FKCQr
# IPWsMDsw9wQjaL8GHk4wCj0CmnixHQanTj2hKRc2G9GL9q7tAbo0kFNIFs0EYkbx
# Cn7lBOEqhBSTyaPS6CvjJZGwD0lNuapXDu72y4Hk4pgExQ3iEv/Ij5oVWwT8okie
# +fFLNcnVgeRrjkANgwoAyX58t0iqbefHqsg3RGSgMBu9MABcZ6FQKwih3Tj0DVPc
# gnJQle3c6xN3dZpuEgFcgJh/EyDXSdppZzJR4+Bbf5XA/Rcsq7g7X7xl4bJoNKLf
# cafOabJhpxfcFOowMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEw
# HhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBT
# aWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# q/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2Avw
# OMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eW
# WcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1
# eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le
# 2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+
# 0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2
# zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv
# 1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLn
# JN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31n
# gOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+Hgg
# WCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAG
# CSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZ
# BgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/
# BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8E
# UzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEB
# BFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcw
# gZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwIC
# MDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBu
# AHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOS
# mUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQ
# VdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQ
# dION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive
# /DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrC
# xq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/
# E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ
# 7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANah
# Rr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3
# S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1W
# Tk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1t
# bWrJUnMTDXpQzTGCBNMwggTPAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcg
# UENBIDIwMTECEzMAAABkR4SUhttBGTgAAAAAAGQwCQYFKw4DAhoFAKCB5zAZBgkq
# hkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGC
# NwIBFTAjBgkqhkiG9w0BCQQxFgQUIFJCTgDg9fWRMdq0vklQ/3d/SdkwgYYGCisG
# AQQBgjcCAQwxeDB2oFyAWgBDAFQAUwB3AGkAbgBkAG8AdwBzAHMAZQB0AHUAcABf
# AFQAUwBfAEMAbAB1AHMAdABlAHIAXwBPAHIAcABoAGEAbgBSAGUAcwBvAHUAcgBj
# AGUALgBwAHMAMaEWgBRodHRwOi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEF
# AASCAQCGyxli15UbTGy74dOaGEFw3ffjxysatDWdFN/e8J9Xdc15B1hHIWtEdOWV
# tQLjfgBo3YQD/F9aeK69e/8LWzzi+BXNOWh0/HrmQWhg7fHxtjJ+9U7HFsAzsG65
# YlyWsUAA0lQ9lgoBFWY767HVokAWdJzVV+75vHjn4gtdaJ1haQT02Hz7XXW/q7pC
# 5xnj1SXDBdZRwYrMcbjHr2m4DkohYmkwHTWy2bvJOx4KQ7DGm6HqZlWSXZbJ/gv8
# N3ckF68bfABDdjFnt77zRWJ3ZILN3KZk5HV4G+7uANZsYLT7viNEUhNqCQT9eu96
# nLcWtnQj6HJv7aHBjZk/2QsD6I2KoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIR
# AgEBMIGOMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQQITMwAAAJqamxbCg9rVwgAA
# AAAAmjAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkq
# hkiG9w0BCQUxDxcNMTYwNzI4MjAwODMzWjAjBgkqhkiG9w0BCQQxFgQUvWSTyqxI
# qJiEbwVPAnxQW9HYZIIwDQYJKoZIhvcNAQEFBQAEggEASA2j1yI+151jLI+CcTRh
# MTE8qhuogSJwaIyfInFcprfFZacuRgrBwNPQ48cOEOeYRazla3nsmLGzd7Gmtado
# +yzgJzO8gn3ettO7n7ekUFlXitrOvOt/J5n+N6c2xMzsHr4Rv20H0Bi8oSuR7SXZ
# eB5nDFqwkw2u8syht6Alep/xpeBw6mgeQA3i7YVHJN7A7cbIgYO4Wn57lHZ8+YGz
# L8DbXL19OKz2ScoS0RCYR2MzdCqTuytKjb5gJ8aajBCv/VeXnii2cjiCwL95G6cr
# 7uiRJ+fGznUJqkMtk0f8LtFem/Yp1D5YFD/l1LTX0rLuf+Ct8nVZdVGJSH1BNIRC
# +g==
# SIG # End signature block
