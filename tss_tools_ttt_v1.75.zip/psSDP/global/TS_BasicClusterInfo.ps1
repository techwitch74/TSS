﻿#************************************************
# DC_BasicClusterInfo.ps1
# Version 2.0.3
# Date: 03-28-2010
# Author: Andre Teixeira - andret@microsoft.com
# Description: This script writes to the report basic information regarding 
#              the cluster (Cluster Info, Nodes and Groups)
#************************************************

#Troubleshooter:

PARAM([switch] $IncludeCoreGroups)

$ClusterSvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\ClusSvc"

if (Test-Path $ClusterSvcKey)
{
	Import-LocalizedData -BindingVariable ClusterBasicInfo 
	Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status $ClusterBasicInfo.ID_ClusterInfoObtaining

	$StartupType = (get-itemproperty -Path $ClusterSvcKey -Name "Start").Start
	if (($StartupType -eq 2) -or ($StartupType -eq 3)) 
	{  # Auto or Manual
		if ($StartupType -eq 2) {$StartupTypeDisplay = "Auto"}
		if ($StartupType -eq 3) {$StartupTypeDisplay = "Manual"}
		$ClusterSvc = Get-Service -Name ClusSvc
		if ($ClusterSvc.Status.Value__ -ne 4) 
		{ #Cluster Service is not running
			Update-DiagRootCause -id "RC_ClusterSvcDown" -Detected $true 
			$InformationCollected = @{"Service State"=$ClusterSvc.Status; "Startup Type"=$StartupTypeDisplay}
			Write-GenericMessage -RootCauseID "RC_ClusterSvcDown" -Component "FailoverCluster" -InformationCollected $InformationCollected -Verbosity "Error" -PublicContentURL "http://blogs.technet.com/b/askcore/archive/2010/06/08/windows-server-2008-and-2008r2-failover-cluster-startup-switches.aspx" -SupportTopicsID 8001 -MessageVersion 2 -Visibility 4
		}
		else 
		{
			Update-DiagRootCause -Id "RC_ClusterSvcDown" -Detected $false
			$ClusterKey="HKLM:\Cluster"
			
			#   Win2K8 R2
			if ((Test-Path $ClusterKey) -and ($OSVersion.Build -gt 7600))
			{
				Import-Module FailoverClusters
				
				$Cluster = Get-Cluster
				
				$Cluster_Summary = new-object PSObject
				
				add-member -inputobject $Cluster_Summary -membertype noteproperty -name $ClusterBasicInfo.ID_ClusterName -value $cluster.Name
				add-member -inputobject $Cluster_Summary -membertype noteproperty -name $ClusterBasicInfo.ID_ClusterDomain -value $cluster.Domain
				add-member -inputobject $Cluster_Summary -membertype noteproperty -name $ClusterBasicInfo.ID_ClusterCSV -value $cluster.EnableSharedVolumes
				
				if ($cluster.EnableSharedVolumes -eq "Enabled") 
				{
					add-member -inputobject $Cluster_Summary -membertype noteproperty -name $ClusterBasicInfo.ID_ClusterCSVRoot -value $cluster.SharedVolumesRoot
				}
				
				$Cluster_Summary | convertto-xml | update-diagreport -id 02_ClusterSummary -name $ClusterBasicInfo.ID_ClusterInfo -verbosity informational

				$ClusterQuorum_Summary = new-object PSObject
				$ClusterQuorum = Get-ClusterQuorum

				add-member -inputobject $ClusterQuorum_Summary -membertype noteproperty -name "Quorum Type" -value $ClusterQuorum.QuorumType
				if ($ClusterQuorum.QuorumResource -ne $null) 
				{
					add-member -inputobject $ClusterQuorum_Summary -membertype noteproperty -name "Quorum Resource" -value $ClusterQuorum.QuorumResource.Name
					
						switch ($ClusterQuorum.QuorumResource.State.value__) {
							2 {$Color = "Green"} #ClusterResourceOnline 
							3 {$Color = "Black"} #ClusterResourceOffline
							4 {$Color = "Red"}   #ClusterResourceFailed
							default { $Color = "Orange" } #Other state
						}

						$State = "<font face=`"Webdings`" color=`"$Color`">n</font> " + $ClusterQuorum.QuorumResource.State
						$ResourceStateDisplay = $State + " - Owner: " + $ClusterQuorum.QuorumResource.OwnerNode
						
						add-member -inputobject $ClusterQuorum_Summary -membertype noteproperty -name "State" -value $ResourceStateDisplay
				}

				$ClusterQuorum_Summary | convertto-xml2 | update-diagreport -id 03_ClusterQuorumSummary -name "Quorum Information" -verbosity informational
				
				$ClusterNodes_Summary = new-object PSObject
				$ClusterNodesNotUp_Summary = new-object PSObject
				
				Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status "Cluster Nodes"
				
				$Error.Clear()
				
				$ClusterNodes = Get-ClusterNode
				
				if ($Error.Count -ne 0) 
				{
					$errorMessage = $Error[0].Exception.Message
					$errorCode = "0x{0:X}" -f $Error[0].Exception.ErrorCode
					$ServiceState = $ClusterSvc.Status
					Update-DiagRootCause -id "RC_ClusterInfoErr" -Detected 
					$InformationCollected = @{"Error Message"=$errorMessage; "Error Code"=$errorCode; "Service State" = $ServiceState}
					Write-GenericMessage -RootCauseID "RC_ClusterInfoErr" -InformationCollected $InformationCollected -Verbosity "Warning" -Component "FailoverCluster"  -SupportTopicsID 8001 -MessageVersion 2 -Visibility 3
				}
				
				if ($ClusterNodes -ne $Null) 
				{
					$ReportNodeNotUpNames=""
					foreach ($ClusterNode in $ClusterNodes) 
					{
						switch ($ClusterNode.State.value__) 
						{
							0 {$Color = "Green"} # Up
							1 {$Color = "Red"}   #Down
							default { $Color = "Orange" } 
						}

						$State = "<font face=`"Webdings`" color=`"$Color`">n</font> " + $ClusterNode.State
						$NodeName = $ClusterNode.NodeName
						if ($NodeName -eq "$ComputerName") {$NodeName += "*"}
						add-member -inputobject $ClusterNodes_Summary -membertype noteproperty -name $NodeName -value $State
						if ($ClusterNode.State.value__ -ne 0 ) 
						{ 
							if ($ReportNodeNotUpNames -ne "") 
							{
								$ReportNodeNotUpNames += ", "
							}
							$ReportNodeNotUpNames += $ClusterNode.NodeName + "/ " + $ClusterNode.State
							add-member -inputobject $ClusterNodesNotUp_Summary -membertype noteproperty -name $NodeName -value ($ClusterNode.State)
						}
					}
		
					if ($ReportNodeNotUpNames -ne "") 
					{
						$XMLFile = "..\ClusterNodesDown.XML"
						#$XMLObj = $ClusterNodesNotUp_Summary | ConvertTo-Xml2 
						#$XMLObj.Save($XMLFile)
						Update-DiagRootCause -id "RC_ClusterNodeDown" -Detected $true #-Parameter @{"NotUpNodesXML"=$XMLFile}
						#$InformationCollected = @{"Cluster Node(s)/ State"= $ReportNodeNotUpNames}
						Write-GenericMessage -RootCauseID "RC_ClusterNodeDown" -InformationCollected $ClusterNodesNotUp_Summary -SupportTopicsID 8001 -MessageVersion 2 -Visibility 3
					}
					else
					{
						Update-DiagRootCause -Id "RC_ClusterNodeDown" -Detected $false
					}
					
					$ClusterNodes_Summary | ConvertTo-Xml2 | update-diagreport -id 04_ClusterNodes -name "Cluster Nodes" -verbosity informational
					
					Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status "Cluster Groups"
					
					$ClusterGroups_Summary = new-object PSObject
					$ClusterGroupNotOnline_Summary = new-object PSObject
					
					if ($IncludeCoreGroups.IsPresent) {
						$ClusterGroups = Get-ClusterGroup
					} else {
						$ClusterGroups = Get-ClusterGroup | Where-Object {$_.IsCoreGroup -eq $false}
					}
					
					if ($ClusterGroups -ne $null)
					{
						$GroupNamesNotOnline = ""
						foreach ($ClusterGroup in $ClusterGroups) {
							switch ($ClusterGroup.State.value__) {
								0 {$Color = "Green"} #Online
								1 {$Color = "Black"}   #ClusterGroupOffline
								2 {$Color = "Red"} #ClusterGroupFailed
								3 {$Color = "Orange"} #ClusterGroupPartialOnline
								4 {$Color = "Yellow"} #ClusterGroupPending
								default { $Color = "Orange" } #Pending
							}

							$State = "<font face=`"Webdings`" color=`"$Color`">n</font> " + $ClusterGroup.State
							$GroupStateDisplay = $State + " - Owner: " + $ClusterGroup.OwnerNode
							if (($IncludeCoreGroups.IsPresent) -and ($ClusterGroup.IsCoreGroup)) {
								$ClusterGroupDisplay = $ClusterGroup.Name + " (Core Group)"
							} else {
								$ClusterGroupDisplay = $ClusterGroup.Name
							}
							add-member -inputobject $ClusterGroups_Summary -membertype noteproperty -name $ClusterGroupDisplay -value $GroupStateDisplay
							
							if (($ClusterGroup.State.value__ -eq 1) -or ($ClusterGroup.State.value__ -eq 2)) 
							{ 
								if ($GroupNamesNotOnline -ne "") 
								{
									$GroupNamesNotOnline += ", "
								}
								$GroupNamesNotOnline += $ClusterGroup.Name + "/ " + $ClusterGroup.State
								add-member -inputobject $ClusterGroupNotOnline_Summary -membertype noteproperty -name $ClusterGroup.Name -value $GroupStateDisplay 
							}
						}

						if ($GroupNamesNotOnline -ne "") 
						{
							$XMLFileName = "..\ClusterGroupsProblem.XML"
							#$XMLObj = $ClusterGroupNotOnline_Summary | ConvertTo-Xml2 
							#$XMLObj.Save($XMLFileName)
							Update-DiagRootCause -id "RC_ClusterGroupDown" -Detected $true #-Parameter @{"XMLFilename"=$XMLFileName}
							$InformationCollected = @{"Cluster Group(s)" = $ClusterGroupNotOnline_Summary}
							Write-GenericMessage -RootCauseID "RC_ClusterGroupDown" -InformationCollected $InformationCollected -Verbosity "Warning" -Component "FailoverCluster" -PublicContentURL "http://technet.microsoft.com/en-us/library/cc757139(WS.10).aspx"
						}
						else
						{
							Update-DiagRootCause -id "RC_ClusterGroupDown" -Detected $false
						}

						$ClusterGroups_Summary | ConvertTo-Xml2 | update-diagreport -id 05_ClusterGroup -name "Cluster Groups" -verbosity informational
						
						if ($clusterGroups.Length -le 50)
						{
							foreach ($ClusterGroup in $ClusterGroups) {
								$ClusterGroup_Summary = new-object PSObject
								$GroupName = $ClusterGroup.Name
								Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status "Cluster Group $GroupName - Querying resources"
								foreach ($ClusterResourceType in get-clusterResource | Where-Object {$_.OwnerGroup.Name -eq $ClusterGroup.Name} | Select-Object ResourceType -Unique) {
									$ResourceTypeDisplayName = $ClusterResourceType.ResourceType.DisplayName
									Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status "Cluster Group $GroupName - Querying $ResourceTypeDisplayName resources"
									$ResourceLine = ""
									foreach ($ClusterResource in get-clusterResource | Where-Object {($_.ResourceType.Name -eq $ClusterResourceType.ResourceType.Name) -and ($_.OwnerGroup.Name -eq $ClusterGroup.Name)}){
										switch ($ClusterResource.State.value__) {
											2 {$Color = "Green"} #Online
											3 {$Color = "Black"} #Offline
											4 {$Color = "Red"}   #ClusterResourceFailed
											default { $Color = "Orange" } #Pending or other state
										}
										$State = "<font face=`"Webdings`" color=`"$Color`">n</font> " + $ClusterResource.State
										if ($ResourceLine -ne "") { $ResourceLine += "<br/>" }
										$ResourceLine += $State + " - " + $ClusterResource.Name
									}			
									add-member -inputobject $ClusterGroup_Summary -membertype noteproperty -name $ResourceTypeDisplayName -value $ResourceLine
								}
								$strID = "05a_" + $GroupName + "_ClusterGroup"
								$ClusterGroup_Summary | ConvertTo-Xml2 | update-diagreport -id $strID -name "Cluster Group $GroupName" -verbosity informational
							}	
						}
						else
						{
							$ClusterGroup_Summary = new-object PSObject
							$ClusterGroup_Summary | ConvertTo-Xml2 | update-diagreport -id "05a" -name "A large number of cluster groups were detected on this system.  Detailed cluster group information is not available in Resultreport.xml" -verbosity informational
						}
						Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status $ClusterBasicInfo.ID_ClusterInfoObtaining
						
						
						
					}
				}
				
				
				$ClusterNetWorks = get-clusternetwork
				if($ClusterNetWorks -ne $null)
				{
					foreach($Psnetwork in $ClusterNetWorks)
					{
					    $PSClusterNetWork = New-Object PSObject
						$AutoMetric = ""
						$RoleDescription = ""
						$IPv6Addresses = ""
						$State = ""
						$Ipv4Addresses = ""
						if($Psnetwork.IPv6Addresses.Count -eq 0)
						{
							$IPv6Addresses = "None/0"
						}
						else
						{
							for($c =0 ;$c -lt $Psnetwork.IPv6Addresses.Count; $c++ )
							{
	
								if($c -eq $Psnetwork.IPv6Addresses.Count-1)
								{
									$IPv6Addresses += $Psnetwork.IPv6Addresses[$c] + " / " + $Psnetwork.Ipv6PrefixLengths[$c]
								}
								else
								{
									$IPv6Addresses += $Psnetwork.IPv6Addresses[$c] + " / " + $Psnetwork.Ipv6PrefixLengths[$c] +"<br/>"
								}
							}
						}
						
						if($Psnetwork.Ipv4Addresses.Count -eq 0)
						{
							$Ipv4Addresses = "None / None"
						}
						else
						{
							for($i =0 ;$i -lt $Psnetwork.Ipv4Addresses.Count; $i++ )
							{
	
								if($i -eq $Psnetwork.Ipv4Addresses.Count-1)
								{
									$Ipv4Addresses += $Psnetwork.Ipv4Addresses[$i] + " / " +$Psnetwork.AddressMask[$i]
								}
								else
								{
									$Ipv4Addresses += $Psnetwork.Ipv4Addresses[$i] + " / " +$Psnetwork.AddressMask[$i] +"<br/>"
								}
							}
						}
						
						if($Psnetwork.AutoMetric)
						{
							$AutoMetric = " [AutoMetric]"
						}
						switch ($Psnetwork.Role) 
						{
								0 {$RoleDescription = " (Do not allow cluster network communications on this network)"}
								1 {$RoleDescription = " (Allow cluster network communications on this network"}
								3 {$RoleDescription = " (Allow clients to connect through this network)"}
						   default{$RoleDescription = ' (Unknown)' }
						}

						$color = $null
						switch ($Psnetwork.State.value__) {
										1 {$Color = "Black"} #down
										2 {$Color = "Red"} #partitioned 
										3 {$Color = "Green"} #up
										default { $Color = "Orange" } #unavailable  or unknow
									}
						$State = "<font face=`"Webdings`" color=`"$Color`">n</font> " + $Psnetwork.State
						Add-member -InputObject $PSClusterNetWork -Membertype Noteproperty -Name "State" -Value $State
						Add-member -InputObject $PSClusterNetWork -Membertype Noteproperty -Name "IPv6 Addresses" -Value $IPv6Addresses
						Add-member -InputObject $PSClusterNetWork -Membertype Noteproperty -Name "IPv4 Addresses" -Value $Ipv4Addresses
						Add-member -InputObject $PSClusterNetWork -Membertype Noteproperty -Name "Metric" -Value ($Psnetwork.Metric.ToString() + $AutoMetric)
						Add-member -InputObject $PSClusterNetWork -Membertype Noteproperty -Name "Role" -Value ($Psnetwork.Role.ToString() + $RoleDescription)
	
						$PsClusterNetworkInfo = Convert-PSObjectToHTMLTable -PSObject $PSClusterNetWork
						$ClusterNetWorkInfoSection = New-Object PSObject
						Add-member -InputObject $ClusterNetWorkInfoSection -Membertype Noteproperty -Name $Psnetwork.Name -Value $PsClusterNetworkInfo
						$ClusterNetWorkName = $Psnetwork.Name
						$ClusterNetWorkCluster = $Psnetwork.Cluster
						$SectionName = "Cluster Networks – $ClusterNetWorkCluster"
						$ClusterNetWorkInfoSection | ConvertTo-Xml2 | update-diagreport -id  "06_$ClusterNetWorkName" -name $SectionName -verbosity informational -Description "Cluster Networks"
						Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status "Cluster Network Information"
					}
				}

			}
			
			#   Win2K8 & 2003
			if ((Test-Path "HKLM:\Cluster") -and ($OSVersion.Build -lt 7600))
			{
				
				$CommandToRun = "`"" + $pwd.Path  + "\clusmps.exe`" /S /G /P:`"" + $pwd.Path + "`""
				$FileTocollect = $pwd.Path  + "\" + $Computername + "_cluster_mps_information.txt"
				$fileDescription = "Cluster Information"
				
				$x = Runcmd -commandToRun $CommandToRun -fileDescription $fileDescription -sectionDescription "Cluster Basic Information" -filesToCollect $FileTocollect -useSystemDiagnosticsObject
				
			}
			
		}
	}
}
# SIG # Begin signature block
# MIIdwAYJKoZIhvcNAQcCoIIdsTCCHa0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUa400zOtlN3+vVTPDNaq32apf
# l+egghhkMIIEwzCCA6ugAwIBAgITMwAAAJvgdDfLPU2NLgAAAAAAmzANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwMzMwMTkyMTI5
# WhcNMTcwNjMwMTkyMTI5WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OjcyOEQtQzQ1Ri1GOUVCMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjaPiz4GL18u/
# A6Jg9jtt4tQYsDcF1Y02nA5zzk1/ohCyfEN7LBhXvKynpoZ9eaG13jJm+Y78IM2r
# c3fPd51vYJxrePPFram9W0wrVapSgEFDQWaZpfAwaIa6DyFyH8N1P5J2wQDXmSyo
# WT/BYpFtCfbO0yK6LQCfZstT0cpWOlhMIbKFo5hljMeJSkVYe6tTQJ+MarIFxf4e
# 4v8Koaii28shjXyVMN4xF4oN6V/MQnDKpBUUboQPwsL9bAJMk7FMts627OK1zZoa
# EPVI5VcQd+qB3V+EQjJwRMnKvLD790g52GB1Sa2zv2h0LpQOHL7BcHJ0EA7M22tQ
# HzHqNPpsPQIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFJaVsZ4TU7pYIUY04nzHOUps
# IPB3MB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBACEds1PpO0aBofoqE+NaICS6dqU7tnfIkXIE1ur+0psiL5MI
# orBu7wKluVZe/WX2jRJ96ifeP6C4LjMy15ZaP8N0OckPqba62v4QaM+I/Y8g3rKx
# 1l0okye3wgekRyVlu1LVcU0paegLUMeMlZagXqw3OQLVXvNUKHlx2xfDQ/zNaiv5
# DzlARHwsaMjSgeiZIqsgVubk7ySGm2ZWTjvi7rhk9+WfynUK7nyWn1nhrKC31mm9
# QibS9aWHUgHsKX77BbTm2Jd8E4BxNV+TJufkX3SVcXwDjbUfdfWitmE97sRsiV5k
# BH8pS2zUSOpKSkzngm61Or9XJhHIeIDVgM0Ou2QwggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TCCBhAwggP4
# oAMCAQICEzMAAABkR4SUhttBGTgAAAAAAGQwDQYJKoZIhvcNAQELBQAwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMTAeFw0xNTEwMjgyMDMxNDZaFw0xNzAx
# MjgyMDMxNDZaMIGDMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24w
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCTLtrY5j6Y2RsPZF9NqFhN
# FDv3eoT8PBExOu+JwkotQaVIXd0Snu+rZig01X0qVXtMTYrywPGy01IVi7azCLiL
# UAvdf/tqCaDcZwTE8d+8dRggQL54LJlW3e71Lt0+QvlaHzCuARSKsIK1UaDibWX+
# 9xgKjTBtTTqnxfM2Le5fLKCSALEcTOLL9/8kJX/Xj8Ddl27Oshe2xxxEpyTKfoHm
# 5jG5FtldPtFo7r7NSNCGLK7cDiHBwIrD7huTWRP2xjuAchiIU/urvzA+oHe9Uoi/
# etjosJOtoRuM1H6mEFAQvuHIHGT6hy77xEdmFsCEezavX7qFRGwCDy3gsA4boj4l
# AgMBAAGjggF/MIIBezAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wIATAd
# BgNVHQ4EFgQUWFZxBPC9uzP1g2jM54BG91ev0iIwUQYDVR0RBEowSKRGMEQxDTAL
# BgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNjQyKzQ5ZThjM2YzLTIzNTktNDdmNi1h
# M2JlLTZjOGM0NzUxYzRiNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUC
# lTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# b3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUF
# BwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1Ud
# EwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjiDGRDHd1crow7hSS1nUDWvWas
# W1c12fToOsBFmRBN27SQ5Mt2UYEJ8LOTTfT1EuS9SCcUqm8t12uD1ManefzTJRtG
# ynYCiDKuUFT6A/mCAcWLs2MYSmPlsf4UOwzD0/KAuDwl6WCy8FW53DVKBS3rbmdj
# vDW+vCT5wN3nxO8DIlAUBbXMn7TJKAH2W7a/CDQ0p607Ivt3F7cqhEtrO1Rypehh
# bkKQj4y/ebwc56qWHJ8VNjE8HlhfJAk8pAliHzML1v3QlctPutozuZD3jKAO4WaV
# qJn5BJRHddW6l0SeCuZmBQHmNfXcz4+XZW/s88VTfGWjdSGPXC26k0LzV6mjEaEn
# S1G4t0RqMP90JnTEieJ6xFcIpILgcIvcEydLBVe0iiP9AXKYVjAPn6wBm69FKCQr
# IPWsMDsw9wQjaL8GHk4wCj0CmnixHQanTj2hKRc2G9GL9q7tAbo0kFNIFs0EYkbx
# Cn7lBOEqhBSTyaPS6CvjJZGwD0lNuapXDu72y4Hk4pgExQ3iEv/Ij5oVWwT8okie
# +fFLNcnVgeRrjkANgwoAyX58t0iqbefHqsg3RGSgMBu9MABcZ6FQKwih3Tj0DVPc
# gnJQle3c6xN3dZpuEgFcgJh/EyDXSdppZzJR4+Bbf5XA/Rcsq7g7X7xl4bJoNKLf
# cafOabJhpxfcFOowMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEw
# HhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBT
# aWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# q/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2Avw
# OMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eW
# WcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1
# eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le
# 2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+
# 0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2
# zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv
# 1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLn
# JN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31n
# gOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+Hgg
# WCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAG
# CSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZ
# BgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/
# BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8E
# UzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEB
# BFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcw
# gZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwIC
# MDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBu
# AHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOS
# mUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQ
# VdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQ
# dION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive
# /DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrC
# xq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/
# E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ
# 7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANah
# Rr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3
# S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1W
# Tk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1t
# bWrJUnMTDXpQzTGCBMYwggTCAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcg
# UENBIDIwMTECEzMAAABkR4SUhttBGTgAAAAAAGQwCQYFKw4DAhoFAKCB2jAZBgkq
# hkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGC
# NwIBFTAjBgkqhkiG9w0BCQQxFgQU2ielcQmiikutD8WqG3iPGRGwa3QwegYKKwYB
# BAGCNwIBDDFsMGqgUIBOAEMAVABTAHcAaQBuAGQAbwB3AHMAcwBlAHQAdQBwAF8A
# VABTAF8AQgBhAHMAaQBjAEMAbAB1AHMAdABlAHIASQBuAGYAbwAuAHAAcwAxoRaA
# FGh0dHA6Ly9taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAF/LDMj+JElT
# J5rkH3hI5AiscA45VAalFggdQmxJ4P/XV+SWaNj/V1x7jJuIv9TVJ5rWAxFMzG4L
# KmLe6gEwi4EMp2H0DRe3g+gywqTfJo4Yex+i+gXHA6zoJwZ6ILAKfkufTQAtp8rh
# 4TpGgOkc2zDmNYV7yZou15pnD7LoJMwvkAxfbDE3M7mHZK/56gd8g74Z6rEvcYxe
# qFpRfFevUO7YQ1PSjTlr8qVyuRNpKvk8fRGOzoI4pjMcM8GU5aS8af9VO6R6eQQi
# cdgO7QX4lhPcl84h8+uw0ka4mi56oqRr3B7+RN54jVszyXVHtWFrcCZmRwHCt9p6
# yrMGVqYNSW6hggIoMIICJAYJKoZIhvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBAhMzAAAAm+B0N8s9TY0uAAAAAACbMAkGBSsOAwIa
# BQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0x
# NjA3MjgyMDA4MjlaMCMGCSqGSIb3DQEJBDEWBBSqWhOs9znmxm2J6sXCG6Tk6vJo
# gzANBgkqhkiG9w0BAQUFAASCAQAiQe6g3iVkKuH4UYASVW0Vb2PIAlR+ZcuY/MKj
# 3EHNrogKAXZGmA2jDRTe5oAcnBYaARqSk+EKFYkkFrw2l9CDsDPWAvGdzRGcxEGi
# XldmpZW8v3uJkfwYMFYYMK83p2oRFc92ixVMqDbiBNUldXDnqBAzhvMDrzzcKvQR
# Vbi5Z+yEN+Mkjkx91ePNZx46sUokU8X4IEjS+TF3/NSvShaCF5S8nkWgDIdZoVi/
# oi6cCRjuIlCB1VgzZlTGTJdX7wU5QV6zZVxReJNHPVu/rqnUJzdA5RsZ7XXKQFGy
# jWYmeEjNl4y+h5PUgDe6GbizY2p+vPdDeDAzUeybLeITFu2o
# SIG # End signature block
