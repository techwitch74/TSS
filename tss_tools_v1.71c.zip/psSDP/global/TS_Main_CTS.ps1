﻿# Copyright ? 2008, Microsoft Corporation. All rights reserved.

# You may use this code and information and create derivative works of it,
# provided that the following conditions are met:
# 1. This code and information and any derivative works may only be used for
# troubleshooting a) Windows and b) products for Windows, in either case using
# the Windows Troubleshooting Platform
# 2. Any copies of this code and information
# and any derivative works must retain the above copyright notice, this list of
# conditions and the following disclaimer.
# 3. THIS CODE AND INFORMATION IS PROVIDED ``AS IS'' WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. IF THIS CODE AND
# INFORMATION IS USED OR MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION
# WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER.

#_#$debug = $false

# Load Common Library:
. ./utils_cts.ps1
#_#. ./TS_RemoteSetup.ps1 #_#

$FirstTimeExecution = FirstTimeExecution

if ($FirstTimeExecution) {

	Run-DiagExpression .\DC_BasicSystemInformation.ps1

	#Run your .ps1 files from here
	#-----------------------------

		# Auto Added Commands [AutoAdded]
	.\TS_AutoAddCommands.ps1
	EndDataCollection

} else {
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
}

