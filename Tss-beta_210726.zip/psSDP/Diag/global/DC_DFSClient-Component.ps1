﻿#************************************************
# DC_DFSClient-Component.ps1
# Version 1.0
# Date: 2009-2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about DFS Client.
# Called from: Main Networking Diag, WebClient Interactive Diag, and others.
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

function RunDfsUtil ([string]$DfsUtilCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSDFSClient -Status "dfsutil.exe $DfsUtilCommandToExecute"

	$DfsUtilCommandToExecuteLength = $DfsUtilCommandToExecute.Length + 6
	"-" * ($DfsUtilCommandToExecuteLength)	| Out-File -FilePath $OutputFile -append
	"DfsUtil $DfsUtilCommandToExecute"		| Out-File -FilePath $OutputFile -append
	"-" * ($DfsUtilCommandToExecuteLength)	| Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c DfsUtil.exe " + $DfsUtilCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}

$sectionDescription = "DFS Client"
Write-DiagProgress -Activity $ScriptVariable.ID_CTSDFSClient -Status $ScriptVariable.ID_CTSDFSClientDescription

if ($OSArchitecture -eq 'ARM')
{
	'Skipping running {dfsutil.exe} since it is not supported in ' + $OSArchitecture + ' architecture.' | WriteTo-StdOut
	return
}

$OutputFile= $Computername + "_DfsClient_info_DfsUtil.TXT"

"===================================================="			| Out-File -FilePath $OutputFile -append
"DFS Client DFSUtil Output"										| Out-File -FilePath $OutputFile -append
"===================================================="			| Out-File -FilePath $OutputFile -append
"Overview"														| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"			| Out-File -FilePath $OutputFile -append
"   1. dfsutil /pktinfo"										| Out-File -FilePath $OutputFile -append
"   2. dfsutil /spcinfo"										| Out-File -FilePath $OutputFile -append
"   3. dfsutil /displaymupcache"								| Out-File -FilePath $OutputFile -append
"===================================================="			| Out-File -FilePath $OutputFile -append
"`n`n`n`n`n`n"	| Out-File -FilePath $OutputFile -append

RunDfsUtil "/pktinfo"				#  dfsutil /pktinfo				# identical commands:  dfsutil /pktinfo & dfsutil cache referral
RunDfsUtil "/spcinfo"				#  dfsutil /spcinfo				# identical commands:  dfsutil /spcinfo & dfsutil cache domain
RunDfsUtil "/displaymupcache"		#  dfsutil /displaymupcache		# identical commands:  dfsutil /displaymupcache & dfsutil cache provider

CollectFiles -filesToCollect $OutputFile -fileDescription "DFS Client Information" -SectionDescription $sectionDescription

#----------Registry
$OutputFile= $Computername + "_DfsClient_reg_output.TXT"

$CurrentVersionKeys =   "HKLM\SYSTEM\CurrentControlSet\services\DfsC",
						"HKLM\SYSTEM\CurrentControlSet\services\MUP",
						"HKLM\Software\Policies\Microsoft\System\DFSClient"
RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "DFS Client registry output" -SectionDescription $sectionDescription

