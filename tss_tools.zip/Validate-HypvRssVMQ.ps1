# file: Validate-HypvRssVMQ.ps1 v1.0

<#
.SYNOPSIS
    Collect and Validate Hypv RSS and Config 
.DESCRIPTION
    Collect and Validate Hypv RSS and Config 
.PARAMETER CollectOnly
    Only Collect infos to validate offline
.EXAMPLE
    .\Validate-HypvRssVMQ.ps1 -scriptmode -DataPath "c:\ms_data"
	This example saves the results in C:\ms_data\HypvRssVMQ, 
.NOTES
    Script developped by Vincent Douhet <vidou@microsoft.com> - Escalation Engineer / Microsoft Support CSS
        Please report him any issue using this script or regarding a ask in term of improvement and contribution

    DISCLAIMER:
    THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
    IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

.LINK
	https://github.com/ViDou83/WinDiag/blob/master/Validate-HypvRssVMQ.ps1
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)] [bool]$CollectOnly,
    [Parameter(Mandatory = $false)] [String]$OfflineData,
	[String]$DataPath = "$env:TMP\HypvRssVMQ",
	[switch]$HostMode  = $true,  # This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false # This tells the logging functions to show logging in log file __Result_HypvRssVMQ.txt
)

#########
####    GLOBALS
########
$VerDate = "2020.03.31.0"
$PROGRAMNAME = "Validate-HypvRssVMQ"
$NbrVmSwitch = 0
#$outputDir = "$env:TMP\HypvRssVMQ"
$outputDir = "$DataPath\HypvRssVMQ"
if ( -not $(Test-Path $outputDir) ) {(new-item -path $outputDir -type directory | Out-Null)}
$LogPath = $outputDir + "\_Result_HypvRssVMQ.txt"
 Write-verbose "LogPath $LogPath"

$LogLevel = 0

Enum NetLbfoTeamTeamingMode {
    Static = 0
    SwitchIndependent = 1
    Lacp = 2
}

Enum NetLbfoTeamLoadBalancingAlgorithm {
    TransportPorts = 0
    IPAddresses = 2
    MacAddresses = 3
    HyperVPort = 4
    Dynamic = 5
}

Enum RssProfile {
    ClosestProcessor = 1
    ClosestProcessorStatic = 2
    NUMAScaling = 3
    NUMAScalingStatic = 4
    ConservativeScaling = 5
}

$g_VMHost = @{ }

#region: Logging Functions
	function WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
		# SYNOPSIS: writes the actual output - used by other Logging Functions
    if($Script:ScriptMode){
      if($NoNewLine) {
        $Script:Trace += "$line"
      }
      else {
        $Script:Trace += "$line`r`n"
      }
      Set-Content -Path $script:LogPath -Value $Script:Trace
    }
    if($Script:HostMode){
      $Params = @{
        NoNewLine    = $NoNewLine -eq $true
        ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
      }
      Write-Host $line @Params
    }
  }

  function WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
		# SYNOPSIS: handles informational logs
    if($WaitForResult){
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
    }
    else{
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message"
    }
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"
      }
    }
  }

  function WriteResult([string]$message,[switch]$Pass,[switch]$Success){
		# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
    if($Pass){
      WriteLine " - Pass" -ForegroundColor Cyan
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
      }
    }
    if($Success){
      WriteLine " - Success" -ForegroundColor Green
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
      }
    }
  }

  function WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
		# SYNOPSIS: write highlighted info
    WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
  }

  function WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
		# SYNOPSIS: write warning logs
    WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Yellow
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
  }

  function WriteError([string]$message){
		# SYNOPSIS: logs errors
			WriteLine ""
			WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
  }

  function WriteErrorAndExit($message){
		# SYNOPSIS: logs errors and terminates script
			WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
			Write-Host "Press any key to continue ..."
			$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
			$HOST.UI.RawUI.Flushinputbuffer()
			Throw "Terminating Error"
	}

	#endregion: Logging Functions
#region: Script Functions
function IsHypvInstalled() {
	#if( (Get-WindowsFeature Hyper-V  )Installed -eq "True" ) { $res=$true }
	<#
	# Windows 10: Get the Hyper-V feature and store it in $hyperv
		$hyperv = Get-WindowsOptionalFeature -FeatureName Microsoft-Hyper-V-All -Online
	# Check if Hyper-V is already enabled.
	if ($hyperv.State -eq "Enabled") {
		WriteInfo -message "Hyper-V is enabled."
		$res = $true
	} else {
		WriteWarning -message "Hyper-V is disabled."
		$res = $false
	}
    return $res
	#>
	$TestPath = Test-Path "C:\Windows\System32\vmms.exe"
	return $TestPath 
    
    
}

function Get-NetAdapterNumaNode {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [String] $NicName
    )

    return $(Get-NetAdapterHardwareInfo -Name $NicName).NumaNode
}

function CollectEnvInfo() {
    WriteInfo -message "--------------------------------------------"
    WriteInfo -message "`tCollecting machine state on $env:COMPUTERNAME"
    WriteInfo -message "--------------------------------------------"

    $RegWinNTCurrVer = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\"

    $RegWinNTCurrVer | ConvertTo-Json | Set-Content -Path $outputDir\WinNTVersion.json

}


function CollectCPUAndNumaTopology() {
    #    $res = $false

    [String []] $cmdlets = @( "Get-VMHost", "Get-VMHostNumaNode" )

    $cmdlets | ForEach-Object { 
        $cmd = $_
        "Collecting $cmd"
        & $cmd | ConvertTo-Json | Set-Content -Path $outputDir\$_.json    
    }

    Get-WmiObject -Class win32_processor -Property * | ConvertTo-JSON  | Set-Content -Path $outputDir\CpuInfo.json 
}


function CollectVMNetworkInfo() {

    WriteInfo -message "--------------------------------------------"
    WriteInfo -message "`tCollecting Network info on $env:COMPUTERNAME"
    WriteInfo -message "--------------------------------------------"


    [String []] $cmdlets = @( "Get-NetAdapter", "Get-NetAdapterHardwareInfo", "Get-NetAdapterRSS", "Get-NetAdapterVMQ", "Get-NetAdapterVmqQueue",
        "Get-VMHost", "Get-VMSwitch", "Get-NetLbfoTeam", "Get-NetLbfoTeamMember", "Get-NetLbfoTeamNic", "Get-VMNetworkAdapter", "Get-NetIPAddress"
    )

    $cmdlets | ForEach-Object { 
        $cmd = $_
        "Collecting $cmd"
        if ( $cmd -eq "Get-VMNetworkAdapter") {
            & $cmd -All | ConvertTo-Json | Set-Content -Path $outputDir\$_.json    
        }
        else {
            & $cmd | ConvertTo-Json -Depth 10 | Set-Content -Path $outputDir\$_.json    
        }
    }


    if ( Test-Path $outputDir\Get-VMSwitch.json ) {
        $VMSwitchobj = Get-Content $outputDir\Get-VMSwitch.json | ConvertFrom-Json 
        $VMSwitchobj | ForEach-Object {
            $VMSwitch = $_
            $VMSwitchName = $_.Name
            $VMSwitchType = $_.SwitchType

            #            WriteResult -Success -message "VMSWITH NAME=$VMSwitchName TYPE=$VMSwitchType detected"
            if ( $VMSwitchType -eq 2) {   
                if ( $VMSwitch.EmbeddedTeamingEnabled -eq "True") {
                    #"SET Team enabled"
                    $cmd = "Get-VMSwitchTeam"
                    Invoke-Command -ScriptBlock { & $cmd $VMSwitchName } | ConvertTo-Json | Set-Content -Path $outputDir\$cmd-$VMSwitchName.json 
                }
                elseif ( $VMSwitch.NetAdapterInterfaceDescription -match "Multiplexor" ) {
                    #"LBFO Team found"
                }

                #
                if ( $VMSwitch.AllowManagementOS -eq "True") {
                    $cmd = "Get-VMNetworkAdapter"
                    Invoke-Command -ScriptBlock { & $cmd -ManagementOS -SwitchName $VMSwitchName } | ConvertTo-Json | Set-Content -Path $outputDir\$cmd-$VMSwitchName.json 
                }
            }
		}
    }
    else {
        WriteError "SCRIPT ERROR: No external VMSwitch configured. Cannot check RSS/VMQ stuff"
    }

    $res = $true

    return $res

}

function GetAndInsertVmqTopology() {
    param(
        [String] $VMSwitchName,
        [PSobject] $NetAdapter
    )

    $NetAdapterVmq = Get-Content $outputDir\Get-NetAdapterVmq.json | ConvertFrom-Json 

    $hashtable = @{ 
        Enabled               = "False";
        NumaNode              = 0;
        BaseProcessorGroup    = 0;
        BaseProcessorNumber   = 0;
        MaxProcessorNumber    = 0;
        MaxProcessors         = 0;
        NumberOfReceiveQueues = 0;
    }    
                              
    $NetAdapterVmq | ForEach-Object { 
        if ($NetAdapter.Name -eq $_.IfAlias) {

            $hashtable.Enabled = $_.Enabled
            $hashtable.NumaNode = $_.NumaNode
            $hashtable.BaseProcessorGroup = $_.BaseProcessorGroup
            $hashtable.BaseProcessorNumber = $_.BaseProcessorNumber
            $hashtable.MaxProcessorNumber = $_.MaxProcessorNumber
            $hashtable.NumberOfReceiveQueues = $_.NumberOfReceiveQueues
            $g_VMHost.$VMSwitchName."VMQ".Add($NetAdapter.Name, $hashtable)
        }    
    }
}

###
## Checking VMQ Status on each Team NIC
#
function IsVmqEnabledOnNIC() {
    param(
        [string] $VMSwitchName,
        [string] $NetAdapterKey
    )

    if ( $g_VMHost.$VMSwitchName."VMQ".$NetAdapterKey.Enabled -eq "True") {
        WriteResult -Success -message "VMQ Enabled on NIC $NetAdapterKey"
        if ( $g_VMHost.$VMSwitchName."VMQ".$NetAdapterKey.BaseProcessorNumber -eq 0) {
            WriteWarning "VMQ BaseProc=0 NIC=$NetAdapterKey - You should consider changing VMQ BaseProcNumber"
        }
    }
    else {
        WriteError "VMQ Disabled on NIC $NetAdapterKey"
        WriteWarning "Don't use VMQ on vmSwitch leads to poor performance"

    }
}

function CheckTeamNicCompliancy() {
    param(
        $hashtable
    )
    WriteInfo -message "- TeamNics compliancy check => Team=$($hashtable.TeamNics) TeamingType=$($hashtable.TeamingType) "
        
    if ( $hashtable.TeamingType -eq "LBFO") {
        $NetLbfoTeamNic = Get-Content $outputDir\Get-NetLbfoTeamNic.json | ConvertFrom-Json 
        $NetLbfoTeamMember = Get-Content $outputDir\Get-NetLbfoTeamMember.json | ConvertFrom-Json 
    }

    $members = $hashtable.members

    # Check how many NICs the teaming has 
    if ( $members.count -eq 1 ) {
        WriteWarning "Team=$($hashtable.TeamNics) TeamingType=$($hashtable.TeamingType) : Teaming with one NIC cannot offer failover"        
    }

    # SET teamin should have between 1 and 8 NICs
    if ( $hashtable.TeamingType -eq "LBFO" ) {
        if ( -Not ( $members.count -ge 1 -and $members.count -le 32 ) ) {
            WriteError "Team=$($hashtable.TeamNics) TeamingType=$($hashtable.TeamingType) : TeamNICs is composed of $($members.count) NICs"
        }
    }
    # LBFO teamin should have between 1 and 32 NICs
    elseif ($hashtable.TeamingType -eq "SET" ) {
        if ( -Not ( $members.count -ge 1 -and $members.count -le 8 ) ) {
            WriteError "Team=$($hashtable.TeamNics) TeamingType=$($hashtable.TeamingType) : TeamNICs is composed of $($members.count) NICs"
        }  
    }

    #Checking Speed
    if ( $NetLbfoTeamNic.ReceiveLinkSpeed -match "Gbps" -and $NetLbfoTeamNic.TransmitLinkSpeed -match "Gbps"  ) {
        $pow = 9
        $unit = "Gpbs"  
    }
    if ( $NetLbfoTeamNic.ReceiveLinkSpeed -match "Mpbs" -and $NetLbfoTeamNic.TransmitLinkSpeed -match "Mpbs"  ) {
        $pow = 6
        $unit = "Mpbs" 
    }

    $TotalSpeedExpected = $members[0].Speed * $members.count 

    if ( $hashtable.TeamingType -eq "LBFO") {
        $TotalSpeedExpected /= [Math]::pow(10, $pow )
        if ( $NetLbfoTeamNic.TransmitLinkSpeed.Split()[0] -ne $TotalSpeedExpected ) {
            WriteError "Team=$($hashtable.TeamNics) TeamingType=$($hashtable.TeamingType) : TeamNICs must have same speed. Teaming of NICs with different speed connections is not supported."
        }
    }
    else {
        $MgmtOsNic = (  Get-Content $outputDir\Get-NetAdapter.json | ConvertFrom-Json ) | Where-Object { $_.Name -match $hashtable.TeamNics } 
        if ( $MgmtOsNic ) { 
            if ( $MgmtOsNic.TransmitLinkSpeed -ne $TotalSpeedExpected ) {
                WriteError "Team=$($hashtable.TeamNics) TeamingType=$($hashtable.TeamingType) : TeamNICs must have same speed. Teaming of NICs with different speed connections is not supported."
            }
        }
    }
    
    #Driver
    $Driver = @{ }

    $Driver.Add($members[0].DriverName, 0)
    $Driver.Add($members[0].DriverVersionString, 0)
    $Driver.Add($members[0].DriverProvider, 0)
    $Driver.Add($members[0].DriverFileName, 0)
    $Driver.Add($members[0].DriverDescription, 0)

    for ($i = 0; $i -lt $members.count; $i++) {
        $Driver[$members[$i].DriverName]++
        $Driver[$members[$i].DriverVersionString]++
        $Driver[$members[$i].DriverProvider]++
        $Driver[$members[$i].DriverFileName]++
        $Driver[$members[$i].DriverDescription]++

    }

    foreach ($key in $Driver.Keys) {
        if ( $Driver[$key] -ne $members.count ) {
            if ( $hashtable.TeamingType -eq "SET") {
                WriteError "Team=$($hashtable.TeamNics) TeamingType=$($hashtable.TeamingType) : TeamNICs must have same driver. TeamNICs with different driver/manufacter is not supported."
            }
            else {
                WriteWarning "Team=$($hashtable.TeamNics) TeamingType=$($hashtable.TeamingType) : TeamNICs with different driver/manufacter might be supported even if this is not recommended"                
            }
            break
        }
    }

}

function ComputeVMSwitchTeamingInfo() {
    param(
        [PSobject]$VMSwitch
    )

    $hashtable = @{ 
        TeamNics               = "";
        TeamingType            = "";
        LoadBalancingAlgorithm = 0;
        TeamingMode            = 0;
        Id                     = "{00000000-0000-0000-0000-000000000000}";
        Members                = [PSobject]@();
        LacpTimers             = 0
    }    
    
    #If SET Teaming
    if ($VMSwitch.EmbeddedTeamingEnabled -eq "True") {
        $NetTeam = Get-Content $outputDir\Get-VMSwitchTeam-$VMSwitchName.json | ConvertFrom-Json 
        $hashtable.TeamNics = $NetTeam.Name
        $hashtable.Id = $NetTeam.Id
        $hashtable.TeamingType = "SET"
        $NetTeam.NetAdapterInterfaceDescription |
        ForEach-Object {
            $NetAdapterInterfaceDescription = $_
            $member = (Get-Content $outputDir\Get-NetAdapter.json | ConvertFrom-Json) | Where-Object { $_.ifDesc -eq $NetAdapterInterfaceDescription }
            $hashtable.Members += $member
        }
    } # Otherwise LBFO 
    elseif ( $VMSwitch.NetAdapterInterfaceDescription -match "Multiplexor" ) {

        $NetTeamNic = ( Get-Content $outputDir\Get-NetLbfoTeamNic.json | ConvertFrom-Json ) | Where-Object { $VMSwitch.NetAdapterInterfaceDescription -eq $_.InterfaceDescription } 
        $NetTeam = ( Get-Content $outputDir\Get-NetLbfoTeam.json | ConvertFrom-Json ) | Where-Object { $_.Name -eq $NetTeamNic.Name    } 
        
        $hashtable.TeamNics = $NetTeamNic.Name
        $hashtable.Id = $NetTeam.InstanceID
        $hashtable.TeamingType = "LBFO"
        $NetTeam.Members.Value |
        ForEach-Object {
            $NetAdapterInterfaceDescription = $_
            $member = (Get-Content $outputDir\Get-NetAdapter.json | ConvertFrom-Json) | Where-Object { $_.Name -eq $NetAdapterInterfaceDescription }            
            $hashtable.Members += $member
        }
    }
    else {
        WriteError -message "SCRIPT ERROR: Wrong Switch type provided"
    }

    $hashtable.TeamingMode = $NetTeam.TeamingMode
    $hashtable.LoadBalancingAlgorithm = $NetTeam.LoadBalancingAlgorithm

    $g_VMHost.$VMSwitchName.Add("TEAM", $hashtable)        

    WriteInfo -message "+ TeamingMode"
    WriteInfo -message "- VMSwithName=$($VMSwitch.name) TeamingType=$($g_VMHost.$VMSwitchName."TEAM".TeamingType)"
    
    #Checking if NIC are same speed / same brand / type and so on
    CheckTeamNicCompliancy $hashtable  

}


function ComputeVMQPlan() {
    param(
        [PSobject] $VMSwitchName
    )
    
    $members = $g_VMHost.$VMSwitchName."TEAM".members.name
    $g_VMHost.$VMSwitchName.Add("VMQ", @{ })

    $members | 
    ForEach-Object {
        $NetAdapterDescription = $_
        $NetAdapter = (Get-Content $outputDir\Get-NetAdapter.json | ConvertFrom-Json) | Where-Object { $_.Name -eq $NetAdapterDescription }
        GetAndInsertVmqTopology $VMSwitchName $NetAdapter
    }  

    WriteInfo -message "+ VMQ status"

    #Checking if VMQ is Enabled on NIC
    foreach ( $NetAdapterKey in $g_VMHost.$VMSwitchName.VMQ.Keys) {        
        IsVmqEnabledOnNIC $VMSwitchName $NetAdapterKey
    }
}

function CheckVMQSumMinQ() { 
    param(
        [PSobject] $VMSwitchName
    )
    
    $QueueModeExpect = ""
    $QueueModeCurrent = ""
    $VMQCpuOverlap = $false

    if ( $g_VMHost.$VMSwitchName."TEAM".TeamingType -eq "SET") {
        $QueueModeExpect = "SUM"
    }
    elseif ( $g_VMHost.$VMSwitchName."TEAM".TeamingType -eq "LBFO") { 
        switch ( $g_VMHost.$VMSwitchName."TEAM".TeamingMode ) {
            ([NetLbfoTeamTeamingMode]::SwitchIndependent.value__) {
                if (  $g_VMHost.$VMSwitchName."TEAM".LoadBalancingAlgorithm -ne [NetLbfoTeamLoadBalancingAlgorithm]::HyperVPort.value__ -or
                    $g_VMHost.$VMSwitchName."TEAM".LoadBalancingAlgorithm -ne [NetLbfoTeamLoadBalancingAlgorithm]::Dynamic.value__ 
                ) {
                    $QueueModeExpect = "MIN"
                }
                else {
                    $QueueModeExpect = "SUM"
                }
            }
            (   [NetLbfoTeamTeamingMode]::Lacp.value__ -or 
                [NetLbfoTeamTeamingMode]::Static.value__
            ) {
                $QueueModeExpect = "MIN"
            }
        }
    }

    WriteInfo -message "- VMQ check if CPU set overlaps"

    #Checking if there is CPU overlaps
    foreach ( $L_member in $g_VMHost.$VMSwitchName."VMQ".Keys  ) {
        foreach ( $R_member in $g_VMHost.$VMSwitchName."VMQ".Keys  ) {
            if ( $L_member -ne $R_member) {
                if ( 
                    $g_VMHost.$VMSwitchName."VMQ".$L_member.BaseProcessorNumber -eq $g_VMHost.$VMSwitchName."VMQ".$R_member.BaseProcessorNumber -and 
                    $g_VMHost.$VMSwitchName."VMQ".$L_member.MaxProcessorNumber -eq $g_VMHost.$VMSwitchName."VMQ".$R_member.MaxProcessorNumber
                ) {
                    $QueueModeCurrent = "MIN"
                }
                else {
                    $QueueModeCurrent = "SUM"
                }

                if ( 
                    (
                        $g_VMHost.$VMSwitchName."VMQ".$R_member.BaseProcessorNumber -ge $g_VMHost.$VMSwitchName."VMQ".$L_member.BaseProcessorNumber -and
                        $g_VMHost.$VMSwitchName."VMQ".$R_member.BaseProcessorNumber -le $g_VMHost.$VMSwitchName."VMQ".$L_member.MaxProcessorNumber
                    ) -or
                    (
                        $g_VMHost.$VMSwitchName."VMQ".$R_member.MaxProcessorNumber -ge $g_VMHost.$VMSwitchName."VMQ".$L_member.BaseProcessorNumber -and
                        $g_VMHost.$VMSwitchName."VMQ".$R_member.MaxProcessorNumber -le $g_VMHost.$VMSwitchName."VMQ".$L_member.MaxProcessorNumber 
                    )        
                ) {
                    WriteError "VMQ CPU set overlaps between $L_member and $R_member NIC"      
                    $VMQCpuOverlap = $true  
                }

            }
        }            
    }

    if ($QueueModeCurrent -eq $QueueModeExpect) {
        WriteResult -Success -message "QueueModeExpect=$QueueModeExpect QueueModeCurrent=$QueueModeCurrent"
    }
    else {
        WriteError "QueueModeExpect=$QueueModeExpect QueueModeCurrent=$QueueModeCurrent"
        if ( $g_VMHost.$VMSwitchName."TEAM".TeamingType -eq "SET") {
            WriteWarning "VMswitch configured with SET teaming must be configured in VMQ Sum-of-Queues mode"
        }
    }

    if ( $VMQCpuOverlap -eq $true ) {
        WriteError "VMQ CPU set overlaps"
    }

}


function Get-RssProfile() {

    param(
        [PSobject] $VMNetworkAdapterRss
    )
    
    switch ( $VMNetworkAdapterRss.Profile) {
        ([RssProfile]::ClosestProcessor.Value__) {
            [RssProfile]::ClosestProcessor   
        }
                        
        ([RssProfile]::ClosestProcessorStatic.Value__) {
            [RssProfile]::ClosestProcessorStatic   
        }

        ([RssProfile]::NUMAScaling.Value__) {
            [RssProfile]::NUMAScaling  
        }
                        
        ([RssProfile]::NUMAScalingStatic.Value__) {
            [RssProfile]::NUMAScalingStatic
        }
                        
        ([RssProfile]::ConservativeScaling.Value__) {
            [RssProfile]::ConservativeScaling                         
        }
    }
}


function CheckVrssStatus() {
    param(
        [PSobject] $VMSwitchName
    )
    
    WriteInfo -message "+ VRSS Status VmSwitch=$VMSwitchName"

    if ( -Not $( Test-Path $outputDir\Get-VMNetworkAdapter.json ) ) { 
        WriteError "Cannot checkt VRSS Status as Get-VMNetworkAdapter.json file is missing"
        return 1
    }
    $VMNetworkAdapter = (Get-Content $outputDir\Get-VMNetworkAdapter.json | ConvertFrom-Json) | Where-Object { $_.SwitchName -eq $VMSwitchName }

    $VMNetworkAdapter | ForEach-Object {
        $VMNetworkAdapterCurrent = $_
        if ( $_.VrssEnabled) {
            #Check Indirection table and NUMA distance
            $VMNetworkAdapterRss = (Get-Content $outputDir\Get-NetAdapterRSS.json | ConvertFrom-Json) | Where-Object { $_.Name -match $VMNetworkAdapterCurrent.name }
            
            $RssPreviousCPU = 0
            $VMNetworkAdapterRss.IndirectionTable.CimInstanceProperties | ForEach-Object {
                $RssCurrentCPU = $_.Value
                if ( $RssPreviousCPU -eq $RssCurrentCPU) {
                    $RssAllZeroes = $true
                }
                else {
                    $RssAllZeroes = $false                    
                }
                $RssPreviousCPU = $RssCurrentCPU
            }
            
            #
            if ($VMNetworkAdapterCurrent.IsManagementOs) { 
                WriteResult -Success -message "VRSS enabled on MgmtOS vNIC=$($VMNetworkAdapterCurrent.name)"
            }
            else {
                WriteResult -Success -message "VRSS enabled on VM=$($VMNetworkAdapterCurrent.VMName) vNIC=$($VMNetworkAdapterCurrent.name) "                
            }

            #
            if ( $VMNetworkAdapterRss.BaseProcessorNumber -eq 0) {
                WriteWarning "RSS BaseProc=0 vNIC=$($VMNetworkAdapterCurrent.name) - you should consider to exlude CPU=0"
            }

            #Indirection table EMPTY
            if ( $RssAllZeroes ) {
                WriteWarning "RSS Indirection table empty for vNIC=$($VMNetworkAdapterCurrent.name) RssProfile=$(Get-RssProfile $VMNetworkAdapterRss)"
                WriteWarning "--------- Please try to reset RSS on $($VMNetworkAdapterRss.name)"   
            }
        }
        else {
            if ($VMNetworkAdapterCurrent.IsManagementOs) { 
                WriteError "VRSS disabled on MgmtOS vNIC=$($VMNetworkAdapterCurrent.name)"
            }
            else {
                WriteError "VRSS disabled on VM=$($VMNetworkAdapterCurrent.VMName) vNIC=$($VMNetworkAdapterCurrent.name) "                
            }
        }
    }
} 


function CheckVMQNumaNode() {
    param(
        [PSobject] $VMSwitchName
    )

    WriteInfo -message "+ VMQ check spreading from NUMA node topology"


    $VMHost = (Get-Content $outputDir\Get-VMHost.json | ConvertFrom-Json)
    $VMHostNumaNode = (Get-Content $outputDir\Get-VMHostNumaNode.json | ConvertFrom-Json)
    #$cpuInfo = @(Get-WmiObject -Class win32_processor -Property "NumberOfCores", "NumberOfLogicalProcessors")

    $NbrNUMA = $VMHostNumaNode.NodeId.Count

    if ( Test-Path $outputDir\CpuInfo.json) {
        $g_VMHost.add("CpuInfo", $( Get-Content $outputDir\CpuInfo.json | ConvertFrom-Json ))
    
        $g_VMHost.CpuInfo[0].NumberOfCores
        for ( $i = 0; $i -lt $g_VMHost.cpuInfo.count ; $i++) {
            $NbrCores += $g_VMHost.cpuInfo[$i].NumberOfCores
            $NbrLPs += $g_VMHost.cpuInfo[$i].NumberOfLogicalProcessors
        }
    }
    else {
        $NbrNUMA = $VMHostNumaNode.NumaNodEId.count
        $NbrCores = $NbrNUMA
        $NbrLPs = $VMHostNumaNode.ProcessorsAvailability.count
    }

    $NbrLPsPerNuma = $NbrLPs / $VMHostNumaNode.NumaNodEId.count

    # Hyper-Threading is enabled if NumberOfCores is less than NumberOfLogicalProcessors
    $htEnabled = $NbrCores -lt $NbrLPs

    $out = if ($htEnabled) { "HyperThreading=Enabled " }else { "HyperThreading=Disabled " } 
    $out += "NbrNUMA=$NbrNUMA NumberOfCores=$NbrCores NbrLPsPerNuma=$NbrLPsPerNuma NumberOfTotalLogicalProcessors=$NbrLPs"    
    WriteInfo -message $out
 
    #Checking if there is CPU overlaps
    foreach ( $NetAdapterName in $g_VMHost.$VMSwitchName."VMQ".Keys  ) {
        $NetAdapterHardwareInfo = (Get-Content $outputDir\Get-NetAdapterHardwareInfo.json | ConvertFrom-Json) | Where-Object { $_.Name -eq $NetAdapterName }

        $VMQNumaNode = if ( $g_VMHost.$VMSwitchName."VMQ".$NetAdapterName.NumaNode -ne 65535) { $g_VMHost.$VMSwitchName."VMQ".$NetAdapterName.NumaNode }else { $NetAdapterHardwareInfo.NumaNode }
  

        $NumaBaseProcNumber = $VMQNumaNode * $NbrLPsPerNuma
        $NumaMaxProcNumber = if ( $htEnabled) { ( $NbrLPsPerNuma * ( $VMQNumaNode + 1 ) ) - 2 }else { ( $NbrLPsPerNuma * ( $VMQNumaNode + 1 ) ) - 1 }

        $PhysicalNumaPin = $NetAdapterHardwareInfo.NumaNode

        if ( $PhysicalNumaPin -ne $VMQNumaNode) { WriteWarning "VMSwitchName=$VMSwitchName NetAdapterName=$NetAdapterName NetHardwareInfoNumaNode=$PhysicalNumaPin != VMQNumaNode=$VMQNumaNode" } 

        #"NetAdapterName=$NetAdapterName NumaNodEId=$($g_VMHost.$VMSwitchName."VMQ".$NetAdapterName.NumaNode) NumaBaseProcNumber=$NumaBaseProcNumber NumaMaxProcNumber=$NumaMaxProcNumber"
        if ( $g_VMHost.$VMSwitchName."VMQ".$NetAdapterName.BaseProcessorNumber -ge $NumaBaseProcNumber -and
            $g_VMHost.$VMSwitchName."VMQ".$NetAdapterName.MaxProcessorNumber -le $NumaMaxProcNumber 
        ) {
            WriteResult -Success -message "VMSwitchName=$VMSwitchName NetAdapterName=$NetAdapterName NumaNode=$VMQNumaNode CPU set is configured properly between $NumaBaseProcNumber and $NumaMaxProcNumber"    
        }
        else {
            WriteError "VMSwitchName=$VMSwitchName NetAdapterName=$NetAdapterName NumaNode=$VMQNumaNode CPU set is not configured properly | not between $NumaBaseProcNumber and $NumaMaxProcNumber"    
        } 
    }
}


###### 
####   ComputeVMSwitchConfig
##
###
### 1/ Check VMSwitch
### 2/ Check teaming 
### 3/ Check CPU & Numa Node topo
### 4/ Check VMQ & vRSS spreading
###
function CheckVMQandRSS() {
		$VMSwitchobj = Get-Content $outputDir\Get-VMSwitch.json | ConvertFrom-Json 
		# Iterating each VMSwitch found
		$VMSwitchobj | 
		ForEach-Object {
			$VMSwitch = $_
			$VMSwitchName = $VMSwitch.Name
			#Only interested by external vmswtich 
			if ( $VMSwitch.SwitchType -eq 2) {
				WriteInfo -message "##"
				WriteInfo -message "### External VMSwitch  Name=$VMSwitchName" 
				WriteInfo -message "##"
				
				#Add it to the hashtable
				$g_VMHost.Add($VMSwitchName, @{ })    
				
				### 2/ Check teaming             
				ComputeVMSwitchTeamingInfo $VMSwitch
				ComputeVMQPlan $VMSwitchName
				CheckVMQSumMinQ $VMSwitchName
				CheckVMQNumaNode $VMSwitchName
				CheckVrssStatus $VMSwitchName
			}
		}
}


function CheckNetworkTopology() {
    
    WriteInfo -message "-----------------------------------------------------"
    WriteInfo -message "`tChecking Hyper-V HOST Network topology"
    WriteInfo -message "-----------------------------------------------------"

    if ( -Not ( Test-Path $outputDir\Get-VMNetworkAdapter.json) ) {
        WriteWarning "HypvHost is not having MgmtOS vNIC means that this is not a converged NIC deployment" 
        WriteWarning "Additionnally it appears that neighter MgmtOS and VM vNICs exist" 
    }
    else {
        $VMNetworkAdapterMgmtOs = $( Get-Content $outputDir\Get-VMNetworkAdapter.json | ConvertFrom-Json ) | Where-Object { $_.IsManagementOs }

        if ( -Not $VMNetworkAdapterMgmtOs) {
            WriteWarning "HypvHost is not having MgmtOS vNIC means that this is not a converged NIC deployment" 
            #
        }
        else {

            $NetLbfoTeam = Get-Content $outputDir\Get-NetLbfoTeam.json | ConvertFrom-Json 
            $NetLbfoTeamNic = Get-Content $outputDir\Get-NetLbfoTeamNic.json | ConvertFrom-Json 
            $NetLbfoTeamMember = Get-Content $outputDir\Get-NetLbfoTeamMember.json | ConvertFrom-Json

            $NetIPAddress = Get-Content $outputDir\Get-NetIPAddress.json | ConvertFrom-Json 
        }
    }
}
#endregion: Script Functions

###### 
####   Main
##
WriteInfo -message "...Starting '$PROGRAMNAME' on $ENV:COMPUTERNAME by $ENV$USERNAME at $(Get-Date) "
#if ( Test-Path $outputDir) { Remove-Item $outputDir -Recurse -Force }

if ( IsHypvInstalled ) {
    if ( $OfflineData ) {
        if ( Test-Path $OfflineData ) {
            $outputDir = $OfflineData
        }
    }
    else {
        if ( -not $(Test-Path $outputDir) ) {
			mkdir $outputDir | Out-Null
			CollectEnvInfo
			CollectCPUAndNumaTopology
			CollectVMNetworkInfo
        }
    }
    if ( -Not $CollectOnly) {
        WriteInfo -message "-----------------------------------------------------"
        WriteInfo -message "`tChecking VirtualNetwork optimization "
        WriteInfo -message "-----------------------------------------------------"
        #
        if (Test-Path $outputDir\Get-VMSwitch.json ) { 
			CheckVMQandRSS } else {WriteWarning "This is not a Hyper-V Host"}
        #
        CheckNetworkTopology
    }
    else {
        Write-Host "Please zip and upload collected informations located in $outputDir to Microsoft Support using DTM workspace." -ForegroundColor Green
    }
}
else {
    WriteError -message "Hyper-V role appears to be not installed"
}

#rmdir $outputDir -Force 
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done $PROGRAMNAME"
# SIG # Begin signature block
# MIIjfAYJKoZIhvcNAQcCoIIjbTCCI2kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBluEHbwCTsucvm
# 3gXy2HHu+FeT3Lu+AEQfqUevxxHeUqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVUTCCFU0CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgPRe1PHpU
# wKoTFF6nvqQTsQbVsR5Szr5neNOsyU58xJcwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAE/2VJqQQq+Dz1VBQ5VPpg3NY13hjLGbXJ0jW+411qYUQ1aWbw8KLy33
# IplsnKjQEpQyx6XMHB3dHJRYQ3E4qsUOsiC18m9gW4eTEeWW7KgIK9F4BWY3HpVp
# ANpecAKm7O9P5mRgOGFQzh2M8QYG5MUzIsjVD+GHdcsdREWG5w3mh0EamSGioEKg
# AvPglyrgAwMeSt6DXLxgiZSBs8OqKhuSCCEafNlFxpP87z+WEVXEbSi8chENMkRs
# KPH/P8qHWOL1MYe3NGoe53mHMDnmcTFQjFb7vRcWQxdrC43g/Q+5XXoJRuma0xZ7
# va34/8L67ErX7L/mFqdiVLOKTCizypKhghLlMIIS4QYKKwYBBAGCNwMDATGCEtEw
# ghLNBgkqhkiG9w0BBwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYL
# KoZIhvcNAQkQAQSgggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgxqxBq5JnMclOoq9Ow2JLYMgzjXCAuSp9ZdHtm7Vov3kCBmCJ1lRF
# zBgTMjAyMTA1MTkyMjE5NTYuNjM4WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
# ZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RDZCRC1F
# M0U3LTE2ODUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# gg48MIIE8TCCA9mgAwIBAgITMwAAAVBYotSnmwsw6wAAAAABUDANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMDExMTIxODI2
# MDNaFw0yMjAyMTExODI2MDNaMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpENkJELUUzRTctMTY4NTElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAOd6f5R7KlnDJxtWmg3zM1ICqdmXjT5GNFPHXuCw+9Vg
# 3G897o/Ou5L8nlfaY43oFG35dokBMkm+QKAe9WImqtTtDf1PSpN/TZ85NPOQFHXO
# EHaKEvddJoSlET8vbBJru+AvyOE8WLR1nyeepyP3ptUtpG8+zsA1d4MXfGlk2BRI
# ovYR6AFyZFSx773a5aT81iyPxjcQK/ao+dII0RKp1D3slLgrdHk/MdIIbbFi9FEu
# n5v3QVUjYkJCvUgCP3ZQ2R7bAodtCzlV3IkT7++CDq3Jl1rFbsBWiMirkpx8zf5B
# qE0qmx04ebfsjBiYPUt9OxvS1WFcuNuHujhPpwIqJZsCAwEAAaOCARswggEXMB0G
# A1UdDgQWBBSCVRkfGUXbrWQvQ8EAQzu3659FfjAfBgNVHSMEGDAWgBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNy
# dDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# CwUAA4IBAQBRP2h0co7+4+PTwB4vk/YeLEw6ocreg+T0kB2aWB/Ze3zEXtj0EeIV
# A1Zgwp38cjavJg67dIACze3FlpGlqW9jRHXpZYhDML0b2ipIPtA03REzGyKIIwzr
# n+er3FI8iuZiHppNcWAgy6HgYs2TuAxAXJtRuDZmUtmyf2vlHPFf/HxorXuCARYq
# aKKPWWBv/oAT5sA9S4TLLnS5rpT1mzT5uLz8e+dmzo+IzAaG1fP+xGtloBiNsu9o
# Jc6T4NtG8cGhgdBCbflCs9Qh+I1zDfSCIgxHLvFgeOKaX8jFqQwVQnnqYsTdK+dt
# IbForCmk+WQizDkeF6Z1IYezlKWtBNteMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAA
# AjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0
# aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPl
# YcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2T
# rNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFh
# E24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+c
# Bj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn
# 9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQB
# gjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB
# /zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEE
# AYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9Q
# S0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcA
# YQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZI
# hvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20Z
# MLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX
# /1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+TH
# zvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnx
# zplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjY
# lPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kW
# umGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3
# ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slva
# yA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5
# KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czm
# TfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYIC
# zjCCAjcCAQEwgfihgdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkQ2QkQtRTNFNy0xNjg1MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQAj
# DXufcvE1a0YRm1qWWaQxlh6gEqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5FAD0zAiGA8yMDIxMDUyMDA1Mzgy
# N1oYDzIwMjEwNTIxMDUzODI3WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDkUAPT
# AgEAMAoCAQACAgL9AgH/MAcCAQACAhGRMAoCBQDkUVVTAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQEFBQADgYEALTmnU76RtsG8Unlnx/v8fRLyBzh+He9c/X0FweNr/+Bl
# tXbxCms8acKVMEa2U7omSlueu4YdkZlGw1oABMm+BUXbR1O0NZW3GG7GssrxrOAi
# +OOhvjojogSBeS66anXYRxjM0sTeqdIRt+f4IaD2Gt6NQuhJMXzNwCaCZ6IVxwAx
# ggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AVBYotSnmwsw6wAAAAABUDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAP36oQoSMt2pLyMt9RkOW8
# 8ogU3taN4C4BmHnL3QbXIjCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIGz0
# Pp8vmsJOGBcmYYiF1dLohjVmDqinjt2Qonwv8qP2MIGYMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFQWKLUp5sLMOsAAAAAAVAwIgQgJwJq
# 7Kv4gM4ttoOd4Smr9j+BpNnlYaQytX0aRRx3H/0wDQYJKoZIhvcNAQELBQAEggEA
# xKBr5iQbrlEokoL4rObrAHxPurt1iuFKdVY+C0neTwU+8Tdy2pAh27/GetGloKc8
# rWZiFHEIuIpNE9fADNujK3dZ7akGCj6N1iaDWzND61yL6h3gBVSIyOmy1qMpsys3
# IwwDM6Vt7kOE3/EBRjKjLLqxqanYMWda4Iv7exHtU6hqalN8N9Isi9OfyPRbfMAT
# 8fK8Oze3dxTjdKsmZv3ocZqcJ3v5Kk7MkL9Z6fV0T0gz4wdC4AcU98YmsSgX4ng4
# ThqX7klDNv5Fjs8iPbGaheU9ttTSMhPNyQXbvXRI5RavmOXVnHgKiWoXKAGTgKsh
# 3r5dNpjMVR1REkUpwYASkQ==
# SIG # End signature block
