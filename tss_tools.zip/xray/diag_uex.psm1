﻿# diag_uex.ps1
# Created by tdimli
# March 2020
#
# Diagnostic functions for UEX area
# contributors: tdimli
# developers: tdimli

Import-Module -Name .\diag_api.psm1 -Force

# version
$UEX_version = "1.0.200425.0"

# Area and Area/Component arrays
# Example: $AREA = @("Component1", "Component2")
$UEX = @()

#Component/Diagnostic Function arrays
# Example: $Component1 = @("Diag_Func1", "Diag_Func1")

# For information on how to create a diagnostic function, please see developers.md at:
# https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/XRay/developer.md

# begin: diagnostic functions
#    <your diagnostic functions here>
# end: diagnostic functions

Export-ModuleMember -Function * -Variable *