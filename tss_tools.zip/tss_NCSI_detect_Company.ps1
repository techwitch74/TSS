<# Name: NCSI_detect_Company.ps1
# last edit:  2017-03-26
# Purpose: Network Diagnostics Script for NLASVC or NCSI issues, troubleshooting yellow exclamation mark on network icon
#          perhaps if you run the script to perform a probe from the machine, the yellow bang may go away.

Usage:
.\NCSI_detect_Company.ps1 [-Capture_Trace on|off|persistent] [-RootDom <string>] [-KnownExtIPAddr <IPaddress>] [-verbose] 

# =======================================================================================
# See https://blogs.technet.microsoft.com/networking/2012/12/20/the-network-connection-status-icon/
# Appendix K: Network Connectivity Status Indicator and Resulting Internet Communication in Windows Vista http://technet.microsoft.com/en-us/library/cc766017(v=WS.10).aspx
# Appendix H: Network Connectivity Status Indicator and Resulting Internet Communication in Windows 7 and Windows Server 2008 R2 http://technet.microsoft.com/en-us/library/ee126135(v=WS.10).aspx
# The network connectivity status incorrectly appears as "Local only" on a Windows Server 2008-based or Windows Vista-based computer that has more than one network adapter http://support.microsoft.com/kb/947041
#
# Resulting Text file may then be sent to IT for analysis
::  Copyright (C) Microsoft. All rights reserved.
::
::  THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
::  ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
::  IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
::  PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
::
#> 

<#
.SYNOPSIS
Network Diagnostics Script for NLASVC or NCSI issues on your system.
The script helps troubleshooting yellow exclamation mark on network icon issues. 
Using parameter 'on' it will also capture network etl trace. Use 'persistent' to capture across next reboot(s).

.DESCRIPTION
Network Diagnostics Script for NLASVC or NCSI issues on your system.
The script helps troubleshooting yellow exclamation mark on network icon issues. 
You can modify the section ## customization section of script ## for your needs, but all parameters are optional.
NLA and NCSI Operational Eventlogs will be collected. 

Usage:
.\NCSI_detect_Company.ps1 [-Capture_Trace on|off|persistent] [-RootDom <string>] [-KnownExtIPAddr <IPaddress>] [-verbose] 

.EXAMPLE
.\NCSI_detect_Company.ps1 -RootDom microsoft.com -KnownExtIPAddr 23.96.52.53
.\NCSI_detect_Company.ps1 microsoft.com 23.96.52.53 -verbose
Following command will enable Network Tracing
.\NCSI_detect_Company.ps1 -Capture_Trace on

#>

Param(
	[ValidateSet("off","on","persistent")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Want to capture trace, on|off|persistent')]
	[string]$Capture_Trace = "off"
,
	[Parameter(Mandatory=$False,Position=1,HelpMessage='Input your DNS root domain, i.e.  corpintra.net')]
	[string]$RootDom = "microsoft.com"
,
	[Parameter(Mandatory=$False,Position=2,HelpMessage='Input your known external IP Addr for DNS root domain corpintra.net ')]
	[IPAddress]$KnownExtIPAddr = "23.96.52.53"
	)
	
	
$ScriptVersion ="1.9"
$startscript = Get-Date # Capture Script start time

switch($Capture_Trace)
	{
	"off"			{$Capture_Trace="off"; $cap_persistent="no"}
	"on"			{$Capture_Trace="on";  $cap_persistent="persistent=no"}
	"persistent"	{$Capture_Trace="on";  $cap_persistent="persistent=yes"}
	}	

if (( -NOT $RootDom) -or ( -NOT $KnownExtIPAddr))  # use the following paramter if script is run without optional parameters [-RootDom <string>] [-KnownExtIPAddr <IPaddress>]
{
###############################################################################
## customization section of script  
# All optional: # actual setting	 # Example for your config	| Example for Microsoft Company
# ------------- = ------------------ #------------------------- | ------------------------------
$RootDom 		= "microsoft.com" 	 # "corpintra.net" 			| "microsoft.com"
# Known external IP Addr for $RootDom - you may use NSLOOKUP to check the external IP-address for external RootDom.com
$KnownExtIPAddr = "23.96.52.53" 	 # "141.113.97.105" 		| "23.96.52.53"
}
$subDom1    	= "corp" 			 # "subDom1" 				| "corp"
$subDom2    	= "europe"			 # "subDom2"					| "europe" 
$ProbeDom		= "dns.msftncsi.com" # "ProbeDom" 				| "dns.msftncsi.com" # "DnsProbeHost"
$companyName    = "Microsoft" 		 # "companyN" 				| "Microsoft"  
$emailUserName  = ""				 # "Admin1@companyN.com"	| ""
$SmtpServerName = "" 				 # "outlook.office365.com"	| ""
# Number of ping attempts before continuing, the less the faster
$pingcount 		= 1					 # 1 to 4	# number of Ping requests to send per IP - Default 4
[bool]$PingExternalIPs= 1			 # 1 or 0 	# whether to PING external IP adresses
[bool]$ListAllInstalledPrograms = 1	 # 1 or 0 	# To get overview of installed programs, possibly known issues
[bool]$Collect_Evt=1				 # 1 or 0 	# To collect 
[bool]$Collect_PSR=1				 # 1 or 0 	# To collect PSR ProblemStepRecorder Screenshot Recording
# Resulting Logfile Name:
# $Logfile = $env:userprofile + "\Desktop\" + $companyName + "_network_" + $env:computername + "_" + $startscript.ToString('yyyyMMdd_HHmm') + ".log"
$Logfile = $env:USERDNSDOMAIN + "_" + $env:computername + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_NCSI.log"
$LogDebugfile = $env:computername + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_Debug.log"
###############################################################################
$Debug=$True

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}
$global:DebugOutLog = Join-Path $pwd.path $LogDebugfile  #"$env:computername_$([Guid]::NewGuid().ToString(`"n`")).txt"
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber



# Note: Trying to Start this Win32_Product task early while working on pings
$ListInstalledPrograms = Start-Job -scriptblock {Get-WmiObject -Class Win32_Product | sort-object name | Format-Table Name, Version, InstallDate}

# Preference variable to suppress PS progress bar
# Output looks like: parent = -1 id =0 act Loading Active Directoy module...
$ProgressPreference = 'SilentlyContinue'

$UsrName = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
#$computername = $env:computername
#$DnsDom = $env:UserDnsDOMAIN

### Supporting Funtions 
Function LogWrite {
    Param ([string]$logstring, [switch]$verbose, [switch]$error)
    if ($verbose) { #write only to Logfile
		Add-Content $Logfile -value $logstring 
    } elseif ($error) {
		Add-Content $Logfile -value $logstring -PassThru | Write-Host -ForegroundColor red
    } else {
        Add-content $Logfile -value $logstring -PassThru
    }
}

# Function Zip-Files( $zipfilename, $sourcedir )
Function Zip-Files(
        [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$false)]
        [string] $zipfilename,
        [Parameter(Position=1, Mandatory=$true, ValueFromPipeline=$false)]
        [string] $sourcedir,
        [Parameter(Position=2, Mandatory=$false, ValueFromPipeline=$false)]
        [bool] $overwrite)
{
	if ($PSVersionTable.PSVersion.Major -le 2) 
	{ Write-Output "Compression not supported for this PS version: $($PSVersionTable.PSVersion.Major)"}
	else {
		Add-Type -Assembly System.IO.Compression.FileSystem
		$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
		if ($overwrite -eq $true ) { if (Test-Path $zipfilename) { Remove-Item $zipfilename } }
		[System.IO.Compression.ZipFile]::CreateFromDirectory($sourcedir, $zipfilename, $compressionLevel, $false)
	}
}


# Function get-PSversion 
Function get-PSversion {
	$psVersion = $PSVersionTable.PSVersion  
    If($psVersion)  
    { 
        #PowerShell Version Mapping 
        $psVersionMappings = @() 
        $psVersionMappings += New-Object PSObject -Property @{Name='5.1.14393.0';FriendlyName='Windows PowerShell 5.1 Preview';ApplicableOS='Windows 10 Anniversary Update'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.1.14300.1000';FriendlyName='Windows PowerShell 5.1 Preview';ApplicableOS='Windows Server 2016 Technical Preview 5'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10586.494';FriendlyName='Windows PowerShell 5 RTM';ApplicableOS='Windows 10 1511 + KB3172985 1607'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10586.122';FriendlyName='Windows PowerShell 5 RTM';ApplicableOS='Windows 10 1511 + KB3140743 1603'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10586.117';FriendlyName='Windows PowerShell 5 RTM 1602';ApplicableOS='Windows Server 2012 R2, Windows Server 2012, Windows Server 2008 R2 SP1, Windows 8.1, and Windows 7 SP1'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10586.63';FriendlyName='Windows PowerShell 5 RTM';ApplicableOS='Windows 10 1511 + KB3135173 1602'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10586.51';FriendlyName='Windows PowerShell 5 RTM 1512';ApplicableOS='Windows Server 2012 R2, Windows Server 2012, Windows Server 2008 R2 SP1, Windows 8.1, and Windows 7 SP1'}  
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10514.6';FriendlyName='Windows PowerShell 5 Production Preview 1508';ApplicableOS='Windows Server 2012 R2'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.10018.0';FriendlyName='Windows PowerShell 5 Preview 1502';ApplicableOS='Windows Server 2012 R2'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='5.0.9883.0';FriendlyName='Windows PowerShell 5 Preview November 2014';ApplicableOS='Windows Server 2012 R2, Windows Server 2012, Windows 8.1'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='4.0';FriendlyName='Windows PowerShell 4 RTM';ApplicableOS='Windows Server 2012 R2, Windows Server 2012, Windows Server 2008 R2 SP1, Windows 8.1, and Windows 7 SP1'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='3.0';FriendlyName='Windows PowerShell 3 RTM';ApplicableOS='Windows Server 2012, Windows Server 2008 R2 SP1, Windows 8, and Windows 7 SP1'}   
        $psVersionMappings += New-Object PSObject -Property @{Name='2.0';FriendlyName='Windows PowerShell 2 RTM';ApplicableOS='Windows Server 2008 R2 SP1 and Windows 7'}    
        foreach ($psVersionMapping in $psVersionMappings) 
        { 
            If($psVersion -ge $psVersionMapping.Name) { 
                @{CurrentVersion=$psVersion;FriendlyName=$psVersionMapping.FriendlyName;ApplicableOS=$psVersionMapping.ApplicableOS}  
                Break  
            }   
        } 
    } 
    Else{ 
        @{CurrentVersion='1.0';FriendlyName='Windows PowerShell 1 RTM';ApplicableOS='Windows Server 2008, Windows Server 2003, Windows Vista, Windows XP'} 
    }	
}

# Function New-WebClient
function New-WebClient
{
    $wc = New-Object Net.WebClient
 
    $wc.UseDefaultCredentials = $true
    $wc.Proxy.Credentials = $wc.Credentials
 
    $wc.Encoding = [System.Text.Encoding]::UTF8
    $wc.CachePolicy = New-Object System.Net.Cache.HttpRequestCachePolicy([System.Net.Cache.HttpRequestCacheLevel]::NoCacheNoStore)
 
    Write-Output $wc
}
$Global:wc = New-WebClient

# WriteTo-StdOut function
# ---------------------
#Author:
#	pcreehan@microsoft.com
#Last Modified:
#	6/16/2011
#Description:
#	This function is dual purposed. When the $Debug variable is set to $true ("debug mode"), it outputs 
#	pipeline input to the $Host, when $Debug is $false or $null ("normal mode"), then it writes the input 
#	to the stdout.log file.
#Arguments:
#	$ObjectToAdd -	Object to add to the output along with any piped in objects
# 	$ShortFormat -	This switch determines whether piped in objects are separated with line breaks or spaces
#	$IsError - 			In debug mode, it will output in Red, in normal mode, has no effect.
#	$Color - 			Sets the Foreground color of the console output. Ignored in normal (not debug) mode.
# 	$DebugOnly - 	Will not write to stdout.log in normal mode.
#	$PassThru - 	Returns the objects passed in as a string. When combined with $DebugOnly, 
#						useful for capturing data that you intend to write to a file
# 	$InvokeInfo -	[System.Management.Automation.InvocationInfo] You can pass in your own invoke info
#						so that script names, resolve correctly. Useful for wrapping functions in a utility .ps1 file
# 	$AdditionaFileName - Write to both stdout output and to an additional log filename
#
#Aliases:
#	Output-Trace
#	Trace
if($null -eq $global:m_WriteCriticalSection) {$global:m_WriteCriticalSection = New-Object System.Object}
function WriteTo-StdOut
{
	param (
		$ObjectToAdd,
		[switch]$ShortFormat,
		[switch]$IsError,
		$Color,
		[switch]$DebugOnly,
		[switch]$PassThru,
		[System.Management.Automation.InvocationInfo] $InvokeInfo = $MyInvocation,
		[string]$AdditionalFileName = $null,
		[switch]$noHeader)
	BEGIN
	{
		$WhatToWrite = @()
		if ($ObjectToAdd -ne  $null)
		{
			$WhatToWrite  += $ObjectToAdd
		} 
		if(($Debug) -and ($Host.Name -ne "Default Host") -and ($Host.Name -ne "Default MSH Host"))
		{
			if($Color -eq $null)
			{
				$Color = $Host.UI.RawUI.ForegroundColor
			}
			elseif($Color -isnot [ConsoleColor])
			{
				$Color = [Enum]::Parse([ConsoleColor],$Color)
			}
			$scriptName = [System.IO.Path]::GetFileName($InvokeInfo.ScriptName)
		}
		$ShortFormat = $ShortFormat -or $global:ForceShortFormat
	}
	PROCESS
	{
		if ($_ -ne $null)
		{
			if ($_.GetType().Name -ne "FormatEndData") 
			{
				$WhatToWrite += $_ | Out-String 
			}
			else 
			{
				$WhatToWrite = "Object not correctly formatted. The object of type Microsoft.PowerShell.Commands.Internal.Format.FormatEntryData is not valid or not in the correct sequence."
			}
		}
	}
	END
	{
		if($ShortFormat)
		{
			$separator = " "
		}
		else
		{
			$separator = "`r`n"
		}
		$WhatToWrite = [string]::Join($separator,$WhatToWrite)
		while($WhatToWrite.EndsWith("`r`n"))
		{
			$WhatToWrite = $WhatToWrite.Substring(0,$WhatToWrite.Length-2)
		}
		if(($Debug) -and ($Host.Name -ne "Default Host") -and ($Host.Name -ne "Default MSH Host"))
		{
			$output = "[$([DateTime]::Now.ToString(`"s`"))] [$($scriptName):$($MyInvocation.ScriptLineNumber)]: $WhatToWrite"

			if($IsError.Ispresent)
			{
				$Host.UI.WriteErrorLine($output)
			}
			else
			{
				if($Color -eq $null){$Color = $Host.UI.RawUI.ForegroundColor}
				$output | Write-Host -ForegroundColor $Color
			}
			if($global:DebugOutLog -eq $null)
			{
				$global:DebugOutLog = Join-Path $Env:TEMP "$([Guid]::NewGuid().ToString(`"n`")).txt"
			}
			$output | Out-File -FilePath $global:DebugOutLog -Append -Force 
		}
		elseif(-not $DebugOnly)
		{
			[System.Threading.Monitor]::Enter($global:m_WriteCriticalSection)
			
			trap [Exception] 
			{
				WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[Writeto-Stdout]: $WhatToWrite" -InvokeInfo $MyInvocation -SkipWriteToStdout
				continue
			}
			Trap [System.IO.IOException]
			{
				# An exection in this location indicates either that the file is in-use or user do not have permissions. Wait .5 seconds. Try again
				sleep -Milliseconds 500
				WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[Writeto-Stdout]: $WhatToWrite" -InvokeInfo $MyInvocation -SkipWriteToStdout
				continue
			}
			if($ShortFormat)
			{
				if ($NoHeader.IsPresent)
				{
				    $WhatToWrite | Out-File -FilePath $StdOutFileName -append -ErrorAction SilentlyContinue 
					 if ($AdditionalFileName.Length -gt 0)
					 {
					 	$WhatToWrite | Out-File -FilePath $AdditionalFileName -append -ErrorAction SilentlyContinue 
					 }
				}
				else
				{
		             "[" + (Get-Date -Format "T") + " " + $ComputerName + " - " + [System.IO.Path]::GetFileName($InvokeInfo.ScriptName) + " - " + $InvokeInfo.ScriptLineNumber.ToString().PadLeft(4) + "] $WhatToWrite" | Out-File -FilePath $StdOutFileName -append -ErrorAction SilentlyContinue 
					 if ($AdditionalFileName.Length -gt 0)
					 {
					 	"[" + (Get-Date -Format "T") + " " + $ComputerName + " - " + [System.IO.Path]::GetFileName($InvokeInfo.ScriptName) + " - " + $InvokeInfo.ScriptLineNumber.ToString().PadLeft(4) + "] $WhatToWrite" | Out-File -FilePath $AdditionalFileName -append -ErrorAction SilentlyContinue 
					 }
				}
			}
			else
			{
				if ($NoHeader.IsPresent)
				{
	                 "`r`n" + $WhatToWrite | Out-File -FilePath $StdOutFileName -append -ErrorAction SilentlyContinue 
					 if ($AdditionalFileName.Length -gt 0)
					 {
					 	"`r`n" + $WhatToWrite | Out-File -FilePath $AdditionalFileName -append -ErrorAction SilentlyContinue 
					 }
				}
				else
				{
	                 "`r`n[" + (Get-Date) + " " + $ComputerName + " - From " + [System.IO.Path]::GetFileName($InvokeInfo.ScriptName) + " Line: " + $InvokeInfo.ScriptLineNumber + "]`r`n" + $WhatToWrite | Out-File -FilePath $StdOutFileName -append -ErrorAction SilentlyContinue 
					 if ($AdditionalFileName.Length -gt 0)
					 {
					 	"`r`n[" + (Get-Date) + " " + $ComputerName + " - From " + [System.IO.Path]::GetFileName($InvokeInfo.ScriptName) + " Line: " + $InvokeInfo.ScriptLineNumber + "]`r`n" + $WhatToWrite | Out-File -FilePath $AdditionalFileName -append -ErrorAction SilentlyContinue 
					 }
				}
			}
			[System.Threading.Monitor]::Exit($global:m_WriteCriticalSection)
		}
		if($PassThru)
		{
			return $WhatToWrite
		}
	}
}
Filter WriteTo-ErrorDebugReport
(
	[string] $ScriptErrorText, 
	[System.Management.Automation.ErrorRecord] $ErrorRecord = $null,
	[System.Management.Automation.InvocationInfo] $InvokeInfo = $null,
	[switch] $SkipWriteToStdout
)
{
	trap [Exception] 
	{
		$ExInvokeInfo = $_.Exception.ErrorRecord.InvocationInfo
		if ($ExInvokeInfo -ne $null)
		{
			$line = ($_.Exception.ErrorRecord.InvocationInfo.Line).Trim()
		}
		else
		{
			$Line = ($_.InvocationInfo.Line).Trim()
		}
		if (-not ($SkipWriteToStdout.IsPresent))
		{
			"[WriteTo-ErrorDebugReport] Error: " + $_.Exception.Message + " [" + $Line + "].`r`n" + $_.StackTrace | WriteTo-StdOut
		}
		continue
	}
	if (($ScriptErrorText.Length -eq 0) -and ($ErrorRecord -eq $null)) {$ScriptErrorText=$_}
	if (($ErrorRecord -ne $null) -and ($InvokeInfo -eq $null))
	{
		if ($ErrorRecord.InvocationInfo -ne $null)
		{
			$InvokeInfo = $ErrorRecord.InvocationInfo
		}
		elseif ($ErrorRecord.Exception.ErrorRecord.InvocationInfo -ne $null)
		{
			$InvokeInfo = $ErrorRecord.Exception.ErrorRecord.InvocationInfo
		}
		if ($InvokeInfo -eq $null)
		{			
			$InvokeInfo = $MyInvocation
		}
	}
	elseif ($InvokeInfo -eq $null)
	{
		$InvokeInfo = $MyInvocation
	}
	$Error_Summary = New-Object PSObject
	if (($InvokeInfo.ScriptName -ne $null) -and ($InvokeInfo.ScriptName.Length -gt 0))
	{
		$ScriptName = [System.IO.Path]::GetFileName($InvokeInfo.ScriptName)
	}
	elseif (($InvokeInfo.InvocationName -ne $null) -and ($InvokeInfo.InvocationName.Length -gt 1))
	{
		$ScriptName = $InvokeInfo.InvocationName
	}
	elseif ($MyInvocation.ScriptName -ne $null)
	{
		$ScriptName = [System.IO.Path]::GetFileName($MyInvocation.ScriptName)
	}
	$Error_Summary_TXT = @()
	if (-not ([string]::IsNullOrEmpty($ScriptName)))
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Script" -Value $ScriptName 
	}
	if ($InvokeInfo.Line -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Command" -Value ($InvokeInfo.Line).Trim()
		$Error_Summary_TXT += "Command: [" + ($InvokeInfo.Line).Trim() + "]"
	}
	elseif ($InvokeInfo.MyCommand -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Command" -Value $InvokeInfo.MyCommand.Name
		$Error_Summary_TXT += "Command: [" + $InvokeInfo.MyCommand.Name + "]"
	}
	if ($InvokeInfo.ScriptLineNumber -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Line Number" -Value $InvokeInfo.ScriptLineNumber
	}
	if ($InvokeInfo.OffsetInLine -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Column  Number" -Value $InvokeInfo.OffsetInLine
	}
	if (-not ([string]::IsNullOrEmpty($ScriptErrorText)))
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Additional Info" -Value $ScriptErrorText
	}
	if ($ErrorRecord.Exception.Message -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Error Text" -Value $ErrorRecord.Exception.Message
		$Error_Summary_TXT += "Error Text: " + $ErrorRecord.Exception.Message
	}
	if($ErrorRecord.ScriptStackTrace -ne $null)
	{
		$Error_Summary | Add-Member -MemberType NoteProperty -Name "Stack Trace" -Value $ErrorRecord.ScriptStackTrace
	}
	$Error_Summary | Add-Member -MemberType NoteProperty -Name "Custom Error" -Value "Yes"
	if ($ScriptName.Length -gt 0)
	{
		$ScriptDisplay = "[$ScriptName]"
	}
	$Error_Summary | ConvertTo-Xml | update-diagreport -id ("ScriptError_" + (Get-Random)) -name "Script Error $ScriptDisplay" -verbosity "Debug"
	if (-not ($SkipWriteToStdout.IsPresent))
	{
		"[WriteTo-ErrorDebugReport] An error was logged to Debug Report: " + [string]::Join(" / ", $Error_Summary_TXT) | WriteTo-StdOut -InvokeInfo $InvokeInfo -ShortFormat -IsError
	}
	$Error_Summary | fl * | Out-String | WriteTo-StdOut -DebugOnly -IsError
}
 
# Function: Validation of DNS request
Function validatedns([string]$dnsrequest, [IPAddress]$knownip) {
    try {
    $addresslist = [Net.DNS]::GetHostEntry($dnsrequest)
    }
    catch {
        LogWrite "DNS request failed" -error
    }
    foreach ($address in $addresslist) {
        if ($address.addresslist -eq $knownip) {
            LogWrite "DNS request to $dnsrequest matched known IP: $($knownip.ToString())" -PassThru | Write-Host  -ForegroundColor green
        } Else {
            LogWrite "DNS request to $dnsrequest did not match known IP: $($knownip.ToString())" -error
        }
    }
}

# Simplified ping Function using Powershell Test-Connection
Function ping($target) {
 # Test-Connection - Sends ICMP echo request packets ("pings") to one or more computers.
 $test = Test-Connection -ComputerName $target -q -count $pingcount 
 if ($test) {
  LogWrite "Ping to $target is successful" -PassThru | Write-Host  -ForegroundColor green
 } Else {
  LogWrite "Error: Ping to $target failed" -error
 }
}

# Test DNS Settings
Function dnstest($domainname) {
 try {
  $addresslist = [Net.DNS]::GetHostEntry($domainname)
  LogWrite "____DNS list of addresses for $domainname"

  foreach ($ip in $addresslist.AddressList.Ipaddresstostring) {
   ping($ip)
  }
        LogWrite
 }
 catch {
  LogWrite "DNS lookup failed for $domainname" -error
        LogWrite
 }
}


#### main ####
LogWrite "Network Tracing is: $Capture_Trace - Persistent: $cap_persistent " 
LogWrite "====================================================================="
LogWrite "Date of test:	$($startscript.ToString('F'))"
LogWrite "Computer: 	$env:COMPUTERNAME  - by User: $UsrName"
LogWrite "DNS Domain: 	$env:USERDNSDOMAIN "

#Capture computer information
#OS version, WINS version
$windowsversion = [System.Environment]::OSVersion.Version.ToString()
LogWrite "Windows Version: $windowsversion"

#$PSversion = Get-Host | Select-Object Version 
#$PSversion = get-PSversion

## output customization section
LogWrite " companyName    : $companyName "  
LogWrite " RootDom        : $RootDom " 
LogWrite " KnownExtIPAddr : $KnownExtIPAddr " 
LogWrite " subDom1        : $subDom1 " 	
LogWrite " subDom2        : $subDom2 " 	
LogWrite " ProbeDom       : $ProbeDom " 
LogWrite " PingCount      : $pingcount "
LogWrite " Capture_Trace  : $Capture_Trace " 
LogWrite "Powershell version: "
get-PSversion 
LogWrite "====================================================================="

### Start Collecting PSR screenshots
if ($Collect_PSR=1) { 
	LogWrite "$(Get-Date -UFormat "%R:%S") === Starting PSR screenshots ================================"
	LogWrite  ( cmd /c START psr.exe /start /output %computername%_psr_Recording.zip /gui 1 /sc 1  2>&1 )
	}
	
### Start collect network trace
if ($Capture_Trace -ieq 'on') {
	LogWrite "$(Get-Date -UFormat "%R:%S") === start network trace ===============================" 
	# $cap_persistent ="persistent=no"
	if ($bn -ge 7600) {  # > Windows 7
	 if ($bn -le 9600) { # < Windows 8.1
	  LogWrite  ( netsh trace start capture=yes $($cap_persistent) scenario=InternetClient,nid_wpp overwrite=yes maxsize=512 tracefile=_$($env:computername)_trace.etl provider="Microsoft-Windows-WinHttp" keywords=0xffffffffffffffff level=0xff provider="Microsoft-Windows-WebIO" keywords=0xffffffffffffffff level=0xff 2>&1 ) }
	 else {	# Windows 10+
	  LogWrite  ( netsh trace start capture=yes $($cap_persistent) InternetClient_dbg,nid_wpp overwrite=yes maxsize=512 tracefile=_$($env:computername)_trace.etl provider="Microsoft-Windows-WinHttp" keywords=0xffffffffffffffff level=0xff provider="Microsoft-Windows-WebIO" keywords=0xffffffffffffffff level=0xff 2>&1 ) }
	}
}

# $winsversion = (Get-ItemProperty 'HKLM:\SOFTWARE\$companyName Versions\WINS\Version').versionnumber + '.' + (Get-ItemProperty 'HKLM:\SOFTWARE\$companyName Versions\WINS\Version').pointnumber
# LogWrite "$companyName WINS version: $winsversion"

LogWrite 
LogWrite "$(Get-Date -UFormat "%R:%S") === Status of NLA service =================================="
 #$network_awareness = Get-Service "network location awareness" | Select-Object status, name, displayname, starttype | Format-List
 $network_awareness = Get-Service "network location awareness" | Format-List
 LogWrite ($network_awareness | Out-String)

### Capture Windows Firewall Settings
 $win_firewall = netsh advfirewall monitor show firewall
 if ($win_firewall | Select-String "make sure that the service is running") {
  LogWrite "Windows Firewall is correctly not enabled"
 } Else {
  LogWrite "$(Get-Date -UFormat "%R:%S") === Windows Firewall Settings ============================="
  LogWrite "Windows Firewall Settings"
  LogWrite ($win_firewall | Select-String Categories -Context 0,4 | Out-String)
  LogWrite ($win_firewall | Select-String Profile -Context 0,4 | Out-String)
 }

# Good response example:
# Categories:
# BootTimeRuleCategory                  McAfee Host Intrusion Prevention Firewall
# FirewallRuleCategory                  McAfee Host Intrusion Prevention Firewall
# StealthRuleCategory                   McAfee Host Intrusion Prevention Firewall
# ConSecRuleRuleCategory                Windows Firewall
# 
# Domain Profile Settings:
# ------------------------------------------
# State                                 OFF


### Capture network adapter settings
LogWrite "$(Get-Date -UFormat "%R:%S") === Network adapter Settings ================================"
$addresses = Get-WmiObject -Class win32_networkadapterconfiguration 
$gwaddresses = $addresses | ForEach-Object {if ($_.defaultipgateway) {$_}}
LogWrite ($gwaddresses | Out-String)

### DHCP Settings including lease time
LogWrite "$(Get-Date -UFormat "%R:%S") === DHCP adapters ==========================================="
$dhcpadapters = $addresses | ForEach-Object {if ($_.dhcpenabled -And $_.ipaddress) {$_}}

# Convert CIM_Datetime to Date
# https://social.technet.microsoft.com/Forums/scriptcenter/en-US/5e73e100-f955-45e1-b7b2-98afdd3e3aa9/powershell-convert-stringvalue-like-20120626141935730000000-to-datetime?forum=ITCG
foreach ($dhcpadapter in $dhcpadapters) {
 $dhcpexpires = [Management.ManagementDateTimeConverter]::ToDateTime($dhcpadapter.DHCPLeaseExpires)
 $dhcpobtained = [Management.ManagementDateTimeConverter]::ToDateTime($dhcpadapter.DHCPLeaseObtained)
 $ipaddress = $dhcpadapter.ipaddress
 LogWrite "DHCP of $ipaddress Expires: $($dhcpexpires.ToString('F'))"
 LogWrite "DHCP of $ipaddress Obtained: $($dhcpobtained.ToString('F'))"
    LogWrite 
}

### Test network stack
LogWrite "$(Get-Date -UFormat "%R:%S") === Network stack ==========================================="
LogWrite "__Testing network stack, Ping 127.0.0.1"
ping("127.0.0.1")

# Ping default Gateway
# Can't ping vpn default gateway
LogWrite "__runnning PING tests for default Gateway"
foreach($address in $gwaddresses) {ping($address.defaultipgateway)}

# Test IP connectivity of Internet Sites
if ($PingExternalIPs) {
	LogWrite "__runnning PING tests for external IP-adresses and Internet Sites"
	ping("8.8.8.8")
	ping("8.8.4.4")
	ping("google.com")

	LogWrite "__runnning DNS tests for configured $RootDom and external domain names"
	dnstest("$RootDom")
	dnstest("microsoft.com")
	dnstest("portal.office.com")
	dnstest("google.com")
	dnstest("scribd.com")
	LogWrite "__runnning DNS tests for Standard Microsoft dns.msftncsi.com and www.msftncsi.com"
	dnstest("dns.msftncsi.com")
	dnstest("www.msftncsi.com")
}

LogWrite "__runnning PING tests for script configured sub domain names '$subDom2.$subDom1.$RootDom' "
if ($subDom1 -ne "") {ping("$subDom1.$RootDom")
 if ($subDom2 -ne "") {ping("$subDom2.$subDom1.$RootDom")}}
if ($ProbeDom -ne "") {ping("$ProbeDom")}


LogWrite
LogWrite "__Validate company DNS for: $RootDom for known IP address: $KnownExtIPAddr"
validatedns "$RootDom" "$KnownExtIPAddr"
LogWrite

# focus on NCSI settings which are used to determine Microsoft Windows
# Yellow triangle for network issues

LogWrite "$(Get-Date -UFormat "%R:%S") === NCSI tests =============================================="
LogWrite "__Now Duplicating Windows NCSI yellow triangle tests"
LogWrite


### Capture workstation settings
# Read registry entries for NCSI Settings
$NCSIsettings = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\services\NlaSvc\Parameters\Internet
$SWncsisettings = Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator

# Read IP address
$addresses = Get-WmiObject -Class win32_networkadapterconfiguration 
$gwaddresses = $addresses | ForEach-Object {if ($_.defaultipgateway) {$_}}

# Global Variables
$activeWebHost = $NCSIsettings.ActiveWebProbeHost
$activeWebPath = $NCSIsettings.ActiveWebProbePath
$knownWebContent = $NCSIsettings.ActiveWebProbeContent
$activeProbe_enabled = $NCSIsettings.EnableActiveProbing
$DnsProbeHost = $NCSIsettings.ActiveDnsProbeHost
$DnsProbeContent = $NCSIsettings.ActiveDnsProbeContent


######## Test 1 Function
# Check EnableActiveProbing=1 Registry Setting
Function ActiveProbe_isEnabled($activeprobe) {
 if ($activeprobe) {
		$result = "Yes" 
        return $result 
 }
 Else {
		$result = "Test1 Error: EnableActiveProbing setting is disabled. ActiveProbe Setting: $activeprobe"
        return $result
 }
}

######## Test 2 Function (used in Test 2 and 4)
# Check DNS query against known IP address
Function test_DNS([string]$hostname, [IPAddress]$knownip) {
    try {
		$addresslist = [Net.DNS]::GetHostEntry($hostname)
    }
    catch {
        $result = "Error: DNS lookup failed for $hostname. IP: $($gwaddresses.ipaddress | Out-String -Stream) DNS: $($gwaddresses.DnsServerSearchOrder | Out-String -Stream)"
        return $result
		return
    }
	if ($knownip) {
		foreach ($address in $addresslist) {
          if ($address.addresslist -eq $knownip) {
                    $result = "Success: KnownIP '$knownip' "
					return $result 
          } Else {
			$result = "Error: DNS request to $hostname at $($address.addresslist.IPaddresstostring) did not match known IP: $($knownip.ToString()) PC IP: $($gwaddresses.ipaddress | Out-String -Stream) DNS: $($gwaddresses.DnsServerSearchOrder | Out-String -Stream)"
			return $result
			}
		}
	} Else {
        $result = "Success: HostName '$hostname' "
		return $result
	}
}

######## Test 3 and Test 4 Function
# Check Web probe for known content
Function test_WebProbe ([string]$webserver, [string]$path, [string]$ExpectedContent) {
 $uri = "http://" + $webserver + '/' + $path
 if ($bn -le 9200) { # < Windows 8.1
	$webrequest = (New-Object Net.WebClient).DownloadString($uri)
	$ActualContent=$webrequest
	}
 else {	#Invoke-WebRequest cmdlet is introduced in Windows PowerShell 3.0. 
	$webrequest = Invoke-WebRequest -Uri $uri
	$ActualContent=$webrequest.content
	}
 
 if ($ActualContent -eq $ExpectedContent) {
    $result = "Success: $($ActualContent)"
  return $result
 } Else {
     $result = "Error: Web Request content, ""$($webrequest.content)"" does not match known content: ""$ExpectedContent"" IP: $($gwaddresses.ipaddress | Out-String -Stream) DNS: $($gwaddresses.DnsServerSearchOrder | Out-String -Stream)"
        return $result
 }
}

# Now actually performing Test 1-5 Functions
### Test 1
# Check IP address for ping to return where failures occur
# Check to see if computer is set to actively probe NCSI
    LogWrite "__Test 1: Check EnableActiveProbing Setting enabled"
	$result1 = ActiveProbe_isEnabled($activeProbe_enabled)
 	LogWrite "	Result1: '$result1' " -PassThru | Write-Host  -ForegroundColor green

### Test 2
# Check DNS against www.msftncsi.com
if ($result1 -eq "Yes") {
	# first step NCSI performs is a DNS query for www.msftncsi.com
	LogWrite "__Test 2: Check DNS against WebProbeHost '$activeWebHost' "
    $result2 = test_DNS($activeWebHost) 
	LogWrite "	Result2: '$result2' " -PassThru | Write-Host  -ForegroundColor green
}

### Test 3 www.msftncsi.com (Win10: www.msftconnecttest.com)
# Check Web probe for known Web content
# "second step is and HTTP get request for http://www.msftncsi.com/ncsi.txt"
if ($result2 -match "Success") {
	LogWrite "__Test 3: Check Web probe for active http://'$activeWebHost'/'$activeWebPath' known WebContent: '$knownWebContent' "
    $result3 = test_WebProbe $activeWebHost $activeWebPath $knownWebContent
	LogWrite "	Result3: '$result3' " -PassThru | Write-Host  -ForegroundColor green
}

### Test 4 -Check DNS query for '$DnsProbeHost' 
if ($result3 -match "Success") {
	# "Last it will perform a DNS query for dns.msftncsi.com."
	LogWrite "__Test 4: Check DNS query against DnsProbeHost '$DnsProbeHost' '$DnsProbeContent' "
    $result4 = test_DNS $DnsProbeHost $DnsProbeContent
	LogWrite "	Result4: '$result4' " -PassThru | Write-Host  -ForegroundColor green
}

LogWrite "***NCSI Results: '$result4' ***" -PassThru | Write-Host  -ForegroundColor green
LogWrite

### Test 5 - DNS lookup for ActiveWebProbeHost:
LogWrite "__DNS lookup for list in addresses for ActiveWebProbeHost"
LogWrite "__Test 5 - DNS lookup for ActiveWebProbeHost: '$($NCSIsettings.ActiveWebProbeHost)' " 
	dnstest($NCSIsettings.ActiveWebProbeHost)

### Test 6 - DNS lookup for Microst WebProbeHost:
LogWrite "__Test 6 - Web probe for 'www.msftconnecttest.com' and 'www.msftncsi.com' " 
LogWrite "___Check Web probe for http://'www.msftconnecttest.com'/'connecttest.txt' known WebContent: 'Microsoft Connect Test' "
	$result6a = test_WebProbe www.msftconnecttest.com connecttest.txt 'Microsoft Connect Test'
LogWrite "	Result6a: '$result6a'" -PassThru | Write-Host  -ForegroundColor green
LogWrite "___Check Web probe for http://'www.msftncsi.com'/'ncsi.txt' known WebContent: 'Microsoft NCSI' "
	$result6b = test_WebProbe www.msftncsi.com ncsi.txt 'Microsoft NCSI'
LogWrite "	Result6b: '$result6b'" -PassThru | Write-Host  -ForegroundColor green

#### Write out long parts to the log file
LogWrite -verbose
LogWrite "$(Get-Date -UFormat "%R:%S") === NCSI settings ============================================" -verbose
LogWrite "Output of computer Registry details" -verbose
LogWrite "__Output of NCSI NLA settings" -verbose
LogWrite ($NCSIsettings | Out-String -Width 1024) -verbose
LogWrite "__Output of NCSI Software settings" -verbose
LogWrite ($SWncsisettings | Out-String -Width 1024) -verbose

LogWrite "__Output of GW adresses" -verbose
LogWrite ($gwaddresses | format-list * | Out-String) -verbose

### Add a list of installed programs
if ( $ListAllInstalledPrograms) {
 # This adds an additional 30 seconds to the script
 LogWrite " "
 Write-Verbose "ListAllInstalledPrograms: $ListAllInstalledPrograms"
 # Loop through a message until WMI call started at the beginning finishes
 LogWrite "$(Get-Date -UFormat "%R:%S") === Installed Programs =====================================" -verbose
 LogWrite "Collecting all installed programs" | Write-Host -NoNewLine
 While ($ListInstalledPrograms.JobStateInfo.State -ne "Completed") {
	Write-Host '.' -nonewline
	Start-Sleep -milliseconds 500
 }
 LogWrite (Receive-Job -job $ListInstalledPrograms | Out-String -Width 1024)  -verbose
 #|Out-file $Logfile -Append -Encoding String -Width 1024
 Write-verbose "ListAllInstalledPrograms_Done " 
}
	
### Add-content $Logfile -value $win_firewall #long format for file to LogFile
LogWrite "$(Get-Date -UFormat "%R:%S") === Firewall ================================================" -verbose
LogWrite "___Output of Win Firewall details" -verbose
LogWrite ($win_firewall | Out-String) -verbose

### Add-content Registry Settings to LogFile
LogWrite "$(Get-Date -UFormat "%R:%S") === Registry ================================================" -verbose
LogWrite "___Output of Registry System NlaSvc\Parameters\Internet" -verbose
$RegNLA  = reg query HKLM\System\CurrentControlSet\services\NlaSvc\Parameters\Internet /s
LogWrite ($RegNLA | Out-String) -verbose
LogWrite "___Output of Registry Software NetworkConnectivityStatusIndicator" -verbose
$RegNCSI = reg query HKLM\Software\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator /s
LogWrite ($RegNCSI | Out-String) -verbose

### Stop Collecting PSR screenshots
if ($Collect_PSR=1) { 
	LogWrite "$(Get-Date -UFormat "%R:%S") === Stopping PSR screenshots================================="
	LogWrite  ( psr.exe /stop  2>&1 )
	}

### Collect network trace
if ($Capture_Trace -ieq 'on') {
	LogWrite
	LogWrite "$(Get-Date -UFormat "%R:%S") === end network trace =======================================" #-NewLine
	LogWrite " Generating trace data collection... please be patient..."
	LogWrite  ( NETSH TRACE STOP 2>&1 )
	if ($cap_persistent -ieq "persistent=yes") {LogWrite "NETSH Trace capture is enabled across reboot! To stop tracing session after reboot run: 'NETSH TRACE STOP'"}
	}

### Collect Network Location Awareness, NCSI, System and Application EventLog
if ($Collect_Evt) {
	LogWrite
	LogWrite "$(Get-Date -UFormat "%R:%S") === Network Location Awareness EventLogs ====================" #-verbose
	LogWrite "_Collecting Network Location Awareness EventLog"
	$OutEvtNlaSvc= $env:ComputerName  + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_evt_NlaSvc-Operational.evtx"
	$OutEvtNCSI= $env:ComputerName  + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_evt_NCSI-Operational.evtx"
	$OutEvtSystem= $env:ComputerName  + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_evt_System.evtx"
	$OutEvtApp= $env:ComputerName  + "_" + $startscript.ToString('yyyyMMdd_HHmm') + "_evt_Application.evtx"	
	wevtutil export-log Microsoft-Windows-NlaSvc/Operational $OutEvtNlaSvc
	wevtutil export-log Microsoft-Windows-NCSI/Operational $OutEvtNCSI
	wevtutil export-log System $OutEvtSystem
	wevtutil export-log Application $OutEvtApp
	}
	
LogWrite " "
LogWrite "$(Get-Date -UFormat "%R:%S") === More Information ========================================" 
LogWrite "For More Information:"
LogWrite "See https://blogs.technet.microsoft.com/networking/2012/12/20/the-network-connection-status-icon/"
LogWrite "and "
LogWrite "Appendix H: Network Connectivity Status Indicator and Resulting Internet Communication in Windows 7 and Windows Server 2008 R2 http://technet.microsoft.com/en-us/library/ee126135(v=WS.10).aspx"
LogWrite " "

$endscript = Get-Date
$script_time = (New-TimeSpan -Start $startscript -End $endscript).seconds
LogWrite "Script v$ScriptVersion Execution duration: $script_time seconds"

### Send email
if ($SmtpServerName -ne "") {
LogWrite "$(Get-Date -UFormat "%R:%S") === Send per Email  =========================================" 
	Send-MailMessage -To $emailUserName -subject "Network Issues" -Body "Here is the report" -Attachments $Logfile -From "$emailUserName" -SmtpServer $SmtpServerName -UseSsl }

### Zip file if PowerShell v3 or higher is installed
if ($PSVersionTable.PSVersion.Major -gt 2) {
	LogWrite "$(Get-Date -UFormat "%R:%S") === Zip Data ================================================" 
	$OutputFileZip = join-path $pwd.path ($env:USERDNSDOMAIN + "_" + $env:ComputerName + "_" +$startscript.ToString('yyyyMMdd_HHmm')+ "_NCSI.zip")
	#$zipdir = join-path $pwd.path ("_NCSI_out") # $env:TEMP
	$zipdir = join-path $env:TEMP ("_NCSI_out") # $env:TEMP
	if (-NOT (Test-Path $zipdir)) {new-item -path $zipdir -type directory |out-null}
	Copy-Item $Logfile $zipdir -Force #-Exclude '*.zip'
	if ($Capture_Trace -ieq 'on') {Move-Item _*trace.* $zipdir -Force}
	if ($Collect_Evt) {Move-Item *_evt_*.* $zipdir -Force}
	if ($Collect_PSR) {Move-Item $env:ComputerName_psr*.* $zipdir -Force}
	Zip-Files -zipfilename $OutputFileZip -sourcedir $zipdir -Verbose -overwrite $true
	Remove-Item $zipdir -Force -Recurse
	Write-host -BackgroundColor Black -ForegroundColor Gray "Logfile zipped to $OutputFileZip"
}
else {
	Write-host -BackgroundColor Black -ForegroundColor Gray "Logfile is here: $Logfile"
}

LogWrite
if ($cap_persistent -ieq "persistent=yes") {LogWrite "NETSH Trace capture is enabled across reboot! To stop tracing session after reboot run: 'NETSH TRACE STOP'" -PassThru | Write-Host  -ForegroundColor green }
LogWrite

#Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force 
 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
if ($PSVersionTable.PSVersion.Major -gt 2) { Unblock-File -Path NCSI_detect_Company.ps1 -ErrorAction SilentlyContinue }
 Write-Host -ForegroundColor Gray "... [Info] in case you see any red error messages regarding script signing, open an Admin Powershell CMD and run this command first:
 	 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

 	 " 
LogWrite

#===all done ================================================================
# In addition please collect a SDP report 'Network Diagnostics' to verify the ProxyConfiguration
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCASi0yk+tAk5Vf4
# WzQETlg+wSxrNwjmBh4UynGBu6POw6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg0J7OIF0Z
# iAgiz2mTyx+iyidajtOBQWOlo5Lqg7c9nKQwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAAJ5YzSbvZlTXyqrUVOvDz54ZsSs8Ut1PZDGRUNkADsmzjFQoxtsevJN
# UVO7LvIvaPiPYhmLguE9HD+tAiAJ42RGVGg+huRs45B20ZWbsy1NG5uMuuB+Fe5c
# DWJtfVIup380LIT0IQ+zZ0Dwp4Svr0PPIYixx1p7eH9P1s5ltdedagQl76Te/s3j
# l3DUTHxQMFmiYlQasGYDkjOJroViD66yNvRNosCSc56gPUNpx9JWGGtzRI37LPdD
# QNlAvZ0Ywr3b5BXZf6l3hyKtSXOMIp7p7dFymE0rSyfJ3FQDDJUkjEhq03h76d6X
# v0JpCQFbv2nRy5rSJSsqohVEnujZNx6hghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgQWJqbtK0QCflOhxl14vJxnlFn1oEAh7XwYrcf5cB00cCBmCJ5j2p
# GBgTMjAyMTA1MTkyMjIxNTQuMjYyWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3
# N0YtRTM1Ni01QkFFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFenSnHX4cFoeoAAAAAAV4wDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE5WhcNMjIwNDExMTkwMjE5WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3N0YtRTM1Ni01QkFF
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmtMjg5B6GfegqnbO6HpY/ZmJv8PHD+ys
# t57JNv153s9f58uDvMEDTKXqK8XafqVq4YfxbsQHBE8S/tkJJfBeBhnoYZofxpT4
# 6sNcBtzgFdM7lecsbBJtrJ71Hb65Ad0ImZoy3P+UQFZQrnG8eiPRNStc5l1n++/t
# OoxYDiHUBPXD8kFHiQe1XWLwpZ2VD51lf+A0ekDvYigug6akiZsZHNwZDhnYrOrh
# 4wH3CNoVFXUkX/DPWEsUiMa2VTd4aNEGIEQRUjtQQwxK8jisr4J8sAhmdQu7tLOU
# h+pJTdHSlI1RqHClZ0KIHp8rMir3hn73zzyahC6j3lEA+bMdBbUwjQIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFKpyfLoN3UvlVMIQAJ7OVHjV+B8rMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAH8h/FmExiQEypGZeeH9WK3ht/HKKgCWvscnVcNIdMi9
# HAMPU8avS6lkT++usj9A3/VaLq8NwqacnavtePqlZk5mpz0Gn64G+k9q6W57iy27
# dOopNz0W7YrmJty2kXigc99n4gp4KGin4yT2Ds3mWUfO/RoIOJozTDZoBPeuPdAd
# BLyKOdDn+qG3PCjUChSdXXLa6tbBflod1TNqh4Amu+d/Z57z0p/jJyOPJp80lJSn
# +ppcGVuMy73S825smy11LE62/BzF54c/plphtOXZw6VrhyiSI9T4FSMhkD+38hl9
# ihrMwaYG0tYUll0L0thZaYsuw0nZbbWqR5JKkQDDimYwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3N0YtRTM1Ni01
# QkFFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQBWSY9X/yFlVL0XNu2hfbHdnbFjKqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9q1TAiGA8y
# MDIxMDUxOTE0NDU0MVoYDzIwMjEwNTIwMTQ0NTQxWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT2rVAgEAMAoCAQACAiRUAgH/MAcCAQACAhFFMAoCBQDkULxVAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEA044nNoyk3hfJ/fzSLaOOr2IcFP1l
# PEZXX4oW2DVIidqI3k3q/MaP138ogXo/Fo7Y9rk+e4p2XAtlZR2aQo37r8o7blYF
# jf/JiLMaB272QpTdMpd0ksCGITa0ehLdM0RCW0aCmPsTWGa3ndRa3+S3wendZX4A
# GKYMQd2Vc2ZUvocxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAV6dKcdfhwWh6gAAAAABXjANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCMrrs5
# SzdHvPOCwSr2vFUi9IexQgGCv9o/mZOx0W1i4zCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIH7lhOyU1JeO4H7mZANMpGQzumuR7CFed69eku/xEtPiMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFenSnHX4cFoeoA
# AAAAAV4wIgQgSfjnG/EsdsrYyb1Kr/7sa+Jxz0wPHrEOZGUHjx6fcmQwDQYJKoZI
# hvcNAQELBQAEggEAhNlL0UZIlpXeEweicjFtX9mE7r7QvNC94lzXHEW+IQYSgLMx
# R9QTlTtW/372olgnUtD8F1N0nTBVdjk+LUuIbrOL2YGIFkT5k5bsO2CFRR7QDNR4
# uqBJEps7xQeAKG3WShhv2kHgvIHL5uGsn0dSIrbhTCHKNyMAXQmHXNRIF7lmQKIc
# XqtmN//kP8tHaKKysVtjpTpH4A8cwDMJ+CVfy9WYZhKEOvBv+Svts5BmeUEcBgu8
# AXRn96PoAPrJMAi57QZw9Kg7TwzwIXtHcpESd4APCw2DKeITFylXklBAzHttIEwf
# xyfe/oJNLVphfeV8i8DVkF4Baj7dqIOGpC2RtQ==
# SIG # End signature block
