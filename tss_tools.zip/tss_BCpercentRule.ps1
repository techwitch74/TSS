<# File tss_BCpercentRule.ps1 [Folderpath BCpercentNr]
#>

<#
.SYNOPSIS
1. Get the Size of the system Disk
2. Get the Size of the BC DataCache
Script will return $TRUE if the datacache is i.e. 120% over the configured 5% limit.

.DESCRIPTION  

The first mechanism should shrink the DataCache once the datacache is 120% over the configured 5% limit.
The second mechanism should shrink the DataCache once the datacache is 180% over the configured limit.
 Defaults: OversizedCacheSizeThresholdPercent=120%, OversizedCacheSizeOnDiskThresholdPercent=180%
Script will throw [WARNING] if the number of *.dat files in any PeerDistRepub subfolder exceeds 1024

.NOTES

.PARAMETER BCpercentNr
	Specify the percentage number over configured limit to watch for, i.e. 120 or 180
	Default is 180%, BC shrinking will kick in within 30 minutes after the 180% limit breached
.PARAMETER	NrOfDatFilesLimit
	Stop when the limit for number of *.dat files below C:\Windows\ServiceProfiles\NetworkService\AppData\Local\PeerDistRepub\Store\0\ is reached.
	Default is 1024
.PARAMETER Folderpath
 	Specify the path to the output folder, i.e. "C:\MS_DATA" will store logfile in C:\MS_DATA\ComputerName__BCpercentCheck.txt"
	Default is current folder
.PARAMETER ServerName
	\\ServerName where to finally copy the resulting logfile
.PARAMETER ShareName
	\ShareName where to finally copy the resulting logfile
	
.EXAMPLE
.\tss_BCpercentRule.ps1 -BCpercentNr "120" -Folderpath "C:\MS_DATA"
	Example 1: will check if BC datacache is 120% over the configured 5% limit and logfile in C:\MS_DATA
#>

param(
	[string]$Folderpath = (Split-Path $MyInvocation.MyCommand.Path -Parent),
	$BCpercentNr = "180",			# Condition#1: percentage over configured BC cache size
	$NrOfDatFilesLimit = "1024",	# Condition#2: kb4565457 - NrOfDatFiles exceeds 1024
	$ServerName = "LocalHost",		# where to finally copy the resulting logfile
	$ShareName  = "Contoso-Share"	# "
)

#region  ::::: Configruation parameters ----------------------------------------------#
$VerDate = "2020.09.03.0"

$ForTesting = $FALSE 				# $TRUE or $FALSE , used for testing only
if ($ForTesting -eq $TRUE) { $NrOfDatFilesLimit = "163"} # for testing only
#endregion ::::: Configruation parameters --------------------------------------------#

#region  [Initialisations] -----------------------------------------------------------#
$ErrorActionPreference = "Stop"
Get-Command -Module BranchCache | Out-Null

$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")

$BClogfile = $Folderpath +"\"+ $ENV:ComputerName + "__BC-" + $BCpercentNr + "percentCheck.txt"
$BClogfileArchive =  $ENV:ComputerName + "__BCpercentCheck_" + $CheckDate + ".txt"
$SharePath = "\\" + $ServerName + "\" + $ShareName
if (Test-Path $SharePath) {$CentralPath = $SharePath} else {$CentralPath = $Folderpath}
$BCcentralLogFile      = $CentralPath + "\BranchCache_" + $BCpercentNr + "-percent_or_DatNr-" + $NrOfDatFilesLimit + "_" +$($env:COMPUTERNAME) + ".log"
$ClearedCentralLogFile = $CentralPath + "\BranchCache_" + $BCpercentNr + "_cleared_" + $($env:COMPUTERNAME) + ".log"
$Global:ErrorFlag = $FALSE
[int64]$Global:BreachAsNumberOfBytes = 0
#endregion  [Initialisations] --------------------------------------------------------#

Write-verbose "Central LogPath: $BCcentralLogFile"
Write-verbose "Temp LogPath:    $BClogfile"

#region  ::::: [Functions] -----------------------------------------------------------#
function Write_Transcript ($Content) {"$(Get-date -Format G) | $($Content)" | Out-File $BClogfile -Append}

function Check-LogSize {
    #Checking the log size and renaming when over max size. 
    Write-verbose "Starting BC Log Size check"
    $file = Get-ChildItem $BClogfile
    [int]$fileSize = ($file | Measure-Object -Sum Length).Sum / 1KB
	Write_Transcript "BC Log-File Size : $fileSize kB"
    [int]$MaxSize = 100
    if ($fileSize -gt $MaxSize) {
        #Remove-Item $BClogfile -Force
		Rename-Item -Path $BClogfile -NewName $BClogfileArchive
        Write_Transcript "BC Log File Cleared: $fileSize"
    } 
}
function RecursiveDirInfo ($directory)
{	# Return: Table of  Directory  | Count | LastWriteTime
    foreach ($file in Get-ChildItem $directory -Directory )
    {	$Script:DatFilesCount 		= (GCI $File.FullName -Recurse -File).Count
		$Script:DatFilesFolderName 	= $($File.FullName)
		if ($Script:DatFilesCount -gt $NrOfDatFilesLimit)  {Write-Host -ForegroundColor Yellow "[ERROR] $Script:DatFilesCount exceeds max $NrOfDatFilesLimit *.dat files in $Script:DatFilesFolderName"; return} # bail out if at least one folder exceeds 1024 *.dat files
        [pscustomobject] @{
        'Directory' = $File.FullName
        'Count' = (GCI $File.FullName -Recurse).Count
		'LastWriteTime' = $File.LastWriteTime
        }
    }
}
#endregion  ::::: [Functions] --------------------------------------------------------#

#region  ::::: MAIN [Execution]-------------------------------------------------------#
Write_Transcript "##### Starting Script $BCpercentNr % above configured limit -or- Repub *.dat exceeds $NrOfDatFilesLimit #####"
Write-verbose "Checking for BranchCache is set to enabled"
#Calling function to check the size of the log
Check-LogSize
#Getting BrachCache Enabled Status.
$BranchCacheEnabled = (Get-BCStatus).BranchCacheIsEnabled
if ($BranchCacheEnabled -eq $TRUE) {
    #If it is Enabled, start Checks
    Write_Transcript "Status BranchCache                   : Enabled"
    $MaxCacheSizeAsPercentageOfDiskVolume = (Get-BCDataCache).MaxCacheSizeAsPercentageOfDiskVolume
    $MaxCacheSizeAsNumberOfBytes = (Get-BCDataCache).MaxCacheSizeAsNumberOfBytes
    Write_Transcript "MaxCacheSizeAsPercentageOfDiskVolume : $($MaxCacheSizeAsPercentageOfDiskVolume)"
    $CurrentSizeOnDiskAsNumberOfBytes = (Get-BCDataCache).CurrentSizeOnDiskAsNumberOfBytes
	$CurrentActiveCacheSize = (Get-BCDataCache).CurrentActiveCacheSize
	$BCactiveCacheUsage = [math]::Round( $CurrentActiveCacheSize / $MaxCacheSizeAsNumberOfBytes * 100)
	$BCDiskUsageInPercent = [math]::Round( $CurrentSizeOnDiskAsNumberOfBytes / $MaxCacheSizeAsNumberOfBytes * 100)
	Write_Transcript "MaxCacheSizeAsNumberOfBytes          : $($MaxCacheSizeAsNumberOfBytes)"
	Write_Transcript "CurrentSizeOnDiskAsNumberOfBytes     : $($CurrentSizeOnDiskAsNumberOfBytes)  ( = $BCDiskUsageInPercent % of configured size)"
	Write_Transcript "CurrentActiveCacheSize               : $($CurrentActiveCacheSize)"
    Write-verbose "Getting Disk Info for C"
    $Disk = get-wmiobject Win32_LogicalDisk -Filter "DriveType = 3" | Where-Object {$_.DeviceID -match "C:"}
    Write-verbose "  .. Getting Free Disk Space"
    $PercentFree = $PercentFree = [Math]::round((($Disk.freespace / $disk.Size) * 100))
    Write_Transcript "Hard Disk size C: is                 : $([int]($Disk.Size / 1GB)) GB = $($Disk.Size) byte"
    Write-verbose "  .. Working Out Percent"
    $PercentUsed = [Math]::Round((($CurrentSizeOnDiskAsNumberOfBytes / $Disk.size) * 100))
	$Global:BreachAsNumberOfBytes = [math]::Round($MaxCacheSizeAsNumberOfBytes * $BCpercentNr / 100 )
	$Global:BreachPercent = [math]::Round($Global:BreachAsNumberOfBytes / $MaxCacheSizeAsNumberOfBytes *  100 )
	Write_Transcript "Free Disk Space: $($PercentFree) % | BranchCache % of Disk: $($PercentUsed) % | MaxCacheSize: $($MaxCacheSizeAsPercentageOfDiskVolume) %"
	Write_Transcript "Monitor for BreachAsNumberOfBytes    : $Global:BreachAsNumberOfBytes = BreachPercent: $Global:BreachPercent %"
	$TotNrOfRepubDatFiles  = (Get-ChildItem C:\Windows\ServiceProfiles\NetworkService\AppData\Local\PeerDistRepub\Store\0\*.dat -Recurse ).count
	$TotNrOfPubDatFiles  = (Get-ChildItem C:\Windows\ServiceProfiles\NetworkService\AppData\Local\PeerDistPub\Store\0\*.dat -Recurse ).count
	Write_Transcript "Total number of BC Repub *.dat files : $TotNrOfRepubDatFiles"
	Write_Transcript "Total number of BC Pub *.dat files   : $TotNrOfPubDatFiles"
	if ($TotNrOfRepubDatFiles -ge $NrOfDatFilesLimit) {
		RecursiveDirInfo C:\Windows\ServiceProfiles\NetworkService\AppData\Local\PeerDistRepub\Store\0\ | Out-File $BClogfile -Append
		if ($Script:DatFilesCount -gt $NrOfDatFilesLimit)  {	Write_Transcript "[ERROR] $Script:DatFilesCount exceeds $NrOfDatFilesLimit *.dat files in subfolder $Script:DatFilesFolderName. "}
		}
    #if ($PercentUsed -gt $MaxCacheSizeAsPercentageOfDiskVolume) {
	if (($CurrentSizeOnDiskAsNumberOfBytes -gt $MaxCacheSizeAsNumberOfBytes) -or ($ForTesting -eq $TRUE)) {	# CurentBCDiskusage > MaxCacheSize
        #if (($CurrentSizeOnDiskAsNumberOfBytes -gt $Global:BreachAsNumberOfBytes) -or ($TotNrOfRepubDatFiles -gt $NrOfDatFilesLimit)) {
        if ($CurrentSizeOnDiskAsNumberOfBytes -gt $Global:BreachAsNumberOfBytes) { # CurentBCDiskusage > x % of MaxCacheSize
            $DataCacheAmountOver = [math]::Round($CurrentSizeOnDiskAsNumberOfBytes - $Global:BreachAsNumberOfBytes) 
            Write_Transcript "[WARNING] Current Size of Disk is greater than the $BCpercentNr % limit"
            Write_Transcript "MaxCacheSizeAsNumberOfBytes: $($MaxCacheSizeAsNumberOfBytes) | CurrentSizeOnDiskAsNumberOfBytes: $($CurrentSizeOnDiskAsNumberOfBytes) | DataCache $BCpercentNr% as Bytes: $($Global:BreachAsNumberOfBytes) | DataCache Over $BCpercentNr% by $($DataCacheAmountOver) | Nr *.dat: $TotNrOfRepubDatFiles"
            $Global:ErrorFlag = $TRUE
        }
        else {
			 Write_Transcript "DataCache exceeding limit but not by more than $BCpercentNr %, total Nr *.dat: $TotNrOfRepubDatFiles"
             $Global:ErrorFlag = $FALSE
        }
		If ($TotNrOfRepubDatFiles -gt $NrOfDatFilesLimit ) { # NrOfDatFiles >1024 
			Write_Transcript "[INFO] Total number of BC Repub *.dat files ($TotNrOfRepubDatFiles) exceeded $NrOfDatFilesLimit"
			if ($Script:DatFilesCount -gt $NrOfDatFilesLimit)  {
				Write_Transcript 				"[ERROR] number of BC Repub *.dat files ($Script:DatFilesCount) in a subfolder exceeded maximum of $NrOfDatFilesLimit, stopping now..."
				Write-Host -ForegroundColor Red "[ERROR] number of BC Repub *.dat files ($Script:DatFilesCount) in a subfolder exceeded maximum of $NrOfDatFilesLimit, stopping now..."
				$Global:ErrorFlag = $TRUE}
		}
    }
    else {
		$Global:BreachAsNumberOfBytes = [math]::Round($MaxCacheSizeAsNumberOfBytes * $BCpercentNr / 100 )
		$Global:BreachPercent = [math]::Round($Global:BreachAsNumberOfBytes / $MaxCacheSizeAsNumberOfBytes *  100 )
	    Write_Transcript "Monitoring: CurrentActiveCacheSize $CurrentActiveCacheSize / Max $MaxCacheSizeAsNumberOfBytes = $BCactiveCacheUsage %"
		Write_Transcript "  CurrentSizeOnDiskAsNumberOfBytes $CurrentSizeOnDiskAsNumberOfBytes / Max $MaxCacheSizeAsNumberOfBytes = $BCDiskUsageInPercent %" 
        Write_Transcript "Percent used: $PercentUsed % is lower than CacheSize Limit $MaxCacheSizeAsPercentageOfDiskVolume %"
        $Global:ErrorFlag = $FALSE            
    }
}
else {Write_Transcript "BranchCache is not Enabled"}

#If NrOfDatFilesLimit reached, or the Percent Used is higher than the Max Cache Size Percentage it will copy the log file centrally. 
if ($Global:ErrorFlag -eq $TRUE) {
    Write_Transcript "Copying Log file centrally"
    Write_Transcript "_____ Script Completed _________________________________ ErrFlag: $Global:ErrorFlag"
    Get-Content $BClogfile | Out-File $BCcentralLogFile -Append -ErrorAction SilentlyContinue
    return $FALSE
}
else {
    $CLogTest = Test-Path $BCcentralLogFile
    if ($CLogTest -eq $TRUE) {
        Write_Transcript "Moving Central log to Cleared"
        Get-Content $BCcentralLogFile | Out-File $ClearedCentralLogFile -ErrorAction SilentlyContinue
        "Free Disk Space%: $($PercentFree) | BranchCache % of Disk: $($PercentUsed) % | MaxCacheSize: $($MaxCacheSizeAsPercentageOfDiskVolume) % | Repub *.dat files: $TotNrOfRepubDatFiles | DataCache Over $BCpercentNr% by $($DataCacheAmountOver)" | Out-File $ClearedCentralLogFile -Append -ErrorAction SilentlyContinue
        Remove-Item $BCcentralLogFile -Force    
    }
    Write_Transcript "_____ Script Completed _________________________________ ErrFlag: $Global:ErrorFlag"
    return $TRUE
}
#endregion  ::::: MAIN [Execution]-------------------------------------------------------#