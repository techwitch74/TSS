<# File tss_BCpercentRule.ps1 [Folderpath BCpercentNr]
#>

<#
.SYNOPSIS
1. Get the Size of the system Disk
2. Get the Size of the BC DataCache
Script will return $TRUE if the datacache is i.e. 120% over the configured 5% limit.

.DESCRIPTION  

The first mechanism should shrink the DataCache once the datacache is 120% over the configured 5% limit.
The second mechanism should shrink the DataCache once the datacache is 180% over the configured limit.
 Defaults: OversizedCacheSizeThresholdPercent=120%, OversizedCacheSizeOnDiskThresholdPercent=180%
Script will throw [WARNING] if the number of *.dat files in any PeerDistRepub subfolder exceeds 1024

.NOTES

.PARAMETER BCpercentNr
	Specify the percentage number over configured limit to watch for, i.e. 120 or 180
	Default is 180%, BC shrinking will kick in within 30 minutes after the 180% limit breached
.PARAMETER	NrOfDatFilesLimit
	Stop when the limit for number of *.dat files below C:\Windows\ServiceProfiles\NetworkService\AppData\Local\PeerDistRepub\Store\0\ is reached.
	Default is 1024
.PARAMETER Folderpath
 	Specify the path to the output folder, i.e. "C:\MS_DATA" will store logfile in C:\MS_DATA\ComputerName__BCpercentCheck.txt"
	Default is current folder
.PARAMETER ServerName
	\\ServerName where to finally copy the resulting logfile
.PARAMETER ShareName
	\ShareName where to finally copy the resulting logfile
	
.EXAMPLE
.\tss_BCpercentRule.ps1 -BCpercentNr "120" -Folderpath "C:\MS_DATA"
	Example 1: will check if BC datacache is 120% over the configured 5% limit and logfile in C:\MS_DATA
#>

param(
	[string]$Folderpath = (Split-Path $MyInvocation.MyCommand.Path -Parent),
	$BCpercentNr = "180",			# Condition#1: percentage over configured BC cache size
	$NrOfDatFilesLimit = "1024",	# Condition#2: kb4565457 - NrOfDatFiles exceeds 1024
	$ServerName = "LocalHost",		# where to finally copy the resulting logfile
	$ShareName  = "Contoso-Share"	# "
)

#region  ::::: Configruation parameters ----------------------------------------------#
$VerDate = "2020.09.03.0"

$ForTesting = $FALSE 				# $TRUE or $FALSE , used for testing only
if ($ForTesting -eq $TRUE) { $NrOfDatFilesLimit = "163"} # for testing only
#endregion ::::: Configruation parameters --------------------------------------------#

#region  [Initialisations] -----------------------------------------------------------#
$ErrorActionPreference = "Stop"
Get-Command -Module BranchCache | Out-Null

$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")

$BClogfile = $Folderpath +"\"+ $ENV:ComputerName + "__BC-" + $BCpercentNr + "percentCheck.txt"
$BClogfileArchive =  $ENV:ComputerName + "__BCpercentCheck_" + $CheckDate + ".txt"
$SharePath = "\\" + $ServerName + "\" + $ShareName
if (Test-Path $SharePath) {$CentralPath = $SharePath} else {$CentralPath = $Folderpath}
$BCcentralLogFile      = $CentralPath + "\BranchCache_" + $BCpercentNr + "-percent_or_DatNr-" + $NrOfDatFilesLimit + "_" +$($env:COMPUTERNAME) + ".log"
$ClearedCentralLogFile = $CentralPath + "\BranchCache_" + $BCpercentNr + "_cleared_" + $($env:COMPUTERNAME) + ".log"
$Global:ErrorFlag = $FALSE
[int64]$Global:BreachAsNumberOfBytes = 0
#endregion  [Initialisations] --------------------------------------------------------#

Write-verbose "Central LogPath: $BCcentralLogFile"
Write-verbose "Temp LogPath:    $BClogfile"

#region  ::::: [Functions] -----------------------------------------------------------#
function Write_Transcript ($Content) {"$(Get-date -Format G) | $($Content)" | Out-File $BClogfile -Append}

function Check-LogSize {
    #Checking the log size and renaming when over max size. 
    Write-verbose "Starting BC Log Size check"
    $file = Get-ChildItem $BClogfile
    [int]$fileSize = ($file | Measure-Object -Sum Length).Sum / 1KB
	Write_Transcript "BC Log-File Size : $fileSize kB"
    [int]$MaxSize = 100
    if ($fileSize -gt $MaxSize) {
        #Remove-Item $BClogfile -Force
		Rename-Item -Path $BClogfile -NewName $BClogfileArchive
        Write_Transcript "BC Log File Cleared: $fileSize"
    } 
}
function RecursiveDirInfo ($directory)
{	# Return: Table of  Directory  | Count | LastWriteTime
    foreach ($file in Get-ChildItem $directory -Directory )
    {	$Script:DatFilesCount 		= (GCI $File.FullName -Recurse -File).Count
		$Script:DatFilesFolderName 	= $($File.FullName)
		if ($Script:DatFilesCount -gt $NrOfDatFilesLimit)  {Write-Host -ForegroundColor Yellow "[ERROR] $Script:DatFilesCount exceeds max $NrOfDatFilesLimit *.dat files in $Script:DatFilesFolderName"; return} # bail out if at least one folder exceeds 1024 *.dat files
        [pscustomobject] @{
        'Directory' = $File.FullName
        'Count' = (GCI $File.FullName -Recurse).Count
		'LastWriteTime' = $File.LastWriteTime
        }
    }
}
#endregion  ::::: [Functions] --------------------------------------------------------#

#region  ::::: MAIN [Execution]-------------------------------------------------------#
Write_Transcript "##### Starting Script $BCpercentNr % above configured limit -or- Repub *.dat exceeds $NrOfDatFilesLimit #####"
Write-verbose "Checking for BranchCache is set to enabled"
#Calling function to check the size of the log
Check-LogSize
#Getting BrachCache Enabled Status.
$BranchCacheEnabled = (Get-BCStatus).BranchCacheIsEnabled
if ($BranchCacheEnabled -eq $TRUE) {
    #If it is Enabled, start Checks
    Write_Transcript "Status BranchCache                   : Enabled"
    $MaxCacheSizeAsPercentageOfDiskVolume = (Get-BCDataCache).MaxCacheSizeAsPercentageOfDiskVolume
    $MaxCacheSizeAsNumberOfBytes = (Get-BCDataCache).MaxCacheSizeAsNumberOfBytes
    Write_Transcript "MaxCacheSizeAsPercentageOfDiskVolume : $($MaxCacheSizeAsPercentageOfDiskVolume)"
    $CurrentSizeOnDiskAsNumberOfBytes = (Get-BCDataCache).CurrentSizeOnDiskAsNumberOfBytes
	$CurrentActiveCacheSize = (Get-BCDataCache).CurrentActiveCacheSize
	$BCactiveCacheUsage = [math]::Round( $CurrentActiveCacheSize / $MaxCacheSizeAsNumberOfBytes * 100)
	$BCDiskUsageInPercent = [math]::Round( $CurrentSizeOnDiskAsNumberOfBytes / $MaxCacheSizeAsNumberOfBytes * 100)
	Write_Transcript "MaxCacheSizeAsNumberOfBytes          : $($MaxCacheSizeAsNumberOfBytes)"
	Write_Transcript "CurrentSizeOnDiskAsNumberOfBytes     : $($CurrentSizeOnDiskAsNumberOfBytes)  ( = $BCDiskUsageInPercent % of configured size)"
	Write_Transcript "CurrentActiveCacheSize               : $($CurrentActiveCacheSize)"
    Write-verbose "Getting Disk Info for C"
    $Disk = get-wmiobject Win32_LogicalDisk -Filter "DriveType = 3" | Where-Object {$_.DeviceID -match "C:"}
    Write-verbose "  .. Getting Free Disk Space"
    $PercentFree = $PercentFree = [Math]::round((($Disk.freespace / $disk.Size) * 100))
    Write_Transcript "Hard Disk size C: is                 : $([int]($Disk.Size / 1GB)) GB = $($Disk.Size) byte"
    Write-verbose "  .. Working Out Percent"
    $PercentUsed = [Math]::Round((($CurrentSizeOnDiskAsNumberOfBytes / $Disk.size) * 100))
	$Global:BreachAsNumberOfBytes = [math]::Round($MaxCacheSizeAsNumberOfBytes * $BCpercentNr / 100 )
	$Global:BreachPercent = [math]::Round($Global:BreachAsNumberOfBytes / $MaxCacheSizeAsNumberOfBytes *  100 )
	Write_Transcript "Free Disk Space: $($PercentFree) % | BranchCache % of Disk: $($PercentUsed) % | MaxCacheSize: $($MaxCacheSizeAsPercentageOfDiskVolume) %"
	Write_Transcript "Monitor for BreachAsNumberOfBytes    : $Global:BreachAsNumberOfBytes = BreachPercent: $Global:BreachPercent %"
	$TotNrOfRepubDatFiles  = (Get-ChildItem C:\Windows\ServiceProfiles\NetworkService\AppData\Local\PeerDistRepub\Store\0\*.dat -Recurse ).count
	$TotNrOfPubDatFiles  = (Get-ChildItem C:\Windows\ServiceProfiles\NetworkService\AppData\Local\PeerDistPub\Store\0\*.dat -Recurse ).count
	Write_Transcript "Total number of BC Repub *.dat files : $TotNrOfRepubDatFiles"
	Write_Transcript "Total number of BC Pub *.dat files   : $TotNrOfPubDatFiles"
	if ($TotNrOfRepubDatFiles -ge $NrOfDatFilesLimit) {
		RecursiveDirInfo C:\Windows\ServiceProfiles\NetworkService\AppData\Local\PeerDistRepub\Store\0\ | Out-File $BClogfile -Append
		if ($Script:DatFilesCount -gt $NrOfDatFilesLimit)  {	Write_Transcript "[ERROR] $Script:DatFilesCount exceeds $NrOfDatFilesLimit *.dat files in subfolder $Script:DatFilesFolderName. "}
		}
    #if ($PercentUsed -gt $MaxCacheSizeAsPercentageOfDiskVolume) {
	if (($CurrentSizeOnDiskAsNumberOfBytes -gt $MaxCacheSizeAsNumberOfBytes) -or ($ForTesting -eq $TRUE)) {	# CurentBCDiskusage > MaxCacheSize
        #if (($CurrentSizeOnDiskAsNumberOfBytes -gt $Global:BreachAsNumberOfBytes) -or ($TotNrOfRepubDatFiles -gt $NrOfDatFilesLimit)) {
        if ($CurrentSizeOnDiskAsNumberOfBytes -gt $Global:BreachAsNumberOfBytes) { # CurentBCDiskusage > x % of MaxCacheSize
            $DataCacheAmountOver = [math]::Round($CurrentSizeOnDiskAsNumberOfBytes - $Global:BreachAsNumberOfBytes) 
            Write_Transcript "[WARNING] Current Size of Disk is greater than the $BCpercentNr % limit"
            Write_Transcript "MaxCacheSizeAsNumberOfBytes: $($MaxCacheSizeAsNumberOfBytes) | CurrentSizeOnDiskAsNumberOfBytes: $($CurrentSizeOnDiskAsNumberOfBytes) | DataCache $BCpercentNr% as Bytes: $($Global:BreachAsNumberOfBytes) | DataCache Over $BCpercentNr% by $($DataCacheAmountOver) | Nr *.dat: $TotNrOfRepubDatFiles"
            $Global:ErrorFlag = $TRUE
        }
        else {
			 Write_Transcript "DataCache exceeding limit but not by more than $BCpercentNr %, total Nr *.dat: $TotNrOfRepubDatFiles"
             $Global:ErrorFlag = $FALSE
        }
		If ($TotNrOfRepubDatFiles -gt $NrOfDatFilesLimit ) { # NrOfDatFiles >1024 
			Write_Transcript "[INFO] Total number of BC Repub *.dat files ($TotNrOfRepubDatFiles) exceeded $NrOfDatFilesLimit"
			if ($Script:DatFilesCount -gt $NrOfDatFilesLimit)  {
				Write_Transcript 				"[ERROR] number of BC Repub *.dat files ($Script:DatFilesCount) in a subfolder exceeded maximum of $NrOfDatFilesLimit, stopping now..."
				Write-Host -ForegroundColor Red "[ERROR] number of BC Repub *.dat files ($Script:DatFilesCount) in a subfolder exceeded maximum of $NrOfDatFilesLimit, stopping now..."
				$Global:ErrorFlag = $TRUE}
		}
    }
    else {
		$Global:BreachAsNumberOfBytes = [math]::Round($MaxCacheSizeAsNumberOfBytes * $BCpercentNr / 100 )
		$Global:BreachPercent = [math]::Round($Global:BreachAsNumberOfBytes / $MaxCacheSizeAsNumberOfBytes *  100 )
	    Write_Transcript "Monitoring: CurrentActiveCacheSize $CurrentActiveCacheSize / Max $MaxCacheSizeAsNumberOfBytes = $BCactiveCacheUsage %"
		Write_Transcript "  CurrentSizeOnDiskAsNumberOfBytes $CurrentSizeOnDiskAsNumberOfBytes / Max $MaxCacheSizeAsNumberOfBytes = $BCDiskUsageInPercent %" 
        Write_Transcript "Percent used: $PercentUsed % is lower than CacheSize Limit $MaxCacheSizeAsPercentageOfDiskVolume %"
        $Global:ErrorFlag = $FALSE            
    }
}
else {Write_Transcript "BranchCache is not Enabled"}

#If NrOfDatFilesLimit reached, or the Percent Used is higher than the Max Cache Size Percentage it will copy the log file centrally. 
if ($Global:ErrorFlag -eq $TRUE) {
    Write_Transcript "Copying Log file centrally"
    Write_Transcript "_____ Script Completed _________________________________ ErrFlag: $Global:ErrorFlag"
    Get-Content $BClogfile | Out-File $BCcentralLogFile -Append -ErrorAction SilentlyContinue
    return $FALSE
}
else {
    $CLogTest = Test-Path $BCcentralLogFile
    if ($CLogTest -eq $TRUE) {
        Write_Transcript "Moving Central log to Cleared"
        Get-Content $BCcentralLogFile | Out-File $ClearedCentralLogFile -ErrorAction SilentlyContinue
        "Free Disk Space%: $($PercentFree) | BranchCache % of Disk: $($PercentUsed) % | MaxCacheSize: $($MaxCacheSizeAsPercentageOfDiskVolume) % | Repub *.dat files: $TotNrOfRepubDatFiles | DataCache Over $BCpercentNr% by $($DataCacheAmountOver)" | Out-File $ClearedCentralLogFile -Append -ErrorAction SilentlyContinue
        Remove-Item $BCcentralLogFile -Force    
    }
    Write_Transcript "_____ Script Completed _________________________________ ErrFlag: $Global:ErrorFlag"
    return $TRUE
}
#endregion  ::::: MAIN [Execution]-------------------------------------------------------#
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBCsbJX30duVP4t
# atPEkh9JmCIanAyjorBV/O8f3fqx9aCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQggYJyqVCe
# 9Nwtkm2EJmDIL8bc3Bbm87Le1viPBdun9ZowOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAKDaTZcEcUAl6Wfxis1x4eKtJK0vyHWllFf8Qp1GuBqOZF9/0qsliduV
# KN3FBLhrTHOS80yPJ/DAfIScTjkl0FFo/JFy/AmjAG2te3Rx2joJhqzqkr7RzFL5
# +U3lQEg5keWT5AnW5arbeWcpmmEYkf/5XYx0YRjyzXBrgEc1VrY87gvmHycE/pAq
# buKGSpu0nZ1LNGDqPB95FFop4LIT/J3L6WQ4whyRIFYiZBmkfVBsyIh8EAp5D9Wd
# edSCMWzcNtyP+IxEi3KmnTeGifHW0AlVsYoXdcWoXpORFgLWqJK5jgf0hlzBmrBO
# X0zD+hXtvuJk35BEnk1mOGirrkNG0AihghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgLvRdO9yUA3px8p7thgt9cCxnODZLS64XWcb9P1op55UCBmCJ+e5d
# HRgTMjAyMTA1MTkyMjIxNTQuODMxWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYw
# QkMtRTM4My0yNjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFaLLluRDTLbygAAAAAAVowDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE2WhcNMjIwNDExMTkwMjE2WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0yNjM1
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsL1cHFcNrScIrvQd/4aKHo3FGXWYCHMU
# l2iTxuzfGknztMzbysR4eRkBoT4pv0aL1S9OlDfOsRbJZKkhCTLG/9Z/RwiEDWYk
# 6rK7bRM3eX3pm+DNivM7+tCU+9spbv2gA7j5gWx6RAK2vMz2FChLkFgbA+H1DPro
# G5LEf1DB7LA0FCyORWiKSkHGRL4RdIjOltrZp++dExfsst7Z6vJz4+U9eZNI58fV
# Y3KRzbm73OjplfSAB3iNSkHN0wuccK0TrZsvY87TRyYAmyK2qBqi/7eUWt93Sw8A
# LBMY72LKaUmVvaxq/COpKePlHMbhHEbqtTaLt61udBOjNHvc4cwY5QIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFGRzJT/1HI+SftAGhdk5NDzA3jFnMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAAAAbex8WBtSLDiBYxXxU7GVsgb8IgxKJyIO0hmc8vzg
# 4w3iUl5Xkt4mv4dgFyjHmu5Zmbj0rb2IGYm/pWJcy0/zWlhnUQUzvfTpj7MsiH+1
# Lnvg95awe88PRA7FDgc4zYY0+8UB1S+jzPmmBX/kT6U+7rW5QIgFMMRKIc743utq
# CpvcwRM+pEo8s0Alwo8NxqUrOeYY+WfNjo/XOin/tr3RVwEdEopD+FO+f/wLxjpv
# 4y+TmRgmHrso1tVVy64FbIVIxlMcZ6cee4dWD2y8fv6Wb9X/AhtlQookk7QdCbKh
# 3JJ4P8ksLs02wNhGkU37b10tG3HR5bJmiwmZPyopsEgwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0y
# NjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQDMgAWYvcYcdZwAliLeFobCWmUaLqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9+kDAiGA8y
# MDIxMDUxOTE2MDk1MloYDzIwMjEwNTIwMTYwOTUyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT36QAgEAMAoCAQACAiRAAgH/MAcCAQACAhHpMAoCBQDkUNAQAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAXQVTueK27//AUfUiggXN8DDFmThP
# HNd2Le5OoEJr8qEBfMGpVZi7jF8iZSUH9l/6ETYmHoASPTTouApmAJ5Af8Xfx/vm
# oYN8YzShzD0I4L885xMWFLRy7gTvwo2wW1zaGWI8+tWW/lQpS/DEhQ15jwffKX4A
# rrUtsL3e79dlzEYxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVosuW5ENMtvKAAAAAABWjANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCA9gxtS
# Xlw6c8PGtUz+BSnsoXfp0JZt9LSnY8rlgwx2JDCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIJP8qCZ0xLLkXTDDghqv1yZ/kizekzSFS4gicvltsX+wMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFaLLluRDTLbygA
# AAAAAVowIgQgOL0wIlEHhiqd5WY8M69hOFUOI1uWdoiGagbxykIYFMEwDQYJKoZI
# hvcNAQELBQAEggEAq7VVrT0yOxopJHVldpMvnNPlgL/0Q0MkE4vQah4A4C6bF+iJ
# bXIuKEMQ3TR5QVj+qTVszuo3EZum95/WT9TD9H5yZtiG387WUabePgFcwwPb7xhD
# EaEtY3YrQfPz0jSsep+YCfvy+6Y9aT7eNf9P7jxMKWDgfQkonlxbxun/RkIga1PF
# n4l2bWlhvQC/qCgMRNLVnCsd2fH0RGmz0ysIw1J8uV8bhIbNnDKLA289LcRGa7jS
# zQRVxwQSa1RaD02/9CuOG0rwzwII6qS1XWov/vA4ngfzU8jao3qN4bjZEUv/vZkh
# 1P1ovsGUfe9Yj/7IEibk65VBDn7bVtBNLeiT+w==
# SIG # End signature block
