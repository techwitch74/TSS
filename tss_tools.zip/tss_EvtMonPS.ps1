<# Name: tss_EvtMonPS.ps1 [-EventIDs -EventlogName -CheckIntInSec -WaitTimeInSec -EventData -EvtDataPartial -EvtDataOperator]
	
if you invoke from CMD:
 PowerShell -noprofile "&{Invoke-Command -ScriptBlock {$EventID=30800;$NrOfMilliSec=60000;$EventlogName="Microsoft-Windows-SmbClient/Operational"; Get-WinEvent -LogName $EventlogName -FilterXPath "*[System[EventID=$EventID and TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]]" -MaxEvents 5 -ErrorAction SilentlyContinue}}"
 PowerShell -noprofile "&{Invoke-Command -ScriptBlock {Get-WinEvent -LogName "Microsoft-Windows-SmbClient/Operational"  -FilterXPath "*[System[EventID=30800]]" -MaxEvents 3 -ErrorAction SilentlyContinue }}"

	#Eventlogs location on disk: "C:\Windows\System32\winevt\Logs\Microsoft-Windows-SmbClient%4Operational.evtx"
Example to delete Source
 Get-WmiObject win32_nteventlogfile -Filter "logfilename='Microsoft-Windows-SmbClient/Operational'" | foreach {$_.sources}
 Remove-Eventlog -Source "TSS"

For Testing:
 you can watch for 40961/40962 in "Microsoft-Windows-PowerShell/Operational", which is logged when starting a  new PoSh window
#>

<#
.SYNOPSIS
Purpose: Monitor Eventlogs for specific event and stop script; in combi with TSS: stop the script based on EventIDs in a non classic Eventlog
	The stop trigger condition is true if the EventID is found in specified Eventlog up to CheckIntInSec back in time, the control is given back to calling script.
	From CMD script you can invoke this PowerShell script by: Powershell -noprofile -file "tss_EvtMon.ps1" -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 0
	Multiple EventIDs are separated by '/', for example -EventID 40961/40962
	Multiple EventData strings are separated by '/', for example -EventData C:\Windows\System32\calc.exe/C:\Windows\System32\cmd.exe


If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
 
SYNTAX: .\tss_EvtMon.ps1 -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 'find-my-string'


.DESCRIPTION
The script will stop, once the specific details EventID(s) and Eventdata string(s) are all met.
You need to run the script in Admin PowerShell window, if you want to monitor 'Security' Event Log
You can append the -verbose parameter to see more details.
When entering -EventData string, please enter the complete string as seen in Event 'XML View', for example 'C:\Windows\System32\calc.exe'
 as seen in 'XML View' <Data Name="NewProcessName">C:\Windows\System32\calc.exe</Data> 
In additin to any specific EventID, the script will also listen on EventID 999 in Application eventlog, and stop when it sees 999 sent by a remote system as a stop trigger.

.PARAMETER EventIDs
	The Event ID to watch for, separate multiple IDs with '/', ex: 30800/30809
.PARAMETER CheckIntInSec
	Specify how often (time-interval in seconds) to search for given EventID(s)
.PARAMETER EventlogName
	Specify name of Eventlog, i.e. "Microsoft-Windows-PowerShell/Operational" or "Microsoft-Windows-SmbClient/Operational"
.PARAMETER WaitTimeInSec
	Force a wait time in seconds after an event is found,  this will instruct tss to stop x seconds later.
.PARAMETER EventData
	Specify a complete string that is seen in Eventlog XML view <Data>"your complete string"</Data>
.PARAMETER EvtDataPartial
	Specify a unique keyword that is part of the complete message, to allow search for partial event data message
	This does not require a full string between <Data> .. </Data>, partial match is ok
.PARAMETER EvtDataOperator
	combine multiple EventData search terms by AND or OR operator (default = OR)
	
.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 0

.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 4688/4689 -EventlogName "Security" -EventData C:\Windows\System32\calc.exe/C:\Windows\System32\cmd.exe -verbose
 
This will monitor for multiple EventIDs  4688 and 4689, checking if either string 'C:\Windows\System32\calc.exe' or 'C:\Windows\System32\cmd.exe' exist in given EventID(s) 

.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 40961/40962 -EventlogName "Microsoft-Windows-PowerShell/Operational" -EventData 0
 
 This will monitor for multiple EventIDs 40961 and 40962 in Microsoft-Windows-PowerShell/Operational, will be triggered as soon as a new PowerShell window opens

.EXAMPLE
 .\tss_EvtMonPS.ps1 -EventID 4624 -EventlogName "Security" -EventData "Contoso.com/User1" -EvtDataPartial -EvtDataOperator "AND"
 
 This will monitor for EventID 4624 in Security eventlog, will be triggered as soon as a Logon attempt from "User1" in domain "Contoso.com" is logged, AND means both criteria must match; omitting -EvtDataOperator or choosing "OR" will fire if one criteria is found in EventID 4624
 
 
 .EXAMPLE

  [Info] for testing it is sufficient to specify an existing "Source", i.e.
  Write-EventLog -LogName "Application" -Source "Outlook" -EventID 59 -EntryType Information -Message "Test this EventID as stop trigger." -Category 1 -RawData 10,20 -ComputerName $Env:Computername
  Note, you can also use the script tss_EventCreate.ps1 to fire such event.

.LINK
waltere@microsoft.com;Sergey.Akinshin@microsoft.com
#>

Param(
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose the EventID, or multiple separated by slash / ')]
	[string[]]$EventIDs 		# separate multiple IDs with '/', ex: 30800/30809
	,
	[Parameter(Mandatory=$False,Position=2,HelpMessage='Choose name of EventLog-File' )]
	[string]$EventlogName 		# name of Eventlog, i.e. "Microsoft-Windows-PowerShell/Operational" #"Microsoft-Windows-SmbClient/Operational"
	,
	[Parameter(Mandatory=$False,Position=3,HelpMessage='Choose the amount of time to search back in seconds ')]
	[Int32]$CheckIntInSec = 2	# specify time-interval in seconds to search back, # how often in seconds should the evenlog file be scanned?
	,
	[Parameter(Mandatory=$False,Position=4,HelpMessage='Choose Stop WaitTime in Sec')]
	[Int32]$WaitTimeInSec = 0	# this specifies the forced wait time after an event is detected
	,
	[Parameter(Mandatory=$False,Position=5,HelpMessage='optional: complete string in any EventData, or multiple separated by slash / ')]
	[string[]]$EventData = '0'	#'3221226599' # = STATUS_FILE_NOT_AVAILABLE / '3221225996' = STATUS_CONNECTION_DISCONNECTED / '0' = STATUS_SUCCESS
	,
	[Parameter(Mandatory=$False,Position=6,HelpMessage='Search for keywords in event Message')]
	[Switch]$EvtDataPartial		# allow search for partial event data message
	,
	[Parameter(Mandatory=$False,Position=7,HelpMessage='choose operator for EventData: AND OR')]
	[string]$EvtDataOperator="OR"	# AND will fire only if both conditions are true
)

#region: customization section of script, logging configuration ----------------------#
$ScriptVer			= "1.09"	# Date: 2020-09-16

[Int32]$cntr		= 0			# counter
[Int32]$MaxEvents	= 1			# we are only interested in a single recent occurence of EventID in Eventlog
$Trigger			= $False	# initialize; While Loop will exit when Trigger=$True
[Int32]$NrOfMilliSec = 1000 * ($CheckIntInSec +5)	#amount of time in MilliSec to search back
$NrOfSecBack		= 10		# Search EvtLog back for x seconds
#endregion: customization section of script, logging configuration -------------------#


#region: MAIN ------------------------------------------------------------------------#

[string[]]$Event_ID_list=$EventIDs.split("/")
[string[]]$Event_ID_list_comma=$EventIDs.replace("/",",")
Write-verbose "--EventIDs: $Event_ID_list"
[array]$xpaths= @()
$EvtDataStrings=$EventData.split("/")
[string]$EvtDataStrings_Or	= $EventData.replace("/","|")	# default OR operator in partial EventData search
[string[]]$EvtDataStrings_And	= $EventData.Split("/") 	# implement AND operator for multple partial EventData words

Write-verbose "--EvtDataStrings:     $EvtDataStrings"
Write-verbose "--EvtDataStrings_Or:  $EvtDataStrings_Or"
Write-verbose "--EvtDataStrings_And: count: $($EvtDataStrings_And.count) Search for: [1] $($EvtDataStrings_And[0]) AND [2] $($EvtDataStrings_And[1])"

foreach ($EventID in $Event_ID_list){
	if ($EvtDataPartial) {	# This does not require a full string between <data> .. </data>, partial match is ok
			$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
"@
	$xpaths += $xpath
	Write-host "---- EventID: $EventID - Xpath: `n$xpath"
	} 
	else {				# full match of 'EvtDataString'
		foreach ($EvtDataString in $EvtDataStrings)
		{
			if ($EventData -ne '0') {
				$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
[EventData[Data='$EvtDataString']]
"@
			} else {
			$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
"@
			}
			
		$xpaths += $xpath
		Write-host "---- EventID: $EventID - Xpath: `n$xpath"	
		}
	}	
}

# watch in addition for App Event ID 999
$xpath999 = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=999]]
"@

if ($EvtDataPartial) { Write-host " - EvtDataPartial: allow search for partial string(s) in event message, operator $EvtDataOperator : '$EvtDataStrings'" }
Write-host -ForegroundColor Green " Monitoring $EventlogName Log for EventID(s): '$Event_ID_list' EventData operator: $EvtDataOperator '$EvtDataStrings' - CheckInterval $CheckIntInSec sec"
 $TimeStampStart= Get-Date
 # Run While loop until Event is recorded 
while (-not $Trigger) {
	Start-Sleep $CheckIntInSec;
	$TimeStartCompare  = (Get-Date).AddSeconds(-$NrOfSecBack)	# look back 10 sec in EvtLog
	$cntr++ ;  write-verbose " `n`n  Loop# $cntr; $(Get-Date -Format 'yyMMdd-hhmmss') - monitoring EventID(s): '$Event_ID_list' EventData: '$EvtDataStrings' Operator: $EvtDataOperator NrOfSecBack: $NrOfSecBack"
	##Write-verbose "--xPath: $xpath"
	
	if (($EvtDataPartial) -and ( -not($EvtDataOperator -ieq "OR"))) {	# Partial Event message and Operator = "AND"
		#Test 5140 = 'File Share': Get-WinEvent -MaxEvents 1 -FilterHashTable @{ LogName = "Security"; StartTime = $TimeStartCompare; ID = 4674 } |Where-Object -Property Message -match "EUROP" |Where-Object -Property Message -match "walt" | select Id,TimeCreated,Message |format-list
		if ($EvtDataStrings_And.count -eq 1) {
			foreach($Event_ID in $Event_ID_list) {
				write-verbose "Get-WinEvent -MaxEvents 1 -FilterHashTable @{ LogName = $EventlogName; StartTime = $TimeStartCompare; ID = $Event_ID }  |Where-Object -Property Message -match $($EvtDataStrings_And[0]) `n"
				$EvtEntry = Get-WinEvent -MaxEvents 1 -FilterHashTable @{ LogName = $EventlogName ; StartTime = $TimeStartCompare; ID = $Event_ID } -ErrorAction SilentlyContinue |Where-Object -Property Message -match $EvtDataStrings_And[0] | select Id,TimeCreated,Message 
				if ($EvtEntry) { break}
			}
		}
		elseif ($EvtDataStrings_And.count -eq 2) {
			foreach($Event_ID in $Event_ID_list) {
				write-verbose "Get-WinEvent -MaxEvents 1 -FilterHashTable @{ LogName = $EventlogName; StartTime = $TimeStartCompare; ID = $Event_ID }  |Where-Object -Property Message -match ($($EvtDataStrings_And[0]) -AND $($EvtDataStrings_And[1])) `n"
				## works for single EventID, but not @($Event_ID_list_comma) = (input "4674/4957")
				$EvtEntry = Get-WinEvent -MaxEvents 1 -FilterHashTable @{ LogName = $EventlogName ; StartTime = $TimeStartCompare; ID = $Event_ID } -ErrorAction SilentlyContinue |Where-Object -Property Message -match $EvtDataStrings_And[0] |Where-Object -Property Message -match $EvtDataStrings_And[1]  | select Id,TimeCreated,Message 
				if ($EvtEntry) { break}
			}
		}
	}
	else {	# # Partial Event message and Operator = "OR", or no Partial
		foreach ($xpath in $xpaths) 
		{ Write-debug "-- xpathCount: $($xpaths.count) -- xPath: $xpath"
			if ($EvtDataPartial) { # search for partial string in EventData
				Write-debug "Partial: $EvtDataPartial"	
				if ($EvtDataOperator -ieq "OR") { 	# Operator "OR", default
					write-verbose "Get-WinEvent -LogName $EventlogName -FilterXPath $xpath  |Where-Object -Property Message -match $EvtDataStrings_Or"
					$EvtEntry = Get-WinEvent -LogName $EventlogName -MaxEvents $MaxEvents -FilterXPath $xpath -ErrorAction SilentlyContinue |Where-Object -Property Message -match $EvtDataStrings_Or |select Message,Id,TimeCreated
					if ($EvtEntry) {$EvtEntry; break}
				} 
				else { 														
				}
			} 
			else { 			# search for full string in EventData
				write-verbose "Get-WinEvent -MaxEvents $MaxEvents -LogName $EventlogName -FilterXPath $xpath "
				$EvtEntry = Get-WinEvent -MaxEvents $MaxEvents -LogName $EventlogName -FilterXPath $xpath -ErrorAction SilentlyContinue |select Message,Id,TimeCreated
				if ($EvtEntry) {$EvtEntry; break}
			}
		}
	}
	# in addition check for Event ID 999 in Application EvtLog
	$EvtEntry999 = ( Get-WinEvent -MaxEvents $MaxEvents -LogName Application -FilterXPath $xpath999 -ErrorAction SilentlyContinue |select Message,Id,TimeCreated )
	if ($EvtEntry999) {$EvtEntry = $EvtEntry999}

	$Trigger = $EvtEntry
	if ($Trigger) {
		$TimeStampCurrent=Get-Date; $Dur=($TimeStampCurrent - $TimeStampStart)
		if ($EvtEntry ) 	{ $EvtEntry |format-list; Write-host -ForegroundColor Yellow " EventID '$($EvtEntry.Id)' - EventData '$EvtDataStrings' found at $($EvtEntry.TimeCreated) - after $($Dur.Days) D $($Dur.Hours) h $($Dur.Minutes) m $($Dur.Seconds) sec / $Dur"}
		Start-Sleep $WaitTimeInSec
		break
	}
}
#endregion: MAIN ---------------------------------------------------------------------#

<# allow partial EventData search? https://www.reddit.com/r/PowerShell/comments/gksxp3/how_to_generate_a_here_string_dynamically/

Test:
$xpath = @"
 *[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
 [EventID=$EventIDs]]
 [UserData[EventData[ClientAddressLength='$EvtDataStrings']]]
"@
[EventData[Data='$EvtDataStrings']]

#EvtDataStrings : 3221226599 # for decimal -1073740697 / hex 0xc0000467 #  STATUS_FILE_NOT_AVAILABLE # The file is temporarily unavailable.
#EvtDataStrings : 3221225996 # for decimal -1073741300 / hex 0xc000020c #  STATUS_CONNECTION_DISCONNECTED
#EvtDataStrings : 3221225653 # STATUS_IO_TIMEOUT # The specified I/O operation on %hs was not completed before the time-out period expired.

# Test: .\tss_EvtMonPS.ps1 -EventID 1006 -EventlogName  'Microsoft-Windows-SMBServer/Security' -EvtDataStrings 128
$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= 1000]]
[EventID=999]]
"@

https://evotec.xyz/powershell-everything-you-wanted-to-know-about-event-logs/
Test: .\tss_EvtMonPS.ps1 -EventID "4674/5140" -EventlogName "Security" -CheckIntInSec 2 -WaitTimeInSec 0 -EventData "waltere/EUROPE" -EvtDataPartial -EvtDataOperator "AND" -verbose	#_# 5140 = 'File Share' / 4674 = 'Sensitive Privilege Use'

#>
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDpjX3vmUMN1Oyd
# NGuQl0eKP+tkEP7U9QPepZqqWL1Io6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg5eSMLeWl
# KNolaQ0pR4xTquIv8qxRAHRYNGVE/cs9/G4wOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAJdVxk3EhIbJLB6ok//KkujR28+3ZoxKr95LAWyTuws79cdJdOhP6Kdx
# sqLpC+nyyAiDIhH4E5ihOOLF0TLitSCL0LqT6s/+0Ucti6Pi5KIdL0BVLcK1TLhr
# oMz47DZ6rwGmhGFkcOsr762sPsGVH7w/pML6ntxatV0zqi9JdIQfB9TpEESK87hB
# 9Ec51N5xaBSjPKrLq9IlGAbPD2RuM0MOCDLsz0pe+1DE1i5AItZDtGhwbqZpjr7J
# 3XthuDmFZaYYWLrD7LsZ6d/KYOmo57wzq9cpAFJF5kDEhci6RORQn2ryanVztFoz
# UIUmyfPE9rZkyHtVBwbFydqsMQhA1ayhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgnk9MAKIH/ImI2RKiSDYqSMyahkcPpt5jT6ohYEOjP7cCBmCJ+rXX
# LRgTMjAyMTA1MTkyMjIxNTQuODkyWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjc4
# ODAtRTM5MC04MDE0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFchtLj7Dn2izgAAAAAAVwwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE3WhcNMjIwNDExMTkwMjE3WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjc4ODAtRTM5MC04MDE0
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0CorPq8qH2JAsmgS8lwJTB3l+dq3BBeY
# hkyUnzi/iewy5+d8lsbrbd/9Tw4G7WzI5c5ntXMc54L/6shmvNwlBpDyvmUJCOf1
# +IbeOT6mo9IVGXfD1gYWOi7L8XG5IDqz8y/tvQZLRtodOUkWBG4MoGAGxNqAZHhJ
# GYecV2tKFPe2TVPdYBItMYhJ4YbHiLQPIO7PzNBWamkvz4FTKI+KvRb9dk6y4DoU
# TGPeBO/JMt+INWGY1zDM+/ktCWshWKvSbb7tQNNjyKfMeX/YKUfg3ja6ptaT0fYj
# iukIJxRZIHDWbwN7iFOxMZARPuqJH4V8js9CUlD715/sA0B+U9I2GwIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFF/zFKw5KHKAkAV/uJp7LWMYwbo+MB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAHh5TPbXfiBzDhwj9TLZ7aOQ7u16krtPlZe3vpr8DP+l
# 00I3oHUPpBhFEcv3QmYaVkx1S3Ab8DoT1Go2oO/1odDz/YUsVyus05OANDRyNn/0
# zHyy2jXuTitbbZC9Ng5AEHXii40CwOWhn1qpz9C2aLwkUd3oxzu8TmgOB5UabfLx
# 6vtSAufiCRMhifyV5M9j0fbK6gt9dtDxeuXRZYUFuZmbq3cMQb6vqtoiY0ns+sFA
# eel1fEKOMXlY08xg14oRYD5GTIDkUPlgDS4pe2U13keC/Bxaj8AIbK4+W7HBgFwM
# JlAUVq2i/S42M6xDEQxGADOkDm+oQ47H9NQRgWRxEEkwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjc4ODAtRTM5MC04
# MDE0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQCe4qWjxp8oR5Wcfl3rI/ieTmnwTKCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9/XjAiGA8y
# MDIxMDUxOTE2MTMxOFoYDzIwMjEwNTIwMTYxMzE4WjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT39eAgEAMAoCAQACAgDdAgH/MAcCAQACAhHSMAoCBQDkUNDeAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAfBaF+V4fh+bSvxurdU3mbh7Ua5/u
# 29bLChMU3aCeId/G74dyyDmAB64vP0pshpSSwo/3yG4LamtLBQdhPpCXbIntd/Ms
# rNMqbtnebaYRZP+q7q5+5GrcNU68vlZMDThF6H6HkoQz81EAU7o2CzxnG5mYWR8c
# +jjIwoIX3ZWWadExggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVyG0uPsOfaLOAAAAAABXDANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAToLyB
# TflrmFdKirQ0NrvnvMjVSN2YdCRrvE2DSpYM7TCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIE8tZFfCIE9sADBJzKQgK1A99C4giEZvFe+0XI8MGea1MIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFchtLj7Dn2izgA
# AAAAAVwwIgQgGhuc7NElkYQ7SvyZQ/cRFyx6iyPPfygN0wmMngM4pFIwDQYJKoZI
# hvcNAQELBQAEggEAIJsrkwooI9OcGnVYddhk40fr7d4svggDGjfEFI3ClD/yA7L+
# N/YF8QCrmVhI/EvYAnUssd/piU/3OCvMC1wIIB/XMeSaMvkbXqYJhyzEvnNATRvP
# +sRluOzBIJmg56/f/PocP2bujwoa2L3MyD4bxjM35rzRmMbmbnxudZ+PyKrrMxCU
# Gx8GDRX0pG3Tb0EwIw0cuvr5hCR/wqGODf3HCqa4Y6AGazF7lpp4d2M+ZPNtyIi3
# 53FObmIixyrd24bo84+6QBJjULwc+WhszZ5VhJiQvZNNP7r3VLvqrjLYMR4LUeQC
# fKN5w8eLcdfqpYT3tfnQnd0a+SwhJNT+NcL9kQ==
# SIG # End signature block
