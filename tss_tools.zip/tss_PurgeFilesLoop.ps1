<# Filename: tss_PurgeFilesLoop.ps1 [-NrFilesToKeep] [-PollInterval] [-Folderpath] [-FilenameList] [-StopTokenFile] [-DateTime] [-Caller] [-EtlBuf] [-ProcMNrFilesToKeep] [-ProcMfilter]
Purpose:  avoiding disk space exhaustion, keep the number of trace & ProcMon files at a maximum of [-NrFilesToKeep]
		  the script will terminate once the stop condition [-StopTokenFile] is met

 Copyright ^(C^) Microsoft. All rights reserved.
 THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
 IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
#>

<#
.SYNOPSIS
The script helps to avoid disk space exhaustion, keep the number of trace & ProcMon files at a maximum of [-NrFilesToKeep]

.DESCRIPTION
The script purges older trace files and keeps only -NrFilesToKeep files 
Usage:
 .\tss_PurgeFilesLoop.ps1 [-NrFilesToKeep] [-PollInterval] [-Folderpath] [-FilenameList] [-StopTokenFile] [-DateTime] [-Caller] [-ProcMNrFilesToKeep] [-ProcMfilter]

If you get an error that running scripts is disabled, run 
	Set-ExecutionPolicy Bypass -force -Scope Process
and verify with 'Get-ExecutionPolicy -List' that no ExecutionPolicy with higher precedence is blocking execution of this script.
Then run the script again.

Alternate method#1: to sign .ps1 scripts: run in elevated CMD 
  tss_PS1sign.cmd Get-psSDP
Alternate method#2: If execution is blocked by machine policy, run in elevated Powershell: 
 Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value ByPass

.PARAMETER NrFilesToKeep
  This switch will keep only NrFilesToKeep of youngest trace files for each category
.PARAMETER PollInterval
  This switch controls how often in seconds interval purge/file deletion is done.
.PARAMETER Folderpath
 This is the data location on disk to monitor and purge.
.PARAMETER FilenameList
  This switch controls the file name/extensions to purge
.PARAMETER StopTokenFile
  This switch watches for existence of a stop trigger Filename for termination condition
.PARAMETER Caller
  This switch tells the script which caller invoked it and if it should look for trace ETL files or Procmon files
.PARAMETER DateTime
  date/time of start of repro
.PARAMETER EtlBuf
  max size of ETL trace file
.PARAMETER ProcMNrFilesToKeep
  This switch will keep only max 2x ProcMonKeep of youngest ProcMon files
.PARAMETER ProcMfilter
  This switch defines the procmon *.PMC config Filter-file-name without .pmc extension to apply

.PARAMETER CreateTestFiles
  This switch is for testing only
 
.EXAMPLE
 .\tss_PurgeFilesLoop.ps1 -NrFilesToKeep 10 -PollInterval 2 -Folderpath "C:\MS_DATA" -FilenameList "*dns*.etl"
 for purging "*dns*.etl" files in interval of 2 sec and keep latest 10 files in folder "C:\MS_DATA"
 
 
.LINK
email: waltere@microsoft.com
https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/TSS
#>

[CmdletBinding()]
PARAM (
	[string]$Folderpath = (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[string]$FilenameList = "etl/procmon/ndiscap/NMcap",
	[int32]$NrFilesToKeep = 10,
	[int32]$ProcMNrFilesToKeep = 5,
	[string]$ProcMfilter = "NoFilter",
	[string]$Caller,
	[int32]$EtlBuf = 1024,
	[int32]$PollInterval = 9,
	[string]$StopTokenFile = "tss_StopTokenFile.tmp",
	$DateTime = "$(Get-Date -UFormat "%D %R:%S")",
	[switch]$CreateTestFiles = $False,
	[switch]$WhatIf = $False
)

$ScriptVersion=1.8	#2021-01-31

[string]$Script:LogFileScript = $Folderpath +"\"+ $ENV:ComputerName + "__Purge-Files-Log.txt"
$DirScript=(Split-Path $MyInvocation.MyCommand.Path -Parent)
if ($env:PROCESSOR_ARCHITECTURE -match "AMD64") {$ProcArch="x64"} else {$ProcArch="x86"}
$Procmon_exe="$DirScript\$ProcArch\Procmon.exe"
[int32]$Script:ProcMonBlockNr=0
# ".. unblocking ProcMon.exe file"
Unblock-File $Procmon_exe -Confirm:$false
$Host.UI.RawUI.BackgroundColor = ($bckgrnd = 'DarkGreen')

if ($ProcMfilter -notMatch "NoFilter") {$ProcMfilter = "/loadConfig " + $DirScript + "\ProcmonNoTss.pmc"} else {$ProcMfilter = "/NoFilter"}

#region  ::::: [Functions] -----------------------------------------------------------#
function CreateTestFiles ([switch]$CreateTestFiles)
{
	# SYNOPSIS: Testing: Create 12 test files, 1 second after each other
	1..12 | % {
		Remove-Item -Path "$Folderpath\$_.txt" -EA SilentlyContinue
		$_ | Out-File "$Folderpath\$_.txt"
		Write-Host "..created $_.txt "
		Start-Sleep -Seconds 1
	}
}
<#
function Start-Procmon {
# SYNOPSIS: Start Procmon
  # force a queue depth of 1 million // check if procmon was run before
  Set-ItemProperty "HKCU:\Software\Sysinternals\Process Monitor" -Name "HistoryDepth" -Value 1
  Push-Location "$DirScript\$ProcArch"
  Unblock-File $Procmon_exe -Confirm:$false
	#load config - if file exists in script folder: /loadConfig ProcmonConfiguration.pmc -, avoid it if you don't know exactly, what you are looking for! Otherwise just trace all with default settings
  Start-Process $Procmon_exe -ArgumentList "/AcceptEula /BackingFile $PM_BackingFile $ProcMfilter /Minimized"
  Pop-Location
}
#>

function Stop-Procmon {
# SYNOPSIS: Stop Procmon
	Start-Process "$Script:ScriptPath\Procmon.exe" -ArgumentList "/terminate"
}

function RestartProcMon ($ProcMNrFilesToKeep)
{
	# SYNOPSIS: ProcMon writes blocks with N ProcMNrFilesToKeep files, then terminates and restarts; delete N-2 block
	if (Test-Path "HKCU:\Software\Sysinternals\Process Monitor\LogFile") {
		Clear-ItemProperty "HKCU:\Software\Sysinternals\Process Monitor" -Name "LogFile"
	}
	Push-Location "$DirScript\$ProcArch"
	
	$Script:ProcMonBlockNr +=1
	$ProcmonNminus2=$Script:ProcMonBlockNr-2
	Write_Transcript "[Restart ProcMon $Script:ProcMonBlockNr]"
	Write-Debug "[RestartProcMon $(Get-Date -UFormat "%R:%S")] Unblock-File $Procmon_exe -Confirm:$false" 
	 Unblock-File -Path $Procmon_exe -Confirm:$false
	Write-Verbose "[RestartProcMon $(Get-Date -UFormat "%R:%S")] [$Script:ProcMonBlockNr]... terminate + restarting Procmon Cnt= $Script:ProcMonBlockNr - DEL: ProcMon_$ProcmonNminus2 * - LoopCnt= $Script:LoopCnt - Keep: $ProcMNrFilesToKeep"
	Write-Verbose "[RestartProcMon $(Get-Date -UFormat "%R:%S")] Start-Process $Procmon_exe -ArgumentList '/Terminate'"
	 Start-Process $Procmon_exe -ArgumentList "/Terminate"

	$PM_BackingFile=$Folderpath +"\"+ $env:COMPUTERNAME +"_"+ $DateTime +"_ProcMonPurge_"+ $Script:ProcMonBlockNr +".pml"
	Write-Debug "[RestartProcMon $(Get-Date -UFormat "%R:%S")] BackingFile: $PM_BackingFile"
	Write-Verbose "[RestartProcMon $(Get-Date -UFormat "%R:%S")] Start-Process $Procmon_exe -ArgumentList '/waitforidle' -wait" # https://trwagner1.wordpress.com/2010/03/25/using-powershell-with-process-monitor/
	 Start-Process $Procmon_exe -ArgumentList "/waitforidle" -wait
	Write-Verbose "[RestartProcMon $(Get-Date -UFormat "%R:%S")] Start-Process $Procmon_exe -ArgumentList '/AcceptEula /BackingFile $PM_BackingFile $ProcMfilter /Minimized'"
	 Start-Process $Procmon_exe -ArgumentList "/AcceptEula /BackingFile $PM_BackingFile $ProcMfilter /Minimized" # /waitforidle" -wait
	Write-Verbose "[RestartProcMon $(Get-Date -UFormat "%R:%S")] Start-Process $Procmon_exe -ArgumentList '/waitforidle' -wait" # https://trwagner1.wordpress.com/2010/03/25/using-powershell-with-process-monitor/
	 Start-Process $Procmon_exe -ArgumentList "/waitforidle" -wait
	# remove older files
	Start-Sleep -Seconds 2
	#Get-ChildItem -Path "$Folderpath\*ProcMon*_$ProcmonNminus2*" | Where-Object {-not $_.PsIsContainer}| Remove-Item -Force 
	Get-ChildItem -Path "$Folderpath\*ProcMon*.pml" -Recurse| Where-Object {-not $_.PsIsContainer}| sort CreationTime -desc| select -Skip $ProcMNrFilesToKeep | Remove-Item -Force -EA SilentlyContinue
	Pop-Location
}
function Write_Transcript ($Content) {"$(Get-date -Format G) | $($Content)" | Out-File $Script:LogFileScript -Append }
function Write-Log {
	# SYNOPSIS: Writes script information to a log file and to the screen when -Verbose is set.
	[CmdletBinding()]param([string]$text, [Switch]$tee = $false, [string]$foreColor = $null, [string]$backColor = "DarkBlue")
	$foreColors = $backColors = "Black","Blue","Cyan","DarkBlue","DarkCyan","DarkGray","DarkGreen","DarkMagenta","DarkRed","DarkYellow","Gray","Green","Magenta","Red","White","Yellow"
	# check the log file, create if missing
	$isPath = Test-Path $LogFileScript
	if (!$isPath) {
		"tss_PurgeFilesLoop.ps1 v$ScriptVersion Log started on $($ENV:ComputerName) - $($Script:osVer) - $($Script:osNameLong) " 	| Out-File $LogFileScript -Force
		"Local log file path: $LogFileScript" 														| Out-File $LogFileScript -Append
		"PowerShell version:  $Script:PSver " 														| Out-File $LogFileScript -Append
		"Start time (UTC):    $((Get-Date).ToUniversalTime())" 										| Out-File $LogFileScript -Append
		"Start time (Local):  $((Get-Date).ToLocalTime()) $(if ((Get-Date).IsDaylightSavingTime()) {([System.TimeZone]::CurrentTimeZone).DaylightName} else {([System.TimeZone]::CurrentTimeZone).StandardName})`n" | Out-File $LogFileScript -Append
	Write-Verbose "$(Get-Date -Format "HH:mm:ss") Local log file path: $LogFileScript"
  }
  # write to log
  "$(Get-date -Format G) | $text" | Out-File $LogFileScript -Append
  # write text verbosely
  Write-Verbose $text
  if ($tee)
  {
    # make sure the foreground color is valid
    if ($foreColors -contains $foreColor -and $foreColor)
    {
      Write-Host -ForegroundColor $foreColor -BackgroundColor $backColor $text
    } else {
      Write-Host $text
    }
  }
} # end Write-Log
#endregion  ::::: [Functions] -----------------------------------------------------------#
#region ::::: CONSTANTS AND VARIABLES ------------------------------------------------#

# OS version
#[void]( $Script:OSinfo = (Get-CimInstance Win32_OperatingSystem) )
$Script:osVer = (Get-WmiObject win32_operatingsystem).Version
$Script:osNameLong = $Script:osName = (Get-WmiObject win32_operatingsystem).Name
$Script:osMajVer = [System.Environment]::OSVersion.Version.Major
$Script:osMinVer = [System.Environment]::OSVersion.Version.Minor
$Script:osBldVer = [System.Environment]::OSVersion.Version.Build
$Script:PSver = $PSVersionTable.PSVersion.Major

#endregion ::::: CONSTANTS AND VARIABLES ---------------------------------------------#

$invocation = (Get-Variable MyInvocation).Value
$scriptName = $MyInvocation.MyCommand.Name
$ScriptBeginTimeStamp = Get-Date
if ($CreateTestFiles.IsPresent) { CreateTestFiles }

#region  ::::: [MAIN] ----------------------------------------------------------------#
Write-Log -tee -foreColor Yellow -backColor black "*** Please DON'T CLOSE this PURGE window while TSS is running, in order to avoid running out of diskspace."
Write-Log -tee "Script will stop automatically once $StopTokenFile exists"
Write-Log -tee "  Trace NrFilesToKeep   : $NrFilesToKeep"
Write-Log -tee "  EtlBuffer size        : $EtlBuf MB"
Write-Log -tee "  ProcMon pml keep      : $ProcMNrFilesToKeep"
Write-Log -tee "  PollInterval          : $PollInterval seconds"
Write-Log -tee "  Repro Start time      : $DateTime"
Write-Log -tee "  Data Folder Folderpath: $Folderpath"
Write-Log -tee "  Caller                : $Caller"
Write-Log -tee "  FilenameList to purge : '$FilenameList'`n"

$host.ui.RawUI.WindowTitle = "DON'T close this PS Purge Window keep $NrFilesToKeep trace files, $ProcMNrFilesToKeep ProcMon, Interval: $PollInterval sec"
Write-Log -tee -foreColor Cyan -backColor black "[ACTION] Purging files:`n Keep only latest $ProcMNrFilesToKeep ProcMon and $NrFilesToKeep Trace (*.Etl or *cap*) files in $Folderpath with filenames containing '$FilenameList', PollInterval: $PollInterval sec `n"

$Script:LoopCnt = 0
$Script:PMpurgeCnt=$ProcMNrFilesToKeep

# calculate disk space
#$FileCriteriaList = ($FilenameList.Trim() -split " ") 
$FileCriteriaList = ($FilenameList.Trim("/"," ") -split "/") 
Write-Log -tee "FileCriteriaList: '$FileCriteriaList' `n "
$calcETL = $($NrFilesToKeep * $($FileCriteriaList).count * $EtlBuf )
$calcProcM = $($ProcMNrFilesToKeep * 300)
Write-Log -tee -foreColor Cyan -backColor black "[INFO] Diskspace (estimated):`n For a longtime repro: Expected minimum required diskspace on $Folderpath is: $calcETL MB ETL's + $calcProcM MB ProcMon = $($calcETL + $calcProcM) MB total, excluding Perfmon/iDNA/ProcDump `n"

Write-Log -tee -foreColor Green -backColor black "...waiting for 'TSS OFF' or stop condition met to stop."
Write_Transcript "LoopCnt: "

# consider to use LastWriteTime instead of CreationTime to get results consistent with that shown in Windows Explorer.
While ( -not (Test-Path $StopTokenFile)) {
	Write-Host -backgroundColor Blue -foregroundColor Cyan -NoNewline -Object "." -Separator .
	Start-Sleep -Seconds $PollInterval
	# ETL purge, including *ndiscap* *NMcap* chained traces
	ForEach ($FileCrit in $FileCriteriaList) {
		$FileCrit = "*" + $FileCrit + "_*"	# file name criteria must end with '_'
		write-Debug "[Purge-Main] FileCrit: $FileCrit"
		#_# Write-Log -tee "[Purge-Main] FileCrit: $FileCrit"
		Get-ChildItem -Path "$Folderpath\*$FileCrit" -Exclude *ProcMon* -Recurse| Where-Object {-not $_.PsIsContainer}| sort CreationTime -desc| select -Skip $NrFilesToKeep | Remove-Item -Force 
		}
	$Script:LoopCnt +=1
	"$Script:LoopCnt " | Out-File $Script:LogFileScript -Append -NoNewline
	# ProcMon purge
	$PMfilesCount = ((Get-ChildItem -Path "$Folderpath\*.pml" | Where-Object {-not $_.PsIsContainer}).count)
	if ($PMfilesCount) {
		$PM_nr_filesCount = ((Get-ChildItem -Path ($Folderpath +"\*procmon*_"+ $Script:ProcMonBlockNr +"*.pml") | Where-Object {-not $_.PsIsContainer}).count)
		Write-Verbose " [ $Script:LoopCnt] total PMfilesCount: $PMfilesCount - Block PM-Nr: $Script:ProcMonBlockNr - PMpurgeCnt $Script:PMpurgeCnt -ge keep: $ProcMNrFilesToKeep ? PM_nr_filesCount= $PM_nr_filesCount -ge $ProcMNrFilesToKeep ?"
		if (($Caller -match "ProcMon") -and ($PMfilesCount -gt $ProcMNrFilesToKeep) -and ($PM_nr_filesCount -ge $ProcMNrFilesToKeep))  { # consider -clike instead of -match
			Write-Verbose "[Purge-Main] Current Procmon Files: $PMfilesCount, $Script:LoopCnt purging... `n"
			RestartProcMon $ProcMNrFilesToKeep
			$Script:PMpurgeCnt=0
		}
	}
	$Script:PMpurgeCnt +=1
}

# doublecheck if Procmon is stopped
#	Start-Process $Procmon_exe -ArgumentList "/Terminate"
	$p = Get-Process -Name "procmon" -EA SilentlyContinue
	if ($p) { Write-Log -tee ".. sending a second 'ProcMon.exe /Terminate'"
			  Start-Process $Procmon_exe -ArgumentList "/Terminate"
			  #Stop-Process -InputObject $p		# avoid killing as it might corrupt *.pml
			  #Get-Process | Where-Object {$_.HasExited}
			}


Write-Log -tee "`n[Purge-Main] End-Trigger: $StopTokenFile exists"
$ScriptEndTimeStamp = Get-Date
$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
Write-Log -tee -backColor Gray -foreColor Black "[Purge-Main] $(Get-Date -UFormat "%R:%S") Done on this PC $env:COMPUTERNAME; script $scriptName $ScriptVersion took $Duration - will close in 20 sec`n"
Start-Sleep -Seconds 20
#endregion  ::::: [MAIN] -------------------------------------------------------------#

#region  ::::: [ToDo] ----------------------------------------------------------------#
<# TodDo: - done roughly: calculate max disk space usage -> now fully in tss_PrereqCheck.ps1
		-  log all purge actions logfile
  Info: 4577110 How to setup unattended circular ProcMon capture
#>
#endregion  ::::: [ToDo] -------------------------------------------------------------#
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAZtqDq2jZmyp6w
# b/fF6eRR7pYHSNfC1v6WyQMwuczWM6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg6SJkUBKS
# Y0Bvzn1a2UNY3imvo7mlVC/wuKJ4mNj0RGkwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBADrso1a/IQ/QVgnJB3im5wC6EgD5PCyjGoH0nloTfSuxZaptBjU9jty6
# QVrTh+W2PuMRGjA4sjQ06TMZScxg5jjl4L+ModGoaUIHSza0aUzB/KhQSJYC1Wh9
# NNQf3gATojnGR9MZGfaGVV3UkpNKfHJlQ4n8uez9tA0RJbiFry2JekEYKjn9Km6W
# YGnMdkrosDLFAsu+y+O4DnsP0MxXfTgcpeo/b4CFKEn+UFlG2vUF3r7QYrDKs8U+
# TKfuxlKGTqWIRVo84suMWFqd00RD10FXHvpBHs5x1o8Wx39XLB3oaSgIovNIWL0/
# VZ7vEpCnQdXJU8MS0owTtIJyNWoLxIihghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQg+GTmhwVE/JsdCHNng3Rt6D1/nDh4oxMFZ+qDSfJl6bYCBmCJ5ae1
# AhgTMjAyMTA1MTkyMjIxNTQuMzQyWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkQ5
# REUtRTM5QS00M0ZFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFh9aIzXqAqJGkAAAAAAWEwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjIxWhcNMjIwNDExMTkwMjIxWjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkQ5REUtRTM5QS00M0ZF
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAl4idqEGtT/8bNOqHFTIALxRdy3pQkKRv
# bERkpXeCOCCYsCF4GvEmTu0f4/Da1NzJqstF+ZXbGjmgGTmlb85wNz+f9NxN5BTo
# kg3k+VNyfQL1GUpDq3065T9YDIDEZOMoTgQ2dSNe3GI2UP8rZkYwu+OlE4EqHtO2
# RQkrpkZbD+5NFps0HFGDXdO+OQYdcRQQMnyKZpzD0EJ5H0vq6d2vfa2Ph244UgcP
# ybV6zdI033xmrggME/cJxv4dCDGlt4chSUrTLrObMiS983vdnHB8a8W/T8xrHv1Y
# ljRwPymgKdkWKNyJat/R4PVPb/7seB7DOt3E91IWhyRRDxCi8gMhiQIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFFYemp3WG/vVJWPksB0980Ts+EsvMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBABBMD1upUGbHlNMyHOP5DzNaQ9BeAJxJCKrLZhhYXSFa
# vkYSI3Yu0D4RZ27XLyjKxlq7gI/tLMzxVNKrfUIsmI7Lf1nhG8SraavQR+0W+ZfY
# LFDtnLOuSFYxlplAuRhsfmhpsgXCd1bfieH3zQE5jf3m1+c1L9jo3R/6Nd2gWft8
# jZzjdMVixSog9aM4cmWgx6S2UPr+5LpmfjGx7+Ui0Wb59Y5wHYDHJcQHdlER5KD2
# Pv4agSXXFP+Im5X9KjtOVZ3DJpxC7iW/cwGy/HNEhsqFnCsNiiCajIn6vCBAHyYp
# Lj8zVING0im1qahMUnnpOToO5RfHUm51Oh6WCMRk9rkwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkQ5REUtRTM5QS00
# M0ZFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQAVblKEDDl6RMRe8v/hXWzStsPPeaCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9qYzAiGA8y
# MDIxMDUxOTE0NDM0N1oYDzIwMjEwNTIwMTQ0MzQ3WjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT2pjAgEAMAoCAQACAhgIAgH/MAcCAQACAhEmMAoCBQDkULvjAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAQ/fNWVdcCfg7UyzryzXV/Qtaewq6
# 2ZYucmWztg31qUW4D6Mlyr9LzHZWgkBYBlN1a11Pk3sZ/8F5MB7wPSStS8BiQo32
# wgXEGxX1m6bzz4c0/pffKf4IP5nM6WG2q+Ab5+65Fc+60tl8tz8EzDSlUqiny3Li
# 32jULlyCEgfWfy4xggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAWH1ojNeoCokaQAAAAABYTANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCABuAsX
# gn+Cy1imKAYzjrXe/L1EsZmbewbg6/pVeEXUuDCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIGHPi6fqaRIt3/MD7Q3lgsMani9b9UG01b+WmaG0CThvMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFh9aIzXqAqJGkA
# AAAAAWEwIgQgCtu8lvmPnmsMBBrtHHkruaOfFRjpGCJFjUBE46mbasswDQYJKoZI
# hvcNAQELBQAEggEAHUtDYhpSUEva62v8QwYUUgWL0p6YgbbI8IwbXbM0QdGuxaNg
# cFEFiu8CTaOWtYvGIkI1uYB7KUB7cJ4t+gj7/6Mx2CW844neEv/1BGkaOVzQposy
# 01S77IFuunQgfqrUgnauLKwc9EYViPZiEUQL+yD0mdmSaXW3Wi4C8qILRhBednDd
# uOUdzFbzWSI7YddHXne24Jp2l19GdGMoG6t0aceJAPFxWs1dcXe/JRd0Tytlogkq
# JI7c7TU9RxkK9NZvyAFnjdsrerWX6wnieCLFdvTq+4K8EcEtC9/3tNsGsYdN+OfQ
# XXNU1dY/sLjnRvPdOb0YDa5ftiA7uCzB5F7MfQ==
# SIG # End signature block
