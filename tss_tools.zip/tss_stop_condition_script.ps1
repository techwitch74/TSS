<# Name: tss_stop_condition_script.ps1 [-Folderpath -TestCondition -PollIntervalInSec] [-BranchCache or -BC] [-PortLoc] [-PortDest] [-SvcName] [-ServerName] [-ShareName] [-FilePath] [-ProcessName] [-DomainName] [-WaitTimeInSec] [-reg_keyLoc] [-reg_keyName] [-reg_ExpectedValue] 
Purpose: use this PowerShell script in combination with 'TSS Stop:ps1' as a stop trigger for data collection
Examples:
1.  until the system stops listening on local TCP 0.0.0.0:135

:: Purpose:  script to process individual stop condition and then end the 'tss ... ' repro section
::
:: Script input parameters: 
:: 	%1 _Folderpath		- path for output data
:: 	%2 _TestCond		- Name of predefined or custom Test condition, Examples below (BranchCache|BC|Dfs|FileExist|HTTP|PortDest|PortLoc|Process|RDP|Reg|Smb|Svc|WINRM|custom)
:: 	%3 _PollInterval 	- Interval in seconds to check, default is 8 seconds
:: 	%4 _StopFileExists	- Filename for termination condition

#>


<# 
.SYNOPSIS
	Script to process individual stop condition and then end the 'tss .. Stop:ps1:... ' repro section, if a failure happens

.DESCRIPTION
	Script will process individual stop condition, choose from BranchCache|BC|Dfs|FileExist|HTTP|LDAP|PortDest|PortLoc|Process|RDP|Reg|Smb|Svc|WINRM|Share|custom
	i.e. 'FileExist' will stop if a file with specification <_FilePath> exists on \\ServerName\ShareName\<_FilePath>
	'Reg' requires additional Registry key definition ($reg_keyLoc and $reg_keyName) within this script param section
	Prior to checking the Reg-test-condition it will the run extra repro steps if script tss_custom_repro_steps.ps1 exists in currrent folder

.PARAMETER Folderpath
	Specify a path for output data, i.e. C:\MS_DATA
	
.PARAMETER TestCondition
	Name of predefined or custom Test condition, Specify one of the predefined test Examples (BranchCache|BC|Dfs|FileExist|HTTP|LDAP|PortDest|PortLoc|Process|RDP|Smb|Svc|WINRM|Share|custom)
	
.PARAMETER PollIntervalInSec
	Specify an interval in seconds for test-condition checks, default is 8 seconds
	
.PARAMETER BranchCache or BC
	Specify a threshold to watch for, BCpercent=120 or BCpercent=180, to be configured in tss_config.cfg
.PARAMETER FilePath

.PARAMETER PortLoc
	Specify a local TCP port number to watch for, if local port is still listening
.PARAMETER PortDest
	Specify a Destination TCP port number to watch for,	if remote system is still listening
.PARAMETER SvcName
	Verify if the service with serviceName is running
.PARAMETER ServerName
	Server Name to be tested, default LocalHost
.PARAMETER ShareName
	SMB Share Name to be tested
.PARAMETER ProcessName
	Process Name to be tested. Verify if the Process is running
.PARAMETER DomainName
	Domain Name to be tested. Verify if 'nltest /DSGETDC:$DomainName' returns result
.PARAMETER WaitTimeInSec
	Force a wait time in seconds after a stop condition is met, this will instruct tss to stop x seconds later.

.PARAMETER reg_keyLoc
	Define the registry path here
.PARAMETER reg_keyName
	Define the key name here
.PARAMETER reg_ExpectedValue
	Define the expected reg key lenght value here

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "BranchCache" -PollInterval 5
	Example 1: will stop if MaxCacheSizeAsNumberOfBytes exceeds 120% or 180%, or NrOfDatFilesLimit exceeds limit; checks performed in intervals of PollIntervalInSec
	
.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "PortLoc" -PollInterval 8
	Example 1: will stop if local system is no more listening on TCP port 0.0.0.0:135, checks performed in intervals of 8 seconds, default PortLoc=135

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "PortDest" -PollInterval 8 -ServerName "ServerName"
	Example 2: will stop if remote system "ServerName" is no more listening on TCP ports 135 and 445, checks performed in intervals of 8 seconds, default PortDest=135,445

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "SMB" -ServerName "ServerName"
	Example 3: will stop if server is no more listening on TCP port 445, or not pingable
	Same tests are available for HTTP,RDP,WINRM
	
.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Svc" -SvcName "LanmanServer"
	Example 4: will stop if the specified service is not running, default servcie name is LanmanWorkstation

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Share" -ServerName "ServerName" -ShareName "Contoso-Share"
	Example 5: will stop if the specified ShareName on ServerName is not reachable , default ServerName:LocalHost, ShareName:Contoso-Share

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Process" -ProcessName "notepad"
	Example 6: will stop if the specified ProcessName has stopped

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "LDAP" -DomainName "$env:userdomain"
	Example 7: will stop if  'nltest /DSGETDC:$DomainName' fails

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "Reg"
	Example 8: will stop if a registry change condition is true, plz specify your condition in fuction Test_Reg

.EXAMPLE
	.\tss_stop_condition_script.ps1 -TestCondition "FileExist" -PollInterval 3 -ServerName "ServerName" -ShareName "Contoso-Share" -FilePath "*.tmp*"
	Example 9: will stop if a file with name <_FilePath> exists on \\ServerName\ShareName
	

.LINK
	email waltere
	
#>


param(
	[string]$Folderpath = (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[ValidateSet("BranchCache","BC","Dfs","FileExist","HTTP","LDAP","PortDest","PortLoc","Process","RDP","Reg","Svc","SMB","WINRM","Share","custom")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose from: BranchCache|BC|Dfs|FileExist|HTTP|LDAP|PortDest|PortLoc|Process|RDP|Reg|Smb|Svc|WINRM|Share|custom')]
	[string]$TestCondition = "custom"
	,
	[Int32]$PollIntervalInSec 	= 8,				# repeat stop-condition tests in intervals of x seconds
	[Int32]$ErrorLimit   		= 1,				# stop i fat least x errors happend
	[Int32]$PortLoc 	 		= 135,				# choose a local TCP port number
	[Int32]$BCpercent 	 		= 120,				# for test if Branchcache size breached 120%
	[Int32]$NrOfDatFilesLimit 	= 1024,				# number of maximum Branchcache PeerDistRepub files per folder
	[string]$PortDest,								# choose a remote TCP port number
	[string]$DomainName	 = "$env:userdomain",		# for LDAP test
	[string]$Reg,									# choose a 
	[string]$FilePath 	 = "*.*tmp*",				# choose a FilePath on \\Servername\Sharename
	[string]$SvcName 	 = "LanmanWorkstation",		# choose a service name
	[string]$ServerName  = "LocalHost",				# for SMB test
	[string]$ShareName   = "Contoso-Share",			# for SMB test
	[string]$ProcessName = "notepad",				# choose a process name without '.exe'
	[Int32]$WaitTimeInSec = 0,						# this specifies the forced wait time after stop condition is met
	[string]$reg_keyLoc	  = 'HKLM:\Software\Microsoft\dot3svc\Interfaces\{949B9E32-B3F7-4E65-9A95-7F483A6CDEB8}',	#_# Define the registry path here
	[string]$reg_keyName  = 'Parameters',																			#_# Define the key name here
	[Int32]$reg_ExpectedValue	= 1190																				#_# Define the expected reg key lenght value here
	
)

$VerDate = "2021.02.18.1"

#region  ::::: Configuration parameters ::::::::::::::::::::::::::::::::::::::::::::::
	[Int32]$TST_ERR_LIMIT 	= $ErrorLimit
	#[Int32[]]$PortDest	= $(135,445)
	if ($PortDest) { $Port_Dest	= $($PortDest.split("/")) }

#endregion ::::: Configruation parameters ::::::::::::::::::::::::::::::::::::::::::::::

$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent

#region  ::::: Functions :::::

# :::::::::: Begin of your own/custom condition logic ::::::::::::::::::::::::::::::::::::::::::::::
function Test_custom {
	Write-Log "What is expected/not expected by now?"
	# Example for SMB:
	$TcpTestStatus = ((Test-NetConnection -ComputerName $ServerName -CommonTCPPort SMB -ErrorAction SilentlyContinue).TcpTestSucceeded)
	if ("$TcpTestStatus" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName stopped listening on SMB port 445, result: $TcpTestStatus "}
}
# :::::::::: End of your own/custom condition logic   ::::::::::::::::::::::::::::::::::::::::::::::

function Test_FileExist {
	# Test if a $FilePath specifcation exists on \\$Servername\$Sharename
	$FileExistStatus = Get-ChildItem -filter $FilePath -path \\$Servername\$Sharename
	if ($FileExistStatus) {$Script:StopCondFound=0; Write-Log "File $FileExistStatus.name exists on \\$Servername\$Sharename"; $FileExistStatus | Out-File $LogFileScript -Append}
}

function Test_Reg {
	# 0. run extra repro steps if script tss_custom_repro_steps.ps1 exists in currrent folder
	if ( Test-Path ($ScriptParentPath + "\tss_custom_repro_steps.ps1")) {
		if ($TST_LOOP_CNT -eq 1) { Write-Host "[$TST_LOOP_CNT] $(Get-Date -format "yyMMdd_HHmmss") : invoking repro script $ScriptParentPath\tss_custom_repro_steps.ps1 in a loop every $PollIntervalInSec seconds."} else {Write-Host "[$TST_LOOP_CNT]" -NoNewline }
		& "$ScriptParentPath\tss_custom_repro_steps.ps1" -Folderpath $Script:Folderpath -Loop_Cnt $TST_LOOP_CNT}

	# 1. Test if the given registry path exists
	if (Test-Path $reg_keyLoc) {
		# 2. Test if the registry key exists with a value
		$reg_keyValue		= (Get-ItemProperty -Path $reg_keyLoc).$reg_keyName 
		if (-not ($reg_keyValue -eq $NULL)) {
			$Reg_keyLength	= $reg_keyValue.length
			# 3. Test if a registry key REG_BINARY length has changed from known/expected length
			if ($Reg_keyLength -ne $reg_ExpectedValue) {$Script:StopCondFound=0; Write-Log "[ERROR] $reg_keyName value length $Reg_keyLength is different than $reg_ExpectedValue bytes"}
		} else { $Script:StopCondFound=0; Write-Log "[ERROR] Key $reg_keyLoc\$reg_keyName does not exist"}
	} else { $Script:StopCondFound=0; Write-Log "[ERROR] Path $reg_keyLoc does not exist"}
}

function Test_AskYN {
	Write-Log "work in progress, waiting for user answer Y/N "
	# loop until the user enters N or E
	do
	{
		Start-Sleep $PollIntervalInSec
		$UserInput = Read-Host 'Do you want to continue [Y|N] or E= end'
		if ($UserInput -match 'n') {Write-Log " ...ending loop per User Input: $UserInput "
									break}
	} until ($UserInput -match 'E')
}

function Test_BCpercent {
	# if MaxCacheSizeAsNumberOfBytes reaches 120% or 180% , checks performed in intervals of 5 minutes
	$BCTestStatus =	& "$ScriptParentPath\tss_BCpercentRule.ps1" -Folderpath $Folderpath -BCpercentNr $BCpercent -NrOfDatFilesLimit $NrOfDatFilesLimit #-EA SilentlyContinue
	if ("$BCTestStatus" -eq "False" ) {$Script:StopCondFound=0; Write-Log "Branch Cache test breached limit $BCpercent % or *.dat $NrOfDatFilesLimit, BCTestStatus result: $BCTestStatus "}
	else { Write-Verbose "$(Get-date -Format G) | Result BCpercentRule: $BCTestStatus -- Script:StopCondFound $Script:StopCondFound -- CurrentActiveCacheSize: $((Get-BCDataCache).CurrentActiveCacheSize)" }
} 
function Test_PortLoc {
	# check if system stops listening on local TCP 0.0.0.0:135
	$Script:StopCondFound = Get-NetTCPConnection -State Listen -LocalPort $PortLoc -LocalAddress 0.0.0.0 -EA SilentlyContinue
} 
function Test_PortDest ($Port, $ServerName) {
	# check if remote system stops listening on TCP port 135
	$TcpTestStatus = Test-Netconnection -ComputerName $ServerName -Port $Port -InformationLevel "Detailed" -EA SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "Test-Netconnection $ServerName failed with result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 

function Test_Share {
	# check if \\server\Share is reachable via SMB ; ToDo: note Test-NetConnection requires PS version ??
	$TestStatus = Test-Path \\$ServerName\$ShareName -ErrorAction SilentlyContinue
	if ("$TestStatus" -eq "False" ) {$Script:StopCondFound=0; Write-Log "\\$ServerName\$ShareName not reachable, result: "; $TestStatus | Out-File $LogFileScript -Append}
} 

function Test_SMB {
	# check if server is reachable via SMB port 445; ToDo: note Test-NetConnection requires PS version ??
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort SMB -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName stopped listening on SMB port 445, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 
function Test_HTTP {
	# check if server is reachable via HTTP
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort HTTP -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName is not reachable via HTTP, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
}
function Test_LDAP {
	# check for failing 'nltest /DSGETDC:$DomainName'
	$TestStatus = nltest /DSGETDC:$DomainName /LDAPONLY
	if ($LASTEXITCODE -ne 0 ) {$Script:StopCondFound=0; Write-Log "DC in Domain $DomainName is not reachable via /LDAPONLY, result: $TestStatus - LASTEXITCODE: $LASTEXITCODE "; "$($TestStatus)" | Out-File $LogFileScript -Append}
}
function Test_RDP {
	# check if server is reachable via RDP
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort RDP -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName is not reachable via RDP, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 
function Test_WINRM {
	# check if server is reachable via WINRM
	$TcpTestStatus = Test-NetConnection -ComputerName $ServerName -CommonTCPPort WINRM -InformationLevel "Detailed" -ErrorAction SilentlyContinue
	if ("$($TcpTestStatus.TcpTestSucceeded)" -eq "False" ) {$Script:StopCondFound=0; Write-Log "$ServerName is not reachable via WINRM, result: "; $TcpTestStatus | Out-File $LogFileScript -Append}
} 
function Test_Svc {
	# check if service status is Running  (not Stopped)
	$SvcStatus = ((Get-Service $SvcName -ErrorAction SilentlyContinue).Status)
	Write-Verbose "SvcStatus $SvcName :	$SvcStatus - Found: $($SvcStatus -eq "Running")"
	$Status = ((Get-Service $SvcName -ErrorAction SilentlyContinue).Status)
	if ($Status -ne "Running" ) {$Script:StopCondFound=0; Write-Log "$SvcName stopped running: $Status "}
} 
function Test_Process {
	# check if Process is running 
	$Script:StopCondFound = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue
}

#region  ::::: Helper Functions :::::
function Get-TimeStamp {
	# SYNOPSIS: Returns a timestamp string
	return "$(Get-Date -Format "yyyyMMdd_HHmmss_ffff")"
} # end Get-TimeStamp
function Write-Log {
	# SYNOPSIS: Writes script information to a log file and to the screen when -Verbose is set.
	[CmdletBinding()]param([string]$text, [Switch]$tee = $false, [string]$foreColor = $null, [string]$backColor = "DarkBlue")
	$foreColors = $backColors = "Black","Blue","Cyan","DarkBlue","DarkCyan","DarkGray","DarkGreen","DarkMagenta","DarkRed","DarkYellow","Gray","Green","Magenta","Red","White","Yellow"
	# check the log file, create if missing
	$isPath = Test-Path $LogFileScript
	if (!$isPath) {
		"TSS_stop_condition_script.ps1 v$VerDate Log started on $ENV:ComputerName - $Script:osVer - $Script:osNameLong " 	| Out-File $LogFileScript -Force
		"Local log file path: $LogFileScript" 														| Out-File $LogFileScript -Append
		"PowerShell version:  $Script:PSver " 														| Out-File $LogFileScript -Append
		"Start time (UTC):    $((Get-Date).ToUniversalTime())" 										| Out-File $LogFileScript -Append
		"Start time (Local):  $((Get-Date).ToLocalTime()) $(if ((Get-Date).IsDaylightSavingTime()) {([System.TimeZone]::CurrentTimeZone).DaylightName} else {([System.TimeZone]::CurrentTimeZone).StandardName})`n" | Out-File $LogFileScript -Append
	Write-Verbose "$(Get-Date -Format "HH:mm:ss") Local log file path: $LogFileScript"
  }
  # write to log
  "$(Get-date -Format G) | $text" | Out-File $LogFileScript -Append
  # write text verbosely
  Write-Verbose $text
  if ($tee)
  {
    # make sure the foreground color is valid
    if ($foreColors -contains $foreColor -and $foreColor)
    {
      Write-Host -ForegroundColor $foreColor -BackgroundColor $backColor $text
    } else {
      Write-Host $text
    }
  }
} # end Write-Log
#endregion  ::::: Helper Functions :::::
#endregion  ::::: Functions :::::

#region ::::: CONSTANTS AND VARIABLES :::::
#region  ::::: Variables :::::
[string]$LogFileScript=$Folderpath +"\"+ $ENV:ComputerName + "__Stop-Cond-Log_" + $TestCondition + ".txt"
Write-Verbose "LogFileScript: $LogFileScript"
[Int32]$TST_LOOP_CNT=0
[Int32]$TST_ERROR_CNT=0
#endregion  ::::: Variables :::::

# OS version
#[void]( $Script:OSinfo = (Get-CimInstance Win32_OperatingSystem) )
$Script:osVer = (Get-WmiObject win32_operatingsystem).Version
$Script:osNameLong = $Script:osName = (Get-WmiObject win32_operatingsystem).Name
$Script:osMajVer = [System.Environment]::OSVersion.Version.Major
$Script:osMinVer = [System.Environment]::OSVersion.Version.Minor
$Script:osBldVer = [System.Environment]::OSVersion.Version.Build
$Script:PSver = $PSVersionTable.PSVersion.Major

# OS version name
if ($Script:osMajVer -le 5) {
  [string]$Script:osName = "Unsupported"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 0) {
  [string]$Script:osName = "2008"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 1) {
  [string]$Script:osName = "2008R2"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 2) {
  [string]$Script:osName = "2012"
 } elseif ($Script:osMajVer -eq 6 -and $Script:osMinVer -eq 3) {
  [string]$Script:osName = "2012R2"
 } elseif ($Script:osMajVer -eq 10) {
  [string]$Script:osName = "10"
 }
#endregion ::::: CONSTANTS AND VARIABLES :::::

#region :::::  Main 
Write-Log -tee -foreColor Green "...v$VerDate - running verification for Test Condition: $TestCondition, check interval: $PollIntervalInSec seconds."

# loop iteration until $TST_ERR_LIMIT is reached
do {
	# loop until stop condition is met
	$Script:StopCondFound=1
	do
	{
		if ($TST_LOOP_CNT -ge 1 ) {Start-Sleep $PollIntervalInSec}
		$TST_LOOP_CNT +=1
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		Write-Verbose "LoopCnt: $TST_LOOP_CNT"
		switch($TestCondition)
			{
			"custom"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: custom test condition"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_custom }
			"Share"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-Path \\$ServerName\$ShareName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Share }
			"BranchCache" { if ($TST_LOOP_CNT -le 1) { Unblock-File -Path tss_BCpercentRule.ps1 -EA SilentlyContinue; Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test tss_BCpercentRule.ps1 Branchcache $BCpercent % breach"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_BCpercent }
			"BC"		{ if ($TST_LOOP_CNT -le 1) { Unblock-File -Path tss_BCpercentRule.ps1 -EA SilentlyContinue; Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test tss_BCpercentRule.ps1 Branchcache $BCpercent % breach"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_BCpercent }
			"Dfs"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: tbd"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_AskYN }
			"FileExist"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: File-Exists condition: \\$Servername\$Sharename\$FilePath"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_FileExist }
			"LDAP"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: nltest /DSGETDC:$DomainName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_LDAP }
			"PortDest"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-Netconnection -ComputerName $ServerName -Port $Port_Dest"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							foreach ($Port in $Port_Dest) {Test_PortDest $Port $ServerName} }
			"PortLoc"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Get-NetTCPConnection -State Listen -LocalPort $Port -LocalAddress 0.0.0.0"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_PortLoc }
			"Process"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Get-Process -Name $ProcessName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Process }
			"Reg"	{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Registry Change condition Key: $reg_keyName under $reg_keyLoc "} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Reg }
			"Svc"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Get-Service $SvcName"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_Svc }
			"Smb"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort SMB"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_SMB }
			"HTTP"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort HTTP"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_HTTP }
			"RDP"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort RDP"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_RDP }
			"WINRM"		{ if ($TST_LOOP_CNT -le 1) {Write-Log "[$TST_LOOP_CNT] $(Get-Date -Format "HH:mm:ss") ...running in loop: Test-NetConnection -ComputerName $ServerName -CommonTCPPort WINRM"} else {"$TST_LOOP_CNT " | Out-File $LogFileScript -Append -NoNewline}
							Test_WINRM }
			}
	} until (-NOT $Script:StopCondFound)
	$TST_ERROR_CNT +=1
	Write-Log -tee -foreColor Gray "   Error count: $TST_ERROR_CNT, waiting until count reached limit of: $TST_ERR_LIMIT"
} until ($TST_ERROR_CNT -ge $TST_ERR_LIMIT)

Write-Log -tee -foreColor Red "...v$VerDate - Stop Condition $TestCondition met at: $(Get-Date)"

# additional wait time $WaitTimeInSec after condition is met
if ($WaitTimeInSec -gt 0) { Write-Log -tee "now waiting $WaitTimeInSec seconds..."; Start-Sleep $WaitTimeInSec }
#endregion :::::  Main 
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDOW/uCESpfC/0T
# AoELMjaNEkd+SNxQhxY4MPL9K5O2i6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg/IJ5BrkJ
# Q63vsUYIq3r57RWLgFqqSsPVk3HqQadFYz4wOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAEZYwJj8/rLGwm9c5PUSAguWOBwFZGEqz8CVYUG4uDytMKakjaLuOJfc
# 5gTTq6IuaMjpO5r+qgg9uD/rOZw2aDesgjYyCX/Svx4ClLFCTlO3dY4BjpgQzHMY
# 9H544wi5NBlxikzzM3DFTLku0ofTYxOs44O1uOp6D/CJpuYjIbU7hcVVwEM+S7Ri
# qSwAu04Bx/dE5G+o98ZZ4fxH7lJIZCApP0fR6+C/raLSCdHdZMDnz09OO2/NUYQB
# rvApO2/bR6D/0s2W4zyNkYjWP5bmNU7zDPy92COQVj1or5yhGLjzpgshrnC4LYbW
# s9WIpmhmmjlUO898oKGnG22UJmP+0BChghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgwY1q9FFF3C+glsNnnmBylJIFF2Rypx8Y3tHPvcoTxD8CBmCJ+e5d
# BhgTMjAyMTA1MTkyMjIxNTMuNjU2WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYw
# QkMtRTM4My0yNjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFaLLluRDTLbygAAAAAAVowDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE2WhcNMjIwNDExMTkwMjE2WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0yNjM1
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsL1cHFcNrScIrvQd/4aKHo3FGXWYCHMU
# l2iTxuzfGknztMzbysR4eRkBoT4pv0aL1S9OlDfOsRbJZKkhCTLG/9Z/RwiEDWYk
# 6rK7bRM3eX3pm+DNivM7+tCU+9spbv2gA7j5gWx6RAK2vMz2FChLkFgbA+H1DPro
# G5LEf1DB7LA0FCyORWiKSkHGRL4RdIjOltrZp++dExfsst7Z6vJz4+U9eZNI58fV
# Y3KRzbm73OjplfSAB3iNSkHN0wuccK0TrZsvY87TRyYAmyK2qBqi/7eUWt93Sw8A
# LBMY72LKaUmVvaxq/COpKePlHMbhHEbqtTaLt61udBOjNHvc4cwY5QIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFGRzJT/1HI+SftAGhdk5NDzA3jFnMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAAAAbex8WBtSLDiBYxXxU7GVsgb8IgxKJyIO0hmc8vzg
# 4w3iUl5Xkt4mv4dgFyjHmu5Zmbj0rb2IGYm/pWJcy0/zWlhnUQUzvfTpj7MsiH+1
# Lnvg95awe88PRA7FDgc4zYY0+8UB1S+jzPmmBX/kT6U+7rW5QIgFMMRKIc743utq
# CpvcwRM+pEo8s0Alwo8NxqUrOeYY+WfNjo/XOin/tr3RVwEdEopD+FO+f/wLxjpv
# 4y+TmRgmHrso1tVVy64FbIVIxlMcZ6cee4dWD2y8fv6Wb9X/AhtlQookk7QdCbKh
# 3JJ4P8ksLs02wNhGkU37b10tG3HR5bJmiwmZPyopsEgwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0y
# NjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQDMgAWYvcYcdZwAliLeFobCWmUaLqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9+kDAiGA8y
# MDIxMDUxOTE2MDk1MloYDzIwMjEwNTIwMTYwOTUyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT36QAgEAMAoCAQACAiRAAgH/MAcCAQACAhHpMAoCBQDkUNAQAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAXQVTueK27//AUfUiggXN8DDFmThP
# HNd2Le5OoEJr8qEBfMGpVZi7jF8iZSUH9l/6ETYmHoASPTTouApmAJ5Af8Xfx/vm
# oYN8YzShzD0I4L885xMWFLRy7gTvwo2wW1zaGWI8+tWW/lQpS/DEhQ15jwffKX4A
# rrUtsL3e79dlzEYxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVosuW5ENMtvKAAAAAABWjANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCD6ZeGe
# 5DOVjd9f6URxUIXXzkS/xzC1jQVMcn1Q2aIZtDCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIJP8qCZ0xLLkXTDDghqv1yZ/kizekzSFS4gicvltsX+wMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFaLLluRDTLbygA
# AAAAAVowIgQgOL0wIlEHhiqd5WY8M69hOFUOI1uWdoiGagbxykIYFMEwDQYJKoZI
# hvcNAQELBQAEggEAGNc6wP0WsWW5C/M7XOiILdloYiXBBRnXcC5NMoCYX0IQfCc/
# D9T/oHQ9wswyVWWzi5umBLs9aEIis7rRn0LsXzMg2oUkX9dXLbv4xEM9rDyuDHJ2
# BO4QIIOFjD4/kXkkOAPfoO8ZmND5oTIoM71dC1U31LwTGU4Jbnz0fBWV9ew5u58y
# AGF4AyNm6lx3OzfztWFfXmO7RUVxdKSV78WDqS8w6zLrFWGKtSwhSxJQx5rUowP6
# JEf3h3BIvp6jPSpjq8fVpuOOaLE5yO2reJjfd0TixwENLEH5WJyENeXUqLC0OmFO
# tNBjOy9JOuUWMWEbcwxrqkgS54wJl5E8ooD66g==
# SIG # End signature block
