#_# File: _setup.ps1 adjusted for TSS package - 2020.09.13 /walterE
#_#   Note: xperf.exe,perfctrl.dll and Poolmon.exe are copied into %Windir%\system32
param([string] $IsSilentInstallation = 'false')

# This code is Copyright (c) 2016 Microsoft Corporation.
#
# All rights reserved.
#
# THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
# �INCLUDING BUT NOT LIMITED To THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
#  PARTICULAR PURPOSE.'
#
# IN NO EVENT SHALL MICROSOFT AND/OR ITS RESPECTIVE SUPPLIERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR 
# �CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
#  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION 
# �WITH THE USE OR PERFORMANCE OF THIS CODE OR INFORMATION.

[string] $Log = ([System.Environment]::ExpandEnvironmentVariables('%TEMP%') + '\ClueSetup.log')
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null

#region  ::::: [Functions] -----------------------------------------------------------#
#////////////////
#// Functions //
#//////////////

Function Write-Log
{
    param($Output)
    #// Writes to the log file.
    $TimeStamp = "$(Get-Date -format yyyyMMdd-HHmmss)"

    if ($Output -eq $null) {Add-content $Log -value ('[' + $TimeStamp + '] NULL') -Encoding Unicode;Return}
    switch ($Output.GetType().FullName)
    {
        'System.String'                {Add-content -Path $Log -value ('[' + $TimeStamp + '] ' + $Output) -Encoding Unicode}
        default                        {Add-content -Path $Log -value ('[' + $TimeStamp + ']') -Encoding Unicode; $Output >> $Log}
    }
}

Function Test-Error
{
    param($Err)
    #// Tests if an error condition exists and writes it to the log.
    if ($Err.Count -gt 0)
    {
        Write-Log ('[Test-Error] Error(s) found: ' + $Err.Count)
        Write-Log ($Err)
        $Err.Clear()
    }
}

Function Test-Property
{
	param ([Parameter(Position=0,Mandatory=1)]$InputObject,[Parameter(Position=1,Mandatory=1)]$Name)
	[Bool](Get-Member -InputObject $InputObject -Name $Name -MemberType *Property)
}

Function Write-Console
{
    param([string] $sLine, [bool] $bNoNewLine = $false, [bool] $bAddDateTime = $true, [string] $Log = $Log)
    Write-Log ($sLine)

    if ($IsSilentInstallation -eq $false)
    {
        $TimeStamp = "$(Get-Date -format yyyyMMdd-HHmmss)"
        if ($bAddDateTime -eq $true)
        {
            [string] $sOutput = '[' + $TimeStamp + '] ' + $sLine
        }
        else
        {
            [string] $sOutput = $sLine
        }

        if ($bNoNewLine -eq $false)
        {
            Write-Host $sOutput
        }
        else
        {
            Write-Host $sOutput -NoNewline
        }        
    }    
}

Function Write-MsgBox
{
    param([string] $sLine, [string] $Log = $Log)    
    if ($IsSilentInstallation -eq $false)
    {
        Write-Console ('[PopUp] ' + $sLine)
        [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
        [void] [Microsoft.VisualBasic.Interaction]::MsgBox($sLine, 0, 'Tool configuration')
    }
}

Function Test-Numeric
{
    param($Value)
    [double] $number = 0
    Return [double]::TryParse($Value, [REF]$number)
}

Function ConvertTo-DataType
{
	param([double] $ValueAsDouble, [string] $DataTypeAsString = 'integer')
	$sDateType = $DataTypeAsString.ToLower()
    If ((Test-Numeric -Value $ValueAsDouble) -eq $True)
    {
    	switch ($sDateType)
    	{
    		'integer' {[Math]::Round($ValueAsDouble,0)}
    		'round1' {[Math]::Round($ValueAsDouble,1)}
    		'round2' {[Math]::Round($ValueAsDouble,2)}
    		'round3' {[Math]::Round($ValueAsDouble,3)}
    		'round4' {[Math]::Round($ValueAsDouble,4)}
    		'round5' {[Math]::Round($ValueAsDouble,5)}
    		'round6' {[Math]::Round($ValueAsDouble,6)}
    		default {$ValueAsDouble}
    	}
    }
    Else
    {
        $ValueAsDouble
    }
}

Function Set-OverallProgress
{
    param([string] $Status='')
    $global:iOverallCompletion++
    $iPercentComplete = ConvertTo-DataType $(($global:iOverallCompletion / 14) * 100) 'integer'
    If ($iPercentComplete -gt 100){$iPercentComplete = 100}
    $sComplete = "Clue installation progress: $iPercentComplete%... $Status"
    Write-Progress -activity 'Progress: ' -status $sComplete -percentcomplete $iPercentComplete -id 1;
    $global:oOverallProgress = 'Overall progress... Status: ' + "$($Status)" + ', ' + "$($sComplete)"
}

Function OpenConfigXml
{
    param([string] $XmlFilePath='.\config.xml')
    #// Opens config.xml
    If (Test-Path -Path $XmlFilePath)
    {
        Return (Get-Content -Path $XmlFilePath)
    }
    Else
    {
        Return $null
    }
}

Function Test-XmlEnabled
{
    param($XmlNode)
    #// Tests if an XML atribute is enabled or not and returns a boolean value.
    If ((Test-Property -InputObject $XmlNode -Name 'Enabled') -eq $True)
    {
        If ($XmlNode.Enabled -eq 'True')
        {Return $true} Else {Return $false}
    }
    Else
    {
        Return $false
    }
}

Function Get-XmlAttribute
{
    param([System.Xml.XmlElement] $XmlNode, [string] $Name)
    if (Test-Property -InputObject $XmlNode -Name $Name)
    {
        Return [string] $XmlNode.$Name
    }
    else
    {Return [string] ''}
}

Function Set-XmlAttribute
{
    param([System.Xml.XmlElement] $XmlNode, [string] $Name, [string] $Value)
    if (Test-Property -InputObject $XmlNode -Name $Name)
    {
        $XmlNode.$Name = $Value
    }
}

function Get-OutputDirectory
{
    param($XmlConfig, [string] $Log = $Log)
    Write-Log ('[Get-OutputDirectory]: START')
    [bool] $IsDone = $false
    [string] $OutputDirectory = Get-XmlAttribute -XmlNode $XmlConfig -Name 'OutputDirectory'
    if ($OutputDirectory -eq '')
    {
        [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
        $sResponse = ''
        if ($IsSilentInstallation -eq $false)
        {
            [int] $Yes = 6; [int] $No = 7;

            while ($sResponse -eq '')
            {
                Write-Console '[PopUp] Waiting for user response...' -bNoNewLine $true -bAddDateTime $false
                $sResponse = [Microsoft.VisualBasic.Interaction]::InputBox('This is where output files will go. Several gigabytes might be necessary.', 'Clue tool - Output Directory', 'C:\ClueOutput')
                Write-Log ('UserResponse: ' + $sResponse)

                if ($sResponse -eq '')
                {
                    $iYesNo = [Microsoft.VisualBasic.Interaction]::MsgBox('Are you sure you?', 4, 'Clue tool - Cancel Installation')
                }

                if ($iYesNo -eq $Yes)
                {
                    Exit;
                }

                while ($sResponse.Contains(' '))
                {
                    $sResponse = $sResponse.Replace(' ','')
                    $sResponse = [Microsoft.VisualBasic.Interaction]::InputBox('Please provide a folder path without spaces. This is due to how the Task Scheduler handles parameters.', 'Clue tool - Output Directory - Try Again', $sResponse)
                    Write-Log ('UserResponse: ' + $sResponse)
                }
            }
        }

        if ($sResponse -eq '')
        {
            Write-Console ('!!!ERROR!!! Unable to continue without an output directory. Setup has failed.')
            if ($IsSilentInstallation -eq 'false')
            {
                Write-MsgBox ('Unable to continue without an output directory. Setup has failed!')
            }
            Break;
        }

        $OutputDirectory = $sResponse
    }
    Write-Log ("`t" + 'OutputDirectory: "' + $OutputDirectory + '"')
    Write-Log ('[Get-OutputDirectory]: END')
    Return $OutputDirectory
}

function Download-SysInternalsTool
{
    param([string] $FileName, [string] $DownloadToFolderPath)
    
    $webclient = New-Object System.Net.WebClient
    [string] $FilePath = $DownloadToFolderPath + '\' + $FileName
        
    if (Test-Path -Path $FilePath)
    {
        Write-Console ($FilePath + ' is already downloaded.')
        Return $true
    }
    else
    {   
        [string] $url = 'http://live.sysinternals.com/' + $FileName
        Write-Console ('Downloading ' + $url + '...')
        $webclient.DownloadFile($url,$FilePath)
    }

    if (Test-Path -Path $FilePath)
    {
        Write-Console 'Downloaded!'
    }
    else
    {
        Write-Console 'Unable to download ' + $FileName + '. Download this SysInternals file manually from ' + $url + ' and place it in the sysint folder under the CLUE installation folder. Otherwise, the CLUE tool might not function properly.'
    }
}

function Get-UploadNetworkShare
{
    param($XmlConfig, [string] $Log = $Log)
    Write-Log ('[Get-UploadNetworkShare]: START')
    $UploadNetworkShare = Get-XmlAttribute -XmlNode $XmlConfig -Name 'UploadNetworkShare'
    if ($UploadNetworkShare -eq '')
    {
        [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
        [int] $Yes = 6; [int] $No = 7;
        $sResponse = ''
        if ($IsSilentInstallation -eq $false)
        {
            Write-Console '[PopUp] Waiting for user response...' -bNoNewLine $true -bAddDateTime $false
            $sResponse = [Microsoft.VisualBasic.Interaction]::InputBox('This is the network share (\\server\share) where Clue will upload incident data and download updates. Grant the SYSTEM account of this computer read/write access to the network share. Leave blank if this is a stand-alone installation.', 'Clue tool - Network Share', '')
            Write-Log ('UserResponse: ' + $sResponse)
        }
        
        if ($sResponse -ne '')
        {
            $UploadNetworkShare = $sResponse
        }
    }
    Write-Log ("`t" + 'UploadNetworkShare: "' + $global:UploadNetworkShare + '"')
    Write-Log ('[Get-UploadNetworkShare]: END')
    Return $UploadNetworkShare
}

Function Get-EmailForReport
{
    param($XmlConfig, [string] $Log = $Log)
    Write-Log ('[Get-EmailForReport]: START')
    $EmailReportTo = Get-XmlAttribute -XmlNode $XmlConfig -Name 'EmailReportTo'
    if ($EmailReportTo -eq '')
    {
        $sResponse = ''
        if ($IsSilentInstallation -eq $false)
        {
            [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
            Write-Console '[PopUp] Waiting for user response...' -bNoNewLine $true -bAddDateTime $false
            $sResponse = [Microsoft.VisualBasic.Interaction]::InputBox('What email addresses (separated by semi-colon (;)) do you want the report sent to?', 'Clue tool - Email report to...', '')
            Write-Log ('UserResponse: ' + $sResponse)
        }
        
        if ($sResponse -ne '')
        {
            $EmailReportTo = $sResponse
        }
    }
    Write-Log ("`t" + 'EmailReportTo: "' + $EmailReportTo + '"')
    Write-Log ('[Get-EmailForReport]: END')
    Return $EmailReportTo
}

Function Get-RegistryKey
{
    param([string] $Path)
    #// Example: (Get-RegistryKey -Path 'HKEY_CURRENT_USER\SOFTWARE\Sysinternals\Handle').EulaAccepted
    $Path = 'Registry::' + $Path
    if (Test-Path -Path $Path)
    {
        Get-ItemProperty -Path $Path -ErrorAction SilentlyContinue
    }
    else
    {
        Return $null
    }
}

function Get-CollectionLevel
{
    param($XmlConfig, [string] $Log = $Log)
    Write-Log ('[Get-CollectionLevel]: START')
    $CollectionLevel = Get-XmlAttribute -XmlNode $XmlConfig -Name 'CollectionLevel'
    if ($CollectionLevel -eq '')
    {
        $CollectionLevel = 1
    }
    Write-Log ("`t" + 'CollectionLevel: "' + $global:CollectionLevel + '"')
    Write-Log ('[Get-CollectionLevel]: END')
    Return $CollectionLevel
}

Function Get-FolderPathFromFilePath
{
    param([string] $FilePath)
    Write-Log ('[Get-FolderPathFromFilePath] FilePath: ' + $FilePath)
    if ($FilePath -ne '')
    {
        [string] $NewPath = ''
        [System.String[]] $aTemp = @($FilePath.Split('\',[StringSplitOptions]'RemoveEmptyEntries'))
        for ($i=0;$i -lt $aTemp.GetUpperBound(0);$i++)
        {
            $NewPath = $NewPath + $aTemp[$i] + '\'
        }
        $NewPath = $NewPath.Substring(0,($NewPath.Length - 1))
        Write-Log ('[Get-FolderPathFromFilePath] NewPath: ' + $NewPath)
        Return $NewPath
    }
    else {Return ''}
}

function ConvertTo-SoftwareVersion
{
    param([string] $SoftwareVersion)
    $aSplit = @($SoftwareVersion.Split('.'))
    switch ($aSplit.Count)
    {
        1       {[system.version] $NewVersion = $SoftwareVersion + '.0.0.0'}
        2       {[system.version] $NewVersion = $SoftwareVersion + '.0.0'}
        3       {[system.version] $NewVersion = $SoftwareVersion + '.0'}
        default {[system.version] $NewVersion = $SoftwareVersion}
    }
    Return $NewVersion
}

Function Test-OSCompatibility
{
    [System.Version] $VersionCompatible = '10.0.15063.0'

    $oWmiOs = Get-WmiObject -Query 'SELECT * FROM Win32_OperatingSystem'
    Write-Log ('[Test-OSCompatibility] OS Version: ' + $oWmiOs.Version)
    $VersionOs = ConvertTo-SoftwareVersion -SoftwareVersion $oWmiOs.Version

    if ($VersionOs -lt $VersionCompatible)
    {
        Return $false
    }

    [int] $x86 = 0
    [int] $x64 = 9
    $iArch = @(Get-WmiObject -Query 'SELECT * FROM Win32_Processor')[0].Architecture
    Write-Log ('OS Architecture (0=x86) (9=x64): ' + $iArch)
    if (($iArch -ne $x86) -and ($iArch -ne $x64))
    {
        Return $false
    }

    Return $true
}

function Test-AdminRights
{
    [string] $sLine = ''
    $oOutput = Invoke-Expression -Command 'logman create counter AdminTest1234 -c "\Processor(*)\% Processor Time"'
    foreach ($sLine in $oOutput)
    {
        if ($sLine.Contains('command completed successfully'))
        {
            $oOutput = Invoke-Expression -Command 'logman delete AdminTest1234'
            Return $true
        }
    }
    Return $false
}

Function Get-TaskSchedulerService
{
    try
    {
        $oTaskSchedulerService = New-Object -ComObject 'Schedule.Service'
        $oTaskSchedulerService.Connect()
        Return $oTaskSchedulerService
    }
    catch
    {
        Return $null
    }
}

Function Remove-AllScheduledTasksInToolFolder
{
    $oTaskSchedulerService = Get-TaskSchedulerService
    Test-Error -Err $Error

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": START')
    $oTaskSchedulerFolder = $null
    $oParentTaskSchedulerFolder = $oTaskSchedulerService.GetFolder('\Microsoft\Windows')
    $oFolders = $oParentTaskSchedulerFolder.GetFolders(0)
    :FolderLoop foreach ($oFolder in $oFolders)
    {
        if ($oFolder.Name -eq 'Clue')
        {
            $oTaskSchedulerFolder = $oFolder
            Break FolderLoop;
        }        
    }

    if ($oTaskSchedulerFolder -eq $null)
    {
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": END')
        Return $null
    }

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": END')

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get tasks of "\Microsoft\Windows\Clue": START')
    $oTasks = $oTaskSchedulerFolder.GetTasks(0)
    Test-Error -Err $Error
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get tasks of "\Microsoft\Windows\Clue": END')

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete tasks of "\Microsoft\Windows\Clue": START')
    ForEach ($oTask in $oTasks)
    {
        $oTask.Stop(0)
        Test-Error -Err $Error
        Start-Sleep -Seconds 2
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete task "\Microsoft\Windows\Clue\' + $oTask.Name + '": START')
        $oTaskSchedulerFolder.DeleteTask($oTask.Name, 0)
        Test-Error -Err $Error
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete task "\Microsoft\Windows\Clue\' + $oTask.Name + '": END')
        Write-Console '.' -bNoNewLine $true -bAddDateTime $false
    }
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete tasks of "\Microsoft\Windows\Clue": END')
    
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": START')
    $oTaskSchedulerFolder = $oTaskSchedulerService.GetFolder('\Microsoft\Windows')
    Test-Error -Err $Error
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": END')

    if ($oTaskSchedulerFolder -is [System.__ComObject])
    {
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete "\Microsoft\Windows\Clue": START')
        $oTaskSchedulerFolder.DeleteFolder('Clue', 0)
        Test-Error -Err $Error
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete "\Microsoft\Windows\Clue": END')
    }
}

Function New-DirectoryWithConfirm
{
    param([string] $DirectoryPath)

    Write-Log ('[New-DirectoryWithConfirm] DirectoryPath: ' + $DirectoryPath)
    if ((Test-Path -Path $DirectoryPath) -eq $False)
    {
        $aFolderPath = $DirectoryPath.Split('\',[StringSplitOptions]'RemoveEmptyEntries')
        [string] $sPartialPath = ''
        [string] $sParentPath = ''
        ForEach ($sPath in $aFolderPath)
        {
            if ($sPartialPath -eq '')
            {
                $sPartialPath = $sPath
                $sParentPath = $sPath + '\'
            }
            else
            {
                $sParentPath = $sPartialPath + '\'
                $sPartialPath = $sPartialPath + '\' + $sPath
            }

            if ((Test-Path -Path $sPartialPath) -eq $False)
            {
                $oNull = New-Item -Path $sParentPath -Name $sPath -type directory
            }
        }
    }
    Return (Test-Path -Path $DirectoryPath)
}

Function Get-TaskSchedulerService
{
    param([string] $Log = '.\Clue.log')
    try
    {
        $oTaskSchedulerService = New-Object -ComObject 'Schedule.Service'
        $oTaskSchedulerService.Connect()
        Return $oTaskSchedulerService
    }
    catch
    {
        Return $null
    }
}

Function Get-Ps2ScheduledTaskFolder
{
    param([string] $Path)

    $oTaskSchedulerService = Get-TaskSchedulerService

    if ($oTaskSchedulerService -eq $null)
    {
        Return $null
    }

    try
    {
        $oTaskSchedulerFolder = $oTaskSchedulerService.GetFolder($Path)
    }
    catch
    {

    }

    if ($oTaskSchedulerFolder -ne $null)
    {
        Return $oTaskSchedulerFolder
    }
    
    if ($Path.Contains('\'))
    {
        $aPath = $Path.Split('\',[StringSplitOptions]'RemoveEmptyEntries')
    }
    else
    {
        Return $null
    }
    
    [int] $iCount = 0
    For ($i = 0; $i -le $aPath.GetUpperBound(0); $i++)
    {
        [string] $sBuildPath = $sBuildPath + '\' + $aPath[$i]

        try
        {
            Write-Log ('sBuildPath: ' + $sBuildPath)
            $oTaskSchedulerFolder = $oTaskSchedulerService.GetFolder($sBuildPath)
        }
        catch
        {
            try
            {
                #// Get the parent path and create it.
                if ($oTaskSchedulerParentFolder -ne $null)
                {
                    $oTaskSchedulerFolder = $oTaskSchedulerParentFolder.CreateFolder($aPath[$i])
                }
                else
                {
                    Return $null
                }
            }
            catch
            {
                Return $null
            }
        }
        finally
        {
            $oTaskSchedulerParentFolder = $oTaskSchedulerFolder
        }
        $iCount++
    }

    if ($iCount -eq $aPath.Count)
    {
        Return $oTaskSchedulerFolder
    }
    else
    {
        Return $null
    }
}

Function New-Ps2ScheduledTask
{
    param([string] $ScheduledTaskFolderPath, [string] $Name, [string] $Description, [string] $Path, [string] $Arguments, [string] $Trigger, [string] $WorkingDirectory, [string] $StartImmediately = 'true', [string] $Priority = 'normal')

    $TASK_TRIGGER_TIME = 1
    $TASK_TRIGGER_BOOT = 8
    $EXECUTABLE_OR_SCRIPT = 0
    $CREATE_OR_UPDATE = 6
    $TASK_LOGON_SERVICE_ACCOUNT = 5
    $TASK_LOGON_PASSWORD = 1
    $HIGH_PRIORITY_CLASS = 1
    $THREAD_PRIORITY_LOW = 8

    Write-Log ('[New-Ps2ScheduledTask]: START')
    Write-Log ('[New-Ps2ScheduledTask]: ' + $ScheduledTaskFolderPath + ',' + $Name + ',' + $Description + ',' + $Path + ',' + $Arguments + ',' + $Trigger + ',' + $WorkingDirectory + ',' + $StartImmediately)

    $oTaskSchedulerFolder = Get-Ps2ScheduledTaskFolder -Path $ScheduledTaskFolderPath

    if ($oTaskSchedulerFolder -eq $null)
    {
        Return $false
    }

    $oTaskSchedulerService = Get-TaskSchedulerService
    $oTaskDefinition = $oTaskSchedulerService.NewTask(0)

    $oTaskDefinition.RegistrationInfo.Description = $Description
    $oTaskDefinition.RegistrationInfo.Author = 'Clint Huffman (clinth@microsoft.com)'
    $oTaskDefinition.Settings.StartWhenAvailable = $true
    $oTaskDefinition.Settings.ExecutionTimeLimit = 'PT0S'
    $oTaskDefinition.Settings.AllowHardTerminate = $false
    $oTaskDefinition.Settings.StopIfGoingOnBatteries = $false
    $oTaskDefinition.Settings.DisallowStartIfOnBatteries = $false
    
    $oTaskDefinition.Settings.IdleSettings.StopOnIdleEnd = $false

    if ($Priority -eq 'high')
    {
        $oTaskDefinition.Settings.Priority = $HIGH_PRIORITY_CLASS
    }

    if ($Priority -eq 'low')
    {
        $oTaskDefinition.Settings.Priority = $THREAD_PRIORITY_LOW
    }

    if (($Trigger -eq 'onstart') -or ($Trigger -eq '0'))
    {
        $oNewTrigger = $oTaskDefinition.Triggers.Create($TASK_TRIGGER_BOOT)
    }

    if (Test-Numeric -Value $Trigger)
    {
        [string] $sTriggerInterval = 'PT' + $Trigger + 'M'
        $oNewTrigger = $oTaskDefinition.Triggers.Create($TASK_TRIGGER_TIME)
        $oNewTrigger.Repetition.Interval = $sTriggerInterval
        $oNewTrigger.StartBoundary = '2015-01-01T10:00:00'
    }

    $oNewAction = $oTaskDefinition.Actions.Create($EXECUTABLE_OR_SCRIPT)

    $oNewAction.Path = $Path
    $oNewAction.Arguments = $ExecutionContext.InvokeCommand.ExpandString($Arguments)
    
    $oNewAction.WorkingDirectory = $WorkingDirectory
    $oTask = $oTaskSchedulerFolder.RegisterTaskDefinition($Name, $oTaskDefinition, $CREATE_OR_UPDATE, 'SYSTEM', $null, $TASK_LOGON_SERVICE_ACCOUNT)

    if ($StartImmediately -eq 'true')
    {
        Start-Sleep -Seconds 2
        [void] $oTask.Run('')
    }
    Write-Log ('[New-Ps2ScheduledTask]: END')
}

Function Start-Ps2ScheduledTask
{
    param([string] $ScheduledTaskFolderPath, [string] $TaskName, [string] $Arguments)

    [string] $TaskPath = $ScheduledTaskFolderPath + '\' + $TaskName
    Write-Log ('[Start-Ps2ScheduledTask: ' + $TaskPath + ']: START')
    Write-Log ('[Start-Ps2ScheduledTask: ' + $TaskPath + ']: Getting folder path...')
    $oTaskSchedulerFolder = Get-Ps2ScheduledTaskFolder -Path $ScheduledTaskFolderPath
    Test-Error -Err $Error
    Write-Log ('[Start-Ps2ScheduledTask: ' + $TaskPath + ']: Getting folder path...Done!')
    if ($oTaskSchedulerFolder -eq $null)
    {
        Return $false
    }
    Write-Log ('[Start-Ps2ScheduledTask: ' + $TaskPath + ']: Getting task...')
    $oTask = $oTaskSchedulerFolder.GetTask($TaskName)
    Write-Log ('[Start-Ps2ScheduledTask: ' + $TaskPath + ']: Getting task...Done!')
    Test-Error -Err $Error
    Write-Log ('[Start-Ps2ScheduledTask: ' + $TaskPath + ']: Running task...')
    $oTaskInstance = $oTask.Run($Arguments)
    Test-Error -Err $Error
    Write-Log ('[Start-Ps2ScheduledTask: ' + $TaskPath + ']: Running task...Done!')
    Write-Log ('[Start-Ps2ScheduledTask: ' + $TaskPath + ']: END')
}

Function Remove-Ps2ScheduledTask
{
    param([string] $Folder, [string] $Task)
    $oTaskSchedulerService = Get-TaskSchedulerService
    $oTaskSchedulerFolder = $oTaskSchedulerService.GetFolder($Folder)
    $oTaskSchedulerFolder.DeleteTask($Task, 0)
}

Function Remove-Ps2ToolScheduledTaskFolder
{
    param([string] $Folder, [string] $Task)
    $oTaskSchedulerService = Get-TaskSchedulerService
    $oTaskSchedulerFolder = $oTaskSchedulerService.GetFolder($Folder)
    $oTasks = $oTaskSchedulerFolder.GetTasks(0)
    ForEach ($oTask in $oTasks)
    {
        $oTaskSchedulerFolder.DeleteTask($oTask.Name, 0)

    }
}

Function Remove-AllScheduledTasksInToolFolder
{
    $oTaskSchedulerService = Get-TaskSchedulerService
    Test-Error -Err $Error

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": START')
    $oTaskSchedulerFolder = $null
    $oParentTaskSchedulerFolder = $oTaskSchedulerService.GetFolder('\Microsoft\Windows')
    $oFolders = $oParentTaskSchedulerFolder.GetFolders(0)
    :FolderLoop foreach ($oFolder in $oFolders)
    {
        if ($oFolder.Name -eq 'Clue')
        {
            $oTaskSchedulerFolder = $oFolder
            Break FolderLoop;
        }        
    }

    if ($oTaskSchedulerFolder -eq $null)
    {
        Return $null
    }

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": END')

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get tasks of "\Microsoft\Windows\Clue": START')
    $oTasks = $oTaskSchedulerFolder.GetTasks(0)
    Test-Error -Err $Error
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get tasks of "\Microsoft\Windows\Clue": END')

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete tasks of "\Microsoft\Windows\Clue": START')
    ForEach ($oTask in $oTasks)
    {
        $oTask.Stop(0)
        Test-Error -Err $Error
        Start-Sleep -Seconds 2
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete task "\Microsoft\Windows\Clue\' + $oTask.Name + '": START')
        $oTaskSchedulerFolder.DeleteTask($oTask.Name, 0)
        Test-Error -Err $Error
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete task "\Microsoft\Windows\Clue\' + $oTask.Name + '": END')
        Write-Console '.' -bNoNewLine $true -bAddDateTime $false
    }
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete tasks of "\Microsoft\Windows\Clue": END')
    
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": START')
    $oTaskSchedulerFolder = $oTaskSchedulerService.GetFolder('\Microsoft\Windows')
    Test-Error -Err $Error
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": END')

    if ($oTaskSchedulerFolder -is [System.__ComObject])
    {
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete "\Microsoft\Windows\Clue": START')
        $oTaskSchedulerFolder.DeleteFolder('Clue', 0)
        Test-Error -Err $Error
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete "\Microsoft\Windows\Clue": END')
    }
}

Function New-Ps2EventLogScheduledTask
{
    param([string] $ScheduledTaskFolderPath, [string] $Name, [string] $Description, [string] $Path, [string] $LogFile, [string] $Source, [string] $EventType, [string] $EventID,  [string] $Arguments, [string] $WorkingDirectory, [string] $Priority = 'normal')

    Write-Log ('[New-Ps2EventLogScheduledTask]: START')
    Write-Log ('[New-Ps2EventLogScheduledTask]: ' + $ScheduledTaskFolderPath + ',' + $Name + ',' + $Description + ',' + $Path + ',' + $LogFile + ',' + $Source + ',' + $EventID + ',' + $EventType + ',' + $Arguments + ',' + $Trigger + ',' + $WorkingDirectory + ',' + $StartImmediately)

    $TASK_TRIGGER_TIME = 1
    $TASK_TRIGGER_BOOT = 8
    $EXECUTABLE_OR_SCRIPT = 0
    $CREATE_OR_UPDATE = 6
    $TASK_LOGON_SERVICE_ACCOUNT = 5
    $TASK_LOGON_PASSWORD = 1
    $HIGH_PRIORITY_CLASS = 1
    $THREAD_PRIORITY_LOW = 8
    $TRIGGER_TYPE_EVENT = 0

    $oTaskSchedulerFolder = Get-Ps2ScheduledTaskFolder -Path $ScheduledTaskFolderPath

    if ($oTaskSchedulerFolder -eq $null)
    {
        Return $false
    }

    $oTaskSchedulerService = Get-TaskSchedulerService
    $oTaskDefinition = $oTaskSchedulerService.NewTask(0)

    $oTaskDefinition.RegistrationInfo.Description = $Description
    $oTaskDefinition.RegistrationInfo.Author = 'Clint Huffman (clinth@microsoft.com)'
    $oTaskDefinition.Settings.StartWhenAvailable = $true
    $oTaskDefinition.Settings.ExecutionTimeLimit = 'PT0S'
    $oTaskDefinition.Settings.AllowHardTerminate = $false
    $oTaskDefinition.Settings.StopIfGoingOnBatteries = $false
    $oTaskDefinition.Settings.DisallowStartIfOnBatteries = $false

    if ($Priority -eq 'high')
    {
        $oTaskDefinition.Settings.Priority = $HIGH_PRIORITY_CLASS
    }

    if ($Priority -eq 'low')
    {
        $oTaskDefinition.Settings.Priority = $THREAD_PRIORITY_LOW
    }

    $oNewTrigger = $oTaskDefinition.Triggers.Create($TRIGGER_TYPE_EVENT)
    switch ($EventType)
    {
        'Critical'    {$EventType = 1}
        'Error'       {$EventType = 2}
        'Warning'     {$EventType = 3}
        'Information' {$EventType = 4}
        'Verbose'     {$EventType = 5}
        default       {$EventType = 2}
    }

    [string] $Query = '*[System[(Level="' + $EventType + '") and EventID="' + $EventID + '"]]'
    $Subscription = "<QueryList><Query Id=`"1`"><Select Path=`"$Source`">$Query</Select></Query></QueryList>"
    $oNewTrigger.Subscription = $Subscription

    $oNewAction = $oTaskDefinition.Actions.Create($EXECUTABLE_OR_SCRIPT)

    $oNewAction.Path = $Path
    $oNewAction.Arguments = $ExecutionContext.InvokeCommand.ExpandString($Arguments)
    
    $oNewAction.WorkingDirectory = $WorkingDirectory
    $oTask = $oTaskSchedulerFolder.RegisterTaskDefinition($Name, $oTaskDefinition, $CREATE_OR_UPDATE, 'SYSTEM', $null, $TASK_LOGON_SERVICE_ACCOUNT)
    Write-Log ('[New-Ps2EventLogScheduledTask]: END')
}

Function Get-WorkingDirectoryFromTask
{
    param([string] $ScheduledTaskFolderPath = '\Microsoft\Windows\Clue', [string] $TaskName = 'Invoke-Rule')
    $oTaskFolder = Get-Ps2ScheduledTaskFolder -Path $ScheduledTaskFolderPath
    if ($oTaskFolder -eq $null)
    {
        Return ''
    }
    try {$oTask = $oTaskFolder.GetTask($TaskName)} catch {}
    if ($oTask -eq $null)
    {
        Return ''
    }
    foreach ($oAction in $oTask.Definition.Actions)
    {
        [string] $WorkingDirectory = $oAction.WorkingDirectory
        if ($WorkingDirectory.Length -gt 0)
        {
            Return $WorkingDirectory
        }
    }
    Return ''
}

Function Start-Wpr
{
    param([string] $WptFolderPath, [string] $Arguments = '-start GeneralProfile', [string] $Log = '.\Clue.log')
    $OriginalDirectory = (PWD).Path
    [string] $sCmd = '.\wpr.exe ' + $Arguments
    Write-Log ('[Start-Wpr] ' + $sCmd) -Log $Log
    Set-Location -Path $WptFolderPath
    $oOutput = Invoke-Expression -Command $sCmd
    Write-Log ($oOutput) -Log $Log
    Test-Error -Err $Error -Log $Log
    Set-Location -Path $OriginalDirectory
}
#endregion  ::::: [Functions] --------------------------------------------------------#

#region  ::::: [MAIN] ----------------------------------------------------------------#
#///////////
#// Main //
#/////////
New-Item -Path $Log -ItemType File -Force | Out-Null
Write-Log ('[Setup]: Start')
$Error.Clear()

Write-Console (Get-Location).Path
$InvocationFolderPath = ($SCRIPT:MyInvocation.MyCommand.Path) -replace '\\_setup.ps1',''
$ToolsDir = Split-Path -Parent $InvocationFolderPath	#_# added for Poolmon.exe and Xperf.*
Write-Console ('InvocationFolderPath: ' + $InvocationFolderPath)

[bool] $IsSilentInstallation = [System.Convert]::ToBoolean($IsSilentInstallation)
[string] $global:ToolName = 'Clue'
[string] $global:ScheduledTaskFolderPath = "\Microsoft\Windows\$global:ToolName"

[int] $global:iOverallCompletion = 0
Write-Progress -activity 'Overall progress: ' -status 'Progress: 0%' -percentcomplete 0 -id 1
Test-Error -Err $Error

Write-Log ('IsSilentInstallation = ' + $IsSilentInstallation.ToString())
Write-Console '/////////////////////////////'
Write-Console '// Clue tool installation //'
Write-Console '///////////////////////////'
Write-Console ''
Write-Console '/////////////////////'
Write-Console '// Compatible OS? //'
Write-Console '///////////////////'

[bool] $IsOsCompatible = Test-OSCompatibility
Test-Error -Err $Error
Write-Console ('IsOsCompatible: ' + $IsOsCompatible.ToString())
if ($IsOsCompatible -eq $false)
{
    Write-Log ('This software requires x86 (32-bit) or x64 (64-bit) Windows 10 Creators Update (10.15063.0).')
    if ($IsSilentInstallation -eq 'false')
    {
        Write-Console '[PopUp] This software requires x86 (32-bit) or x64 (64-bit) Windows 10 Creators Update (10.15063.0).'
        Write-MsgBox 'This software requires x86 (32-bit) or x64 (64-bit) Windows 10 Creators Update (10.15063.0) or later.'
    }
    Exit;
}
Test-Error -Err $Error
Write-Console ''

Set-OverallProgress -Status 'Admin rights...'
Write-Console '///////////////////'
Write-Console '// Admin rights //'
Write-Console '/////////////////'
[bool] $IsElevated = Test-AdminRights
Test-Error -Err $Error
Write-Console ('IsElevated: ' + $IsElevated.ToString())
if ($IsElevated -eq $false)
{
    Write-MsgBox 'Administrator rights is required. Try running setup again with Administrator rights.'
    Exit;
}
Write-Console ''

Set-OverallProgress -Status 'Test Windows Performance Toolkit...'
Write-Console '////////////////////////////////////////'
Write-Console '// Windows Performance Toolkit (WPT) //'
Write-Console '//////////////////////////////////////'
[string] $FilePathOfWpr = ($env:Windir + '\System32\wpr.exe')
[bool] $IsWprFound = Test-Path -Path $FilePathOfWpr
Test-Error -Err $Error
Write-Console ('IsWprFound: ' + $IsWprFound.ToString())
if ($IsWprFound -eq $false)
{
    Write-MsgBox 'Unable to find Windows Performance Recorder (wpr.exe).'
    Exit;
}
$WptFolderPath = ($env:Windir + '\System32')
Write-Console ''

Set-OverallProgress -Status 'Delete scheduled tasks...'
Write-Console '/////////////////////////////'
Write-Console '// Delete scheduled tasks //'
Write-Console '////////////////////////////'
Write-Console ''
Write-Console 'Deleting scheduled tasks...' -bNoNewLine $true
Remove-AllScheduledTasksInToolFolder
Test-Error -Err $Error
Write-Console 'Done!' -bAddDateTime $false
Write-Console ''

Set-OverallProgress -Status 'Configuring...'
Write-Console '//////////////////////'
Write-Console '// Open Config.xml //'
Write-Console '////////////////////'
Write-Console ''
[xml] $XmlDoc = OpenConfigXml -XmlFilePath "$InvocationFolderPath\config.xml"
Test-Error -Err $Error
if (Test-Property -InputObject $XmlDoc -Name 'Configuration')
{
    [System.Xml.XmlElement] $XmlConfig = $XmlDoc.Configuration
    Write-Console ('IsConfigFileLoadedFromInvocationFolder: True')
}
Test-Error -Err $Error
if ($XmlConfig -eq $null)
{
    Write-MsgBox 'Unable to get the XML configuration. Setup has failed.'
    Exit;
}

Set-OverallProgress -Status 'Installation folder...'
Write-Console ''
Write-Console '//////////////////////////'
Write-Console '// Installation folder //'
Write-Console '////////////////////////'
Write-Console ''
Write-Console 'Getting installation folder...' -bNoNewLine $true
$InstallationDirectory = Get-XmlAttribute -XmlNode $XmlConfig -Name 'InstallationDirectory'
Test-Error -Err $Error
if ($InstallationDirectory -eq '') {$InstallationDirectory = '%ProgramFiles%\Clue'}
$InstallationDirectory = [System.Environment]::ExpandEnvironmentVariables($InstallationDirectory)
Write-Console 'Done!' -bAddDateTime $false
Write-Console ("`t" + 'Installation folder: "' + $InstallationDirectory + '"')
if (Test-Path -Path $InstallationDirectory) 
{
    Write-Console 'Removing previous installation folder...' -bNoNewLine $true
    Remove-Item -Path $InstallationDirectory -Recurse -ErrorAction SilentlyContinue
    Write-Console 'Done!' -bAddDateTime $false
}
Test-Error -Err $Error
Write-Console ("`t" + 'InvocationFolderPath:  ' + $InvocationFolderPath)
Write-Console ("`t" + 'InstallationDirectory: ' + $InstallationDirectory)

#$SourcePath = $InvocationFolderPath + '\*'
$SourcePath = $InvocationFolderPath + '\'
#_#$SourcePath = $InvocationFolderPath
Write-Console ("`t" + 'SourcePath:            ' + $SourcePath)
Write-Console 'Copying content to installation folder...' -bNoNewLine $true
Copy-Item -Path $SourcePath -Destination $InstallationDirectory -Recurse -Force -ErrorAction SilentlyContinue
$Error.Clear()
Write-Console 'Done!' -bAddDateTime $false
[string] $FilePathOfConfigXml = $InstallationDirectory + '\config.xml'
if (Test-Path -Path $FilePathOfConfigXml)
{
    Write-Console ("`t" + 'Folder copy successful.')
}
else
{	Write-Console ("`t" + 'Test-Path -Path ' + $FilePathOfConfigXml ) #_#
    Write-Console ("`t" + 'Folder copy FAILED! See "' + $Log + '" for details.')
    Exit;
}
Write-Console ('Log: ' + $Log)
Write-Console ('Loading config.xml from installation directory') -bNoNewLine $true
[xml] $XmlDoc = OpenConfigXml -XmlFilePath $FilePathOfConfigXml
Test-Error -Err $Error
if (Test-Property -InputObject $XmlDoc -Name 'Configuration')
{
    [System.Xml.XmlElement] $XmlConfig = $XmlDoc.Configuration
}
Test-Error -Err $Error
if ($XmlConfig -eq $null)
{
    Write-MsgBox 'Unable to get the XML configuration. Setup has failed.'
    Exit;
}
Write-Console 'Done!' -bAddDateTime $false

Write-Console ''
Write-Console '/////////////////'
Write-Console '// Copy Xperf //'
Write-Console '///////////////'
Write-Console ''
#_# $xSourcePath = $InvocationFolderPath + '\xperf.exe'
$xSourcePath = $ToolsDir + '\xperf.exe'
$xDestination = ($env:Windir + '\System32')
Write-Console ('xSourcePath: ' + $xSourcePath)
Write-Console ('xDestination: ' + $xDestination)
Copy-Item -Path $xSourcePath -Destination $xDestination -Force -ErrorAction SilentlyContinue
#_# $xSourcePath = $InvocationFolderPath + '\perfctrl.dll'
$xSourcePath = $ToolsDir + '\perfctrl.dll'
$xDestination = ($env:Windir + '\System32')
Write-Console ('xSourcePath: ' + $xSourcePath)
Write-Console ('xDestination: ' + $xDestination)
Copy-Item -Path $xSourcePath -Destination $xDestination -Force -ErrorAction SilentlyContinue

#_# copy Poolmon.exe
$xSourcePath = $ToolsDir + '\Poolmon.exe'
$xDestination = ($env:Windir + '\System32')
Write-Console ('xSourcePath: ' + $xSourcePath)
Write-Console ('xDestination: ' + $xDestination)
Copy-Item -Path $xSourcePath -Destination $xDestination -Force -ErrorAction SilentlyContinue

$xPath = $xDestination + '\xperf.exe'
$IsConfirmed = (Test-Path $xPath)
Write-Console ('xPerfConfirmed: ' + $IsConfirmed.ToString())
$xPath = $xDestination + '\perfctrl.dll'
$IsConfirmed = (Test-Path $xPath)
Write-Console ('PerfCtrlConfirmed: ' + $IsConfirmed.ToString())
$xPath = $xDestination + '\Poolmon.exe'
$IsConfirmed = (Test-Path $xPath)
Write-Console ('PoolmonConfirmed: ' + $IsConfirmed.ToString())

<#
Write-Console ''
Write-Console '/////////////////////////'
Write-Console '// Copy UserInitiated //'
Write-Console '///////////////////////'
Write-Console ''
[string] $DesktopBatchFile = $(Get-Content env:PUBLIC) + '\Desktop\ClueUserInitiated.bat'
$xSourcePath = $InvocationFolderPath + '\ClueUserInitiatedDataCollector.bat'
$xDestination = ($env:PUBLIC + '\Desktop')
Write-Console ('xSourcePath: ' + $xSourcePath)
Write-Console ('xDestination: ' + $xDestination)
Copy-Item -Path $xSourcePath -Destination $xDestination -Force -ErrorAction SilentlyContinue
#>

Set-OverallProgress -Status 'Output folder...'
Write-Console ''
Write-Console '////////////////////'
Write-Console '// Output folder //'
Write-Console '//////////////////'
Write-Console ''
Write-Console 'Getting output folder...' -bNoNewLine $true
$OutputDirectory = Get-OutputDirectory -XmlConfig $XmlConfig
if ($OutputDirectory -eq '') {$OutputDirectory = 'C:\ClueOutput'}
Write-Console 'Done!' -bAddDateTime $false
Write-Console ("`t" + 'Output folder: "' + $OutputDirectory + '"')
Test-Error -Err $Error
Write-Console ("`t" + 'Creating output folder...') -bNoNewLine $true
$IsDone = New-DirectoryWithConfirm -DirectoryPath $OutputDirectory
if ($IsDone -eq $false)
{
    Write-Console ('!!!ERROR!!! Unable to create output directory ' + $OutputDirectory + '"')
    Exit;
}
Write-Console ('Done!') -bAddDateTime $false

Set-OverallProgress -Status 'Upload folder...'
Write-Console ''
Write-Console '////////////////////'
Write-Console '// Upload folder //'
Write-Console '//////////////////'
Write-Console ''
Write-Console 'Getting upload network share (optional)...' -bNoNewLine $true
$UploadNetworkShare = Get-UploadNetworkShare -XmlConfig $XmlConfig
Write-Console 'Done!' -bAddDateTime $false
Write-Console ("`t" + 'Upload network share: "' + $UploadNetworkShare + '"')
Test-Error -Err $Error

Set-OverallProgress -Status 'Email address(es)...'
Write-Console ''
Write-Console '///////////////////////'
Write-Console '// Email address(es) //'
Write-Console '/////////////////////'
Write-Console ''
Write-Console '// Get email address for report //'
Write-Console 'Getting email address(es) for the end user report (optional)...' -bNoNewLine $true
$EmailReportTo = Get-EmailForReport -XmlConfig $XmlConfig
Write-Console 'Done!' -bAddDateTime $false
Write-Console ("`t" + 'Email report to: "' + $EmailReportTo + '"')
Test-Error -Err $Error


Set-OverallProgress -Status 'Collection Level...'
Write-Console ''
Write-Console '///////////////////////'
Write-Console '// Collection Level //'
Write-Console '/////////////////////'
Write-Console ''
$CollectionLevelDefault = 1
$CollectionLevel = Get-CollectionLevel -XmlConfig $XmlConfig
Write-Console ("`t" + 'CollectionLevel: "' + $CollectionLevel + '"')
$IsNumeric = Test-Numeric -Value $CollectionLevel
Test-Error -Err $Error
If ($IsNumeric)
{
    if (($CollectionLevel -ge 0) -and ($CollectionLevel -le 3))
    {
        $IsFound = Test-Path -Path 'HKLM:\SOFTWARE\Clue'
        If ($IsFound -eq $false)
        {
            New-Item -Path 'HKLM:\SOFTWARE\Clue' -Force | Out-Null
        }
        $IsFound = Test-Path -Path 'HKLM:\SOFTWARE\Clue'
        If ($IsFound -eq $true)
        {
            New-ItemProperty -Path 'HKLM:\SOFTWARE\Clue' -Name 'CollectionLevel' -Value $CollectionLevel -PropertyType DWORD -Force | Out-Null
        }
        $RegCollectionLevel = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Clue').CollectionLevel
        Write-Console ("`t" + 'HKLM:\SOFTWARE\ClueRegCollectionLevel: "' + $RegCollectionLevel + '"')
        if ($CollectionLevel -ne $RegCollectionLevel)
        {
            Write-Console ('Failed to set HKLM:\SOFTWARE\Clue\CollectionLevel to: ' + $CollectionLevel)
        }
    }
    else
    {
        Write-Console ('CollectLevel must be a value between 0 and 3. Setting to default.')
    }
}
else
{
    Write-Console ('CollectLevel in config.xml is not numeric, setting to default.')
}

Set-OverallProgress -Status 'Save changes...'
Write-Console ''
Write-Console '///////////////////'
Write-Console '// Save changes //'
Write-Console '/////////////////'
Write-Console ''
Set-XmlAttribute -XmlNode $XmlConfig -Name 'OutputDirectory' -Value $OutputDirectory
Test-Error -Err $Error
Set-XmlAttribute -XmlNode $XmlConfig -Name 'UploadNetworkShare' -Value $UploadNetworkShare
Test-Error -Err $Error
Set-XmlAttribute -XmlNode $XmlConfig -Name 'EmailReportTo' -Value $EmailReportTo
Test-Error -Err $Error
Set-XmlAttribute -XmlNode $XmlConfig -Name 'WptFolderPath' -Value $WptFolderPath
Test-Error -Err $Error
$XmlDoc.Save($FilePathOfConfigXml)
Test-Error -Err $Error

Set-OverallProgress -Status 'PAL collector...'
Write-Console ''
Write-Console '////////////////////'
Write-Console '// PAL Collector //'
Write-Console '//////////////////'
Write-Console ''
Write-Console 'Creating PalCollector (this may take a few minutes)...' -bNoNewLine $true
& $InstallationDirectory\PalCollector\PalCollector.ps1 -OutputDirectory $OutputDirectory -Log '.\PalCollector.log'
Write-Console 'Done!' -bAddDateTime $false
Test-Error -Err $Error

Set-OverallProgress -Status 'Scheduled tasks...'
Write-Console ''
Write-Console '//////////////////////'
Write-Console '// Scheduled tasks //'
Write-Console '////////////////////'
Write-Console ''
Write-Console 'Creating scheduled tasks...' -bNoNewLine $true
foreach ($XmlNode in $XmlConfig.Rule)
{
    if (Test-XmlEnabled -XmlNode $XmlNode)
    {
        $NodeType = Get-XmlAttribute -XmlNode $XmlNode -Name 'Type'
        switch ($NodeType)
        {
            'Counter'
            {
                $Name = Get-XmlAttribute -XmlNode $XmlNode -Name 'Name'
                [string] $Arguments = '-ExecutionPolicy ByPass -File Test-CounterRule.ps1 -RuleName ' + $Name
                $IsCreated = New-Ps2ScheduledTask -ScheduledTaskFolderPath $global:ScheduledTaskFolderPath -Name $Name -Path 'powershell' -Arguments $Arguments -WorkingDirectory $InstallationDirectory -Description 'Performance counter data collector.' -Trigger '5' -StartImmediately $false
            }

            'EventLog'
            {
                $Name = Get-XmlAttribute -XmlNode $XmlNode -Name 'Name'
                $Description = Get-XmlAttribute -XmlNode $XmlNode -Name 'Description'
                $LogFile = Get-XmlAttribute -XmlNode $XmlNode -Name 'LogFile'
                $Source = Get-XmlAttribute -XmlNode $XmlNode -Name 'Source'
                $EventID = Get-XmlAttribute -XmlNode $XmlNode -Name 'EventID'
                $EventType = Get-XmlAttribute -XmlNode $XmlNode -Name 'EventType'
                [string] $Arguments = '-ExecutionPolicy ByPass -File Test-EventLogRule.ps1 -RuleName ' + $Name
                $IsCreated = New-Ps2ScheduledTask -ScheduledTaskFolderPath $global:ScheduledTaskFolderPath -Name $Name -Path 'powershell' -Arguments $Arguments -WorkingDirectory $InstallationDirectory -Description $Description -Trigger '5' -StartImmediately $false
            }

            'ScheduledTask'
            {
                [string] $Name = Get-XmlAttribute -XmlNode $XmlNode -Name 'Name'
                [string] $Description = Get-XmlAttribute -XmlNode $XmlNode -Name 'Description'
                [string] $Path = Get-XmlAttribute -XmlNode $XmlNode -Name 'Path'
                [string] $Arguments = Get-XmlAttribute -XmlNode $XmlNode -Name 'Arguments'
                [string] $Trigger = Get-XmlAttribute -XmlNode $XmlNode -Name 'Trigger'
                [string] $StartImmediately = Get-XmlAttribute -XmlNode $XmlNode -Name 'StartImmediately'
                [bool] $IsStartImmediately = [System.Convert]::ToBoolean($StartImmediately)
                $IsCreated = New-Ps2ScheduledTask -ScheduledTaskFolderPath $global:ScheduledTaskFolderPath -Name $Name -Path $Path -Arguments $Arguments -WorkingDirectory $InstallationDirectory -Description $Description -Trigger $Trigger -StartImmediately $IsStartImmediately
            }
        }
    }
    Write-Console '.' -bNoNewLine $true -bAddDateTime $false
    Test-Error -Err $Error
}
Write-Console 'Done!' -bAddDateTime $false

Set-OverallProgress -Status 'Scheduled tasks...'
Write-Console ''
Write-Console '//////////////////'
Write-Console '// WMI Tracing //'
Write-Console '/////////////////'
Write-Console ''
Write-Console 'Enabling WMI EventLog Tracing...' -bNoNewLine $true
[string] $sCmd = 'Wevtutil.exe sl Microsoft-Windows-WMI-Activity/Trace /e:true /q:true'
$oOutput = Invoke-Expression -Command $sCmd
Write-Log ($oOutput) -Log $Log
Test-Error -Err $Error -Log $Log
[string] $sCmd = 'Wevtutil.exe sl Microsoft-Windows-WMI-Activity/Operational /e:true /q:true'
$oOutput = Invoke-Expression -Command $sCmd
Write-Log ($oOutput) -Log $Log
Test-Error -Err $Error -Log $Log
Write-Console 'Done!' -bAddDateTime $false

#// Finalize setup.
Write-Progress -activity 'Overall progress: ' -status 'Progress: 100%' -Completed -id 1
Write-Console '[PopUp] Please acknowledge installation has finished...' -bNoNewLine $true
[string] $FinalMessage = ('Installation is finished! For details see ' + $Log)
Write-Console ''
Write-Console '////////////'
Write-Console '// DONE! //'
Write-Console '//////////'
Write-Console ''
Write-MsgBox $FinalMessage
Write-Console 'Done!' -bAddDateTime $false
Write-Log ('[Setup]: End')
#endregion  ::::: [MAIN] -------------------------------------------------------------#

# SIG # Begin signature block
# MIIjeQYJKoZIhvcNAQcCoIIjajCCI2YCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAHxjNMk3bUpC/J
# LW3nMTJ4aBiGPH6jLhR5fMLQIoN8I6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVTjCCFUoCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgstUv2XUL
# WzkvJP/1+Bboq64g7hyHlXRvutJHTFWT+FcwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBABQb0Y4yoKuVkWWS5cqQfIlznpXsnlDAfK0VL4smpsSxs+CraVlkCpH7
# HRoMs0qbuw7C3VWF+YOqpwuxRzS/yMGpYnaQRywvCw6PdCP0+03IB1mKZwP1J5Gw
# 2GSlvQjG+Zkb2t8Idoe9KPhm/5d+RUaIER6WkFFgJl/1tQiyDuSyLmSZqgKc20Df
# 2066Zwr9yG/ULrxgZZzpz+X0pWer0cMWro2Sc6lsB0YbSA3Ebq5M3U6wPfmwb/IX
# Kew9Mt9aVN50uc3dm1Dla3rosxKKVyxoKkF0Tg3qpOXt/bWfudW01OQgzRHsjiZD
# XCi+2ltFSLoMbE+5flKDwFu81ZpyxauhghLiMIIS3gYKKwYBBAGCNwMDATGCEs4w
# ghLKBgkqhkiG9w0BBwKgghK7MIIStwIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYL
# KoZIhvcNAQkQAQSgggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgeZggkK0AEvTvz/ieV2Scszi85hN3INzfuTfHnSWlvNsCBmDRFQ97
# 6hgTMjAyMTA3MTUxNTQ1MTAuMzI2WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
# ZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RTVBNi1F
# MjdDLTU5MkUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# gg45MIIE8TCCA9mgAwIBAgITMwAAAUedj/Hm3jGDWQAAAAABRzANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMDExMTIxODI1
# NTVaFw0yMjAyMTExODI1NTVaMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpFNUE2LUUyN0MtNTkyRTElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAK0FA0zpffYoWT8Enxhqmt/MS3ouPfgb5UuPOB8SA4ZJ
# V3Uy7ucKmErQrijI+vMi2A1GMHiBSIqrobODF0MeBk+BMS+bnvOxqxzIavJtaR/d
# VWvxup/Y8iAa/AoM0SBVzKCwRu5bBfP0uLozsA6gPhMHx+XgBOb4vtvj6VgNQwlg
# wvOmInMzvjlrRceKuJRo6lhZ+TA70fPq5/6TYervIbKC4fydo8sydh+Zgi3Y9cDB
# ZW8bgwPhhuNcFVnXi56HtiWplMy5ref2RPUJkOwe/P6jnyeyhqZdHBEU5vssONVX
# 75xkhks7b26yIjQfv21vd9K+H21TtALsKKs0IFhqA0kCAwEAAaOCARswggEXMB0G
# A1UdDgQWBBS0+Nxv3mShhlcbL0M/E3j11IKwujAfBgNVHSMEGDAWgBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNy
# dDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# CwUAA4IBAQBQxA7KNX55raQS1eoPRw58PZnY8VQjLmQuQZTndEMZx+GXMhH1CVOB
# kupMSGAsu4JLLqNyZr6c+Dt7leDWioJlxklHC1E/NLUXr8zphHfkfdus3SZpWc+u
# atD3WSR+w2oNO25YOIAgF+Q0SAKlBkJvg5Xccy7kvx5nODl1RontcT4sG6mElIsU
# m1pvFi3h+QJDGdMPbPnRjfZm5eI2YUWJrupWr7dhzeaZbTb78pYfw/Uc+Khskbxy
# sZiBISTG2RRcZ2i63AZZbzwpH1FFwz/gYouq3Y5DwBYRBvuyGAzynE2+7fRPF6NE
# ClrhYB84B6NMbj4rMGbrteNVnYiVcA+SMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAA
# AjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0
# aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPl
# YcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2T
# rNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFh
# E24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+c
# Bj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn
# 9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQB
# gjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB
# /zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEE
# AYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9Q
# S0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcA
# YQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZI
# hvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20Z
# MLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX
# /1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+TH
# zvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnx
# zplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjY
# lPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kW
# umGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3
# ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slva
# yA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5
# KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czm
# TfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYIC
# yzCCAjQCAQEwgfihgdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkU1QTYtRTI3Qy01OTJFMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQCr
# p8G0QQ2hw0BIyovTfMYlLTBl3aCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5JqOEzAiGA8yMDIxMDcxNTE4MzYw
# M1oYDzIwMjEwNzE2MTgzNjAzWjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDkmo4T
# AgEAMAcCAQACAgfTMAcCAQACAhFmMAoCBQDkm9+TAgEAMDYGCisGAQQBhFkKBAIx
# KDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZI
# hvcNAQEFBQADgYEAF/scsitTJ7u3YCnhd21jpoitlCZGP8tlrr2b0f6volOQFJsX
# x9or3VmmTYzx/3bjXXsJOfVL6fInuf3KqOaSR0D6PR4sBIcRd/+oAF6QwrpE+cSv
# S46mZpbPvlcYcCrD4eMmFFLkV6UiqvKAwAhE+qnwQP3b7avjCbNSILNHlWoxggMN
# MIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAUed
# j/Hm3jGDWQAAAAABRzANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0G
# CyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCA5yN12n3kqKbdVjB3btT0eD9WX
# UqVpdV139di8YVTeLjCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIHvbPBID
# lM+6BsiJk7/YfWGuKwBUi3DMOxxvRaqKGOmFMIGYMIGApH4wfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFHnY/x5t4xg1kAAAAAAUcwIgQgxF/aQ/Dy
# WW2+3DOjztNuPdJzwhMuEGr9s4VSnVSlGRAwDQYJKoZIhvcNAQELBQAEggEAesi9
# 9OOrI7+h5flqTiouu/+CCAe3u++LG2uBbgZrhnKRkjqTgflAsKjrCi9DQsmjXjML
# HKFmGs/lSNv9NGyw/XBrRll/6hRsXxXniIhWifs0M9Y8tm9rlBZMXzZMFxcuPrGD
# IstsimgV2izJqvBatgmPLDzY6vpEMK/tPbJLuPgVzjMEaUmVpJ3G5ZeAB5IA8Ki7
# 3PwetUrZrYxYnHhoWacs+lWsujaRxRogpXbWf6ABg0FiHAZPWxDB4db2DtvENiXK
# 2Si7wMjd0BGAdsvn0yrs2Bfk8n0oMfjEyjk+RygVwQcidYM1qPqYWAawbD8Fby98
# MkIASKDOZm8vHJrXUw==
# SIG # End signature block
