﻿param([string] $RuleName='Counter-ProcessorTimeGt90')
# This code is Copyright (c) 2016 Microsoft Corporation.
#
# All rights reserved.
#
# THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
#  INCLUDING BUT NOT LIMITED To THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
#  PARTICULAR PURPOSE.'
#
# IN NO EVENT SHALL MICROSOFT AND/OR ITS RESPECTIVE SUPPLIERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR 
#  CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
#  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION 
#  WITH THE USE OR PERFORMANCE OF THIS CODE OR INFORMATION.

Remove-Module * -Force
Import-Module .\Modules\General.psm1 -Force
Import-Module .\Modules\TaskScheduler.psm1 -Force
Import-Module .\Modules\Xml.psm1 -Force
Import-Module .\Modules\FileSystem.psm1 -Force

[string] $Log = $RuleName + '.log'

#////////////////
#// Functions //
#//////////////

Function Test-CounterInstanceExclusion
{
    param([string] $Exclude, [string] $CounterInstanceName, [string] $Log = $Log)
    
    if ($Exclude -eq '')
    {
        Return $false
    }

    [string[]] $aExclude = $Exclude.Split(',',[StringSplitOptions]'RemoveEmptyEntries')

    foreach ($sExclude in $aExclude)
    {
        if ($CounterInstanceName -imatch $sExclude)
        {
            Return $True
        }
    }
    Return $false
}

function Measure-PerformanceCounter
{
    param([string] $RuleName = 'Testing',[string] $CounterPath, [int] $SampleInterval = 1, [int] $MaxSamples = 3, [string] $Operator, [double] $Threshold, [string] $Exclude = '', [string] $Log = $Log)

    $oCounterData = @(Get-Counter -Counter $CounterPath -SampleInterval $SampleInterval -MaxSamples $MaxSamples)
    foreach ($Sample in ($oCounterData.CounterSamples))
    {
        if ($Sample.Status -ne 0)
        {
            Write-Log ('[Test-CounterRule: Sample Status: ' + $RuleName + ']: ' + $Sample.Status) -Log $Log
            Return $false
        }
    }

    Test-Error -Err $Error -Log $Log
    If ((Test-Property -InputObject $oCounterData -Name 'Count' -Log $Log) -eq $False)
    {
        Write-Log ('[Test-CounterRule:' + $RuleName + '] No data!') -Log $Log
        Return $false
    }
    else
    {
        Write-Log ('[Test-CounterRule:' + $RuleName + '] CounterData.Count: ' + $oCounterData.Count) -Log $Log
    }
    $uCounterData = $oCounterData.GetUpperBound(0)
    $uCounterSamples = $oCounterData[0].CounterSamples.GetUpperBound(0)
    Test-Error -Err $Error -Log $Log
    For ($a = 0;$a -le $uCounterSamples;$a++)
    {
        [bool] $IsWithinThreshold = $false
        [bool] $IsThresholdBrokenAtLeastOnce = $false
        :SampleDataLoop For ($b = 0; $b -le $uCounterData;$b++)
        {
            $oTime = $oCounterData[$b]
            $oCounterInstance = $oCounterData[$b].CounterSamples[$a]

            if ((Test-CounterInstanceExclusion -Exclude $Exclude -CounterInstanceName $oCounterInstance.InstanceName -Log $Log) -eq $false)
            {
                Write-Log ($oCounterInstance.Path + ', CookedValue: ' + $oCounterInstance.CookedValue) -Log $Log
                switch ($Operator)
                {
                    'gt'
                    {
                        If (($oCounterInstance.CookedValue) -gt $Threshold)
                        {$IsThresholdBrokenAtLeastOnce = $true} else {$IsWithinThreshold = $true;Break SampleDataLoop;}
                    }
                    'ge'
                    {
                        If (($oCounterInstance.CookedValue) -ge $Threshold) 
                        {$IsThresholdBrokenAtLeastOnce = $true} else {$IsWithinThreshold = $true;Break SampleDataLoop;}
                    }
                    'lt'
                    {
                        If (($oCounterInstance.CookedValue) -lt $Threshold)
                        {$IsThresholdBrokenAtLeastOnce = $true} else {$IsWithinThreshold = $true;Break SampleDataLoop;}
                    }
                    'le'
                    {
                        If (($oCounterInstance.CookedValue) -le $Threshold)
                        {$IsThresholdBrokenAtLeastOnce = $true} else {$IsWithinThreshold = $true;Break SampleDataLoop;}
                    }
                    'eq'
                    {
                        If (($oCounterInstance.CookedValue) -eq $Threshold)
                        {$IsThresholdBrokenAtLeastOnce = $true} else {$IsWithinThreshold = $true;Break SampleDataLoop;}
                    }
                    default
                    {
                        If (($oCounterInstance.CookedValue) -gt $Threshold)
                        {$IsThresholdBrokenAtLeastOnce = $true} else {$IsWithinThreshold = $true;Break SampleDataLoop;}
                    }
    	        }
                Test-Error -Err $Error -Log $Log
            }
            else
            {
                #// Write-Log ('Counter instance is excluded!') -Log $Log
            }
        }

        if (($IsThresholdBrokenAtLeastOnce -eq $true) -and ($IsWithinThreshold -eq $false))
        {
            $sCounterName = ($oCounterData[0].CounterSamples[$a]).Path
            Write-Log ($sCounterName + ' <= Exceeded the threshold') -Log $Log
            Return $true
        }
    }
    Return $False
}

function Get-CollectionLevelFromRegistry
{
    [int] $iCollectionLevel = 1
    $IsFound = Test-Path -Path 'HKLM:\SOFTWARE\Clue'
    If ($IsFound -eq $true)
    {
        $RegCollectionLevel = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Clue').CollectionLevel
        $iCollectionLevel = $RegCollectionLevel
        if (($iCollectionLevel -ge 0) -and ($iCollectionLevel -le 3))
        {
            Return $iCollectionLevel
        }
    }
}

#///////////
#// Main //
#/////////

$Error.Clear()
Write-Log ('[Test-CounterRule:' + $RuleName + '] Started') -Log $Log

#//////////////////////
#// Open config.xml //
#////////////////////

[xml] $XmlDoc = OpenConfigXml -Log $Log
Test-Error -Err $Error -Log $Log
if (Test-Property -InputObject $XmlDoc -Name 'Configuration' -Log $Log)
{
    [System.Xml.XmlElement] $XmlConfig = $XmlDoc.Configuration
}

$InstallationDirectory = $XmlConfig.InstallationDirectory
$InstallationDirectory = [System.Environment]::ExpandEnvironmentVariables($InstallationDirectory)
$OutputDirectory = $XmlConfig.OutputDirectory
$OutputDirectory = [System.Environment]::ExpandEnvironmentVariables($OutputDirectory)
$UploadNetworkShare = $XmlConfig.UploadNetworkShare
$EmailReportTo = $XmlConfig.EmailReportTo
$WptFolderPath = $XmlConfig.WptFolderPath
$CollectionLevel = $XmlConfig.CollectionLevel

$XmlRuleNode = Get-MatchingNodeByAttribute -XmlConfig $XmlConfig -NodeName 'Rule' -Attribute 'Name' -Value $RuleName -Log $Log
Test-Error -Err $Error -Log $Log

if ((Test-XmlEnabled -XmlNode $XmlRuleNode -Log $Log) -eq $false)
{
    Exit;
}

#// CounterPath
[string] $CounterPath = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'CounterPath' -Log $Log
Test-Error -Err $Error -Log $Log

#// Exclude
[string] $Exclude = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'Exclude' -Log $Log
Test-Error -Err $Error -Log $Log

#// SampleInterval
[string] $Temp = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'SampleInterval' -Log $Log
if (Test-Numeric -Value $Temp -Log $Log) {[int] $SampleInterval = $Temp} else {[int] $SampleInterval = -1}
Test-Error -Err $Error -Log $Log

#// MaxSamples
[string] $Temp = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'MaxSamples' -Log $Log
if (Test-Numeric -Value $Temp -Log $Log) {[int] $MaxSamples = $Temp} else {Write-Log ('[Test-CounterRule:' + $RuleName + '] MaxSamples is not found or not numeric.') -Log $Log;Exit;}
Test-Error -Err $Error -Log $Log

#// Operator
[string] $Operator = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'Operator' -Log $Log
#if (($Operator -ne 'gt') -and ($Operator -ne 'lt')) {Write-Log ('[Test-CounterRule:' + $RuleName + '] Operator is not found or greater than or less than sign.') -Log $Log;Exit;}
switch ($Operator)
{
    'gt' {}
    'ge' {}
    'lt' {}
    'le' {}
    'eq' {}
    default {Write-Log ('[Test-CounterRule:' + $RuleName + '] Operator is not found or greater than or less than sign.') -Log $Log;Exit;}
}
Test-Error -Err $Error -Log $Log

#// Threshold
[string] $Temp = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'Threshold' -Log $Log
if (Test-Numeric -Value $Temp -Log $Log) {[double] $Threshold = $Temp} else {Write-Log ('[Test-CounterRule:' + $RuleName + '] Threshold is not found or not numeric.') -Log $Log;Exit;}
Test-Error -Err $Error -Log $Log

#// OnStart actions
[string] $OnStartActions = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'OnStartActions' -Log $Log
Test-Error -Err $Error -Log $Log

#// OnEndActions actions
[string] $OnEndActions = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'OnEndActions' -Log $Log
Test-Error -Err $Error -Log $Log

#// MaxTraceTimeInSeconds
[int] $Temp = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'MaxTraceTimeInSeconds' -Log $Log
if (Test-Numeric -Value $Temp -Log $Log) {[int] $MaxTraceTimeInSeconds = $Temp} else {Write-Log ('[Test-CounterRule:' + $RuleName + '] MaxTraceTimeInSeconds is not found or not numeric.') -Log $Log;Exit;}
Test-Error -Err $Error -Log $Log

#// RunLimit
[int] $Ran = 0
[int] $RunLimit = 3
[int] $Temp = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'RunLimit' -Log $Log
if (Test-Numeric -Value $Temp -Log $Log) {[int] $RunLimit = $Temp} else {Write-Log ('[Test-CounterRule:' + $RuleName + '] RunLimit is not found or not numeric.') -Log $Log;Exit;}
Test-Error -Err $Error -Log $Log

#// Code
if (Test-Property -InputObject $XmlRuleNode -Name 'CODE' -Log $Log)
{
    $oDataCollector = New-Object pscustomobject
    Add-Member -InputObject $oDataCollector -MemberType NoteProperty -Name 'Name' -Value ''
    Add-Member -InputObject $oDataCollector -MemberType NoteProperty -Name 'CounterPath' -Value ''
    Add-Member -InputObject $oDataCollector -MemberType NoteProperty -Name 'Exclude' -Value ''
    Add-Member -InputObject $oDataCollector -MemberType NoteProperty -Name 'SampleInterval' -Value '1'
    Add-Member -InputObject $oDataCollector -MemberType NoteProperty -Name 'MaxSamples' -Value '3'
    Add-Member -InputObject $oDataCollector -MemberType NoteProperty -Name 'Operator' -Value 'gt'
    Add-Member -InputObject $oDataCollector -MemberType NoteProperty -Name 'Threshold' -Value ''
    Add-Member -InputObject $oDataCollector -MemberType NoteProperty -Name 'OnStartActions' -Value ''
    Add-Member -InputObject $oDataCollector -MemberType NoteProperty -Name 'OnEndActions' -Value ''
    Add-Member -InputObject $oDataCollector -MemberType NoteProperty -Name 'Code' -Value ''

    if ((Test-Property -InputObject $XmlRuleNode -Name 'Name' -Log $Log) -eq $True)           {$oDataCollector.Name           = $XmlRuleNode.Name}
    if ((Test-Property -InputObject $XmlRuleNode -Name 'CounterPath' -Log $Log) -eq $True)    {$oDataCollector.CounterPath    = $XmlRuleNode.CounterPath}
    if ((Test-Property -InputObject $XmlRuleNode -Name 'Exclude' -Log $Log) -eq $True)        {$oDataCollector.Exclude        = $XmlRuleNode.Exclude}
    if ((Test-Property -InputObject $XmlRuleNode -Name 'SampleInterval' -Log $Log) -eq $True) {$oDataCollector.SampleInterval = $XmlRuleNode.SampleInterval}
    if ((Test-Property -InputObject $XmlRuleNode -Name 'MaxSamples' -Log $Log) -eq $True)     {$oDataCollector.MaxSamples     = $XmlRuleNode.MaxSamples}
    if ((Test-Property -InputObject $XmlRuleNode -Name 'Operator' -Log $Log) -eq $True)       {$oDataCollector.Operator       = $XmlRuleNode.Operator}
    if ((Test-Property -InputObject $XmlRuleNode -Name 'Threshold' -Log $Log) -eq $True)      {$oDataCollector.Threshold      = $XmlRuleNode.Threshold}
    if ((Test-Property -InputObject $XmlRuleNode -Name 'OnStartActions' -Log $Log) -eq $True) {$oDataCollector.OnStartActions = $XmlRuleNode.OnStartActions}
    if ((Test-Property -InputObject $XmlRuleNode -Name 'OnEndActions' -Log $Log) -eq $True)   {$oDataCollector.OnEndActions   = $XmlRuleNode.OnEndActions}

    $oDataCollector.Code = $XmlRuleNode.CODE.get_innertext()
    $oDataCollector = Invoke-CounterRuleCode -DataCollector $oDataCollector -Log $Log

    $XmlRuleNode.Name = $oDataCollector.Name
    $XmlRuleNode.CounterPath = $oDataCollector.CounterPath
    $XmlRuleNode.Exclude = $oDataCollector.Exclude
    $XmlRuleNode.SampleInterval = $oDataCollector.SampleInterval
    $XmlRuleNode.MaxSamples = $oDataCollector.MaxSamples
    $XmlRuleNode.Operator = $oDataCollector.Operator
    $XmlRuleNode.Threshold = $oDataCollector.Threshold
    $XmlRuleNode.OnStartActions = $oDataCollector.OnStartActions
    $XmlRuleNode.OnEndActions = $oDataCollector.OnEndActions
    [bool] $IsDone = $false
    [int] $i = 0
    Do
    {
        $Error.Clear()
        $XmlDoc.Save('.\config.xml')
        if ($Error.Count -eq 0)
        {
            Write-Log ('Changes saved to config.xml.') -Log $Log
            $IsDone = $true
        }
        else
        {
            if ($i -ge 10) {$IsDone = $true;Write-Log ('config.xml save timeout reached!') -Log $Log} else {$i++}
            Start-Sleep -Seconds 1
        }
    } Until ($IsDone -eq $true)
    
}

$CollectionLevel = Get-CollectionLevelFromRegistry

[string] $Temp = Get-XmlAttribute -XmlNode $XmlRuleNode -Name 'Threshold' -Log $Log
if (Test-Numeric -Value $Temp -Log $Log) {[double] $Threshold = $Temp} else {Write-Log ('[Test-CounterRule:' + $RuleName + '] Threshold is not found or not numeric.') -Log $Log;Exit;}
Test-Error -Err $Error -Log $Log

Write-Log ('[Test-CounterRule] Start-TruncateLog') -Log $Log
Start-TruncateLog -FilePath $Log -Log $Log
Test-Error -Err $Error -Log $Log
Write-Log ('[Test-CounterRule] Start-TruncateLog...Done!') -Log $Log
[datetime] $dtLastLogTruncate = (Get-Date)

#////////////////////////////////////
#// Search and confirm WPT folder //
#//////////////////////////////////

[string] $WptFolderPath = ''
if (Test-Property -InputObject $XmlConfig -Name 'WptFolderPath' -Log $Log)
{
    [string] $WptFolderPath = Get-WptFolderPath -SuggestedPath $XmlConfig.WptFolderPath -Log $Log
}
else
{
    [string] $WptFolderPath = Get-WptFolderPath -Log $Log
}
Test-Error -Err $Error -Log $Log
if ($WptFolderPath -eq '')
{
    Write-Log ('[Invoke-Rule:' + $RuleName + '] Unable to find WptFolderPath. Unable to continue.') -Log $Log
}

#//////////////////////////
#// Get OutputDirectory //
#////////////////////////

[string] $OutputDirectory = ''
[string] $OutputDirectory = Get-XmlAttribute -XmlNode $XmlConfig -Name 'OutputDirectory' -Log $Log
$OutputDirectory = [System.Environment]::ExpandEnvironmentVariables($OutputDirectory)
Test-Error -Err $Error -Log $Log

if ($OutputDirectory -ne '')
{
    if ((New-DirectoryWithConfirm -DirectoryPath $OutputDirectory -Log $Log) -eq $false)
    {
        Test-Error -Err $Error -Log $Log
        Write-Log ('[Invoke-Rule:' + $RuleName + '] Unable to create: ' + $OutputDirectory) -Log $Log
        Exit;
    }
}

[datetime] $dtTraceStartTime = (Get-date)
[bool] $IsCollecting = $false
[bool] $IsTimeoutReached = $false
[string] $IncidentOutputFolder = ''
[int] $CollectionLevel = 1
$CollectionLevel = Get-CollectionLevelFromRegistry
Write-Log ('CollectionLevel: ' + $CollectionLevel) -Log $Log

Write-Log ('Starting infinite loop...') -Log $Log
Do
{
    [bool] $IsThresholdBroken = $false
    $IsThresholdBroken = Measure-PerformanceCounter -RuleName $RuleName -CounterPath $CounterPath -SampleInterval $SampleInterval -MaxSamples $MaxSamples -Operator $Operator -Threshold $Threshold -Exclude $Exclude -Log $Log

    if (($IsThresholdBroken -eq $True) -and ($IsCollecting -eq $false))
    {
        if ($Ran -ge $RunLimit)
        {
            Write-Log ('///////////////////') -Log $Log
            Write-Log ('// RunLimit Hit //') -Log $Log
            Write-Log ('/////////////////') -Log $Log
            Write-Log ('Ran: ' + $Ran + ' / RunLimit: ' + $RunLimit)
            Write-Log 'Runlimit hit! Disabling this task.' -Log $Log
            Disable-ScheduledTask -TaskName $RuleName -Log $Log
            Write-Log ('!!! Stopping this task !!!')
            Stop-Ps2ScheduledTask -TaskName $RuleName -Log $Log
        }
        else
        {
            $IsCollecting = $True
            Write-Log ('/////////////////////////////') -Log $Log
            Write-Log ('// Invoke OnStart Actions //') -Log $Log
            Write-Log ('///////////////////////////') -Log $Log

            if ($OnStartActions -ne '')
            {
                Write-Log ('Get-CollectionLevelFromRegistry::Start')
                $CollectionLevel = Get-CollectionLevelFromRegistry
                Write-Log ('CollectionLevel: ' + $CollectionLevel.ToString())
                Write-Log ('Get-CollectionLevelFromRegistry::End')
                Write-Log 'Running OnstartActions...' -Log $Log
                Write-Log ('[Invoke-Rule:' + $RuleName + '] Invoke-Actions: ' + $OnStartActions) -Log $Log
                $TimeStamp = "$(Get-Date -format yyyyMMdd-HHmmss)"
                Write-Log ('[Invoke-Actions] TimeStamp: ' + $TimeStamp) -Log $Log
                $IncidentOutputFolder = Get-IncidentFolderPath -TimeStamp $TimeStamp -RuleName $RuleName -OutputDirectory $OutputDirectory
                Write-Log ('[Invoke-Actions] IncidentOutputFolder: ' + $IncidentOutputFolder) -Log $Log
                if ((New-DirectoryWithConfirm -DirectoryPath $IncidentOutputFolder -Log $Log) -eq $false)
                {
                    Test-Error -Err $Error -Log $Log
                    Write-Log ('[Invoke-Actions] Unable to create: ' + $IncidentOutputFolder) -Log $Log
                    Exit;
                }
                New-DataCollectionInProgress -IncidentOutputFolder $IncidentOutputFolder
                Write-Log ('[Invoke-Actions] CollectionLevel before Invoke-Actions: ' + $CollectionLevel) -Log $Log
                Invoke-Actions -XmlConfig $XmlConfig -WptFolderPath $WptFolderPath -RuleName $RuleName -Actions $OnStartActions -IncidentOutputFolder $IncidentOutputFolder -CollectionLevel $CollectionLevel -Log $Log
                Test-Error -Err $Error -Log $Log
                $IsTimeoutReached = $false
                $dtTraceStartTime = (Get-date)
                Write-Log 'Running OnstartActions...Done!' -Log $Log
                Write-Log ('[Invoke-Actions] Update-Ran: ' + $RuleName) -Log $Log
                $Ran = $Ran + 1
                #Update-Ran -XmlConfig $XmlConfig -RuleName $RuleName
                Test-Error -Err $Error -Log $Log
            }
            else
            {
                Write-Log ('[Invoke-Rule:' + $RuleName + '] OnStartActions is blank.') -Log $Log
            }
        }
    }

    #// Is MaxTraceTime hit?
    if ($IsCollecting -eq $True)
    {
        $TraceElapedSeconds = (New-TimeSpan -Start $dtTraceStartTime -End (Get-Date)).TotalSeconds
        if ($TraceElapedSeconds -gt $MaxTraceTimeInSeconds)
        {
            $IsTimeoutReached = $True
            Write-Log ('MaxTraceTimeInSeconds: ' + $MaxTraceTimeInSeconds.ToString())
            Write-Log ('MaxTraceTimeInSeconds reached!')
            Write-Log ('dtTraceStartTime: ' + $dtTraceStartTime.ToString())
            Write-Log ('dtCurrentTime: ' + (Get-Date).ToString())
        }
        else
        {
            $IsTimeoutReached = $false
        }
    }

    if ((($IsThresholdBroken -eq $false) -and ($IsCollecting -eq $True)) -or $IsTimeoutReached -eq $True)
    {
        Write-Log ('///////////////////////////') -Log $Log
        Write-Log ('// Invoke OnEnd Actions //') -Log $Log
        Write-Log ('/////////////////////////') -Log $Log

        if ($OnEndActions -ne '')
        {

            Write-Log ('Get-CollectionLevelFromRegistry::Start')
            $CollectionLevel = Get-CollectionLevelFromRegistry
            Write-Log ('CollectionLevel: ' + $CollectionLevel.ToString())
            Write-Log ('Get-CollectionLevelFromRegistry::End')
            Write-Log 'Running OnEndActions...' -Log $Log
            Write-Log ('[Invoke-Rule:' + $RuleName + '] Invoke-Actions: ' + $OnEndActions) -Log $Log
            Invoke-Actions -XmlConfig $XmlConfig -WptFolderPath $WptFolderPath -RuleName $RuleName -Actions $OnEndActions -IncidentOutputFolder $IncidentOutputFolder -CollectionLevel $CollectionLevel -Log $Log
            Test-Error -Err $Error -Log $Log
            $IsCollecting = $false
            Write-Log 'Running OnEndActions...Done!' -Log $Log
            Remove-DataCollectionInProgress -IncidentOutputFolder $IncidentOutputFolder
        }
        else
        {
            Write-Log ('[Invoke-Rule:' + $RuleName + '] OnEndActions is blank.') -Log $Log
        }
        $IsTimeoutReached = $false
    }

    [int] $RandomMinutes = Get-Random -Minimum 100 -Maximum 200
    if ((New-TimeSpan -Start $dtLastLogTruncate -End (Get-Date)).TotalMinutes -gt $RandomMinutes)
    {
        Write-Log ('[Test-CounterRule] Start-TruncateLog') -Log $Log
        Start-TruncateLog -FilePath $Log -Log $Log
        Test-Error -Err $Error -Log $Log
        [datetime] $dtLastLogTruncate = (Get-Date)
        Write-Log ('[Test-CounterRule] Start-TruncateLog...Done!') -Log $Log
    }

    Start-Sleep -Seconds 1
} Until ($false -eq $true)
Write-Log ('[/Test-CounterRule:' + $RuleName + ']') -Log $Log
# SIG # Begin signature block
# MIIjeQYJKoZIhvcNAQcCoIIjajCCI2YCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBagv0zubTIp33d
# 6OLEhMSmQGwP5RZ0GFuJdas5808qEKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVTjCCFUoCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgZ6ITYQhi
# v47LcKf7DwcTRU/TEdUHtYlPXXkbRXflJDYwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAGH8GkRnA2QpA8HkxUgLVx/QkUWSVvjeH4DgA9nGbIxhWCq0A7/ToFU7
# ET4QGIBWcGQwW5/Q/2NXvjubqpsnBH+mMfdZw4rLuC2WrnGJq6LO2Vj+iZw6Y3no
# rJNTU74OIDf4pbs34d6EyKvPCggGJGjC7iSrLrgCtBLB0tbBgtO94AO1KUve020J
# Izi1zH9DE5nUUM0rya4G7FtLJtERb0cE/JgcjxNPMb7/9KbaoQiZA41ok2KvpmD3
# FNkFAPvMeUTqBi5DrWFsPf4ixSXSOWUeDOEBj20IsmmSvfJhcdkeI5cRBxPbdCx3
# LiV+TaGmXFNbv+1YFFw3NUHDGQOiWqOhghLiMIIS3gYKKwYBBAGCNwMDATGCEs4w
# ghLKBgkqhkiG9w0BBwKgghK7MIIStwIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYL
# KoZIhvcNAQkQAQSgggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgMzt3GorGnXf8Jd+wSXZP6owOTMuKRkd6mu/3LQ1qrS8CBmDRFRis
# 5xgTMjAyMTA3MTUxNTQ1MDkuODA5WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
# ZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RUFDRS1F
# MzE2LUM5MUQxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# gg45MIIE8TCCA9mgAwIBAgITMwAAAUzFTMHQ228/sgAAAAABTDANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMDExMTIxODI2
# MDBaFw0yMjAyMTExODI2MDBaMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpFQUNFLUUzMTYtQzkxRDElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAMphYFHDrMe576NV7IEKD/jk37xPiaTjee2zK3XP+qUJ
# pBVMY2ICxaRRhy1Cnyf/5vWRpn33Bk9xbGegnpbkoL880bNpSZ6uWcpzSgFBOdmN
# UrTBt96RWXaPY7ktUMBZEWviSf3yCV2IXgWYAQFuZ9ssQ9Ygjpo1pvUrtaoUwAji
# aM436UCU9fW1D+kcEH05m4hucWbE8JW+O9b3bletiv78n+fC6oKk6aSQRRFL4OJi
# ovS+ib175G6pSf9wDRk9X3kO661OtCcrHZAfwe2MHXDP4eZfGRksA/IvvrLFNcaj
# I7It6Tx+onDyR5igRi+kCJoTG0YUGC1UMjCK05WtDrsCAwEAAaOCARswggEXMB0G
# A1UdDgQWBBQBlh6nBApe5yeVQgGA9BBH3mb6fDAfBgNVHSMEGDAWgBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNy
# dDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# CwUAA4IBAQBPBOSw99ZDrqiAYq9362Z3HYhBhoSXvMeICG9xw7rlp8hAtmiSHPIA
# cM74xkfYZndBf1ZQ5unU5YmV+/PG/Qu7NX8ZKgkcsNW8UPAnVbTpR+vNmf//kXdi
# DJP3b8U7nMzZ05peRKMV4vUOEYD6+ww8HNSSBEjRVfaESBLZ3opjPoxzayaop+WX
# U5ZWtloml3oLrnum1sicTVqw30mM2jY/wJJH/bK4bTRzzv7t7n18gB/+XC/YR/j2
# +tIuntj0xL0QUFG0XuBAL+6zLSCtJR36q0hP/77Zsk0txL95mNcrRfRQJy4xT5lk
# GIZXbAyEQg51BG5aomVO/1+05vrtz8prMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAA
# AjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0
# aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPl
# YcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2T
# rNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFh
# E24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+c
# Bj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn
# 9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQB
# gjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB
# /zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEE
# AYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9Q
# S0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcA
# YQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZI
# hvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20Z
# MLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX
# /1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+TH
# zvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnx
# zplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjY
# lPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kW
# umGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3
# ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slva
# yA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5
# KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czm
# TfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYIC
# yzCCAjQCAQEwgfihgdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkVBQ0UtRTMxNi1DOTFEMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQA9
# mVtOCSgTYnYdGM1jKASXGuD3oKCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5JqOOjAiGA8yMDIxMDcxNTE4MzY0
# MloYDzIwMjEwNzE2MTgzNjQyWjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDkmo46
# AgEAMAcCAQACAiiGMAcCAQACAhFMMAoCBQDkm9+6AgEAMDYGCisGAQQBhFkKBAIx
# KDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZI
# hvcNAQEFBQADgYEASjEKlVy5I3kS/VI0+ugjfydPczP8OcWfXPrSL+T8YcjfHtI6
# ebTPCxqBXbClZk2jxarsdsfl/Ijxk3WRZ7mgcfhAaO1LUaO7vy6enqX4WRYM2T66
# 2wXb8Rg0vb9gWheQt+RNgG68LRJl1fokqjw+m1u8l7jjkVSdWo2hvhM5pu4xggMN
# MIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAUzF
# TMHQ228/sgAAAAABTDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0G
# CyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDjGElkzubIt7bbtKJf132Nl4zy
# BSf5Jk0A5eyfvm0rzzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EINvCpbu/
# UEsy0RBMIOH6TwsthlN90/tz2a8QYmfEr04lMIGYMIGApH4wfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFMxUzB0NtvP7IAAAAAAUwwIgQgqts4Em2/
# HHRjeyKf2oglrHufqYyYy/5SoPpKXFnt8UwwDQYJKoZIhvcNAQELBQAEggEAaosv
# nwtc2dkl1luzFndG3/497enAEkuuJC1A2iDTldr/nA53584OHnDJ53qELzEPgfor
# bhW5LVa+GE/nlEPIoz/G1QLr2KwrWRQ1P+/3hjyiOSjJhjCm+JE37cqwu2rN7A0Y
# rvbolXOSJQBkG2TAfFZ/GGEKLdPqRg1y0XOwNGwJkUvvNmE4Ni4SzQ/EmhRm+S4y
# w6UNAnowk1ztfp4mz94IpLmy8MIVnna3ViYCXK95el27fia20O6RM2VICE/xs+9t
# VfRmNTxPxb8kSCqfeV89c1CvBAimbByfqvUDYPLSHFEMH5NmZy9ugn7a8Ppa9H8L
# ZsfF8rO6hEIuH5N/5Q==
# SIG # End signature block
