﻿# Copyright ?2010, Microsoft Corporation. All rights reserved.

# You may use this code and information and create derivative works of it,
# provided that the following conditions are met:
# 1. This code and information and any derivative works may only be used for
# troubleshooting a) Windows and b) products for Windows, in either case using
# the Windows Troubleshooting Platform
# 2. Any copies of this code and information
# and any derivative works must retain the above copyright notice, this list of
# conditions and the following disclaimer.
# 3. THIS CODE AND INFORMATION IS PROVIDED ``AS IS'' WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. IF THIS CODE AND
# INFORMATION IS USED OR MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION
# WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER.
#************************************************

#************************************************
# DistSvcs_Utils.ps1
# Version 1.0.0
# Date: 05-09-2011
# Author: Jeremy LaBorde - jlaborde@microsoft.com
# Description: This script provides gathers MSDTC registry keys in XML format,
#  generates a summary report, and a XAML representation of the local DTC settings
#
# This is the main SDP package for MSDTC
#************************************************




###########################################################
#
# Last Update: 5-9-2011
# Author: jlaborde
#
# Description:
#  returns string representing the OS version
#
# Usage:
#  Get-OSVersionString
#
# Example:
#  Get-OSVersionString
#
# Needs to be moved to a utils / globally accessible location
#
###########################################################

function Get-OSVersionString( )
{	$local:version	= ([Environment]::OSVersion.Version.Major.ToString()) + "." + ([Environment]::OSVersion.Version.Minor.ToString())
	switch( $local:version )
	{
		"6.2"	{ return "Windows 8 / 2012" }
		"6.1"	{ return "Windows 7 / 2008 R2" }
		"6.0"	{ return "Windows Vista / 2008" }
		"5.2"	{ return "Windows XP 64 / 2003" }
		"5.1"	{ return "Windows XP" }
		"5.0"	{ return "Windows 2000" }
	}
	return ""
}



###########################################################
#
# Last Update: 5-9-2011
# Author: jlaborde
#
# Description:
#  collect Distributed Services application event logs of interest
#
# Usage:
#  Get-DistSvcsAppLogsAsCSV [string]$local:outputfile
#   where $local:outputfile will be a csv file
#
# Example:
#  Get-DistSvcsAppLogsAsCSV "ApplicationLogs.csv"
#
###########################################################

function Get-DistSvcsAppLogsAsCSV( [string]$local:outputfile )
{
	if( (Get-Host).version.major -eq "1" )
	{
		$Logs = Get-EventLog -LogName application | Select-Object -Property EntryType, EventID, Source, TimeWritten, Message
	} else
	{
		$Logs = get-eventlog -logname application -Source "*Windows Error Reporting*",
														"*SideBySide*",
														"*Application Error*",
														"*Application Hang*",
														"*Application Popup*",
														"*User Profile Service*",
														"*MsiInstaller*",
														"*DNS*",
														"*VSS*",
														"*SQL*",
														"*Cluster*",
														"*MSDTC*",
														"*COM*",
														"*Complus*",
														"*gupdate*",
														"*Userenv*"`
														| Select-Object `
															-property EntryType, EventID, Source, TimeWritten, Message 
	}
	$Logs | Export-Csv $local:outputfile
}

###########################################################
#
# Last Update: 5-9-2011
# Author: jlaborde
#
# Description:
#  collect Distributed Services system event logs of interest
#
# Usage:
#  Get-DistSvcsSysLogsAsCSV [string]$local:outputfile
#   where $local:outputfile will be a csv file
#
# Example:
#  Get-DistSvcsSysLogsAsCSV "SystemLogs.csv"
#
###########################################################

function Get-DistSvcsSysLogsAsCSV( [string]$local:outputfile )
{
	if( (Get-Host).version.major -eq "1" )
	{
		$Logs = Get-EventLog -LogName system | Select-Object -Property EntryType, EventID, Source, TimeWritten, Message
	} else
	{
		$Logs = get-eventlog -logname system -Source "*Windows Error Reporting*",
													"*VSS*",
													"*SQL*",
													"*Cluster*",
													"*MSDTC*",
													"*Complus*",
													"*DistributedCOM*",
													"*Kerberos*",
													"*GroupPolicy*",
													"*SMSvcHost*",
													"*DnsApi*"`
													| Select-Object `
														-property EntryType, EventID, Source, TimeWritten, Message 
	}
	$Logs | Export-Csv $local:outputfile
}



###########################################################
#
# Last Update: 5-9-2011
# Author: jlaborde
# Inspired By: Joe Mansfield ( http://helvick.blogspot.com/2007/08/checking-service-permissions-with.html )
#
# Description:
#  output permissions on a service
#
# Usage:
#  Get-ServicePermission [string]$local:ServiceNameMask
#
# Example:
#  Get-ServicePermission "*msdtc*"
#
###########################################################

function Get-ServicePermission( [string]$local:ServiceNameMask )
{	$local:retv	= ""

	# get the services
	$local:services	= get-wmiobject -query 'select * from win32_service'

	# loop through each, looking for the ones of interest
	foreach( $local:service in $local:services )
	{	if( $local:service.Name -like $local:ServiceNameMask )
		{	$local:retv	+= "Display Name: " + $local:service.DisplayName + "`r`n"
			$local:retv	+= "Name: " + $local:service.Name + "`r`n"
			$local:retv	+= "Path: " + $local:service.PathName + "`r`n"

			# get the permissions on the object
			$local:path		= $local:service.PathName.Substring( 0, $local:service.PathName.IndexOf( "." ) ) + ".exe"
			$local:secure	= get-acl $local:path
			# output permissions
			foreach( $local:item in $local:secure.Access )
			{	$local:retv	+= "`r`n"
				$local:retv	+= "`t" + $item.IdentityReference.Value + "`r`n"
				$local:retv	+= "`t" + $item.AccessControlType.ToString() + "`r`n"
				$local:retv	+= "`t" + $item.FileSystemRights.ToString() + "`r`n"
			}

			$local:retv	+= "`r`n"
			$local:retv	+= "`r`n"
		}
	}
	return $local:retv
}



###########################################################
#
# Last Update: 5-24-2011
# Author: jlaborde
#
# Description:
#  return a reg key value
#
# Usage:
#  Get-RegKeyValue [string]$local:regkey, [string]$local:regvalue
#
# Example:
#  $local:binSD	= Get-RegKeyValue "HKEY_LOCAL_MACHINE\software\microsoft\ole" "MachineLaunchRestriction"
#
###########################################################

function Get-RegKeyValue( [string]$local:regkey, [string]$local:regvalue )
{	if( (Test-Path ("registry::" + $local:regkey)) -eq $false )
	{	return $null
	}
	$local:reg	= Get-Item ("registry::" + $local:regkey)

	if( $local:regvalue -eq $null -or $local:regvalue -eq "" )
	{	return ( ($local:reg).GetValue( "", $null ) )
	}

	$local:val	= Get-ItemProperty $reg.PSPath
	if( $local:val -eq $null )
	{	return $null
	}
	return $local:val.$local:regvalue
}

###########################################################
#
# Last Update: 3-31-2012
# Author: jlaborde
#
# Description:
#  test if a registry value exists
#
# Usage:
#  Get-RegKeyValueExists [string]$local:regkey, [string]$local:regvalue
#
# Example:
#  if( ( Get-RegKeyValue "HKEY_LOCAL_MACHINE\software\microsoft\ole" "MachineLaunchRestriction" ) )
#
###########################################################

function Get-RegKeyValueExists( [string]$local:regkey, [string]$local:regvalue )
{	if( (Test-Path ("registry::" + $local:regkey)) -eq $false )
	{	return $false
	}
	$local:reg	= Get-Item ("registry::" + $local:regkey)

	if( $local:regvalue -eq $null -or $local:regvalue -eq "" )
	{	return $true
	}

	$local:val	= Get-ItemProperty $reg.PSPath
	if( $local:val -eq $null )
	{	return $false
	}
	return $true
}

###########################################################
#
# Last Update: 10-6-2011
# Author: jlaborde
#
# Description:
#  return a reg key value as true or false
#
# Usage:
#  Get-RegKeyBool [string]$local:regkey, [string]$local:regvalue
#
# Example:
#  $local:bool	= Get-RegKeyValue "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\MSDTC\Security" "NetworkDtcAccess"
#
###########################################################

function Get-RegKeyBool( [string]$local:regkey, [string]$local:regvalue )
{	$local:bool	= Get-RegKeyValue $local:regkey $local:regvalue
	if( $local:bool -eq $null -or $local:bool -eq $false -or $local:bool -eq 0 )
	{	return $false
	}
	return $true
}

###########################################################
#
# Last Update: 10-6-2011
# Author: jlaborde
#
# Description:
#  find subkey based on presence of an inner subkey, possibly at a certain default value
#
# Usage:
#  Get-RegistryKeyBasedOnSubkey [string]$local:keyname, [string]$local:subkeyname, [string]$local:subkeyvalue
#
# Example:
#  Get-RegistryKeyBasedOnSubkey "HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CID" "Description" "MSDTC"
#   we're looking for the subkey who contains a subkey name Description set to default value MSDTC
#
###########################################################

function Get-RegistryKeyBasedOnSubkey( [string]$local:keyname, [string]$local:subkeyname, [string]$local:subkeyvalue )
{
	# get the subkeys for this key
	$local:ChildKeys	= Get-Item ("registry::" + $local:keyname + "\*") -ErrorAction SilentlyContinue

	# loop through the root's subkeys
	foreach( $local:subkey in $local:ChildKeys )
	{
		# find the subkey off the looping subkey
		$local:s2	= Get-Item ("registry::" + $local:subkey.Name + "\" + $local:subkeyname) -ErrorAction SilentlyContinue
		if( $local:s2 -ne $null )
		{	# if we don't care about the default value, return this key
			if( $local:subkeyvalue -eq $null -or $local:subkeyvalue -eq "" )
			{	return $local:subkey
			}
			# if we do care about the default value, make sure we have one and compare it
			$local:default		= ($local:s2).GetValue( "", $null )
			if( $local:default -ne $null )
			{	if( $local:default.CompareTo( $local:subkeyvalue ) -eq 0 )
				{	return $local:subkey
				}
			}
		}
	}
	return $null
}

###########################################################
#
# Last Update: 10-6-2011
# Author: jlaborde
#
# Description:
#  find subkey based on presence of an entry
#
# Usage:
#  Get-RegistrySubKeyBasedOnEntry [string]$local:keyname [string]$local:entryname [string]$local:entryvalue
#
# Example:
#  Get-RegistrySubKeyBasedOnEntry "HKEY_LOCAL_MACHINE\Cluster\Resources\{GUID}" "MSDTC" ""
#   we're looking for the subkey who contains an entry name MSDTC set to any value
#
###########################################################

function Get-RegistrySubKeyBasedOnEntry( [string]$local:keyname, [string]$local:entryname, [string]$local:entryvalue )
{
	# get the subkeys for this key
	$local:ChildKeys	= Get-Item ("registry::" + $local:keyname + "\*") -ErrorAction SilentlyContinue

	# loop through the root's subkeys
	foreach( $local:subkey in $local:ChildKeys )
	{
		# try to find the entry name
		$local:regentries	= ($local:subkey).GetValueNames( )
		if( $local:regentries -ne $null )
		{
			foreach( $local:entry in $local:regentries )
			{	if( $local:entry -eq $local:entryname )
				{	if( $local:entryvalue -eq $null -or $local:entryvalue -eq "" )
					{	return $local:subkey
					}
					if( (Get-RegKeyValue $local:subkey.Name $local:entryname) -eq $local:entryvalue )
					{	return $local:subkey
					}
					return $null
				}
			}
		}
	}
	return $null
}



###########################################################
#
# Last Update: 5-24-2011
# Author: jlaborde
#
# Description:
#  create a basic 'permissions' class
#
# Usage:
#  Get-PermissionsClass
#
# Example:
#  $local:Perms = Get-PermissionsClass
#
###########################################################



function Get-PermissionsClass( )
{	$local:strings	= @()

	$local:object	= New-Object Object |
		Add-Member -MemberType NoteProperty -Name Account -Value "" -PassThru |
		Add-Member -MemberType NoteProperty -Name Type    -Value "" -PassThru |
		Add-Member -MemberType NoteProperty -Name Rights  -Value 0 -PassThru
	return $local:object
}

###########################################################
#
# Last Update: 5-24-2011
# Author: jlaborde
#
# Description:
#  create a a permission object based on a binary representation of a SID
#
# Usage:
#  Get-PermissionsFromBinarySID $local:binary
#
# Example:
#  $local:Perm		= Get-PermissionsFromBinarySID $local:binSD
#
###########################################################

function Get-PermissionsFromBinarySID( $local:binary )
{	$local:array	= @()

	# not supported pre-Vista
	#if( $OSVersion.Major -lt 6 )
	#{	return $local:array
	#}

	#$converter	= new-object system.management.ManagementClass Win32_SecurityDescriptorHelper
	#$SDDL		= $converter.BinarySDToSDDL( $local:binary )
	#$CSD		= New-Object System.Security.AccessControl.CommonSecurityDescriptor -ArgumentList $false, $false, $SDDL.SDDL
	$CSD		= New-Object System.Security.AccessControl.CommonSecurityDescriptor -ArgumentList $false, $false, $local:binary, 0

	foreach( $dacl_ in $CSD.DiscretionaryAcl )
	{	$local:Perms	= Get-PermissionsClass

		$AccountSID		= New-Object System.Security.Principal.SecurityIdentifier ( $dacl_.SecurityIdentifier )
		$local:RealSID	= $AccountSID.Translate( [System.Security.Principal.NTAccount] )

		if( $local:RealSID -ne $null )
		{
			$local:Perms.Account	= $local:RealSID.Value
			$local:Perms.Type		= $dacl_.AceType
			$local:Perms.Rights		= $dacl_.AccessMask

			$local:array	= $local:array + $local:Perms
		}
	}
	return $local:array
}

function Get-CombinePermissionsClass( )
{	$local:objects1	= @()
	$local:objects2	= @()
	

	$local:object	= New-Object Object |
		Add-Member -MemberType NoteProperty -Name Account -Value "" -PassThru |
		Add-Member -MemberType NoteProperty -Name aAllow  -Value $local:objects1 -PassThru |
		Add-Member -MemberType NoteProperty -Name aDeny   -Value $local:objects2 -PassThru
	return $local:object
}

function Get-CombinedPermFromListByAccount( [Object]$local:CombPermsArray, [string]$local:account )
{	foreach( $local:perm in $local:CombPermsArray )
	{	if( $local:perm.Account.ToUpper( ) -eq $local:account.ToUpper( ) )
		{	return $local:perm }
	}
	return $null
}

function Get-CombinedPermissionsFromPermissionsList( $local:PermsArray )
{	$local:CombPerms	= @()

	foreach( $local:perm in $local:PermsArray )
	{	$local:cp	= Get-CombinedPermFromListByAccount $local:CombPerms $local:perm.Account
		if( $local:cp -eq $null )
		{	$local:cp	= Get-CombinePermissionsClass
			$local:cp.Account	= $local:perm.Account
			$local:CombPerms	= $local:CombPerms + $local:cp
		}
		if( $local:perm.Type -eq "AccessAllowed" )
		{	$local:cp.aAllow	= $local:cp.aAllow + $local:perm
		} else
		{	$local:cp.aDeny	= $local:cp.aDeny + $local:perm
		}
	}
	
	return $local:CombPerms
}



###########################################################
#
# Last Update: 6-21-2011
# Author: jlaborde
#
# Description:
#  generate a GUID with { } around it
#
# Usage:
#  Get-GUID
#
# Example:
#  $local:guid		= Get-GUID
#
###########################################################
function Get-GUID( )
{	return ( "{" + ([System.Guid]::NewGuid()).ToString( ) + "}" )
}



# functions used to output SDDL information

# use Format-SDDL for full text output

# returns a string of the SID / Account
function Get-SDDL_WellKnown( [string] $code )
{
	if( $code.Length -gt 2 )
	{	return $code
	}

	switch( $code )
	{
		"AN"	{ return "Anonymous" }
		"AO"	{ return "Account Operators" }
		"AU"	{ return "Authenticated Users" }
		"BA"	{ return "Built-In Administrators" }
		"BG"	{ return "Built-In Guests" }
		"BO"	{ return "Backup Operators" }
		"BU"	{ return "Built-In Users" }
		"CA"	{ return "Certificate Publishers" }
		"CD"	{ return "Users Cert DCOM" }
		"CG"	{ return "Creator Group" }
		"CO"	{ return "Creator Owner" }
		"DA"	{ return "Domain Administrators" }
		"DC"	{ return "Domain Computers" }
		"DD"	{ return "Domain Controllers" }
		"DG"	{ return "Domain Guests" }
		"DU"	{ return "Domain Users" }
		"EA"	{ return "Enterprise Administrators" }
		"ED"	{ return "Enterprise DCs" }
		"HI"	{ return "High Integrity Level" }
		"IU"	{ return "Interactively Logged-On User" }
		"LA"	{ return "Local Administrator" }
		"LG"	{ return "Local Guest" }
		"LS"	{ return "Local Service Account" }
		"LW"	{ return "Low Integrity Level" }
		"ME"	{ return "Medium Integrity Level" }
		"MU"	{ return "Performance Monitor Users" }
		"NO"	{ return "Network Configuration Operators" }
		"NS"	{ return "Network Service Account" }
		"NU"	{ return "Network Logon User" }
		"PA"	{ return "Group Policy Administrators" }
		"PO"	{ return "Printer Operators" }
		"PS"	{ return "Principal Self" }
		"PU"	{ return "Power Users" }
		"RC"	{ return "Restricted Code" }
		"RD"	{ return "Terminal Server Users" }
		"RE"	{ return "Replicator" }
		"RO"	{ return "Enterprise Read-only DCs" }
		"RS"	{ return "RAS Servers Group" }
		"RU"	{ return "Alias PreWin2K" }
		"SA"	{ return "Schema Administrators" }
		"SI"	{ return "System Integrity Level" }
		"SO"	{ return "Server Operators" }
		"SU"	{ return "Service Logon User" }
		"SY"	{ return "Local System" }
		"WD"	{ return "Everyone" }
	}
	return "unknown SDDL group ( " + $code + " )"
}
# returns a string name of the Owner
function Get-SDDL_Owner( [string] $SDDLString )
{	$indexOwner	= $SDDLString.IndexOf( "O:" )
	$indexGroup	= $SDDLString.IndexOf( "G:" )
	
	if( $indexOwner -eq -1 -or $indexGroup -eq -1 )
	{	return "error parsing owner (1)"
	}
	if( $indexGroup -lt $indexOwner )
	{	return "error parsing owner (2)"
	}
	
	$substring	= $SDDLString.Substring( $indexOwner +2, $indexGroup -2 )

	return Get-SDDL_WellKnown $substring
}
# returns a string name of the Group
function Get-SDDL_Group( [string] $SDDLString )
{	$indexGroup	= $SDDLString.IndexOf( "G:" )
	$indexDACL	= $SDDLString.IndexOf( "D:" )
	
	if( $indexDACL -eq -1 -or $indexGroup -eq -1 )
	{	return "error parsing group (1)"
	}
	if( $indexDACL -lt $indexOwner )
	{	return "error parsing group (2)"
	}
	
	$substring	= $SDDLString.Substring( $indexGroup +2, $indexDACL -2 -$indexGroup )

	return Get-SDDL_WellKnown $substring
}
# returns a string name of ACE type
function Get-SDDL_Ace_Type( [string] $code )
{	if( $code -eq $null -or $code -eq "" )
	{	return ""
	}

	switch( $code )
	{
		"A"		{ return "Access Allowed" }
		"D"		{ return "Access Denied" }
		"OA"	{ return "Access Allowed Object" }
		"OD"	{ return "Access Denied Object" }
		"AU"	{ return "Audit" }
		"AL"	{ return "Alarm" }
		"OU"	{ return "Audit Object" }
		"OL"	{ return "Alaram Object" }
		"ML"	{ return "Mandatory Label" }
	}
	return "Unknown ACE Type: " + $code
}
# returns a string array of ACE flags
function Get-SDDL_Ace_Flags( [string] $code )
{	$retstring	= @()
	if( $code -eq $null -or $code -eq "" )
	{	return $retstring
	}


	while( $code.Length -gt 0 )
	{	if( $code.Length -gt 1 )
		{	$tempcode	= $code.Substring( 0, 2 )
			$code		= $code.Substring( 2 )
		} else
		{	$tempcode	= $code
			$code		= ""
		}


		switch( $tempcode )
		{
			"CI"	{ $retstring	+= "Container Inherit" }
			"OI"	{ $retstring	+= "Object Inherit" }
			"NP"	{ $retstring	+= "No Propagate Inherit" }
			"IO"	{ $retstring	+= "Inherit Only" }
			"ID"	{ $retstring	+= "Inherited" }
			"SA"	{ $retstring	+= "Audit Successful" }
			"FA"	{ $retstring	+= "Audit Failure" }
		}
	}
	return $retstring
}
# returns a string array of ACE rights
function Get-SDDL_Ace_Rights( [string] $code )
{	$retstring	= @()
	if( $code -eq $null -or $code -eq "" )
	{	return $retstring
	}

	while( $code.Length -gt 0 )
	{	if( $code.Length -gt 1 )
		{	$tempcode	= $code.Substring( 0, 2 )
			$code		= $code.Substring( 2 )
		} else
		{	$tempcode	= $code
			$code		= ""
		}

		if( $tempcode.StartsWith( "0x" ) )
		{	$tempcode	= $code.Substring( 0, 6 )
			$code		= $code.Substring( 6 )
			$retstring	+= ( "0x" + $tempcode ).ToString( )
		}

		switch( $tempcode )
		{
			"GA"	{ $retstring	+= "Generic All" }
			"GR"	{ $retstring	+= "Generic Read" }
			"GW"	{ $retstring	+= "Generic Write" }
			"GX"	{ $retstring	+= "Generic Execute" }
			"RC"	{ $retstring	+= "Read" }
			"SD"	{ $retstring	+= "Delete" }
			"WD"	{ $retstring	+= "Write DAC" }
			"WO"	{ $retstring	+= "Write Owner" }
			"RP"	{ $retstring	+= "Read Property" }
			"WP"	{ $retstring	+= "Write Property" }
			"CC"	{ $retstring	+= "Create Child" }
			"DC"	{ $retstring	+= "Delete Child" }
			"LC"	{ $retstring	+= "List Children" }
			"SW"	{ $retstring	+= "Self Write" }
			"LO"	{ $retstring	+= "List Object" }
			"DT"	{ $retstring	+= "Delete Tree" }
			"CR"	{ $retstring	+= "Control Access" }
			"FA"	{ $retstring	+= "File All" }
			"FR"	{ $retstring	+= "File Read" }
			"FW"	{ $retstring	+= "File Write" }
			"FX"	{ $retstring	+= "File Execute" }
			"KA"	{ $retstring	+= "Reg Key All" }
			"KR"	{ $retstring	+= "Reg Key Read" }
			"KW"	{ $retstring	+= "Reg Key Write" }
			"KX"	{ $retstring	+= "Reg Key Execute" }
			"NR"	{ $retstring	+= "No Read Up" }
			"NW"	{ $retstring	+= "No Write Up" }
			"NX"	{ $retstring	+= "No Execute Up" }
		}
	}
	return $retstring
}
# returns a string of the SID / Account
function Get-SDDL_Ace_ObjectGUID( [string] $code )
{	if( $code -eq $null -or $code -eq "" )
	{	return ""
	}

	switch( $code )
	{
		"CR;ab721a53-1e2f-11d0-9819-00aa0040529b"	{ return "Change Password" }
		"CR;00299570-246d-11d0-a768-00aa006e0529"	{ return "Reset Password" }
	}
	return Get-SDDL_WellKnown $code
}
# returns a string of the SID / Account
function Get-SDDL_Ace_InheritObjectGUID( [string] $code )
{	if( $code -eq $null -or $code -eq "" )
	{	return ""
	}

	return Get-SDDL_WellKnown $code
}
# returns a string of the SID / Account
function Get-SDDL_Ace_SID( [string] $code )
{	if( $code -eq $null -or $code -eq "" )
	{	return ""
	}

	return Get-SDDL_WellKnown $code
}
# returns a string of full ACE info
function Get-SDDL_Ace( [string] $Ace )
{	$Ace	= $Ace.TrimStart( '(' )
	$Ace	= $Ace.TrimEnd( ')' )
	$array	= $Ace.Split( ';' )
	
	$ret		= ""
	$acetype	= Get-SDDL_Ace_Type $array[0]
	$aceflags	= Get-SDDL_Ace_Flags $array[1]
	$acerights	= Get-SDDL_Ace_Rights $array[2]
	$aceobjg	= Get-SDDL_Ace_ObjectGUID $array[3]
	$aceiobjg	= Get-SDDL_Ace_InheritObjectGUID $array[4]
	$acesid		= Get-SDDL_Ace_SID $array[5]
	
	$ret		+= "Type:`t" + $acetype + "`r`n"
	if( $aceflags -ne $null -and $aceflags.Count -gt 0 )
	{	$ret	+= "Flags:`t"
		foreach( $flag in $aceflags )
		{	$ret	+= $flag + "`r`n"
		}
	}
	if( $acerights -ne $null -and $acerights.Count -gt 0 )
	{	$ret	+= "Rights:`t"
		foreach( $right in $acerights )
		{	$ret	+= $right + "`r`n"
		}
	}
	if( $aceobjg -ne $null -and $aceobjg -ne "" )
	{	$ret	+= "Ace Obj:`t" + $aceobjg + "`r`n"
	}
	if( $aceiobjg -ne $null -and $aceiobjg -ne "" )
	{	$ret	+= "Ace IObj:`t" + $aceiobjg + "`r`n"
	}
	if( $acesid -ne $null -and $acesid -ne "" )
	{	$ret	+= "Ace SID:`t" + $acesid + "`r`n"
	}
	return $ret
}
# returns a string array of the flags for a DACL or SACL
function Get-ACL_Flags( [string] $flags )
{	$ret	= @()

	if( $flags -eq $null -or $flags -eq "" )
	{	return $ret
	}

	while( $flags.Length -gt 0 )
	{
		switch( $flags.SubString( 0, 1 ) )
		{
			"P"	{	$ret	+= "Protected"
				}
			"A"	{	switch( $flags.SubString( 1, 1 ) )
					{
						"R"	{	$ret	+= "Auto Inherit Req"
							}
						"I"	{	$ret	+= "Auto Inherit"
							}
					}
					$flags	= $flags.Substring( 1 )
				}
		}
		$flags	= $flags.Substring( 1 )
	}
	return $ret
}
function Get-SDDL_DACL( [string] $SDDLString )
{	$indexDACL	= $SDDLString.IndexOf( "D:" )
	$indexSACL	= $SDDLString.IndexOf( "S:" )
	
	if( $indexDACL -eq -1 )
	{	return "error parsing DACL (1)"
	}
	if( $indexSACL -ne -1 -and $indexSACL -lt $indexDACL )
	{	return "error parsing DACL (2)"
	}
	
	if( $indexSACL -ne -1 )
	{	$substring	= $SDDLString.Substring( $indexDACL +2, $indexSACL -2 -$indexDACL )
	} else
	{	$substring	= $SDDLString.Substring( $indexDACL +2 )
	}

	$ret	= "DACL:`r`n"
	$array	= $substring.Split( '(' )
	$index	= 0
	if( -not $array[0].EndsWith( ')' ) )
	{	$dflags	= Get-ACL_Flags $array[0]
		if( $dflags -ne $null -and $dflags.Count -gt 0 )
		{	$ret	+= "Flags:`t"
			foreach( $dflag in $dflags )
			{	$ret	+= $dflag + "`r`n"
			}
		}

		$index++
	}
	while( $index -lt $array.Count )
	{
		$rAce	= Get-SDDL_Ace $array[ $index ]
		$ret	+= $rAce + "`r`n"
		$index++
	}

	return $ret
}
function Get-SDDL_SACL( [string] $SDDLString )
{	$indexSACL	= $SDDLString.IndexOf( "S:" )
	
	if( $indexSACL -eq -1 )
	{	return ""
	}
	
	$substring	= $SDDLString.Substring( $indexSACL +2 )

	$ret	= "SACL:`r`n"
	$array	= $substring.Split( '(' )
	$index	= 0
	if( -not $array[0].EndsWith( ')' ) )
	{	$sflags	= Get-ACL_Flags $array[0]
		if( $sflags -ne $null -and $sflags.Count -gt 0 )
		{	$ret	+= "Flags:`t"
			foreach( $dflag in $dflags )
			{	$ret	+= $dflag + "`r`n"
			}
		}

		$index++
	}
	while( $index -lt $array.Count )
	{
		$rAce	= Get-SDDL_Ace $array[ $index ]
		$ret	+= $rAce + "`r`n"
		$index++
	}

	return $ret
}

# main interface
#ex. Format-SDDL "O:BAG:DUD:(A;ID;FA;;;BA)(A;ID;FA;;;SY)(A;ID;0x1301bf;;;AU)(A;ID;0x1200a9;;;BU)"
function Format-SDDL( [string] $SDDLString )
{	$ret	= ""
	$ret	+= "Owner: " + (Get-SDDL_Owner $SDDLString) + "`r`n"
	$ret	+= "Group: " + (Get-SDDL_Group $SDDLString) + "`r`n"
	$ret	+= (Get-SDDL_DACL $SDDLString) + "`r`n"
	$ret	+= (Get-SDDL_SACL $SDDLString) + "`r`n"
	return $ret
}

###########################################################
#
# Last Update: 5-11-2011
# Author: jlaborde
#
# Description:
#  retrieve EnableDOCM key
#
# Usage:
#  Get-EnableDCOM
#
# Example:
#  $local:OnOrOff = Get-EnableDCOM
#   returns $true or $false
#
###########################################################

function Get-EnableDCOM(  )
{	$local:value	= (Get-ItemProperty "registry::HKEY_LOCAL_MACHINE\Software\Microsoft\OLE" EnableDCOM).EnableDCOM.ToUpper( )
	if( $local:value -eq "Y" )
	{	return $true
	}
	return $false
}


###########################################################
#
# Last Update: 3-20-2012
# Author: jlaborde
#
# Description:
#  used to log a 'root cause' message
#
# Usage:
#  AlertKnownIssue $true / $false "RootCauseID" "Description of error" "FTE Only" / "Partners" / "Internal" / "Public"
#
###########################################################

# Visibility = FTE Only, Partners, Internal, or Public
function AlertKnownIssue( [string]$sRootCauseID, [string]$sStatement, [string]$sVisibility )
{
	switch( $sVisibility )
	{
		"FTE Only"	{ $vis	= 1 }
		"Partners"	{ $vis	= 2 }
		"Internal"	{ $vis	= 3 }
		"Public"	{ $vis	= 4 }
		default		{ $vis	= 1 }
	}

	if( $global:gDebugSDPOn )
	{	Update-DiagRootCause -Id $sRootCauseID -Detected $true
		Write-GenericMessage -RootCauseID $sRootCauseID -Visibility $vis -SolutionTitle $sStatement
	} else
	{	"Issue detected: " + $sRootCauseID + ", " + $vis + ", " + $sStatement
	}
}

# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCwC1u2G2EsN41h
# Sl+sG7mUJBN5uh+H8u71jVMFKpJ4vaCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQger/8umK5
# +2I3YnKDe5frzLY/jspT8fYAZWwTdzGp6wswOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAChLiuyhdjggJVwvZpJLMF6vZwDZBuXrFbl9NtDIKbCiGkBDKl3bIhpj
# Rnlzaknfqm7uRrG3cHB8saf86lthoCDI188zGOgTIPBls13BFhUBo5NORfcAi7vJ
# e5yYcXfSPr7VrIylhz3ZNRW5rTgT4KVB8kFvbIM0bPKT4XEoM8KyedyLw/gx91rD
# 6vAK8MfcJfQ1OqWfuamyEPtkM4XieAnZBmYydDXwvf0nLUxM5Q0PRMb0rtyTYMsA
# Eg8UB1/VpBTAAqfHusLK/A/W2KMmYj8sSV+1/PFk66KZoC7nFPr9nxtymgBmCIiM
# 5cFSsmoHz5KpPs2mYIWEofyYPeeIAcqhghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgAVgY16oDZGOwmZXCtIrRM8smgu848HmdR4DV7apy41ICBmBjTFo5
# MhgTMjAyMTA1MTkyMjIwNTYuNDkzWjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpFMDQxLTRCRUUtRkE3RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABN0GPQ+daW2+nAAAAAAE3MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgxNFoXDTIyMDExMjE3MjgxNFowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RTA0MS00
# QkVFLUZBN0UxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDEEe5p0SWbcbm2KSFPONIM
# HT72xeZSFTINVGPRji/P2tn2zKQ2hsvn/oC3nM6R4HZuX0he9V3JL9kk1lPfveSf
# OtDfjvPfQybDv75VT8IT7jHjD2RvlupAd9LNslC3oqZay4yYkvODhHkx4mzkxjlh
# 08vGgygNFxOL/8qgwVHQrNLX/fbgPb/gqQcPVe36zTFjQMgJQ4rVFuYkIoSAE/X8
# YNmO5lAFL0OLz3JOe8slX4uvVC2uIfgSqZGgB2ZXfMnQYmyvm+EY+Yp848JFKTtD
# yKBfuCgWcIvOlhx8cYKqhH+bD3mB9CnDKZXDFkHQ+QYytDD4spU9r8Uc/gLgo75B
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQUDWCwcwz652BjusSd7ro7LPGUT2UwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAnfZT133RFW4BRv02ydcEbUrjaqOFT6Me
# /AF1uKkhxfhaDt0fll25BmPeBaAoANnnP5N6FfsacFuLbrlUjvENGwV7YKORObgk
# iiKx0rBgEOu5L5hFEEbgHURG5aLnhcbDH6VID6JA2siLombQIv8x9Au/Cyo8lIY/
# r04QcLJoTGizjzr5fclO4ZXXUIGX8E7uvxQdvH+sTp9muVllhpsgXpp5qG9MvXgu
# 9ktX9szNhI4OxuMcexOb1BoabWKOFqAJ1uQCqvz7scCBgRqvxc+XPFSFUjhKFUHl
# kZ32BnbIGTDF0DSgVzvjlN04+ts/v293R4+qC8kMfm2Q6FNE0jnldDCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpFMDQxLTRCRUUtRkE3RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUA6ruoOTiJXPwhO5ltQWsAbt5zGpyggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAORPtCUwIhgPMjAyMTA1MTkyMzU4MjlaGA8yMDIxMDUyMDIzNTgyOVowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5E+0JQIBADAKAgEAAgIXOAIB/zAHAgEAAgIR
# gDAKAgUA5FEFpQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAFnaSI48yVkw
# 4cC3G2dDbrOOmdP+ZLp+gMg++PL5rSSb5I+Jhq+mv4oa081KR6BNbJRZ04fTf8mK
# I5w0Jq+1fM/SV6qMbp1ig7fhz6zMxeXkmhqw6rXbbNzeFC0lGTXSifTc1At0xMxj
# /py93HcG7Ik2/1FjJlLAKMVBw61mFnBxMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAE3QY9D51pbb6cAAAAAATcwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgYe6wPJmnVQl0iUlsbXk9tIBlL/4SPUgbD5xqmx/C2mAwgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAdWX6vwJ4EnSLJf9oZkPZhtDuCT5Ts3sFC
# JMMoBhIcEDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABN0GPQ+daW2+nAAAAAAE3MCIEIEFC3ANrREfyUIPRAbC54GuLTD0unKmsQ/4k
# fbYKwF+cMA0GCSqGSIb3DQEBCwUABIIBAAHtc+ncC2+G6DymyUxT9Xa8GZiF/OF2
# Rlqxky+2KUCAk9DDAZS8rtTZgOY2lJZXNbzzaQjwK31L+blikfZSghZzZ08kSm1e
# tXbdxKDlEfO6YOO3hpsqf5t3BnchThYTfHIPHxlh01LDHs9bFObKQvOEZmun3nHt
# KikbLJKW6CxH7/1Ps2qEw4muCmRtrrWeWnEwG+RsMCv6sNcmtMk5ucHTumINcb+v
# Xh5PgrcuMrpqyUAdLNBoZkd7NmToeaopd+SoE63oX3FxubJ/mwwjyo7CoPevSd/0
# GTUDnOy4UPsEDpVrC063/bxIncaHcPfn0biD/oDN+BPVhlXV/jY5fiA=
# SIG # End signature block
