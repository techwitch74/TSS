﻿# Load Common Library
# Load Reporting Utilities
#_#$debug = $false

. ./utils_cts.ps1
. ./TS_RemoteSetup.ps1

if (FirstTimeExecution) 
{


	$RemoteServerCore = .\DC_ServerCoreR2Setup.ps1

	if ($RemoteServerCore -ne $null) 
	{
		$ExpressionArray = @()
		$ItemNumber = 0	
		
		$ExpressionToRunOnMachine = @'
		Run-DiagExpression .\DC_BasicSystemInformation.ps1 -MachineName $Env:COMPUTERNAME
		Run-DiagExpression .\DC_ClusterLogs.ps1 -LocalOnly
		Run-DiagExpression .\TS_DumpCollector.ps1 -CopyWERMinidumps -CopyMachineMiniDumps -MaxFileSize 300 -CopyMachineMemoryDump
		.\TS_AutoAddCommands_Remote.ps1
'@

		foreach ($MachineName in $RemoteServerCore)
		{
			if ($ItemNumber -eq 0) 
			{
				#Execute TS_BasicClusterInfo only in one node
				$ExpressionArray += ($ExpressionToRunOnMachine + "`n Run-DiagExpression .\TS_BasicClusterInfo.ps1")
			} else {
				$ExpressionArray += $ExpressionToRunOnMachine
			}
			
			$ItemNumber += 1
		}
		
		ExecuteRemoteExpression -ComputerNames $RemoteServerCore -Expression $ExpressionArray -ShowDialog	

	}
	
	
	EndDataCollection
} else {
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
