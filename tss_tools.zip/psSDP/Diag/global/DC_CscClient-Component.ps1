﻿#************************************************
# DC_CscClient-Component.ps1
# Version x
# Date: 2009-2014, 2020-10-26 WalterE added CscDbDump, run script only for Client SKU
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about Client Side Caching (CSC)
# Called from: Networking Diagnostics
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSCscClient -Status $ScriptVariable.ID_CTSCscClientDescription

function RunNetSH ([string]$NetSHCommandToExecute="")
{
	
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSCscClient -Status "netsh $NetSHCommandToExecute"
	
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"`n`n`n" + "-" * ($NetSHCommandToExecuteLength) + "`r`n" + "netsh $NetSHCommandToExecute" + "`r`n" + "-" * ($NetSHCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
}


function cscWMI ([string]$wmiObject)
{
	$cscWmiObject = get-wmiobject -query "select * from $wmiObject" -EA SilentlyContinue #_# -EA SilentlyContinue
	$cscWmiObjectLen = $cscWmiObject.length
	"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	"WMI object: " + $wmiObject 						 	| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	if ($cscWmiObjectLen -ne 0)
	{
		foreach ($object in $cscWmiObject)
		{
			$object	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"There are no items in this WMI object"	| Out-File -FilePath $OutputFile -append
	}
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}

#_# run on client SKU only
$cs =  gwmi -Namespace "root\cimv2" -class win32_computersystem -ComputerName $ComputerName
$DomainRole = $cs.domainrole
if ($cs.DomainRole -lt 2)
{

	$sectionDescription = "CSC Client"

	#----------W8/WS2012 powershell cmdlets
	# detect OS version and SKU
	$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
	[int]$bn = [int]$wmiOSVersion.BuildNumber

	$OutputFile= $Computername + "_CscClient_info_wmi.TXT"

	"===================================================="			| Out-File -FilePath $OutputFile -append
	"Client Side Caching Client WMI Output"							| Out-File -FilePath $OutputFile -append
	"===================================================="			| Out-File -FilePath $OutputFile -append
	"Overview"														| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"			| Out-File -FilePath $OutputFile -append
	"   1. Win32_UserStateConfigurationControls   (W8/WS2012+)"		| Out-File -FilePath $OutputFile -append
	"   2. Win32_OfflineFilesCache                (WV/WS2008+)"		| Out-File -FilePath $OutputFile -append
	"   3. Win32_OfflineFilesItem                 (WV/WS2008+)"		| Out-File -FilePath $OutputFile -append
	"   4. Win32_OfflineFilesMachineConfiguration (W8/WS2012+)"		| Out-File -FilePath $OutputFile -append
	"===================================================="			| Out-File -FilePath $OutputFile -append
	"`n`n`n`n`n"													| Out-File -FilePath $OutputFile -append

	if ($bn -gt 9000)                               
	{
		#----------------------------------------------------
		# USER PROFILE (W8/WS2012+)
		#----------------------------------------------------
		#cscWMI "Win32_UserProfile"							# shows information about each user profile
		cscWMI "Win32_UserStateConfigurationControls"		# shows on/off state of FolderRedirection, OfflineFiles, and RoamingUserProfile

		#----------------------------------------------------
		# OFFLINE FILES (WV/WS2008+)
		#Reference: http://msdn.microsoft.com/en-us/library/bb309180(v=vs.85).aspx
		#----------------------------------------------------
		cscWMI "Win32_OfflineFilesCache"					# shows Active, Enabled, and Location
		cscWMI "Win32_OfflineFilesItem"						# shows ItemName
		#-----
		#cscWMI "Win32_OfflineFilesAssociatedItems"			# "This class is not supported"
		#cscWMI "Win32_OfflineFilesChangeInfo"				# usefulness unknown
		#cscWMI "Win32_OfflineFilesConnectionInfo"			# usefulness unknown
		#cscWMI "Win32_OfflineFilesFileSysInfo"				# usefulness unknown
		#cscWMI "Win32_OfflineFilesPinInfo"					# usefulness unknown
		#cscWMI "Win32_OfflineFilesSuspendInfo"				# usefulness unknown

		#----------------------------------------------------
		# OFFLINE FILES (W8/WS2012+)
		#----------------------------------------------------
		cscWMI "Win32_OfflineFilesMachineConfiguration"		# shows
		#-----
		#cscWMI "Win32_OfflineFilesBackgroundSync"			# usefulness unknown
		#cscWMI "Win32_OfflineFilesDiskSpaceLimit"			# usefulness unknown
		#cscWMI "Win32_OfflineFilesHealth"					# usefulness unknown
		#cscWMI "Win32_OfflineFilesUserConfiguration"		# usefulness unknown
	}
	elseif ($bn -gt 7000)
	{
		#----------------------------------------------------
		# OFFLINE FILES (WV/WS2008+)
		#Reference: http://msdn.microsoft.com/en-us/library/bb309180(v=vs.85).aspx
		#----------------------------------------------------
		cscWMI "Win32_OfflineFilesCache"					# shows Active, Enabled, and Location
		cscWMI "Win32_OfflineFilesItem"						# shows ItemName
		#-----
		#cscWMI "Win32_OfflineFilesAssociatedItems"			# "This class is not supported"
		#cscWMI "Win32_OfflineFilesChangeInfo"				# usefulness unknown
		#cscWMI "Win32_OfflineFilesConnectionInfo"			# usefulness unknown
		#cscWMI "Win32_OfflineFilesFileSysInfo"				# usefulness unknown
		#cscWMI "Win32_OfflineFilesPinInfo"					# usefulness unknown
		#cscWMI "Win32_OfflineFilesSuspendInfo"				# usefulness unknown
	}
	CollectFiles -filesToCollect $OutputFile -fileDescription "CscClient WMI output" -SectionDescription $sectionDescription



	#----------CscClient Registry

	$OutputFile= $Computername + "_CscClient_reg_output.TXT"
	$CurrentVersionKeys =	"HKCU\SOFTWARE\Policies\Microsoft\Windows\Netcache",
							"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\NetCache",
							"HKLM\SOFTWARE\Policies\Microsoft\NetCache",
							"HKLM\SYSTEM\CurrentControlSet\services\CSC",
							"HKLM\SYSTEM\CurrentControlSet\services\CscService"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "CscClient Registry Keys" -SectionDescription $sectionDescription



	#----------CSC Eventlogs
	#WV/WS2008+
	if ($bn -gt 6000)
	{
		#----------CscClient EventLog
		$sectionDescription = "CscClient Eventlogs"
		$EventLogNames = 	"Microsoft-Windows-OfflineFiles/Operational",
							"Microsoft-Windows-OfflineFiles/Analytic",
							"Microsoft-Windows-OfflineFiles/Debug",
							"Microsoft-Windows-OfflineFiles/SyncLog"
		$Prefix = ""
		$Suffix = "_evt_"
		.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
	}


	#----------Driver Information for CSC Client
	#$OutputFileSym = "_CscClient"

	# Array of file names to pass to checksym
	#[array]$arrFileNames = @("cscapi.dll","cscdll.dll","cscmig.dll","cscobj.dll","cscsvc.dll")
	# Call DC_ChkSym.ps1 with array of files
	#Run-DiagExpression .\DC_ChkSym.ps1 -FolderName "$Env:SystemRoot\System32" -FileMask $arrFileNames -Prefix $OutputFileSym -Suffix "_binaries_dll" -FileDescription "Offline Files and Folders Driver Versions"
	#Run-DiagExpression .\DC_ChkSym.ps1 -FolderName "$Env:SystemRoot\System32\drivers" -FileMask "csc.sys" -Prefix $OutputFileSym -Suffix "_binaries_sys" -FileDescription "Offline Files and Folders Driver Versions"

	#----------CSC Database
	#$ProcArc = $Env:PROCESSOR_ARCHITECTURE
	$fileDescription = $ScriptVariable.ID_CscClientOutput
	$sectionDescription = $ScriptVariable.ID_CscClientOutputDesc
	$OutputFile = $ComputerName + "_CSCdump.txt"
	$CommandToExecute = "cmd.exe /c CscDbDump.exe dump > $OutputFile"

	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -BackgroundExecution
}
# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDDChBb8kQs4DMW
# aQZ/qPc56NswEJZpnDZhpn1Fds+obqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgx1AbWJYO
# m9Rpwyfm0E6WKxUoPbj42ezLBuUwQQX1lcEwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAJT0dY8aQXBxAuEivPpPvWxT32oU/9jfJ+fN0NWxgf9v6gv9fzABkzfH
# UeXOnt95pObxGQi8DH1mG5o9EsnpQfCZF2wHaXNXjRYdJQgFKpK+2Qi8bNtPnjBs
# zJBvMPRmF0JH38HqUIkB8SfdGr4flc9XpcQ1c84sZvIe8gz9Xbku4616CELqhNbP
# InTeTrQwiHeims7pTkI1ARsszsSZWqEqCEy7NnELuTHrM+4AI83PgbnXiIG5qfXi
# oseu36sVpcz0rP/tkOHONszv7enPsBFVIqqzu2TDtiXmkFxzyLUwSDAYlxd6E4pT
# S9rSRpUc3l9aMalVoyaOY3z/EqKyr0ihghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgQJmp+O1yBZAC0q0BurSY6NRFw6saGuMkpi9aLBSLOmgCBmBjTFo+
# /hgTMjAyMTA1MTkyMjIzNTguNTc3WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpFMDQxLTRCRUUtRkE3RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABN0GPQ+daW2+nAAAAAAE3MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgxNFoXDTIyMDExMjE3MjgxNFowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RTA0MS00
# QkVFLUZBN0UxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDEEe5p0SWbcbm2KSFPONIM
# HT72xeZSFTINVGPRji/P2tn2zKQ2hsvn/oC3nM6R4HZuX0he9V3JL9kk1lPfveSf
# OtDfjvPfQybDv75VT8IT7jHjD2RvlupAd9LNslC3oqZay4yYkvODhHkx4mzkxjlh
# 08vGgygNFxOL/8qgwVHQrNLX/fbgPb/gqQcPVe36zTFjQMgJQ4rVFuYkIoSAE/X8
# YNmO5lAFL0OLz3JOe8slX4uvVC2uIfgSqZGgB2ZXfMnQYmyvm+EY+Yp848JFKTtD
# yKBfuCgWcIvOlhx8cYKqhH+bD3mB9CnDKZXDFkHQ+QYytDD4spU9r8Uc/gLgo75B
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQUDWCwcwz652BjusSd7ro7LPGUT2UwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAnfZT133RFW4BRv02ydcEbUrjaqOFT6Me
# /AF1uKkhxfhaDt0fll25BmPeBaAoANnnP5N6FfsacFuLbrlUjvENGwV7YKORObgk
# iiKx0rBgEOu5L5hFEEbgHURG5aLnhcbDH6VID6JA2siLombQIv8x9Au/Cyo8lIY/
# r04QcLJoTGizjzr5fclO4ZXXUIGX8E7uvxQdvH+sTp9muVllhpsgXpp5qG9MvXgu
# 9ktX9szNhI4OxuMcexOb1BoabWKOFqAJ1uQCqvz7scCBgRqvxc+XPFSFUjhKFUHl
# kZ32BnbIGTDF0DSgVzvjlN04+ts/v293R4+qC8kMfm2Q6FNE0jnldDCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpFMDQxLTRCRUUtRkE3RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUA6ruoOTiJXPwhO5ltQWsAbt5zGpyggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAORPtCUwIhgPMjAyMTA1MTkyMzU4MjlaGA8yMDIxMDUyMDIzNTgyOVowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5E+0JQIBADAKAgEAAgIXOAIB/zAHAgEAAgIR
# gDAKAgUA5FEFpQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAFnaSI48yVkw
# 4cC3G2dDbrOOmdP+ZLp+gMg++PL5rSSb5I+Jhq+mv4oa081KR6BNbJRZ04fTf8mK
# I5w0Jq+1fM/SV6qMbp1ig7fhz6zMxeXkmhqw6rXbbNzeFC0lGTXSifTc1At0xMxj
# /py93HcG7Ik2/1FjJlLAKMVBw61mFnBxMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAE3QY9D51pbb6cAAAAAATcwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQglhaYWi1e3iabdIoXQMtGglY36POYRDcgJQ4n41AttB8wgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAdWX6vwJ4EnSLJf9oZkPZhtDuCT5Ts3sFC
# JMMoBhIcEDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABN0GPQ+daW2+nAAAAAAE3MCIEIEFC3ANrREfyUIPRAbC54GuLTD0unKmsQ/4k
# fbYKwF+cMA0GCSqGSIb3DQEBCwUABIIBAE8iQsiIYijLOFBZhliZ0G7pQcNTr01z
# GUVX8Cu10JTWqPX0ExH90gU68rpH/bkaAbv3g+66kvjpnMjPIjNnwWafk/3kF/Eg
# s7wHeV/qq0pL0syV0lrTlyM91ffP045xYflfvzUe5YZoi4ellaA/T7Qmg8KGwekR
# 2m51xcaX8X/eIcMJA/wnyjxsXW0z4GrV196D/PDM8Rcy98lv5HVDgHn/3c6KeBsO
# sClDkVlrUXu9ilBAMKTy8Bq2LHHgyzLXRJUAH7jEm3lHQfwbkf5pwHRaYSX0ivfs
# hVQWBRegJ7GjXJrdPdrHweTV1ZGyvX949CaNGGMsAo8sH5XvBVS5PcE=
# SIG # End signature block
