﻿###########################################################################
# DC_Descriptors
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Gets service descriptors
###########################################################################

Import-LocalizedData -BindingVariable Desc -FileName DC_Desc -UICulture en-us
Write-DiagProgress -Activity $Desc.ID_Descriptors 

$OutputFile = $ComputerName + "_Descriptors.txt"
logstart

Set-Content $OutputFile ""

function Descriptors ($service, $Description)
	{
		if (($OSVersion.Major -eq 6) -and ($OSVersion.Minor -lt 2)) #_#
		{
			Add-Content $OutputFile $Description -Encoding Unknown 
			$CommandLineToExecute = "cmd.exe /c sc.exe sdshow $service >> $OutputFile" 
			runCMD -commandToRun $CommandLineToExecute  
			#Invoke-Expression -command "sc.exe sdshow $service" | Out-File -Append $OutputFile -Encoding ascii 
			Add-Content $OutputFile "===============================================================`n" -Encoding Unknown 
		}
		
		else			
		{
			Add-Content $OutputFile $Description -Encoding ascii
			Invoke-Expression -command "sc.exe sdshow $service" | Out-File -Append $OutputFile -Encoding ascii 
			Add-Content $OutputFile "===============================================================`n" -Encoding ascii
		}
	
	}
	

$Description = "Wuauserv (Automatic Updates Service): Security Descriptor "
Descriptors "wuauserv" $Description 

$Description = "BITS (Background Intelligent Transfer Service): Security Descriptor  "
Descriptors "BITS" $Description 

$Description = "MSIServer (Windows Installer Service): Security Descriptor  "
Descriptors "MSIServer" $Description 

$Description = "Termservice (Terminal Services): Security Descriptor (for issues where WU AU MU do not install in TS session - SOX060202700067)  "
Descriptors "TermService" $Description 


If ($OS.Name -like "*Windows 7*")
{
Add-Content -Encoding unknown $OutputFile "`n`n`n`nWindows 7 Default Descriptor Values `
Wuauserv (Automatic Updates Service): Security Descriptor  `
D:(A;;CCLCSWRPLORC;;;AU)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)`
======================================================================================`
BITS (Background Intelligent Transfer Service): Security Descriptor`
D:(A;CI;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)`
====================================================================================== `
MSIServer (Windows Installer Service): Security Descriptor`
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)`
====================================================================================== `
Termservice (Terminal Services): Security Descriptor `
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)"
}

elseif ($OS.Name -contains "*Vista*")
{
Add-Content -Encoding Unknown $OutputFile "`n`n`n`nWindows Vista Default Descriptor Values `
Wuauserv (Automatic Updates Service): Security Descriptor  `
D:(A;;CCLCSWRPLORC;;;AU)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)`
======================================================================================`
BITS (Background Intelligent Transfer Service): Security Descriptor`
D:(A;CI;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)`
====================================================================================== `
MSIServer (Windows Installer Service): Security Descriptor`
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)`
====================================================================================== `
Termservice (Terminal Services): Security Descriptor `
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)"

}
elseif ($OS.Name -contains "*2008*")
{
Add-Content -Encoding Unknown $OutputFile "`n`n`n`nWindows 2008 Default Descriptor Values`
Wuauserv (Automatic Updates Service): Security Descriptor  `
D:(A;;CCLCSWRPLORC;;;AU)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)S:(AU;FA;CCDCLCSWRPWPDTLOSDRCWDWO;;;WD)`
======================================================================================`
BITS (Background Intelligent Transfer Service): Security Descriptor`
D:(A;CI;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)S:(AU;SAFA;WDWO;;;BA)`
====================================================================================== `
MSIServer (Windows Installer Service): Security Descriptor`
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)S:(AU;FA;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;WD)`
====================================================================================== `
Termservice (Terminal Services): Security Descriptor `
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)S:(AU;FA;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;WD)"
}
elseif ($os.Name -Contains "*2003*")
{
Add-Content -Encoding Unknown $OutputFile "`n`n`n`nWindows 2003 SP1 Default Descriptor Values`
Wuauserv (Automatic Updates Service): Security Descriptor  `
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)(A;;CR;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)`
======================================================================================`
BITS (Background Intelligent Transfer Service): Security Descriptor`
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)(A;;CR;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)`
====================================================================================== `
MSIServer (Windows Installer Service): Security Descriptor`
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)(A;;CR;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)`
====================================================================================== `
Termservice (Terminal Services): Security Descriptor `
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)(A;;CR;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)`
`n`n`n`nWindows 2003 SP2 Default Descriptor Values`
Wuauserv (Automatic Updates Service): Security Descriptor  `
D:(A;;CCLCSWRPLORC;;;AU)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)`
======================================================================================`
BITS (Background Intelligent Transfer Service): Security Descriptor`
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)`
====================================================================================== `
MSIServer (Windows Installer Service): Security Descriptor`
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)`
====================================================================================== `
Termservice (Terminal Services): Security Descriptor `
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;IU)(A;;CCLCSWLOCRRC;;;SU)(A;;CR;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)"
}

elseif ($OS.Name -contains "*XP*")
{
Add-Content -Encoding Unknown $OutputFile "`n`n`n`nWindows XP Default Descriptor Values`
Wuauserv (Automatic Updates Service): Security Descriptor  `
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)`
======================================================================================`
BITS (Background Intelligent Transfer Service): Security Descriptor`
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)`
====================================================================================== `
MSIServer (Windows Installer Service): Security Descriptor`
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)`
====================================================================================== `
Termservice (Terminal Services): Security Descriptor `
D:(A;;CCLCSWRPWPDTLOCRRC;;;SY)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;BA)(A;;CCLCSWLOCRRC;;;AU)(A;;CCLCSWRPWPDTLOCRRC;;;PU)"
}

CollectFiles -filesToCollect $OutputFile -fileDescription "Descriptors" -sectionDescription "Windows Update Information"
logstop
	
	

