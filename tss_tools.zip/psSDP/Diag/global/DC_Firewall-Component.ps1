﻿#************************************************
# DC_Firewall-Component.ps1
# Version 1.0
# Version 1.1: Altered the runPS function correctly a column width issue.
# Date: 2009, 2014, 2020/waltere: add NetworkIsolation
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about the Windows Firewall.
# Called from: Main Networking Diag
#*******************************************************

param(
		[switch]$before,
		[switch]$after
	)

	
Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSFirewall -Status $ScriptVariable.ID_CTSFirewallDescription

# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber


function RunNetSH ([string]$NetSHCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSFirewall -Status "netsh $NetSHCommandToExecute"
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $outputFile -append
	"netsh $NetSHCommandToExecute"			| Out-File -FilePath $outputFile -append
	"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $outputFile -append
	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $outputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}


$sectionDescription = "Firewall"


#Handle suffix of file name
	if ($before)
	{
		$suffix = "_BEFORE"
	}
	elseif ($after)
	{
		$suffix = "_AFTER"
	}
	else
	{
		$suffix = ""
	}


#W8/WS2012+
if ($bn -gt 9000)
{	
	"[info]: Firewall-Component W8/WS2012+"  | WriteTo-StdOut 

	$outputFile= $Computername + "_Firewall_info_pscmdlets" + $suffix + ".TXT"
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Firewall Powershell Cmdlets"						| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Overview"											| Out-File -FilePath $OutputFile -append
	"----------------------------------------"			| Out-File -FilePath $OutputFile -append
	"Firewall Powershell Cmdlets"						| Out-File -FilePath $OutputFile -append
	"   1. Show-NetIPsecRule -PolicyStore ActiveStore"	| Out-File -FilePath $OutputFile -append
	"   2. Get-NetIPsecMainModeSA"						| Out-File -FilePath $OutputFile -append
	"   3. Get-NetIPsecQuickModeSA"						| Out-File -FilePath $OutputFile -append
	"   4. Get-NetFirewallProfile"						| Out-File -FilePath $OutputFile -append
	"   5. Get-NetFirewallRule"							| Out-File -FilePath $OutputFile -append
	"   6. Show-NetFirewallRule"						| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Firewall Powershell Cmdlets"						| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	runPS "Show-NetIPsecRule -PolicyStore ActiveStore"		# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Get-NetIPsecMainModeSA"							# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Get-NetIPsecQuickModeSA"							# W8/WS2012, W8.1/WS2012R2	# fl				
	runPS "Get-NetFirewallProfile"							# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Get-NetFirewallRule"								# W8/WS2012, W8.1/WS2012R2	# fl
	runPS "Show-NetFirewallRule"							# W8/WS2012, W8.1/WS2012R2	# fl

	CollectFiles -filesToCollect $outputFile -fileDescription "Firewall Information PS cmdlets" -SectionDescription $sectionDescription
}


#WV/WS2008+
if ($bn -gt 6000)
{
	"[info]: Firewall-Component WV/WS2008+"  | WriteTo-StdOut 

	#----------Netsh
	$outputFile = $ComputerName + "_Firewall_netsh_advfirewall" + $suffix + ".TXT"
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Output"					| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Overview"											| Out-File -FilePath $OutputFile -append
	"----------------------------------------"			| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Output"					| Out-File -FilePath $OutputFile -append
	"   1. netsh advfirewall show allprofiles"			| Out-File -FilePath $OutputFile -append
	"   2. netsh advfirewall show allprofiles state"	| Out-File -FilePath $OutputFile -append
	"   3. netsh advfirewall show currentprofile"		| Out-File -FilePath $OutputFile -append
	"   4. netsh advfirewall show domainprofile"		| Out-File -FilePath $OutputFile -append
	"   5. netsh advfirewall show global"				| Out-File -FilePath $OutputFile -append
	"   6. netsh advfirewall show privateprofile"		| Out-File -FilePath $OutputFile -append
	"   7. netsh advfirewall show publicprofile"		| Out-File -FilePath $OutputFile -append
	"   8. netsh advfirewall show store"				| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Output"					| Out-File -FilePath $OutputFile -append
	"========================================"			| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "advfirewall show allprofiles"
	RunNetSH -NetSHCommandToExecute "advfirewall show allprofiles state"
	RunNetSH -NetSHCommandToExecute "advfirewall show currentprofile"
	RunNetSH -NetSHCommandToExecute "advfirewall show domainprofile"
	RunNetSH -NetSHCommandToExecute "advfirewall show global"
	RunNetSH -NetSHCommandToExecute "advfirewall show privateprofile"
	RunNetSH -NetSHCommandToExecute "advfirewall show publicprofile"
	RunNetSH -NetSHCommandToExecute "advfirewall show store"
	CollectFiles -filesToCollect $outputFile -fileDescription "Firewall Advfirewall" -SectionDescription $sectionDescription


	#-----WFAS export
	$filesToCollect = $ComputerName + "_Firewall_netsh_advfirewall-export" + $suffix + ".wfw"
	$commandToRun = "netsh advfirewall export " +  $filesToCollect
	RunCMD -CommandToRun $commandToRun -filesToCollect $filesToCollect -fileDescription "Firewall Export" -sectionDescription $sectionDescription 

	#-----WFAS ConSec rules (all)
	$outputFile = $ComputerName + "_Firewall_netsh_advfirewall-consec-rules" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules Output"					| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules Output"					| Out-File -FilePath $OutputFile -append
	"   1. netsh advfirewall consec show rule all any dynamic verbose"	| Out-File -FilePath $OutputFile -append
	"   2. netsh advfirewall consec show rule all any static verbose"	| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules Output"					| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	# 3/5/2013: Through feedback from Markus Sarcletti, this command has been removed because it is an invalid command:
	#   "advfirewall consec show rule name=all"
	RunNetSH -NetSHCommandToExecute "advfirewall consec show rule all any dynamic verbose"
	RunNetSH -NetSHCommandToExecute "advfirewall consec show rule all any static verbose"
	CollectFiles -filesToCollect $outputFile -fileDescription "Advfirewall ConSec Rules" -SectionDescription $sectionDescription

	
	#-----WFAS ConSec rules (active)
	# 3/5/2013: Through feedback from Markus Sarcletti, adding active ConSec rules
	$outputFile = $ComputerName + "_Firewall_netsh_advfirewall-consec-rules-active" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules (ACTIVE)"					| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules (ACTIVE)"					| Out-File -FilePath $OutputFile -append
	"   1. netsh advfirewall monitor show consec verbose"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall ConSec Rules (ACTIVE)"					| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "advfirewall monitor show consec verbose"
	CollectFiles -filesToCollect $outputFile -fileDescription "Advfirewall ConSec Rules" -SectionDescription $sectionDescription

	
	#-----WFAS Firewall rules (all)
	$outputFile = $ComputerName + "_Firewall_netsh_advfirewall-firewall-rules" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules"							| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules"							| Out-File -FilePath $OutputFile -append
	"   1. netsh advfirewall monitor show consec verbose"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules"							| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "advfirewall firewall show rule name=all"
	CollectFiles -filesToCollect $outputFile -fileDescription "Advfirewall Firewall Rules" -SectionDescription $sectionDescription

	
	#-----WFAS Firewall rules all (active)
	# 3/5/2013: Through feedback from Markus Sarcletti, adding active Firewall Rules
	$outputFile = $ComputerName + "_Firewall_netsh_advfirewall-firewall-rules-active" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules (ACTIVE)"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules (ACTIVE)"				| Out-File -FilePath $OutputFile -append
	"   1. netsh advfirewall monitor show firewall verbose"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh AdvFirewall Firewall Rules (ACTIVE)"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "advfirewall monitor show firewall verbose"
	CollectFiles -filesToCollect $outputFile -fileDescription "Advfirewall Firewall Rules" -SectionDescription $sectionDescription	

	
	
	#-----Netsh WFP	

	#-----Netsh WFP show netevents file=
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-netevents" + $suffix + ".XML"
	$commandToRun = "netsh wfp show netevents file= " +  $outputFile
	RunCMD -CommandToRun $commandToRun -filesToCollect $outputFile -fileDescription "Netsh WFP Show Netevents" -sectionDescription $sectionDescription 
	
	#-----Netsh WFP show BoottimePolicy file=
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-boottimepolicy" + $suffix + ".XML"
	$commandToRun = "netsh wfp show boottimepolicy file= " +  $outputFile
	RunCMD -CommandToRun $commandToRun -filesToCollect $outputFile -fileDescription "Netsh WFP Show BootTimePolicy" -sectionDescription $sectionDescription 

	#-----Netsh wfp show Filters file=
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-filters" + $suffix + ".XML"
	$commandToRun = "netsh wfp show filters file= " +  $outputFile
	RunCMD -CommandToRun $commandToRun -filesToCollect $outputFile -fileDescription "Netsh WFP Show Filters" -sectionDescription $sectionDescription 
	
	#-----Netsh wfp show Options optionsfor=keywords
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-options" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Options"									| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Options"									| Out-File -FilePath $OutputFile -append
	"   1. netsh wfp show options optionsfor=keywords"					| Out-File -FilePath $OutputFile -append
	"   2. netsh wfp show options optionsfor=netevents"					| Out-File -FilePath $OutputFile -append
	"   3. netsh wfp show options optionsfor=txnwatchdog"				| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Options"									| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "wfp show options optionsfor=keywords"
	RunNetSH -NetSHCommandToExecute "wfp show options optionsfor=netevents"
	RunNetSH -NetSHCommandToExecute "wfp show options optionsfor=txnwatchdog"
	CollectFiles -filesToCollect $outputFile -fileDescription "Netsh WFP Show Options" -SectionDescription $sectionDescription

	
	#-----Netsh wfp show Security netevents
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-security-netevents" + $suffix + ".TXT"
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Security Netevents"						| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Security Netevents"						| Out-File -FilePath $OutputFile -append
	"   1. netsh wfp show security netevents"							| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh WFP Show Security Netevents"						| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "wfp show security netevents"
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	CollectFiles -filesToCollect $outputFile -fileDescription "Netsh WFP Show Security NetEvents" -SectionDescription $sectionDescription






	#-----Netsh wfp show State file=
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-state" + $suffix + ".XML"
	$commandToRun = "netsh wfp show state file= " +  $outputFile
	RunCMD -CommandToRun $commandToRun -filesToCollect $outputFile -fileDescription "Netsh WFP Show State" -sectionDescription $sectionDescription 
	
	#-----Netsh wfp show Sysports file=
	$outputFile = $ComputerName + "_Firewall_netsh_wfp-show-sysports" + $suffix + ".XML"
	$commandToRun = "netsh wfp show sysports file= " +  $outputFile
	RunCMD -CommandToRun $commandToRun -filesToCollect $outputFile -fileDescription "Netsh WFP Show Sysports" -sectionDescription $sectionDescription 



	#----------Netsh
	$outputFile = $ComputerName + "_Firewall_netsh_firewall.TXT"	
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh Firewall"											| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"Overview"															| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"				| Out-File -FilePath $OutputFile -append
	"Firewall Netsh Firewall"											| Out-File -FilePath $OutputFile -append
	"   1. netsh firewall show allowedprogram"							| Out-File -FilePath $OutputFile -append
	"   2. netsh firewall show config"									| Out-File -FilePath $OutputFile -append
	"   3. netsh firewall show currentprofile"							| Out-File -FilePath $OutputFile -append
	"   4. netsh firewall show icmpsetting"								| Out-File -FilePath $OutputFile -append
	"   5. netsh firewall show logging"									| Out-File -FilePath $OutputFile -append
	"   6. netsh firewall show multicastbroadcastresponse"				| Out-File -FilePath $OutputFile -append
	"   7. netsh firewall show notifications"							| Out-File -FilePath $OutputFile -append
	"   8. netsh firewall show opmode"									| Out-File -FilePath $OutputFile -append
	"   9. netsh firewall show portopening"								| Out-File -FilePath $OutputFile -append
	"  10. netsh firewall show service"									| Out-File -FilePath $OutputFile -append
	"  11. netsh firewall show state"									| Out-File -FilePath $OutputFile -append
	"===================================================="				| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	"`n"																| Out-File -FilePath $OutputFile -append
	RunNetSH -NetSHCommandToExecute "firewall show allowedprogram"
	RunNetSH -NetSHCommandToExecute "firewall show config"
	RunNetSH -NetSHCommandToExecute "firewall show currentprofile"
	RunNetSH -NetSHCommandToExecute "firewall show icmpsetting"
	RunNetSH -NetSHCommandToExecute "firewall show logging"
	RunNetSH -NetSHCommandToExecute "firewall show multicastbroadcastresponse"
	RunNetSH -NetSHCommandToExecute "firewall show notifications"
	RunNetSH -NetSHCommandToExecute "firewall show opmode"
	RunNetSH -NetSHCommandToExecute "firewall show portopening"
	RunNetSH -NetSHCommandToExecute "firewall show service"
	RunNetSH -NetSHCommandToExecute "firewall show state"
	CollectFiles -filesToCollect $outputFile -fileDescription "Firewall" -SectionDescription $sectionDescription


	
	#----------Registry
	$outputFile= $Computername + "_Firewall_reg_" + $suffix + ".TXT"
	$CurrentVersionKeys =	"HKLM\Software\Policies\Microsoft\WindowsFirewall",
							"HKLM\SYSTEM\CurrentControlSet\Services\BFE",
							"HKLM\SYSTEM\CurrentControlSet\Services\IKEEXT",
							"HKLM\SYSTEM\CurrentControlSet\Services\MpsSvc",
							"HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess",
							"HKLM\Software\Policies\Microsoft\Windows\NetworkIsolation"
	$sectionDescription = "Firewall"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -outputFile $outputFile -fileDescription "Firewall Registry Keys" -SectionDescription $sectionDescription


	#----------EventLogs
	if ( ($suffix -eq "") -or ($suffix -eq "_AFTER") )
	{
		#----------WFAS Event Logs
		$sectionDescription = "Firewall EventLogs"
		#WFAS CSR
		$EventLogNames = "Microsoft-Windows-Windows Firewall With Advanced Security/ConnectionSecurity"
		$Prefix = ""
		$Suffix = "_evt_"
		.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix

		#WFAS CSR Verbose
		$EventLogNames = "Microsoft-Windows-Windows Firewall With Advanced Security/ConnectionSecurityVerbose"
		$Prefix = ""
		$Suffix = "_evt_"
		.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix

		#WFAS FW
		$EventLogNames = "Microsoft-Windows-Windows Firewall With Advanced Security/Firewall"
		$Prefix = ""
		$Suffix = "_evt_"
		.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix

		#WFAS FW Verbose
		$EventLogNames = "Microsoft-Windows-Windows Firewall With Advanced Security/FirewallVerbose"
		$Prefix = ""
		$Suffix = "_evt_"
		.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
	}
	
} 
#Windows Server 2003
else
{
	"[info]: Firewall-Component XP/WS2003"  | WriteTo-StdOut 
	#----------Registry
	$outputFile= $Computername + "_Firewall_reg_.TXT"
	$CurrentVersionKeys =	"HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall",
							"HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess"
	$sectionDescription = "Firewall"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -outputFile $outputFile -fileDescription "Firewall Registry Keys" -SectionDescription $sectionDescription
	
	#----------Netsh
	$outputFile = $ComputerName + "_Firewall_netsh.TXT"
	RunNetSH -NetSHCommandToExecute "firewall show allowedprogram"
	RunNetSH -NetSHCommandToExecute "firewall show config"
	RunNetSH -NetSHCommandToExecute "firewall show currentprofile"
	RunNetSH -NetSHCommandToExecute "firewall show icmpsetting"
	RunNetSH -NetSHCommandToExecute "firewall show logging"
	RunNetSH -NetSHCommandToExecute "firewall show multicastbroadcastresponse"
	RunNetSH -NetSHCommandToExecute "firewall show notifications"
	RunNetSH -NetSHCommandToExecute "firewall show opmode"
	RunNetSH -NetSHCommandToExecute "firewall show portopening"
	RunNetSH -NetSHCommandToExecute "firewall show service"
	RunNetSH -NetSHCommandToExecute "firewall show state"
	CollectFiles -filesToCollect $outputFile -fileDescription "Firewall" -SectionDescription $sectionDescription
}


