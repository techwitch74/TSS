﻿#************************************************
# DC_WinUpdateCollect.ps1
# Version 1.1
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects WindowsUpdate information.
# Called from: TS_AutoAddCommands_Apps.ps1
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_WinUpdateCollect.ps1"
"Starting WinUpdateCollect.ps1 script" | WriteTo-StdOut
"============================================================" | WriteTo-StdOut
#_# Import-LocalizedData -BindingVariable ScriptStrings

# Registry keys
"Getting Windows Update Registry Keys." | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_WindowsUpdateRegistryKeys_Title -Status $ScriptStrings.ID_WindowsUpdateRegistryKeys_Status


$Regkeys = "HKLM\Software\Microsoft\Windows\CurrentVersion\WindowsStore\WindowsUpdate"
$OutputFile = $ComputerName + "_reg_WindowsStoreWU_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "WindowsStoreWU Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate" 
$OutputFile = $ComputerName + "_reg_WindowsUpdatePolicy_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "WindowsUpdate Policy Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKLM\Software\Microsoft\Windows\CurrentVersion\WindowsUpdate" 
$OutputFile = $ComputerName + "_reg_WindowsUpdate_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "WindowsUpdate Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx" 
$OutputFile = $ComputerName + "_reg_Appx_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Appx Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKLM\Software\Microsoft\Windows\CurrentVersion\AppHost" 
$OutputFile = $ComputerName + "_reg_AppHost_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "AppHost Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKLM\Software\Microsoft\Windows\CurrentVersion\Internet Settings\PluggableProtocols" 
$OutputFile = $ComputerName + "_reg_PluggableProtocols_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Pluggable Protocols Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKLM\Software\Microsoft\Windows\Windows Error Reporting\BrokerUp" 
$OutputFile = $ComputerName + "_reg_BrokerUp_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "BrokerUp Registry Key" -SectionDescription "Software Registry keys" 

#_# $Regkeys = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModel" 
#_# $OutputFile = $ComputerName + "_reg_AppModel_HKLM.txt"
#_# RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "AppModel Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKLM\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel" 
$OutputFile = $ComputerName + "_reg_Classes_AppModel_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Classes AppModel Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKLM\Software\Policies\Microsoft\Windows\AppX" 
$OutputFile = $ComputerName + "_reg_Policies_AppX_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Policies AppX Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" 
$OutputFile = $ComputerName + "_reg_InternetSettings_HKCU.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "InternetSettings Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKCU\Software\Microsoft\Windows\CurrentVersion\AppHost" 
$OutputFile = $ComputerName + "_reg_AppHost_HKCU.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "HKCU AppHost Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModel" 
$OutputFile = $ComputerName + "_reg_AppModel_HKCU.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "HKCU AppModel Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel" 
$OutputFile = $ComputerName + "_reg_Local_Settings_AppModel_HKCU.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Local Settings AppModel Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer" 
$OutputFile = $ComputerName + "_reg_Local_Settings_AppContainer_HKCU.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Local Settings AppContainer Registry Key" -SectionDescription "Software Registry keys"




# Saved Directories
"Getting copy of log files" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_Updatelogfiles_Title -Status $ScriptStrings.ID_Updatelogfiles_Status

$sectionDescription = "Update Log Files"
if(test-path "$env:localappdata\Microsoft\Windows\WindowsUpdate.log")
{	$OutputFile = $ComputerName + "_WindowsUpdate-Appdata.log"
	copy-item -Path "$env:localappdata\Microsoft\Windows\WindowsUpdate.log" -Destination $OutputFile -Force
	CollectFiles -filesToCollect $OutputFile -fileDescription "Local Appdata WindowsUpdate.Log" -sectionDescription $sectionDescription
}
if(test-path "$env:windir\windowsupdate.log")
{	$OutputFile = $ComputerName + "_WindowsUpdate-WinDir.log"
	copy-item -Path "$env:windir\Comsetup.log" -Destination $OutputFile -Force
	CollectFiles -filesToCollect $OutputFile -fileDescription "Windows\WindowsUpdate.Log" -sectionDescription $sectionDescription
}
if(test-path "$env:windir\SoftwareDistribution\ReportingEvents.log")
{	$OutputFile = $ComputerName + "_ReportingEvents.log"
	copy-item -Path "$env:windir\SoftwareDistribution\ReportingEvents.log" -Destination $OutputFile -Force
	CollectFiles -filesToCollect $OutputFile -fileDescription "Windows\SoftwareDistribution\ReportingEvents.log" -sectionDescription $sectionDescription
}



# Directory Listings
"Getting Directory Listing of Windows Update files" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_WindowsUpdateFilesDirectoryListings_Title -Status $ScriptStrings.ID_WindowsUpdateFilesDirectoryListings_Status

$sectionDescription = "Windows Update Files Directory Listings"
if(test-path "$env:windir\SoftwareDistribution")
{	$OutputFile = $ComputerName + "_DirList_SoftwareDistributionDir.txt"
	dir -Recurse "$env:windir\SoftwareDistribution" >> $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "Software Distribution Directory Listings" -sectionDescription $sectionDescription
}


# Permission Data

#Running BitsAdmin application
"Getting BitsAdmin Output" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_RunningBitsAdmin_Title -Status $ScriptStrings.ID_RunningBitsAdmin_Status
$OutputFile = $ComputerName + "_BitsJobs.log"
$CommandLineToExecute = "cmd.exe /c bitsadmin.exe /list > $OutputFile"
RunCmD -commandToRun $CommandLineToExecute -filesToCollect $OutputFile -fileDescription "BitsJobs log" -sectionDescription "BitsJobs Log Files"

# Event Data
$sectionDescription = "Event Logs"
$EventLogNames = "Microsoft-Windows-Bits-Client/Operational", "Microsoft-Windows-WindowsUpdateClient/Analytic", "Microsoft-Windows-WindowsUpdateClient", "Microsoft-Windows-WindowsUpdateClient/Operational"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_WinUpdateCollect.ps1"

#Missing Service.txt
#Missing WinHttpProxy.log

