﻿# *****************************************************************************************
# Version 1.0
# Date: 02-23-2012
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects all Configuration Manager Logs
#		Log Collection flags are pre-set in appropriate utils script.
#		1. Collects CCM Logs.
#		2. Collects SMS Logs.
#		3. Collects most recent copy of CrashDumps and Crash.log for previous 9 crashes.
#		4. Collects Admin Console Logs.
#		5. Collects Site Setup Logs.
#		6. Collects CCMSetup Logs.
#		7. Collects WSUS Logs.
#		8. Collects logs for new CM12 Roles
#		9. Collects Lantern Logs for CM12 Client
#		10. Compresses all logs to ConfigMgrLogs.zip
# *****************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

TraceOut "Started"

TraceOut "GetCCMLogs: $GetCCMLogs"
TraceOut "GetSMSLogs: $GetSMSLogs"
TraceOut "CCMSetup Logs Directory = $CCMSetupLogPath"
TraceOut "AdminUI Logs Directory: $AdminUILogPath"

Import-LocalizedData -BindingVariable ScriptStrings

$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_Logs_ConfigMgr")
$ZipName = "Logs_ConfigMgr.zip"
$Compress = $false
$fileDescription = "ConfigMgr Logs"
$sectionDescription = "Configuration Manager Logs"

# Remove temp destination directory if it exists
If (Test-Path $Destination)
{
	Remove-Item -Path $Destination -Recurse
}

# ---------
# CCM Logs
# ---------

TraceOut "    Getting CCM Logs"
If ($CCMLogPath -ne $null)
{
	# CCM Logs
	If (Test-Path ($CCMLogPath))
	{
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CCM_CollectConfigMgrLogs
		$TempDestination = Join-Path $Destination "CCM_Logs"
		New-Item -ItemType "Directory" $TempDestination

		# Copy-Item ($CCMLogPath + "\*.lo*") ($TempDestination) -ErrorAction SilentlyContinue -Force
		Copy-FilesWithStructure -Source $CCMLogPath -Destination $TempDestination -Include *.lo*

		if (Test-Path (Join-Path $Env:windir "\WindowsUpdate.log")) {
			Copy-Item ($Env:windir + "\WindowsUpdate.log") ($TempDestination) -ErrorAction SilentlyContinue
		}
		$Compress = $true
	}
	Else
	{
		TraceOut "      $CCMLogPath does not exist. CCM Logs not collected. Check Logging\@Global\LogDirectory Registry Key Value."
	}

	if ($GetCCMLogs) {
		# Software Catalog Logs
		TraceOut "    Getting Software Catalog Logs for all users"
		$TempDestination = Join-Path $Destination "CCM_SoftwareCatalog_Logs"
		New-Item -ItemType "Directory" $TempDestination
		if ($OSVersion.Major -lt 6) {
			$ProfilePath = Join-Path $env:systemdrive "Documents and Settings"
			$SLPath = "\Local Settings\Application Data\Microsoft\Silverlight\is"
		}
		else {
			$ProfilePath = Join-Path $env:systemdrive "Users"
			$SLPath = "\AppData\LocalLow\Microsoft\Silverlight\is"
		}

		Get-ChildItem $ProfilePath | `
			foreach {
				if (!$_.Name.Contains("All Users") -and !$_.Name.Contains("Default") -and !$_.Name.Contains("Public") -and !$_.Name.Contains("LocalService") -and !$_.Name.Contains("NetworkService") -and !$_.Name.Contains("Classic .NET AppPool")) {
					$currentUserName = $_.Name
					TraceOut "      Checking user $currentUserName"
					Get-ChildItem -Path (Join-Path $_.FullName $SLpath) -Recurse -Filter *ConfigMgr*.lo* -ErrorAction SilentlyContinue | `
						foreach {
							TraceOut "        Copying ConfigMgr Silverlight logs for $currentUserName"
							Copy-Item -Path $_.FullName -Destination "$TempDestination\$($currentUserName)_$($_)" -Force
							$Compress = $true
						}
				}
			}
	}
}
Else
{
	TraceOut "    Client detected but CCMLogPath is set to null. CCM Logs not collected. Check Logging\@Global\LogDirectory Registry Key Value."
}

# ----------
# SMS Logs
# ----------
TraceOut "    Getting SMS Logs"
If ($SMSLogPath -ne $null)
{
	If (Test-Path ($SMSLogPath))
	{
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_SMS_CollectConfigMgrLogs

		# SMS Logs
		$SubDestination =Join-Path $Destination "SMS_Logs"
		New-Item -ItemType "Directory" $SubDestination
		# Copy-Item ($SMSLogPath + "\*.lo*") $SubDestination
		Copy-Files -Source $SMSLogPath -Destination $SubDestination -Filter *.lo*

		# CrashDumps
		If (Test-Path ($SMSLogPath + "\CrashDumps"))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CrashDumps_CollectConfigMgrLogs
			$CrashDumps = Get-ChildItem ($SMSLogPath + "\CrashDumps") | Sort-Object CreationTime -Descending | Select -first 10
			$i = 0
			for ($i = 0 ; $i -lt $CrashDumps.Length ; $i++)
			{
				if ($i -eq 0)
				{
					Copy-Item $CrashDumps[$i].PSPath ($Destination + "\CrashDumps\" + $CrashDumps[$i] + "_Full") -Recurse
				}
				else
				{
					New-Item -ItemType "Directory" ($Destination + "\CrashDumps\" + $CrashDumps[$i]) -Force
					Copy-Item ($CrashDumps[$i].PSPath + "\crash.log") ($Destination + "\CrashDumps\" + $CrashDumps[$i] + "\crash.log") -ErrorAction SilentlyContinue
				}
			}
		}

		$Compress = $true
	}
	Else
	{
		TraceOut "      $SMSLogPath does not exist. SMS Logs not collected. Check $Reg_SMS\Identification\Installation Directory Registry Key Value."
	}
}
Else
{
	TraceOut "      SMSLogPath is set to null. SMS Logs not collected. Check $Reg_SMS\Identification\Installation Directory Registry Key Value."
}

# Collect SQL Backup Logs. Not implemented for CM07.
If ($Is_SiteServer)
{
	TraceOut "    Getting SQLBackup Logs"
	if ($SQLBackupLogPathUNC -ne $null) {
		if (Test-Path $SQLBackupLogPathUNC) {
			$SubDestination = Join-Path $Destination ("SMSSqlBackup_" + $ConfigMgrDBServer + "_Logs")
			New-Item -ItemType "Directory" $SubDestination

			TraceOut "SubDestination = $SubDestination"
			#Copy-Item ($SQLBackupLogPathUNC + "\*.lo*") $SubDestination
			Copy-Files -Source $SQLBackupLogPathUNC -Destination $SubDestination -Filter *.lo*
			$Compress = $true
		}
		else {
			TraceOut "      $SQLBackupLogPathUNC does not exist or Access Denied. SMS SQL Backup Logs not collected."
		}
	}
	else {
		TraceOut "      SQLBackupLogPathUNC is set to null. SMS SQL Backup Logs not collected."
	}
}

# Collect DP Logs. For CM07, DPLogPath should be null.
TraceOut "    Getting DP Logs"
If ($DPLogPath -ne $null)
{
	If (Test-Path ($DPLogPath))
	{
		New-Item -ItemType "Directory" ($Destination + "\DP_Logs")
		# Copy-Item ($DPLogPath + "\*.lo*") ($Destination + "\DP_Logs")
		Copy-Files -Source $DPLogPath -Destination ($Destination + "\DP_Logs") -Filter *.lo*
		$Compress = $true
	}
	Else
	{
		TraceOut "      $DPLogPath does not exist. DP Logs not collected."
	}
}
Else
{
	TraceOut "      DPLogPath is set to null. DP Logs not collected."
}

# Collect SMSProv Log(s) if SMS Provider is installed on Remote Server.
If ($Is_SMSProv)
{
	If ($Is_SiteServer -eq $false)
	{
		TraceOut "    Getting SMSProv Logs"
		If (Test-Path ($SMSProvLogPath))
		{
			New-Item -ItemType "Directory" ($Destination + "\SMSProv_Logs")
			# Copy-Item ($SMSProvLogPath + "\*.lo*") ($Destination + "\SMSProv_Logs")
			Copy-Files -Source $SMSProvLogPath -Destination ($Destination + "\SMSProv_Logs") -Filter *.lo*

			$Compress = $true
		}
		Else
		{
			TraceOut "      $SMSProvLogPath does not exist. SMS Provider Logs not collected."
		}
	}
}

# Collect AdminUI Logs
If ($Is_AdminUI -and ($RemoteStatus -ne 2))
{
	If ($AdminUILogPath -ne $null)
	{
		TraceOut "    Getting AdminUI Logs"
		If (Test-Path ($AdminUILogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_AdminUI_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\AdminUI_Logs")
			#$FilesToCopy = Get-ChildItem ($AdminUILogPath + "\*.log") | Where-Object -FilterScript {$_.Name -notlike "*-*"}
			#Copy-Item $FilesToCopy ($Destination + "\AdminUI_Logs")
			Copy-Files -Source $AdminUILogPath -Destination ($Destination + "\AdminUI_Logs") -Filter *.lo*
			$Compress = $true
		}
		Else
		{
			TraceOut "      $AdminUILogPath does not exist. AdminUI Logs not collected."
		}
	}
	Else
	{
		TraceOut "      AdminUI detected but AdminUILogPath is set to null. AdminUI Logs not collected."
	}
}

# Collect Setup logs
If (Test-Path ("$Env:SystemDrive\ConfigMgr*.log"))
{
	If ($RemoteStatus -ne 2) {
		TraceOut "    Getting ConfigMgr Setup Logs"
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Setup_CollectConfigMgrLogs
		New-Item -ItemType "Directory" ($Destination + "\ConfigMgrSetup_Logs")
		Copy-Item ($Env:SystemDrive + "\Config*.lo*") ($Destination + "\ConfigMgrSetup_Logs") -Force -ErrorAction SilentlyContinue
		Copy-Item ($Env:SystemDrive + "\Comp*.lo*") ($Destination + "\ConfigMgrSetup_Logs") -Force -ErrorAction SilentlyContinue
		Copy-Item ($Env:SystemDrive + "\Ext*.lo*") ($Destination + "\ConfigMgrSetup_Logs") -Force -ErrorAction SilentlyContinue
		$Compress = $true
	}
}

# Collect CCM Setup Logs
If (Test-Path ($CCMSetupLogPath))
{
	TraceOut "    Getting CCMSetup Logs"
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CCMSetup_CollectConfigMgrLogs
	New-Item -ItemType "Directory" ($Destination + "\CCMSetupRTM_Logs")
	New-Item -ItemType "Directory" ($Destination + "\CCMSetup_Logs")
	Copy-Item ($CCMSetupLogPath + "\*.log") ($Destination + "\CCMSetupRTM_Logs") -Recurse -Force -ErrorAction SilentlyContinue
	Copy-Item ($CCMSetupLogPath + "\Logs\*.log") ($Destination + "\CCMSetup_Logs") -Recurse -Force -ErrorAction SilentlyContinue

	$Compress = $true
}

# Collect WSUS Logs
#If ($Is_WSUS -and ($RemoteStatus -ne 2))
#{
#	$WSUSLogPath = $WSUSInstallDir + "LogFiles"
#	TraceOut "WSUS Logs Directory: $WSUSLogPath"
#	New-Item -ItemType "Directory" ($Destination + "\WSUS_Logs")
#	Copy-Item ($WSUSLogPath + "\*.log") ($Destination + "\WSUS_Logs") -Force -ErrorAction SilentlyContinue
#	$Compress = $true
#}

# Collect App Catalog Service Logs
If ($Is_AWEBSVC -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting AppCatalogSvc Logs"
	If ($AppCatalogSvcLogPath -ne $null)
	{
		If (Test-Path ($AppCatalogSvcLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_AppCat_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\AppCatalogSvc_Logs")
			$FilesToCopy = Get-ChildItem ($AppCatalogSvcLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\AppCatalogSvc_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $AppCatalogSvcLogPath does not exist. App Catalog Service Logs not collected."
		}
	}
	Else
	{
		TraceOut "      App Catalog Service Role detected but App Catalog Service Log Path is set to null. Logs not collected."
	}
}

# Collect App Catalog Website Logs
If ($Is_PORTALWEB -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting App Catalog Logs"
	If ($AppCatalogLogPath -ne $null)
	{
		If (Test-Path ($AppCatalogLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_AppCatSvc_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\AppCatalog_Logs")
			$FilesToCopy = Get-ChildItem ($AppCatalogLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\AppCatalog_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $AppCatalogLogPath does not exist. App Catalog Logs not collected."
		}
	}
	Else
	{
		TraceOut "      App Catalog Role detected but App Catalog Log Path is set to null. Logs not collected."
	}
}

# Collect Enrollment Point Logs
If ($Is_ENROLLSRV -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting Enrollment Point Logs"
	If ($EnrollPointLogPath -ne $null)
	{
		If (Test-Path ($EnrollPointLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_EnrollPoint_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\EnrollPoint_Logs")
			$FilesToCopy = Get-ChildItem ($EnrollPointLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\EnrollPoint_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $EnrollPointLogPath does not exist. Enrollment Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Enrollment Point Role detected but Enrollment Point Log Path is set to null. Logs not collected."
	}
}

# Collect Enrollment Proxy Point Logs
If ($Is_ENROLLWEB -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting Enrollment Proxy Point Logs"
	If ($EnrollProxyPointLogPath -ne $null)
	{
		If (Test-Path ($EnrollProxyPointLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_EnrollProxy_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\EnrollProxyPoint_Logs")
			$FilesToCopy = Get-ChildItem ($EnrollProxyPointLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\EnrollProxyPoint_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $EnrollProxyPointLogPath does not exist. Enrollment Proxy Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Enrollment Proxy Point Role detected but Enrollment Proxy Point Log Path is set to null. Logs not collected."
	}
}

# Collect Certificate Registration Point Logs
If ($Is_CRP -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting Certificate Registration Point Logs"
	If ($CRPLogPath -ne $null)
	{
		If (Test-Path ($CRPLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CRP_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\CRP_Logs")
			$FilesToCopy = Get-ChildItem ($CRPLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\CRP_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $CRPLogPath does not exist. Certificate Registration Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Certificate Registration Point Role detected but Certificate Registration Point Log Path is set to null. Logs not collected."
	}
}

If ($Is_Lantern) {
	TraceOut "    Getting Policy Platform Logs"
	If ($LanternLogPath -ne $null)
	{
		If (Test-Path ($LanternLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Lantern_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\PolicyPlatform_Logs")
			Copy-Item $LanternLogPath ($Destination + "\PolicyPlatform_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $LanternLogPath does not exist. Microsoft Policy Platform Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Microsoft Policy Platform is Installed but Log Path is set to null. Logs not collected."
	}
}

If ($Is_PXE) {
	TraceOut "    Getting WDS Logs"
	New-Item -ItemType "Directory" ($Destination + "\WDS_Logs")
	Copy-Item ("$Env:windir\tracing\wds*.log") ($Destination + "\WDS_Logs") -Recurse -Force -ErrorAction SilentlyContinue
	$Compress = $true
}

# Collect System Health Validator Point Logs
If ($Is_SMSSHV -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting System Health Validator Point Logs"
	If ($SMSSHVLogPath -ne $null)
	{
		If (Test-Path ($SMSSHVLogPath))
		{
			#Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_EnrollProxy_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\SMSSHV_Logs")
			$FilesToCopy = Get-ChildItem ($SMSSHVLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\SMSSHV_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $SMSSHVLogPath does not exist. System Health Validator Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      System Health Validator Point Role detected but System Health Validator Point Log Path is set to null. Logs not collected."
	}
}

# Compress and Collect Logs if something was copied
If ($Compress)
{
	TraceOut "    Compressing and collecting logs"
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Compress_CollectConfigMgrLogs
	compressCollectFiles -DestinationFileName $ZipName -filesToCollect ($Destination + "\*.*") -sectionDescription $sectionDescription -fileDescription $fileDescription -Recursive -ForegroundProcess -noFileExtensionsOnDescription
	Remove-Item -Path $Destination -Recurse
}

Traceout "Completed"
# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDWdpZ41UptdV9F
# 6LDeayJWtwXWzxXMgiDXyKLeeOxpgaCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg72K8GvaX
# hsLfSt4rctDZft34vlBB9Q6szN3dKoFn2AswOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAF5xZDYEjJqjj7/523bQNbmYxPrXLDnO9K70bXPWcI+655XfSG3NbSwf
# weQRxXgdHEdJpqEqactgJKRxQ7joL8WGACDc9lMaOA6FdS1Io38xX+UE4fR/u2yi
# gXXnwL+Gpg1L8oEFLEboAckNFQdOnOVwKkBTmeObGQPol1lX5jVUn1AIK2mxp4Xe
# 6HelXLsucO7c0r2pxYD8XYa31IVP5+N4LTVi3t1T2uEtqQGMjSjNzx3x6nj49x12
# UpHKB3UmPxPG1C8vT6jv4v3h0eTF17ZnwJKMu+RA6nwqKfvVaybyr/Mi3IGto02m
# HO7kAWRKU7Au0uyRfa3qhbQ/nwSx87ihghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQg9SlZ0PSZhhWKt6WULJgFTgUZ/ssK9d0V5Qk9ZMqmxVECBmGDCPNa
# SBgTMjAyMTExMTExNjUzNDMuMTU2WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpGQzQxLTRCRDQtRDIyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABQCMZ1l7elSQxAAAAAAFAMA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyNloXDTIyMDExMjE3MjgyNlowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RkM0MS00
# QkQ0LUQyMjAxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCufWszcerVL03TPxH5gqpm
# 7bnKSTk6VPxOy7C10FbIMJEWgBKT18HqyIKiUWFcGHJ6PhzfIjA3RTIlYE5MCMe1
# 44hiN8KnHnf2tuAEjn8FMe0L6pwFPt+0+SdO1Cfz2U05yk/vR+5hVkuhCwOcuMbH
# G1b95V7BHlDQjWZZB8nLnE596WTk5aPPdhXgcq2rIhHMll39HNxjzDqqbOhI2xgh
# 2+WJPZ55BlvJhN0lCxGjMgpMwsIlQF9WOjDZ8kwO3MMH1cQ51+E9bO9Q5p1iCqqH
# SWyUBHs1X3QUWZmBlYBGsbyPtmdWcLkw5c5L80jnxLjzJyy6DSk3Y0YsuTZhaPEL
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQUNUMcLiZ3RiCOjNKqdWz454QtDmcwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAYwxSraBC4IL3CvhiEhJ8/Khto1hXc6/h
# jBaxJ8jP+PXFo31O8sAHYHE+LYK1FuBsFR/jyfTvJF5kifC7avy/Aug0bZO1jN7L
# TUNHKOOw2iIcX1S5EsXIpkKGQoLej2vQ7LbHRhiNSkPFUKFnmrlwB/DzzjA/SJRx
# icooafx4nSfCmvvOv9OW74c6NcNP0LvnhpLgpQU2bwPuLC69ZbNI5WXtcxZ27zYG
# edOYHuzY5x/cjhp0bN2LFDlnHFrfM4C8rOtX7QdxVAhjdJAn0/OMNGXMK+IxOHED
# wVQhEvcWdiq9yFaQShnjDxLsWwZY2VctZDt8cxveXiCO54fI7inq1TCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpGQzQxLTRCRDQtRDIyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAQqXmHvITpjsyl+YykRtDOQlyUVOggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAOU3aiAwIhgPMjAyMTExMTExODA4MzJaGA8yMDIxMTExMjE4MDgzMlowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5TdqIAIBADAKAgEAAgIO7wIB/zAHAgEAAgIR
# dzAKAgUA5Ti7oAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBANEyD5Ljo9OQ
# SWXH6IHTDCTITSyNr8EZKXoanwHFhGnSBciAXIHmbeZcwwlqaoeK8yp5GTyXexIE
# xobyFbrdHl1wWVAfcRR9rnOnWx7R0oXpHgReDLdwHLySbSrsQ63ofwwGM/S5XEuK
# vlErjLYXNIKHIZt8CY6YPtFDCASWrRrAMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFAIxnWXt6VJDEAAAAAAUAwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgHzTZ4tK3TdmdTW1UxHW6izT65j4G58oyq/RFCX+b6MYwgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAvNrC16szSpFwk7/Ny8lPt2j/JynxFmxFJ
# Oqq2AgiXgzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABQCMZ1l7elSQxAAAAAAFAMCIEIBBMG02OYr9XqrlepsjPw+b55xQrKrger77b
# WRAMxNnzMA0GCSqGSIb3DQEBCwUABIIBABFNrDCXN9+qd9DlGQotvJt9KHwJOpVH
# Tqwd86pfLY6jZJa8b9yRWHLZQaeuWEo7O+cvw35xaIPHnnSBIUEOes+2hUO6Pw1Z
# Gcxg/2pYvq4VO6iP9GlVpJkMBjP3Eav8c/+5gl35AzZuDeAE/QLEkQIdc17aC+F5
# za3cezhYaE76Wkkh2Rd6U+IfrL2iDNzSYWD8syQoeQ22u6kNn4wDoICAJr+xf6gK
# D/cUXiAv8Ros262KMg/nRVEbdOPEXBa7VeF2TAmjgPTkVsweLiAszyHfj85AnQQN
# wQUyTxpJf/niy5q4BF3fW186ZCP0+NUGez6UaItw1lCq1Dsl6fE+9I0=
# SIG # End signature block
