﻿# ***********************************************************************************************************
# Version 1.0
# Date: 01-24-2014
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description: Collects data from SMS Provider
# ***********************************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

If (!$Is_SiteServer) {
	TraceOut "ConfigMgr Site Server not detected. This script gathers data only from a Site Server. Exiting."
	exit 0
}

If ($SiteType -eq 2) {
	TraceOut "Secondary Site Server detected. This script gathers data only from a Primary Site Server. Exiting."
	AddTo-CMServerSummary -Name "Boundaries" -Value "Not available on a Secondary Site" -NoToSummaryReport
	AddTo-CMServerSummary -Name "Cloud Services Info" -Value "Not available on a Secondary Site" -NoToSummaryReport
	AddTo-CMServerSummary -Name "Features Info" -Value "Not available on a Secondary Site" -NoToSummaryReport
	exit 0
}

function Get-BoundariesNotInAnyGroups ()
{
	param (
		$SMSProvServer,
		$SMSProvNamespace
	)

	process {
		$BoundaryNotInGroups = @()
		Get-WmiObject -Query "SELECT * FROM SMS_Boundary WHERE GroupCount = 0" -ComputerName $SMSProvServer -Namespace $SMSProvNamespace | `
			foreach {
				$BoundaryType = switch($_.BoundaryType) {
					0 {"IP Subnet"}
					1 {"AD Site"}
					2 {"IPv6 Prefix"}
					3 {"IP Range"}
					default {"Unknown"}
				}

				$Boundary = @{'BoundaryID'=$_.BoundaryID;
						'BoundaryType'=$BoundaryType;
						'DisplayName'=$_.DisplayName;
						'Value'=$_.Value;
						'SiteSystems'=$_.SiteSystems}

				$BoundaryObject = New-Object PSObject -Property $Boundary
				$BoundaryNotInGroups += $BoundaryObject
			}

		# $BoundaryNotInGroups | Select BoundaryID, BoundaryType, DisplayName, Value, SiteSystems | Sort BoundaryType | Format-Table -AutoSize
		return $BoundaryNotInGroups
	}
}

function Get-Boundaries ()
{
	param (
		$SMSProvServer,
		$SMSProvNamespace
	)

	process {
		# Boundary Groups
		$BoundaryResults  = "#######################`r`n"
		$BoundaryResults += "# All Boundary Groups #`r`n"
		$BoundaryResults += "#######################`r`n"
		$BoundaryGroups = Get-WmiObject -Query "SELECT * FROM SMS_BoundaryGroup LEFT JOIN SMS_BoundaryGroupSiteSystems ON SMS_BoundaryGroupSiteSystems.GroupId = SMS_BoundaryGroup.GroupId" -ComputerName $SMSProvServer -Namespace $SMSProvNamespace -ErrorAction SilentlyContinue -ErrorVariable WMIError
		If ($WMIError.Count -eq 0) {
			if ($BoundaryGroups -ne $null) {
				$BoundaryGroups = Get-BoundaryGroupsFromWmiResults -BoundaryGroupsFromWmi $BoundaryGroups
				$BoundaryResults += $BoundaryGroups | Sort GroupID | Format-Table -AutoSize | Out-String -Width 2048
			}
			else {
				$BoundaryResults += "    None.`r`n`r`n"
			}
		}
		else {
			$BoundaryResults += "    ERROR: $($WMIError[0].Exception.Message)`r`n`r`n"
			$WMIError.Clear()
		}

		# Boundaries with multiple Sites for Assignment
		$BoundaryResults += "###################################################`r`n"
		$BoundaryResults += "# Boundaries set for Assignment to multiple Sites #`r`n"
		$BoundaryResults += "###################################################`r`n"
		$BoundariesWithAssignments = Get-WmiObject -Query "SELECT * FROM SMS_Boundary WHERE GroupCount > 0" -ComputerName $SMSProvServer -Namespace $SMSProvNamespace -ErrorAction SilentlyContinue -ErrorVariable WMIError
		If ($WMIError.Count -eq 0) {
			if ($BoundariesWithAssignments -ne $null) {
				$BoundaryMultipleAssignments = $BoundariesWithAssignments | ForEach {$asc = $_.DefaultSiteCode | Where-Object {$_}; if ($asc.Count -gt 1) {$_}}
				if ($BoundaryMultipleAssignments -ne $null) {
					$BoundaryMultipleAssignments = Get-BoundariesFromWmiResults -BoundariesFromWmi $BoundaryMultipleAssignments
					$BoundaryResults += $BoundaryMultipleAssignments
				}
				else {
					$BoundaryResults += "`r`n    None.`r`n`r`n"
				}
			}
			else {
				$BoundaryResults += "`r`n    None.`r`n`r`n"
			}
		}
		else {
			$BoundaryResults += "    ERROR: $($WMIError[0].Exception.Message)`r`n`r`n"
			$WMIError.Clear()
		}

		# Boundaries not in any groups
		$BoundaryResults += "#########################################`r`n"
		$BoundaryResults += "# Boundaries not in any Boundary Groups #`r`n"
		$BoundaryResults += "#########################################`r`n"
		$BoundaryNotInGroups = 	Get-WmiObject -Query "SELECT * FROM SMS_Boundary WHERE GroupCount = 0" -ComputerName $SMSProvServer -Namespace $SMSProvNamespace -ErrorAction SilentlyContinue -ErrorVariable WMIError
		If ($WMIError.Count -eq 0) {
			if ($BoundaryNotInGroups-ne $null) {
				$BoundaryNotInGroups = Get-BoundariesFromWmiResults -BoundariesFromWmi $BoundaryNotInGroups
				$BoundaryResults += $BoundaryNotInGroups
			}
			else {
				$BoundaryResults += "`r`n    None.`r`n`r`n"
			}
		}
		else {
			$BoundaryResults += "`r`n    ERROR: $($WMIError[0].Exception.Message)`r`n`r`n"
			$WMIError.Clear()
		}

		# Members for each Boundary Group
		$BoundaryResults += "#############################`r`n"
		$BoundaryResults += "# Boundary Group Membership #`r`n"
		$BoundaryResults += "#############################`r`n`r`n"
		$Members = Get-WmiObject -Query "SELECT * FROM SMS_Boundary JOIN SMS_BoundaryGroupMembers ON SMS_BoundaryGroupMembers.BoundaryID = SMS_Boundary.BoundaryID" -ComputerName $SMSProvServer -Namespace $SMSProvNamespace -ErrorAction SilentlyContinue -ErrorVariable WMIError
		If ($WMIError.Count -eq 0) {
			if ($Members -ne $null) {
				#foreach ($Member in $($Members.SMS_BoundaryGroupMembers | Select GroupID -Unique)) { # Works with PowerShell 3.0
				foreach ($Member in $($Members | Select -ExpandProperty SMS_BoundaryGroupMembers | Select GroupID -Unique)) {  # Works with PowerShell 2.0
					$BoundaryResults += "Boundary Members for Boundary Group ID: $($Member.GroupId)`r`n"
					$BoundaryResults += "===================================================`r`n"
					$MembersWmi = $Members | Where-Object {$_.SMS_BoundaryGroupMembers.GroupID -eq $Member.GroupId} | Select -ExpandProperty SMS_Boundary
					$MemberBoundary = Get-BoundariesFromWmiResults -BoundariesFromWmi $MembersWmi
					$BoundaryResults += $MemberBoundary
				}
			}
			else {
				$BoundaryResults += "    Boundary Groups have no members.`r`n`r`n"
			}
		}
		else {
			$BoundaryResults += "    ERROR: $($WMIError[0].Exception.Message)`r`n`r`n"
			$WMIError.Clear()
		}

		return $BoundaryResults
	}
}

function Get-BoundaryGroupsFromWmiResults ()
{
	param (
		$BoundaryGroupsFromWmi
	)

	$BoundaryGroups = @()

	foreach($Group in ($BoundaryGroupsFromWmi | Select -ExpandProperty SMS_BoundaryGroup | Select GroupId -Unique)) {
		$BoundaryGroupWmi = $BoundaryGroupsFromWmi | Select -ExpandProperty SMS_BoundaryGroup | Where-Object {$_.GroupId -eq $Group.GroupId} | Select -Unique
		$SiteSystems = ""
		$SiteSystems = $BoundaryGroupsFromWmi | Select -ExpandProperty SMS_BoundaryGroupSiteSystems | Where-Object {$_.GroupId -eq $Group.GroupId} | Select -ExpandProperty ServerNalPath `
			| ForEach {$SiteSystem = $_; $SiteSystem.Split("\\")[2]}
		$BoundaryGroup = @{
			'GroupID'=$BoundaryGroupWmi.GroupID;
			'Name'=$BoundaryGroupWmi.Name;
			'AssignmentSiteCode'=$BoundaryGroupWmi.DefaultSiteCode
			'Shared'=$BoundaryGroupWmi.Shared;
			'MemberCount'=$BoundaryGroupWmi.MemberCount;
			'SiteSystemCount'=$BoundaryGroupWmi.SiteSystemCount;
			'SiteSystems'=$SiteSystems -join "; ";
			'Description'=$BoundaryGroupWmi.Description
		}

		$BoundaryGroupObject = New-Object PSObject -Property $BoundaryGroup
		$BoundaryGroups += $BoundaryGroupObject
	}

	return ($BoundaryGroups | Select GroupID, Name, AssignmentSiteCode, Shared, MemberCount, SiteSystemCount, SiteSystems, Description)
}

function Get-BoundariesFromWmiResults ()
{
	param (
		$BoundariesFromWmi
	)

	$Boundaries = @()

	foreach ($BoundaryWmi in $BoundariesFromWmi)
	{
		$BoundaryType = switch($BoundaryWmi.BoundaryType) {
			0 {"IP Subnet"}
			1 {"AD Site"}
			2 {"IPv6 Prefix"}
			3 {"IP Range"}
			default {"Unknown"}
		}

		if (($BoundaryWmi.DefaultSiteCode | ? {$_}).Count -gt 1) {
			$AssignmentSiteCode = $BoundaryWmi.DefaultSiteCode -join "; "
		}
		else {
			$AssignmentSiteCode = $BoundaryWmi.DefaultSiteCode -join ""
		}

		$Boundary = @{
			'BoundaryID'=$BoundaryWmi.BoundaryID;
			'DisplayName'=$BoundaryWmi.DisplayName;
			'BoundaryType'=$BoundaryType;
			'Value'=$BoundaryWmi.Value;
			'AssignmentSiteCode'=$AssignmentSiteCode;
			'SiteSystems'=$BoundaryWmi.SiteSystems -join "; "
		}

		$BoundaryObject = New-Object PSObject -Property $Boundary
		$Boundaries += $BoundaryObject
	}

	return ($Boundaries | Select BoundaryID, DisplayName, BoundaryType, Value, AssignmentSiteCode, SiteSystems | Sort BoundaryID | Format-Table -AutoSize | Out-String -Width 2048)
}

function Get-WmiOutput {
	Param(
		[Parameter(Mandatory=$false)]
	    [string]$ClassName,
		[Parameter(Mandatory=$false)]
	    [string]$Query,
		[Parameter(Mandatory=$false)]
	    [string]$DisplayName,
		[Parameter(Mandatory=$false)]
		[switch]$FormatList,
		[Parameter(Mandatory=$false)]
		[switch]$FormatTable
	)

	if ($DisplayName) {
		$DisplayText = $DisplayName
	}
	else {
		$DisplayText = $ClassName
	}

	$results =  "`r`n=================================`r`n"
	$results += " $DisplayText `r`n"
	$results += "=================================`r`n`r`n"

	if ($ClassName) {
		$Temp = Get-WmiData -ClassName $ClassName
	}

	if ($Query) {
		$Temp = Get-WmiData -Query $Query
	}

	if ($Temp) {
		if ($FormatList) {
			$results += ($Temp | Format-List | Out-String).Trim()
		}

		if ($FormatTable) {
			$results += ($Temp | Format-Table | Out-String -Width 500).Trim()
		}

		$results += "`r`n"
	}
	else {
		$results += "    No Instances.`r`n"
	}

	return $results
}

function Get-WmiData{
	Param(
	   [Parameter(Mandatory=$false)]
	   [string]$ClassName,
		[Parameter(Mandatory=$false)]
	   [string]$Query
	)

	if ($ClassName) {
		$Temp = Get-WmiObject -Computername $SMSProviderServer -Namespace $SMSProviderNamespace -Class $ClassName -ErrorVariable WMIError -ErrorAction SilentlyContinue
	}

	if ($Query) {
		$Temp = Get-WmiObject -Computername $SMSProviderServer -Namespace $SMSProviderNamespace -Query $Query -ErrorVariable WMIError -ErrorAction SilentlyContinue
	}

	if ($WMIError.Count -ne 0) {
		if ($WMIError[0].Exception.Message -eq "") {
			$results = $WMIError[0].Exception.ToString()
		}
		else {
			$results = $WMIError[0].Exception.Message
		}
		$WMIError.Clear()
		return $results
	}

	if (($Temp | Measure-Object).Count -gt 0) {
		$results = $Temp | Select * -ExcludeProperty __GENUS, __CLASS, __SUPERCLASS, __DYNASTY, __RELPATH, __PROPERTY_COUNT, __DERIVATION, __SERVER, __NAMESPACE, __PATH, PSComputerName, Scope, Path, Options, ClassPath, Properties, SystemProperties, Qualifiers, Site, Container
	}
	else {
		$results = $null
	}

	return $results
}

TraceOut "Started"

Import-LocalizedData -BindingVariable ScriptStrings
$sectiondescription = "Configuration Manager Server Information"

TraceOut "    SMS Provider: $SMSProviderServer"
TraceOut "    SMS Provider Namespace: $SMSProviderNamespace"

# ===========
# Boundaries
# ===========
TraceOut "    Getting Boundaries from SMS Provider"
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ServerInfo -Status $ScriptStrings.ID_SCCM_CMServerInfo_Boundary
$TempFileName = ($ComputerName + "_CMServer_Boundaries.TXT")
$OutputFile = join-path $pwd.path $TempFileName
$Temp = Get-Boundaries -SMSProvServer $SMSProviderServer -SMSProvNamespace $SMSProviderNamespace
$Temp | Out-File $OutputFile -Append
AddTo-CMServerSummary -Name "Boundaries" -Value "Review $TempFileName" -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "Boundaries" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ============
# Cloud Roles
# ============
TraceOut "    Getting Cloud Services Data from SMS Provider"
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ServerInfo -Status $ScriptStrings.ID_SCCM_CMServerInfo_Cloud

$TempFileName = ($ComputerName + "_CMServer_CloudServices.TXT")
$OutputFile = join-path $pwd.path $TempFileName

Get-WmiOutput -ClassName SMS_Azure_CloudService -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_CloudSubscription -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_IntuneAccountInfo -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_CloudProxyConnector -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_CloudProxyRoleEndpoint -FormatTable | Out-File $OutputFile -Append -Width 500
Get-WmiOutput -ClassName SMS_CloudProxyEndpointDefinition -FormatTable | Out-File $OutputFile -Append -Width 500
Get-WmiOutput -ClassName SMS_CloudProxyExternalEndpoint -FormatTable | Out-File $OutputFile -Append -Width 500
Get-WmiOutput -ClassName SMS_AzureService -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_WSfBConfigurationData -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_OMSConfigurationData -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_OMSCollection -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_ReadinessDashboardConfigurationData -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_AfwAccountStatus -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_MDMAppleVppToken -FormatList | Out-File $OutputFile -Append

AddTo-CMServerSummary -Name "Cloud Services Info" -Value "Review $TempFileName" -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "Cloud Services" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ============
# Features
# ============
TraceOut "    Getting Features List from SMS Provider"
$TempFileName = ($ComputerName + "_CMServer_Features.TXT")
$OutputFile = join-path $pwd.path $TempFileName

Get-WmiOutput -Query "SELECT FeatureGUID, FeatureType, Exposed, Status, Name FROM SMS_CM_UpdateFeatures" `
	-DisplayName "SMS_CM_UpdateFeatures" -FormatTable | Out-File $OutputFile -Append
AddTo-CMServerSummary -Name "Features Info" -Value "Review $TempFileName" -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "Features Information" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

TraceOut "Completed"
# SIG # Begin signature block
# MIIa7QYJKoZIhvcNAQcCoIIa3jCCGtoCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUinpY/FPfrf7E41lpi2lEeBrG
# GGagghWDMIIEwzCCA6ugAwIBAgITMwAAAMZ4gDYBdRppcgAAAAAAxjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODUz
# WhcNMTgwOTA3MTc1ODUzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArQsjG6jKiCgU
# NuPDaF0GhCh1QYcSqJypNAJgoa1GtgoNrKXTDUZF6K+eHPNzXv9v/LaYLZX2GyOI
# 9lGz55tXVv1Ny6I1ueVhy2cUAhdE+IkVR6AtCo8Ar8uHwEpkyTi+4Ywr6sOGM7Yr
# wBqw+SeaBjBwON+8E8SAz0pgmHHj4cNvt5A6R+IQC6tyiFx+JEMO1qqnITSI2qx3
# kOXhD3yTF4YjjRnTx3HGpfawUCyfWsxasAHHlILEAfsVAmXsbr4XAC2HBZGKXo03
# jAmfvmbgbm3V4KBK296Unnp92RZmwAEqL08n+lrl+PEd6w4E9mtFHhR9wGSW29C5
# /0bOar9zHwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFNS/9jKwiDEP5hmU8T6/Mfpb
# Ag8JMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJhbANzvo0iL5FA5Z5QkwG+PvkDfOaYsTYksqFk+MgpqzPxc
# FwSYME/S/wyihd4lwgQ6CPdO5AGz3m5DZU7gPS5FcCl10k9pTxZ4s857Pu8ZrE2x
# rnUyUiQFl5DYSNroRPuQYRZZXs2xK1WVn1JcwcAwJwfu1kwnebPD90o1DRlNozHF
# 3NMaIo0nCTRAN86eSByKdYpDndgpVLSoN2wUnsh4bLcZqod4ozdkvgGS7N1Af18R
# EFSUBVraf7MoSxKeNIKLLyhgNxDxZxrUgnPb3zL73zOj40A1Ibw3WzJob8vYK+gB
# YWORl4jm6vCwAq/591z834HDNH60Ud0bH+xS7PowggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTUMIIE
# 0AIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHtMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBSL
# CCLgfjK3MyPd5IKbwEu2iAqYRzCBjAYKKwYBBAGCNwIBDDF+MHygYoBgAEQASQBB
# AEcAXwBDAFQAUwBfAFMAQwBDAE0AXwAyADAAMQAyAF8AZwBsAG8AYgBhAGwAXwBE
# AEMAXwBDAE0AMQAyAFMATQBTAFAAcgBvAHYASQBuAGYAbwAuAHAAcwAxoRaAFGh0
# dHA6Ly9taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAJXe27JPpZGCYD3I
# ozWs48aYOGryB7EDhvk4+vicEpvDxzikvI108HlukJT5k6g4tiPHgUzaThBqsK4L
# CWsgUAL8oBdB52MbkC5R0yNvsKjgyRKOncUnFCSGftdRsQedPX8TFKmfZEpwK3ud
# CRNohd/NPSl10rUlqSsHh1NMEYCG29v0LEeuAcWj0nLkeqUP/zvN3pBx1ZT/utyQ
# cFfLflKeGvJ+yExE0+Y7dNu0Fp/A0Nyd1RYg2QQjjWT+87VUGMI4roY7Jzgzx8RS
# YxosGMohs1xNI0WBvSu+GDYZeCtMnRtaE2eRMiHmlrmD1LfNFSFGTY+cfr/kvmo3
# /wFNKhOhggIoMIICJAYJKoZIhvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBAhMzAAAAxniANgF1GmlyAAAAAADGMAkGBSsOAwIaBQCg
# XTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0xNzA0
# MjcxNDIzMzBaMCMGCSqGSIb3DQEJBDEWBBRV7U6gZ6vzgwWa/w2EvhFWGsIUoTAN
# BgkqhkiG9w0BAQUFAASCAQByUOIkd+Gn+KYIGeP1nnaeF2kLdOWtwRl5pCsqohP4
# prLYA8OGJun9wTexW+gUuyqRlLL/5hzojqunx5wh85gIkhowGm1UrMOE0QpPr5TN
# MaWL53XywtH3ZZQkDCRn8ZLS8UZ3c4zNE1nIch+SNIAHvfwUl4mzSI/x7lamsF4O
# koJapu5Cl4/tsnfwwErqCm1GEvSDCUpHM6Jhs9fhT/9EOX/WxxQz4IN5uijzxV11
# EIVOB1SuLT+ycq6yO++2FX+ZiJEAmtBEVu1Q/Nisct1t/X8YI+flOVe86K8PrlBT
# gOI/XAnG8TIAPvBXOy9BeQTFfgOZNYzm7AaB0blOF/zx
# SIG # End signature block
