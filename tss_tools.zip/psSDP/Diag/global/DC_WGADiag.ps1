﻿###########################################################################
# DC_WGADiag
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Runs MGADiag.exe and outputs to WGADiag.txt
###########################################################################

Import-LocalizedData -BindingVariable WGA -FileName DC_WGADiag -UICulture en-us
Write-DiagProgress -Activity $WGA.ID_WGA -Status $WGA.ID_WGAStatus

$OutputFile = $ComputerName + "_MGADiag.txt"
#Add-Content $OutputFile "blah"
$CommandLineToExecute = "MGADiag.exe /f $OutputFile"

"Start running MGADiag.exe with command: " + $CommandLineToExecute | WriteTo-StdOut

RunCmD -commandToRun $CommandLineToExecute -useSystemDiagnosticsObject

CollectFiles -filesToCollect $OutputFile -fileDescription "MGDA Diag Output" -sectionDescription "Windows Update Information"

logstop

