﻿# ***********************************************************************************************************
# Version 1.0
# Date: 03-01-2012
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects Configuration Manager SQL Server Information.
# ***********************************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	$_ | Out-File -FilePath $OutputBase -Append
	continue
}

# ===============================================================
# Function Definitions
# Taken from DC_CollectSQL.ps1 from OpsMgr
# ===============================================================

function WriteConnectionEvents($currentEventID) {
     Get-Event | % {
        if ($_.SourceIdentifier -eq $currentEventID) {
             $CurrentEventIdentifier = $_.EventIdentifier;
            $info = $_.SourceEventArgs
            Remove-Event -EventIdentifier $CurrentEventIdentifier
             $info.Message
         }
     }
}

function Run-SQLCommandtoFile
{
    param (
		$SqlQuery,
		$outFile,
		$DisplayText,
		$collectFiles=$false,
		$fileDescription="",
		$ZipFile="",
		$OutputWidth = 1024,
		[switch]$HideSqlQuery,
		[switch]$NoSecondary
		)
	process
	{
		# Reset DisplayText to SqlQuery if it's not provided
		if ($DisplayText -eq $null) {
			$DisplayText = $SqlQuery
		}

		# Skip secondary site
		if ($NoSecondary -and ($SiteType -eq 2)) {
			AddTo-CMDatabaseSummary -NoToSummaryReport -NoToSummaryFile -Name $DisplayText -Value "Not available on a Secondary Site"
			return
		}

		# Standardize text added to summary file "Review $outFileName"
		if ($ZipFile -eq "") {
			$outFileName = $outFile
		}
		else {
			$outFileName = $ZipFile + $outFile.Substring($outFile.LastIndexOf("\"))
		}

		# Hide SQL Query from output if specified
		if ($HideSqlQuery) {
			"=" * ($DisplayText.Length + 4) + "`r`n-- " + $DisplayText + "`r`n" + "=" * ($DisplayText.Length + 4) + "`r`n" | Out-File -FilePath $outFile -Append
			TraceOut "  Current Query = $DisplayText"
		}
		else {
			"=" * ($SqlQuery.Length + 2) + "`r`n-- " + $DisplayText + "`r`n" + $SqlQuery + "`r`n" + "=" * ($SqlQuery.Length + 2) + "`r`n" | Out-File -FilePath $outFile -Append
			TraceOut "  Current Query = $SqlQuery"
		}

		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM12SQL -Status $DisplayText

		$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
		$SqlCmd.CommandText = $SqlQuery
		$SqlCmd.Connection = $global:DatabaseConnection

		$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
		$SqlAdapter.SelectCommand = $SqlCmd

		$SqlTable = New-Object System.Data.DataTable
		try {
			$SqlAdapter.Fill($SqlTable) | out-null

			$results = ($SqlTable | Select * -ExcludeProperty RowError, RowState, HasErrors, Table, ItemArray | Format-Table -AutoSize -Wrap -Property * `
				| Out-String -Width $OutputWidth).Trim()
			$results += "`r`n`r`n"
			$results | Out-File -FilePath $outFile -Append

			AddTo-CMDatabaseSummary -NoToSummaryReport -NoToSummaryFile -Name $DisplayText -Value "Review $outFileName"

			If ($collectFiles -eq $true) {
				CollectFiles -filesToCollect $outFile -fileDescription $fileDescription -sectionDescription $sectiondescription -noFileExtensionsOnDescription
			}
		}
		catch [Exception] {
			AddTo-CMDatabaseSummary -NoToSummaryReport -NoToSummaryFile -Name $DisplayText -Value "ERROR: $_"
		}
	}
}

function Run-SQLCommandtoFileWithInfo
{
    param (
		$SqlQuery,
		$outFile,
		$DisplayText,
		$collectFiles=$false,
		$ZipFile="",
		[switch]$HideSqlQuery,
		[switch]$SkipEvents
		)
	process
	{
		# Reset DisplayText to SqlQuery if it's not provided
		if ($DisplayText -eq $null) {
			$DisplayText = $SqlQuery
		}

		# Standardize text added to summary file "Review $outFileName"
		if ($ZipFile -eq "") {
			$outFileName = $outFile
		}
		else {
			$outFileName = $ZipFile + $outFile.Substring($outFile.LastIndexOf("\"))
		}

		# Hide SQL Query from output if specified
		if ($HideSqlQuery) {
			"=" * ($DisplayText.Length + 4) + "`r`n-- " + $DisplayText + "`r`n" + "=" * ($DisplayText.Length + 4) + "`r`n" | Out-File -FilePath $outFile -Append
			TraceOut "  Current Query = $DisplayText"
		}
		else {
			"=" * ($SqlQuery.Length + 2) + "`r`n-- " + $DisplayText + "`r`n" + $SqlQuery + "`r`n" + "=" * ($SqlQuery.Length + 2) + "`r`n" | Out-File -FilePath $outFile -Append
			TraceOut "  Current Query = $SqlQuery"
		}

		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM12SQL -Status $DisplayText

		If (-not $SkipEvents) {
			$eventID = $outFile
			Register-ObjectEvent -inputObject $global:DatabaseConnection -eventName InfoMessage -sourceIdentifier $eventID
		}

		$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
		$SqlCmd.Connection = $global:DatabaseConnection
		$SqlCmd.CommandText = $SqlQuery
		$SqlCmd.CommandTimeout = 0

		$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
		$SqlAdapter.SelectCommand = $SqlCmd

		$DataSet = New-Object System.Data.DataSet

		try {
			$SqlAdapter.Fill($DataSet)

			If ($DataSet.Tables.Count -gt 0) {
				foreach ($table in $DataSet.Tables)
				{
					$table | Format-Table -AutoSize | Out-String -width 2048 | Out-File -FilePath $outFile -Append
				}
			}

			If (-not $SkipEvents) {
				If (($RemoteStatus -eq 0) -or ($RemoteStatus -eq 1)) {
					WriteConnectionEvents $eventID | Out-String -width 2048 | Out-File -FilePath $outFile -Append
				}
				Else {
					"Message Information Events cannot be obtained Remotely. Run Diagnostics locally on a Primary or Central Site to obtain this data." | Out-File -FilePath $outFile -Append
				}
			}

			If ($collectFiles -eq $true) {
				CollectFiles -filesToCollect $outFile -fileDescription "$DisplayText" -sectionDescription $sectionDescription -noFileExtensionsOnDescription
			}

			AddTo-CMDatabaseSummary -NoToSummaryReport -NoToSummaryFile -Name $DisplayText -Value "Review $outFileName"
		}
		catch [Exception] {
			AddTo-CMDatabaseSummary -NoToSummaryReport -NoToSummaryFile -Name $DisplayText -Value "ERROR: $_"
		}
	}
}

function Get-SQLValue
{
	Param(
		[string]$SqlQuery,
	    [string]$ColumnName,
		[string]$DisplayText
	)

	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM12SQL -Status $DisplayText

	$Result = New-Object -TypeName PSObject

	$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
	$SqlCmd.CommandText = $SqlQuery
	$SqlCmd.Connection = $global:DatabaseConnection

	$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
	$SqlAdapter.SelectCommand = $SqlCmd

	TraceOut "Current Query = $SqlQuery"
	$SqlTable = New-Object System.Data.DataTable
	try {
		$SqlAdapter.Fill($SqlTable) | out-null
		$ActualValue = $SqlTable | Select -ExpandProperty $ColumnName -ErrorAction SilentlyContinue
		$Result | Add-Member -MemberType NoteProperty -Name "Value" -Value $ActualValue
		$Result | Add-Member -MemberType NoteProperty -Name "Error" -Value $null
	}
	catch [Exception] {
		$Result | Add-Member -MemberType NoteProperty -Name "Value" -Value $null
		$Result | Add-Member -MemberType NoteProperty -Name "Error" -Value $_
	}

	# Return column value
	return $Result
}

function Get-SQLValueWithError
{
	Param(
		[string]$SqlQuery,
	    [string]$ColumnName,
		[string]$DisplayText
	)

	$ResultValue = Get-SQLValue -SqlQuery $SqlQuery -ColumnName $ColumnName -DisplayText $DisplayText
	if ($ResultValue.Error -eq $null) {
		return $ResultValue.Value
	}
	else {
		return $ResultValue.Error
	}
}

function Format-XML ([xml]$xml, $indent=2)
{
    $StringWriter = New-Object System.IO.StringWriter
    $XmlWriter = New-Object System.XMl.XmlTextWriter $StringWriter
    $xmlWriter.Formatting = "indented"
    $xmlWriter.Indentation = $Indent
    $xml.WriteContentTo($XmlWriter)
    $XmlWriter.Flush()
    $StringWriter.Flush()
    return $StringWriter.ToString()
}

#function RunSQLCommandtoCSV
#{
#    param (
#		$cmd,
#		$outfile
#		)
#	process
#	{
#		$out = $ComputerName + "_SQL_" + $outfile + ".csv"

#		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM12SQL -Status $cmd
#		$da = new-object System.Data.SqlClient.SqlDataAdapter ($cmd, $connnectionstring)
#		$dt = new-object System.Data.DataTable
#		$da.fill($dt) | out-null

#		$dt | Export-CSV -Path $out
#		CollectFiles -filesToCollect $out -fileDescription "$cmd" -sectionDescription $sectiondescription

#	}
#}

# ===========================
# Script Execution
# ===========================

If (!$Is_SiteServer) {
	TraceOut "ConfigMgr Site Server not detected. This script gathers data only from a Site Server. Exiting."
	exit 0
}

TraceOut "Started"
Import-LocalizedData -BindingVariable ScriptStrings
$sectiondescription = "Configuration Manager SQL Data"

TraceOut "ConfigMgr SQL Server: $ConfigMgrDBServer"
TraceOut "ConfigMgr SQL Database: $ConfigMgrDBName"

if ($global:DatabaseConnectionError -ne $null) {
	TraceOut "SQL Connection Failed With Error: $global:DatabaseConnectionError"
	return
}

$Temp = Get-SQLValueWithError -SqlQuery "SELECT name, value_in_use FROM sys.configurations WHERE name = 'max server memory (MB)'" -ColumnName "value_in_use" -DisplayText "Max Server Memory (MB)"
AddTo-CMDatabaseSummary -Name "Max Memory (MB)" -Value $Temp -NoToSummaryQueries

$Temp = Get-SQLValueWithError -SqlQuery "SELECT name, value_in_use FROM sys.configurations WHERE name = 'max degree of parallelism'" -ColumnName "value_in_use" -DisplayText "MDOP"
AddTo-CMDatabaseSummary -Name "MDOP" -Value $Temp -NoToSummaryQueries

# ------------------
# Basic SQL Queries
# ------------------
$OutFile= $ComputerName +  "_SQL_Basic.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT @@SERVERNAME AS [Server Name], @@VERSION AS [SQL Version]" -outFile $OutFile -DisplayText "SQL Version"
Run-SQLCommandtoFile -SqlQuery "SELECT servicename, process_id, startup_type_desc, status_desc,
last_startup_time, service_account, is_clustered, cluster_nodename, [filename]
FROM sys.dm_server_services WITH (NOLOCK) OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "SQL Services" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT cpu_count AS [Logical CPU Count], scheduler_count, hyperthread_ratio AS [Hyperthread Ratio],
cpu_count/hyperthread_ratio AS [Physical CPU Count],
physical_memory_kb/1024 AS [Physical Memory (MB)], committed_kb/1024 AS [Committed Memory (MB)],
committed_target_kb/1024 AS [Committed Target Memory (MB)],
max_workers_count AS [Max Workers Count], affinity_type_desc AS [Affinity Type],
sqlserver_start_time AS [SQL Server Start Time], virtual_machine_type_desc AS [Virtual Machine Type]
FROM sys.dm_os_sys_info WITH (NOLOCK) OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "SQL Server Hardware Info" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "EXEC sp_helpdb" -outFile $OutFile -DisplayText "Databases"
Run-SQLCommandtoFile -SqlQuery "EXEC sp_helprolemember" -outFile $OutFile -DisplayText "Role Members"
Run-SQLCommandtoFile -SqlQuery "SELECT uid, status, name, createdate, islogin, hasdbaccess, updatedate FROM sys.sysusers" -outFile $OutFile -DisplayText "Sys Users"
Run-SQLCommandtoFile -SqlQuery "SELECT status, name, loginname, createdate, updatedate, accdate, dbname, denylogin, hasaccess, sysadmin, securityadmin, serveradmin, setupadmin, processadmin, diskadmin, dbcreator, bulkadmin, isntname, isntgroup, isntuser FROM [master].sys.syslogins" `
	-outFile $OutFile -DisplayText "Sys Logins ([master].sys.syslogins)" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT certificate_id, principal_id, name, subject, pvt_key_encryption_type_desc, expiry_date, start_date, is_active_for_begin_dialog, issuer_name, string_sid, thumbprint, attested_by  FROM [master].sys.certificates" `
	-outFile $OutFile -DisplayText "Certificates ([master].sys.certificates)" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.dm_os_loaded_modules WHERE company <> 'Microsoft Corporation' OR company IS NULL"	`
	-outFile $OutFile -DisplayText "Loaded Modules"

CollectFiles -filesToCollect $OutFile -fileDescription "Basic SQL Information" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ------------------------------------
# Top SP's by CPU, Elapsed Time, etc.
# ------------------------------------
#$OutFile= $ComputerName +  "_SQL_TopQueries.txt"
#Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) DB_NAME(t.[dbid]) AS [Database Name], qs.creation_time AS [Creation Time],
#qs.total_worker_time AS [Total Worker Time], qs.min_worker_time AS [Min Worker Time],
#qs.total_worker_time/qs.execution_count AS [Avg Worker Time],
#qs.max_worker_time AS [Max Worker Time],
#qs.total_elapsed_time/qs.execution_count AS [Avg Elapsed Time],
# qs.execution_count AS [Execution Count],
#qs.total_logical_reads/qs.execution_count AS [Avg Logical Reads],
#qs.total_physical_reads/qs.execution_count AS [Avg Physical Reads],
#rtrim(t.[text]) AS [Query Text]
#FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
#CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS t
#ORDER BY qs.total_worker_time DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 Queries by CPU" -HideSqlQuery
#Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) DB_NAME(t.[dbid]) AS [Database Name], qs.creation_time AS [Creation Time],
#qs.total_elapsed_time  AS [Total Elapsed Time],
#qs.total_elapsed_time/qs.execution_count AS [Avg Elapsed Time],
#qs.total_worker_time AS [Total Worker Time],
#qs.total_worker_time/qs.execution_count AS [Avg Worker Time],
#qs.execution_count AS [Execution Count],
#qs.total_logical_reads/qs.execution_count AS [Avg Logical Reads],
#qs.total_physical_reads/qs.execution_count AS [Avg Physical Reads],
#rtrim(t.[text]) AS [Query Text]
#FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
#CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS t
#ORDER BY qs.total_elapsed_time/qs.execution_count DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 Queries by Average Elapsed Time" -HideSqlQuery

$OutFile= $ComputerName +  "_SQL_TopQueries.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) p.name AS [SP Name], qs.total_worker_time AS [TotalWorkerTime],
qs.total_worker_time/qs.execution_count AS [AvgWorkerTime],
qs.execution_count,
ISNULL(qs.execution_count/DATEDIFF(Minute, qs.cached_time, GETDATE()), 0) AS [Calls/Minute],
qs.total_elapsed_time,
qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID() AND qs.execution_count > 0
ORDER BY qs.total_worker_time DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 SPs by CPU" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) p.name AS [SP Name], qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.total_elapsed_time, qs.execution_count, ISNULL(qs.execution_count/DATEDIFF(Minute, qs.cached_time,
GETDATE()), 0) AS [Calls/Minute], qs.total_worker_time/qs.execution_count AS [AvgWorkerTime],
qs.total_worker_time AS [TotalWorkerTime], qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID() AND qs.execution_count > 0
ORDER BY avg_elapsed_time DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 SPs by Average Elapsed Time" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) p.name AS [SP Name], qs.execution_count,
ISNULL(qs.execution_count/DATEDIFF(Minute, qs.cached_time, GETDATE()), 0) AS [Calls/Minute],
qs.total_worker_time/qs.execution_count AS [AvgWorkerTime], qs.total_worker_time AS [TotalWorkerTime],
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID() AND qs.execution_count > 0
ORDER BY qs.execution_count DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 SPs by Execution Count" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) p.name AS [SP Name], ISNULL(qs.execution_count/DATEDIFF(Minute, qs.cached_time, GETDATE()), 0) AS [Calls/Minute],
qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.total_elapsed_time, qs.total_worker_time/qs.execution_count AS [AvgWorkerTime],
qs.total_worker_time AS [TotalWorkerTime], qs.execution_count, qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID() AND ISNULL(qs.execution_count/DATEDIFF(Minute, qs.cached_time, GETDATE()), 0) > 0  AND qs.execution_count > 0
ORDER BY [Calls/Minute] DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 SPs by Calls Per Minute" -HideSqlQuery

CollectFiles -filesToCollect $OutFile -fileDescription "Top Queries" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ------------------
# SQL Transactions
# ------------------
$OutFile= $ComputerName +  "_SQL_Transactions.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT sp.spid, rtrim(sp.status) [status], rtrim(sp.loginame) [Login], rtrim(sp.hostname) [hostname],
sp.blocked BlkBy, sd.name DBName, rtrim(sp.cmd) Command, sp.open_tran, sp.cpu CPUTime, sp.physical_io DiskIO, sp.last_batch LastBatch, rtrim(sp.program_name) [ProgramName], rtrim(qt.text) [Text]
FROM master.dbo.sysprocesses sp
JOIN master.dbo.sysdatabases sd ON sp.dbid = sd.dbid
OUTER APPLY sys.dm_exec_sql_text(sp.sql_handle) AS qt
WHERE sp.blocked <> 0
ORDER BY sp.spid" -outFile $OutFile -DisplayText "Blocked SPIDs" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT sp.spid, rtrim(sp.status) [status], rtrim(sp.loginame) [Login], rtrim(sp.hostname) [hostname],
sp.blocked BlkBy, sd.name DBName, rtrim(sp.cmd) Command, sp.open_tran, sp.cpu CPUTime, sp.physical_io DiskIO, sp.last_batch LastBatch, rtrim(sp.program_name) [ProgramName], rtrim(qt.text) [Text]
FROM master.dbo.sysprocesses sp
JOIN master.dbo.sysdatabases sd ON sp.dbid = sd.dbid
OUTER APPLY sys.dm_exec_sql_text(sp.sql_handle) AS qt
WHERE sp.spid IN (SELECT blocked FROM master.dbo.sysprocesses) AND sp.blocked = 0
ORDER BY sp.spid" -outFile $OutFile -DisplayText "Head Blockers" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT T.*, S.blocked, rtrim(E.text) [Text]
	FROM sys.dm_tran_active_snapshot_database_transactions T
	JOIN sys.dm_exec_requests R ON T.Session_ID = R.Session_ID
	INNER JOIN sys.sysprocesses S on S.spid = T.Session_ID
	OUTER APPLY sys.dm_exec_sql_text(R.sql_handle) AS E
	ORDER BY elapsed_time_seconds DESC" -outFile $OutFile -DisplayText "Active Snapshot Database Transactions" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "EXEC sp_who2" -outFile $OutFile -DisplayText "sp_who2"
CollectFiles -filesToCollect $OutFile -fileDescription "SQL Transactions" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------------------
# List of Site Systems
# ----------------------
$OutFile = $ComputerName + "_SQL_SiteSystems.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT SMSSiteCode, COUNT(1) AS [Number Of DPs] FROM DistributionPoints GROUP BY SMSSiteCode UNION SELECT 'Total' AS SMSSiteCode, COUNT(1) AS [Number Of DPs] FROM DistributionPoints" `
	-outFile $OutFile -DisplayText "Count of All Available Distribution Points by Site"
Run-SQLCommandtoFile -SqlQuery "SELECT SiteCode, ServerName, COUNT(ServerName) AS [Number Of Site System Roles] FROM SysResList GROUP BY SiteCode, ServerName" `
	-outFile $OutFile -DisplayText "Count of All Available Site Systems by Server Name"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM DistributionPoints ORDER BY SMSSiteCode, ServerName" `
	-outFile $OutFile -DisplayText "List of Distribution Points"
Run-SQLCommandtoFile -SqlQuery "SELECT SiteCode, RoleName, ServerName, ServerRemoteName, PublicDNSName, InternetEnabled, Shared, SslState, DomainFQDN, ForestFQDN, IISPreferredPort, IISSslPreferredPort, IsAvailable FROM SysResList ORDER BY SiteCode, ServerName, RoleName" `
	-outFile $OutFile -DisplayText "List of Site Systems"

CollectFiles -filesToCollect $OutFile -fileDescription "List of Site Systems" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ------------------------
# CM Database Information
# ------------------------
$OutFile = $ComputerName + "_SQL_CMDBInfo.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT SiteNumber, SiteCode, TaskName, TaskType, IsEnabled, NumRefreshDays, DaysOfWeek, BeginTime, LatestBeginTime, BackupLocation, DeleteOlderThan FROM vSMS_SC_SQL_Task ORDER BY SiteCode" `
	-outFile $OutFile -DisplayText "ConfigMgr Maintenance Tasks Configuration"
Run-SQLCommandtoFile -SqlQuery "SELECT *, DATEDIFF(S, LastStartTime, LastCompletionTime) As TimeTakenInSeconds, DATEDIFF(MI, LastStartTime, LastCompletionTime) As TimeTakenInMinutes FROM SQLTaskStatus ORDER BY TimeTakenInMinutes DESC" `
	-outFile $OutFile -DisplayText "ConfigMgr Maintenance Tasks Status ($global:SMSSiteCode)"
Run-SQLCommandtoFile -SqlQuery "SELECT *, DATEDIFF(S, LastStartTime, LastSuccessfulCompletionTime) As TimeTakenInSeconds, DATEDIFF(MI, LastStartTime, LastSuccessfulCompletionTime) As TimeTakenInMinutes FROM vSR_SummaryTasks ORDER BY TimeTakenInMinutes DESC" `
	-outFile $OutFile -DisplayText "State System Summary Tasks ($global:SMSSiteCode)" -NoSecondary

Run-SQLCommandtoFile -SqlQuery "SELECT BoundaryType, CASE WHEN BoundaryType = 0 THEN 'IPSUBNET' WHEN BoundaryType = 1 THEN 'ADSITE' WHEN BoundaryType = 2 THEN 'IPV6PREFIX' WHEN BoundaryType = 3 THEN 'IPRANGE' END AS [Type], COUNT(BoundaryType) AS [Count] FROM BoundaryEx GROUP BY BoundaryType" `
	-outFile $OutFile -DisplayText "Boundary Counts"

CollectFiles -filesToCollect $OutFile -fileDescription "ConfigMgr DB Info" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ------------------------
# Site Control File
# ------------------------
$OutFile = $ComputerName + "_SQL_SiteControlFile.xml.txt"
$ResultValue = Get-SQLValue -SqlQuery "SELECT * FROM vSMS_SC_SiteControlXML WHERE SiteCode = '$SMSSiteCode'" -ColumnName "SiteControl" -DisplayText "Site Control File (XML)"

if ($ResultValue.Error -eq $null) {
	try {
		$ScfXml = Format-XML -xml $ResultValue.Value
		$ScfXml | Out-String -Width 4096 | Out-File -FilePath $OutFile -Force
	}
	catch [Exception] {
		$_ | Out-File -FilePath $OutFile -Force
	}
}
else {
	$ResultValue.Error | Out-File -FilePath $OutFile -Force
}

CollectFiles -filesToCollect $OutFile -fileDescription "Site Control File" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ---------------------
# SUP Sync information
# ---------------------
$OutFile = $ComputerName + "_SQL_SUPSync.txt"

Run-SQLCommandtoFile -SqlQuery "SELECT CI.CategoryInstance_UniqueID, CI.CategoryTypeName, LCI.CategoryInstanceName FROM CI_CategoryInstances CI
JOIN CI_LocalizedCategoryInstances LCI ON CI.CategoryInstanceID = LCI.CategoryInstanceID
JOIN CI_UpdateCategorySubscription UCS ON CI.CategoryInstanceID = UCS.CategoryInstanceID
WHERE UCS.IsSubscribed = 1
ORDER BY CI.CategoryTypeName, LCI.CategoryInstanceName" -outFile $OutFile -DisplayText "SUM Products/Classifications" -NoSecondary -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM  vSMS_SUPSyncStatus"-outFile $OutFile -DisplayText "SUP Sync Status" -NoSecondary
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM WSUSServerLocations" -outFile $OutFile -DisplayText "WSUSServerLocations"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM Update_SyncStatus" -outFile $OutFile -DisplayText "Update_SyncStatus"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CI_UpdateSources" -outFile $OutFile -DisplayText "CI_UpdateSources"

CollectFiles -filesToCollect $OutFile -fileDescription "SUP Sync Status" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ---------------------
# OSD Information
# ---------------------
$OutFile = $ComputerName + "_SQL_BootImages.txt"

Run-SQLCommandtoFile -SqlQuery "SELECT * FROM vSMS_OSDeploymentKitInstalled"-outFile $OutFile -DisplayText "ADK Version from Database" -NoSecondary -HideSqlQuery
"========================================" | Out-File $OutFile -Append
"-- ADK Version from Add/Remove Programs " | Out-File $OutFile -Append
"========================================" | Out-File $OutFile -Append
"" | Out-File $OutFile -Append
($global:ADKVersion).Trim() | Out-File $OutFile -Append
"`r`n" | Out-File $OutFile -Append
Run-SQLCommandtoFile -SqlQuery "SELECT PkgID, Name, ImageOSVersion, Version, Architecture, DefaultImage, SourceSite, SourceVersion, LastRefresh, SourceDate, SourceSize, Action, Source, ImagePath FROM vSMS_BootImagePackage_List"-outFile $OutFile -DisplayText "Boot Images" -NoSecondary
Run-SQLCommandtoFile -SqlQuery "SELECT ImageId, Architecture, Name, MsiComponentID, Size, IsRequired, IsManageable FROM vSMS_WinPEOptionalComponentInBootImage ORDER BY ImageId, Architecture"-outFile $OutFile -DisplayText "Optional Components" -NoSecondary
CollectFiles -filesToCollect $OutFile -fileDescription "Boot Images" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------
# DRS Data
# ----------
$ZipName = $ComputerName + "_SQL_DRSData.zip"
$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_SQL_DRSData")
If (Test-Path $Destination) {
	Remove-Item -Path $Destination -Recurse -Force
}
New-Item -ItemType "Directory" $Destination

$OutFile = Join-Path $Destination "spDiagDRS.txt"
Run-SQLCommandtoFileWithInfo -SqlQuery "EXEC spDiagDRS" -outFile $OutFile -DisplayText "spDiagDRS" -ZipFile $ZipName

# Removed spDiagGetSpaceUsed as it takes a long time, and is not absolutely necessary
# $OutFile = Join-Path $Destination "spDiagGetSpaceUsed.txt"
# Run-SQLCommandtoFileWithInfo -SqlQuery "EXEC spDiagGetSpaceUsed" -outFile $OutFile -DisplayText "spDiagGetSpaceUsed" -ZipFile $ZipName

$OutFile = Join-Path $Destination "Sites.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT SiteKey, SiteCode, SiteName, ReportToSite, Status, DetailedStatus, SiteType, BuildNumber, Version, SiteServer, InstallDir, ReplicatesReservedRanges FROM Sites" -outFile $OutFile -DisplayText "Sites Output" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM ServerData" -outFile $OutFile -DisplayText "ServerData Output" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT SiteKey, SiteCode, ReportToSite, SiteServer, Settings FROM Sites" -OutputWidth 2048 -outFile $OutFile -DisplayText "Client Operational Settings" -ZipFile $ZipName

$OutFile = Join-Path $Destination "RCM_Tables.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM RCM_ReplicationLinkStatus" -outFile $OutFile -DisplayText "RCM_ReplicationLinkStatus Table Output" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM RCM_DrsInitializationTracking" -outFile $OutFile -DisplayText "RCM_DrsInitializationTracking Table Output" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM RCM_RecoveryTracking" -outFile $OutFile -DisplayText "RCM_RecoveryTracking" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM RCM_RecoveryPostAction" -outFile $OutFile -DisplayText "RCM_RecoveryPostAction" -ZipFile $ZipName

$OutFile = Join-Path $Destination "vReplicationLinkStatus.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM vReplicationLinkStatus" -outFile $OutFile -DisplayText "vReplicationLinkStatus Output" -ZipFile $ZipName

$OutFile = Join-Path $Destination "DRS_Tables.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT COUNT (ConflictType) [Count], TableName, ConflictType, ConflictLoserSiteCode FROM DrsConflictInfo GROUP BY TableName, ConflictType, ConflictLoserSiteCode ORDER BY [Count] DESC" -outFile $OutFile -DisplayText "DRS Conflicts Summary (All time)" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT COUNT (ConflictType) [Count], TableName, ConflictType, ConflictLoserSiteCode FROM DrsConflictInfo WHERE ConflictTime > DATEAdd(dd,-5,GETDate()) GROUP BY TableName, ConflictType, ConflictLoserSiteCode ORDER BY [Count] DESC" -outFile $OutFile -DisplayText "DRS Conflicts Summary (Past 5 days)" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM DrsConflictInfo WHERE ConflictTime > DATEAdd(dd,-5,GETDate()) ORDER BY ConflictTime DESC" -outFile $OutFile -DisplayText "DRS Conflicts (Past 5 days)" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM DRSReceiveHistory WHERE ProcessedTime IS NULL" -outFile $OutFile -DisplayText "DRSReceiveHistory Table Output" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM DRSSendHistory WHERE ProcessedTime IS NULL" -outFile $OutFile -DisplayText "DRSSendHistory Table Output" -ZipFile $ZipName

$OutFile = Join-Path $Destination "vLogs.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT TOP 1000 * FROM vLogs WHERE LogText NOT LIKE 'INFO:%' AND LogText NOT LIKE 'Not sending changes to sites%' AND LogText <> 'Web Service heartbeat' AND LogText NOT LIKE 'SYNC%'ORDER BY LogLine DESC" -outFile $OutFile -DisplayText "vLogs Output" -ZipFile $ZipName

$OutFile = Join-Path $Destination "TransmissionQueue.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT COUNT (to_service_name) [Count], to_service_name FROM sys.transmission_queue GROUP BY to_service_name" -outFile $OutFile -DisplayText "Transmission Queue Summary" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.transmission_queue WHERE conversation_handle NOT IN (SELECT handle FROM SSB_DialogPool)" -outFile $OutFile -DisplayText "Orphaned Messages" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.transmission_queue" -outFile $OutFile -DisplayText "Transmission Queue" -ZipFile $ZipName

$OutFile = Join-Path $Destination "EndPointsAndQueues.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.tcp_endpoints" -outFile $OutFile -DisplayText "TCP Endpoints" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.service_broker_endpoints" -outFile $OutFile -DisplayText "Service Broker Endpoints" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.service_queues" -outFile $OutFile -DisplayText "Service Queues" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.conversation_endpoints" -outFile $OutFile -DisplayText "Conversation Endpoints" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM SSB_DialogPool" -outFile $OutFile -DisplayText "SSB Dialog Pool" -ZipFile $ZipName

$OutFile = Join-Path $Destination "DRS_Config.txt"
# Run-SQLCommandtoFile -SqlQuery "SELECT * FROM ServerData" -outFile $OutFile -DisplayText "Server Data Table" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT SD.SiteCode,
MAX(CASE WHEN vRSCP.Name = 'Degraded' THEN vRSCP.Value END) AS Degraded,
MAX(CASE WHEN vRSCP.Name = 'Failed' THEN vRSCP.Value END) AS Failed,
MAX(CASE WHEN vRSCP.Name = 'DviewForHINV' THEN vRSCP.Value END) AS DviewForHINV,
MAX(CASE WHEN vRSCP.Name = 'DviewForSINV' THEN vRSCP.Value END) AS DviewForSINV,
MAX(CASE WHEN vRSCP.Name = 'DviewForStatusMessages' THEN vRSCP.Value END) AS DviewForStatusMessages,
MAX(CASE WHEN vRSCP.Name = 'SQL Server Service Broker Port' THEN vRSCP.Value END) AS BrokerPort,
MAX(CASE WHEN vRSCP.Name = 'Send History Summarize Interval' THEN vRSCP.Value END) AS SendHistorySummarizeInterval,
MAX(CASE WHEN vRSCP.Name = 'SQL Server Service Broker Port' THEN vRSCP.Value END) AS SSBPort,
MAX(CASE WHEN vRSCP.Name = 'Retention Period' THEN vRSCP.Value END) AS RetentionPeriod,
MAX(CASE WHEN vRSCP.Name = 'IsCompression' THEN vRSCP.Value END) AS IsCompression
FROM vRcmSqlControlProperties vRSCP
JOIN RCMSQlControl RSC ON vRSCP.ID = RSC.ID
JOIN ServerData SD ON RSC.SiteNumber = SD.ID
GROUP BY SD.SiteCode" -outFile $OutFile -DisplayText "RCM Control Properties" -ZipFile $ZipName -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT D.name, CTD.* FROM sys.change_tracking_databases AS CTD JOIN sys.databases AS D ON D.database_id = CTD.database_id WHERE D.name = '$ConfigMgrDBNameNoInstance'" -outFile $OutFile -DisplayText "DRS Data Retention Settings" -ZipFile $ZipName

# Compress and Collect
compressCollectFiles -DestinationFileName $ZipName -filesToCollect ($Destination + "\*.*") -sectionDescription $sectionDescription -fileDescription "DRS Data" -Recursive -ForegroundProcess -noFileExtensionsOnDescription
Remove-Item -Path $Destination -Recurse -Force
# CollectFiles -filesToCollect $OutFile -fileDescription "DRS Troubleshooting Data" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------------------
# Update Servicing Data
# ----------------------
$ZipName = $ComputerName + "_SQL_UpdateServicing.zip"
$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_SQL_UpdateServicing")
If (Test-Path $Destination) {
	Remove-Item -Path $Destination -Recurse -Force
}
New-Item -ItemType "Directory" $Destination

if ($global:SiteBuildNumber -gt 8325) {
	# CM_UpdatePackages
	$OutFile = Join-Path $Destination "CM_UpdatePackages.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackages" -outFile $OutFile -DisplayText "CM_UpdatePackages" -ZipFile $ZipName
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackages_Hist ORDER BY RecordTime DESC" -outFile $OutFile -DisplayText "CM_UpdatePackages_Hist" -ZipFile $ZipName

	# CM_UpdatePackageSiteStatus
	$OutFile = Join-Path $Destination "CM_UpdatePackageSiteStatus.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackageSiteStatus" -outFile $OutFile -DisplayText "CM_UpdatePackageSiteStatus" -ZipFile $ZipName
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackageSiteStatus_HIST ORDER BY RecordTime DESC" -outFile $OutFile -DisplayText "CM_UpdatePackageSiteStatus_HIST" -ZipFile $ZipName

	# CM_UpdatePackageInstallationStatus
	$OutFile = Join-Path $Destination "CM_UpdatePackageInstallationStatus.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackageInstallationStatus ORDER BY MessageTime DESC" -outFile $OutFile -DisplayText "CM_UpdatePackageInstallationStatus" -ZipFile $ZipName

	# CM_UpdateReadiness
	$OutFile = Join-Path $Destination "CM_UpdateReadiness.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdateReadiness" -outFile $OutFile -DisplayText "CM_UpdateReadiness" -ZipFile $ZipName
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdateReadinessSite ORDER BY LastUpdateTime DESC" -outFile $OutFile -DisplayText "CM_UpdateReadinessSite" -ZipFile $ZipName

	# CM_UpdatePackagePrereqStatus
	$OutFile = Join-Path $Destination "CM_UpdatePackagePrereqStatus.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackagePrereqStatus" -outFile $OutFile -DisplayText "CM_UpdatePackagePrereqStatus" -ZipFile $ZipName

	# EasySetupSettings
	$OutFile = Join-Path $Destination "EasySetupSettings.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM EasySetupSettings" -outFile $OutFile -DisplayText "EasySetupSettings" -ZipFile $ZipName
	Run-SQLCommandtoFile -SqlQuery "SELECT PkgID, Name, SourceVersion, StoredPkgVersion, SourceSite, SourceSize, UpdateMask, Action, Source, StoredPkgPath, StorePkgFlag, ShareType, LastRefresh, PkgFlags, SourceDate, HashVersion FROM SMSPackages WHERE PkgID = (SELECT PackageID FROM EasySetupSettings)" -outFile $OutFile -DisplayText "EasySetup Package" -ZipFile $ZipName
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM PkgStatus WHERE Type = 1 AND ID = (SELECT PackageID FROM EasySetupSettings)" -outFile $OutFile -DisplayText "EasySetup Package Status" -ZipFile $ZipName

	# Compress and Collect
	compressCollectFiles -DestinationFileName $ZipName -filesToCollect ($Destination + "\*.*") -sectionDescription $sectionDescription -fileDescription "Update Servicing Data" -Recursive -ForegroundProcess -noFileExtensionsOnDescription
	Remove-Item -Path $Destination -Recurse -Force
}
else {
	TraceOut "    Update Servicing Data not collected because Site Build Number $global:SiteBuildNumber is less than 8325."
}

# ---------------------------
# Collect Server Information
# ---------------------------
# Moved to DC_FinishExecution

TraceOut "Completed"
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBd/z+TCBuBNUhj
# cYetG9+ts4lBSCEnHw6piLgAjP4smqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgEcIPerOY
# eitTWJbiR2LCq/xTtoKlJZBrPEDHx0qTcoEwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAJLihEfDwO2szMj2YLylZuSljeCdODhm9umdd5LSs4/H5YR50SqyBYuJ
# v/GJmH18Zk74NUe7mV++kfaYQQZhbdsuL+9ImeCis1FSCVlscA6cHBVvB8HNoqJz
# fhetHmlZCqjxPZO+GDtsbt+4uIQ99308dG117AX0yHB/R+8pW3TBMulvnh60b6JY
# m1UYeQt5l6Xz/MB70dLchf3b+kqIhDp3FQ0puYz7HQ7HbCm5kLWv+WvZrgzN4Pku
# Rm8lR5BmVsnJndaMq5RL3FFL2a4Fbsz9NOz0W6Z+E6sfxvgIb+W8eXU+TRtFi8F7
# mc2m8w+u2urbGin/C3t/iNvRY2eApSKhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgdUWZ3vYwZ8RV7vzo/RXtud/OJsr3h75+351wqcfsvAQCBmGCBVHy
# 4RgTMjAyMTExMTExNjUzMzYuNjM4WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjMy
# QkQtRTNENS0zQjFEMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFi0P4C8wHlzUkAAAAAAWIwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjIyWhcNMjIwNDExMTkwMjIyWjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjMyQkQtRTNENS0zQjFE
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA74ah1Pa5wvcyvYNCy/YQs1tK8rIGlh1Q
# q1QFaJmYVXLXykb+m5yCStzmL227wJjsalZX8JA2YcbaZV5Icwm9vAJz8AC/sk/d
# sUK3pmDvkhtVI04YDV6otuZCILpQB9Ipcs3d0e1Dl2KKFvdibOk0/0rRxU9l+/Yx
# eb5lVTRERLxzI+Rd6Xv5QQYT6Sp2IE0N1vzIFd3yyO773T5XifNgL5lZbtIUnYUV
# mUBKlVoemO/54aiFeVBpIG+YzhDTF7cuHNAzxWIbP1wt4VIqAV9JjuqLMvvBSD56
# pi8NTKM9fxrERAeaTS2HbfBYfmnRZ27Czjeo0ijQ5DSZGi0ErvWfKQIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFMvEShFgSkO3OnzgHlaVk3aQ/iprMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAC1BrcOhdhtb9xcAJtxVIUZ7iALwZewXFIdPcmDAVT81
# 0k5xuRwVNW9Onq+WZO8ebqwiOSdEEHReLU0FOo/DbS7q79PsKdz/PSBPqZ/1ysjR
# VH0L5HUK2N7NgpkR1lnt+41BaOzJ+00OFDL5GqeqvK3RWh7MtqWF6KKcfNkP/hji
# Flg9/S7xNK/Vl8q10HB5YbdBTQun8j1Jsih6YMb3tFQsxw++ra5+FSnc4yJhAYvV
# aqTKRKepEmwzYhwDiXh2ag80/p0uDkOvs1WhgogwidpBVmNLAMxmFavK9+LNfRKv
# PIuCQw+EsxWR8vFBBJDfs14WTsXVF94CQ1YCHqYI5EEwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjMyQkQtRTNENS0z
# QjFEMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQCas/oKGtvPRrHuznufk+indULyDKCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5Te4SjAiGA8y
# MDIxMTExMTE5NDIwMloYDzIwMjExMTEyMTk0MjAyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN7hKAgEAMAoCAQACAiHFAgH/MAcCAQACAhLGMAoCBQDlOQnKAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEASlWfw+kc9QPidqQu5ud3kPZfUgvL
# vhF64qnQh6v7VplHDJN9y5j9FUH4NCkl9y9OYxGU1UtJJhxNya9189MoCXytYR1S
# XQZWN4NOlG+MUgeoDtk6bbE1vIDZaTr/Rqbj6D5gHePQpd9KPFIxd4mCMSHqqYij
# fmeXDBwu2f4rsrcxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAWLQ/gLzAeXNSQAAAAABYjANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAH4HuL
# IjQubvd6oZHvBWqQ6Dg7LN4uBDYiWO0cxXMf5DCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIIqqGJX7PA0OulTsNEHsyLnvGLoYE1iwaOBmqrapUwoyMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFi0P4C8wHlzUkA
# AAAAAWIwIgQgfGSBnJ6w9YR8AGFaxMapl/Ts8QcWeJ59EyJVJ8qeHb4wDQYJKoZI
# hvcNAQELBQAEggEAV9wcGZ96HFbqGL85Q7FksMme7OE6AANwfOFmcSfucz3vYjMT
# NcMDuLNimTOLc54AoVnX6oJuDfoSCMVF238UzO9zf51IB7c77Sy8cOtfid6oETje
# NW6QEJPWtk6mHj+ulIW2bASlhHlOEnwIGBnyXgbKdAiQDQYU6Jr9y/D5n0aUcPX0
# 7naGvyQP0NB0C09/23nY3Vpdxac1w9U+FBCXT8/wqS2oe8s9OrTr1XoxxQrr8xsn
# FrDpQVwtlQst+wYkUt+gG/vckRMVMMhVnug1jxEVMAgllKR/jGn4fyH8zXDoE8NG
# YAOTghyPG3Q5KdunwzIQud7NaoJjICslr9viKg==
# SIG # End signature block
