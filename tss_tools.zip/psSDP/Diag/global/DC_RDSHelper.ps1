#************************************************
# DC_RDSHelper.ps1
# Version 1.0.1
# Date: 21-01-2012
# Author: Daniel Grund - dgrund@microsoft.com /#_# WalterE
# Description: 
#	RDS helper file 
# 1.0.0 Beta release
# 1.0.1 Added advapi32 to get userrightsassigments
#************************************************
PARAM(
    $RDSHelper,
	$RDSSDPStrings
)

$RDSHelper=@"
using System;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Security;
using System.ComponentModel;
using System.Collections;

public class RDSHelper
{
		public struct Collection
		{
			public string CollectionName;
			public string[] CollectionServers;
		}

		public struct ConnectionBroker
		{
			public string ConnectionBrokerName;
			public Collection[] Collections;
		}

        [StructLayout(LayoutKind.Sequential,Pack=1)]
        struct CertChain
        {
            public int Version;
            public int Count;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8000)]
            /*
            struct _Cert_Blob
            {
                public int cbCert;     // size of this certificate blob
                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8000)]
                public byte[] abCert;    // beginning byte of this certificate

            }*/
            public byte[] Certs;

        }

        [StructLayout(LayoutKind.Sequential,Pack=1)]
        struct _Cert_Blob
        {
            public int cbCert;     // size of this certificate blob
            public byte[] abCert;    // beginning byte of this certificate

        }
    public static bool RDPTestPort(string HostName, int port)
    { 
        // 5985 will be new Win8 'remoting' port
        // Create a TCP/IP client socket.
        // machineName is the host running the server application.
        TcpClient client = new TcpClient(HostName,port);
        if (client.Connected) return true;
        return false;
    }    
    public static X509Certificate RDPGetCert(string HostName, int port, string SavePath)
    { 
        X509Certificate cert = null;
       // Create a TCP/IP client socket.
        // machineName is the host running the server application.
        TcpClient client = new TcpClient(HostName,port);
		// sets the time out for the read and write to 5 seconds.
		client.ReceiveTimeout =5000;
        client.SendTimeout = 5000;
        try 
        {
			// Create an SSL stream that will close the client's stream.
	        SslStream sslStream = new SslStream(
	            client.GetStream(), 
	            false,
	            // always accept certificate 
	            new RemoteCertificateValidationCallback (delegate {return true;}), 
	            null
	            );
			// Set timeouts for the read and write to 5 seconds.
		    sslStream.ReadTimeout = 5000;
			sslStream.WriteTimeout = 5000;
            sslStream.AuthenticateAsClient(HostName);
            cert = sslStream.RemoteCertificate ;
            FileStream FS = new FileStream(SavePath, FileMode.Create);
            byte[] certBytes = cert.Export(X509ContentType.Cert, "");
            FS.Write(certBytes, 0, certBytes.Length);
            FS.Close();
        } 
        catch (System.Security.Cryptography.CryptographicException e)
        {
            // must do something with e to satisfy compiler or compile with -ignorewarning
        }
        client.Close();
        return cert ;
    }

	public static X509CertificateCollection GetCertCollFromReg( byte[] Cert)
        {
            X509CertificateCollection CertColl = null;
            try
            {
                GCHandle Handle = GCHandle.Alloc(Cert, GCHandleType.Pinned);
                IntPtr Ptr = Handle.AddrOfPinnedObject();
                CertChain certChain = (CertChain) Marshal.PtrToStructure(Ptr,typeof (CertChain));
                CertColl = new X509CertificateCollection();
                byte[] sCert = ((CertChain)Marshal.PtrToStructure(Ptr, typeof(CertChain))).Certs;
                
                int SizeCert = 0, offset = 0 ;
                GCHandle CHandle = GCHandle.Alloc(sCert, GCHandleType.Pinned);
                IntPtr CPtr = CHandle.AddrOfPinnedObject();
                
                for (int x = 0; x < certChain.Count ;x++ )
                {
                
                    SizeCert = sCert[offset +3];
                    SizeCert = SizeCert *256 + sCert[offset +2];
                    SizeCert = SizeCert *256 + sCert[offset +1];
                    SizeCert = SizeCert * 256 + sCert[offset + 0];
                    byte[] Cert1 = new byte[SizeCert];
                    uint uPtr = (uint)CPtr;
                    uPtr += 4;
                    CPtr = (IntPtr)uPtr;
                    Marshal.Copy(CPtr, Cert1, 0 , SizeCert );
                   CertColl.Add(new X509Certificate(Cert1));
                   offset += 4 + SizeCert;
                   uPtr += (uint) SizeCert;
                   CPtr = (IntPtr)uPtr;
                   
                }
                Handle.Free();
                CHandle.Free();
                return CertColl;
            }
            catch( System.Security.Cryptography.CryptographicException e)
            {
                // must do something with e to satisfy compiler or compile with -ignorewarning
                 
                return CertColl;
            }
            
        }
        
        public static IPAddress[] DNSLookup(string HostName)
        {
            IPHostEntry rdhost = Dns.GetHostEntry(HostName);
            return rdhost.AddressList;
        }

		public static int GetHttpsCert(string HostName, string SavePath)
		{
			bool Success = false;
			string Error = "";
			int nError = 0;
			X509Certificate cert = null;
			string targetURL = "https://" + HostName + "/rpc";
            HttpWebRequest webreq = (HttpWebRequest)WebRequest.Create(targetURL);
            HttpWebResponse webresp;
			try
			{
				webreq.UseDefaultCredentials = true;
				// should be set automaticly when UseDefaultCredentials is set to true.. just to be sure
                webreq.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials;
				// accept all certificates
				ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(delegate {return true;});
				Uri Host = new Uri(targetURL);
				webresp = (HttpWebResponse)webreq.GetResponse();
			}
			catch (Exception gwe)
            {
                Error = gwe.Message;
            }

			if (Error !="")
			{
				// first of all did we get to the Rpc page...?
				if (Error.Contains("401")) // auth error, page must exist
					nError = 1 ;  //Supplied credentials did not work

				if (Error.Contains("404")) // auth error, page must exist
					nError = 2; //There is no Rpc web site, required for SOAP calls to the AAEdge/Gateway

				if (Error.Contains("Unable to connect")) // no HTTPS
					nError = 3; //There is no HTTPS web service at the address

				if (Error.Contains("503")) 
                    nError = 4; //"The remote server returned an error: (503) Server Unavailable."
				
			}
			if (webreq.ServicePoint.Certificate != null)
            {
				// now save the retrieved certificate.
				cert = webreq.ServicePoint.Certificate;
				FileStream FS = new FileStream(SavePath, FileMode.Create);
				byte[] certBytes = cert.Export(X509ContentType.Cert, "");
				FS.Write(certBytes, 0, certBytes.Length);
				FS.Close();
				return 0; //Success
			}
			if (nError ==0) // only log error if we did not get certificate......
			return 5; //No certificate found.
			return nError;
		}
		
		    [StructLayout(LayoutKind.Sequential)]
    struct OBJECT_ATTRIBUTES
    {
        internal int Length;
        internal IntPtr RootDirectory;
        internal IntPtr ObjectName;
        internal int Attributes;
        internal IntPtr SecurityDescriptor;
        internal IntPtr SecurityQualityOfService;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct UNICODE_STRING
    {
        internal ushort Length;
        internal ushort MaximumLength;
        [MarshalAs(UnmanagedType.LPWStr)]
        internal string Buffer;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct ENUMERATION_INFORMATION
    {
        internal IntPtr PSid;
    }

    sealed class advapi32
    {
        [DllImport("advapi32", CharSet = CharSet.Unicode, SetLastError = true),
        SuppressUnmanagedCodeSecurityAttribute]
        internal static extern uint LsaOpenPolicy(
            UNICODE_STRING[] SystemName,
            ref OBJECT_ATTRIBUTES ObjectAttributes,
            int AccessMask,
            out IntPtr PolicyHandle);

        [DllImport("advapi32", CharSet = CharSet.Unicode, SetLastError = true),
        SuppressUnmanagedCodeSecurityAttribute]
        internal static extern uint LsaEnumerateAccountsWithUserRight(
            IntPtr PolicyHandle,
            UNICODE_STRING[] UserRights,
            out IntPtr EnumerationBuffer,
            out int CountReturned);

        [DllImport("advapi32")]
        internal static extern int LsaClose(IntPtr PolicyHandle);

        [DllImport("advapi32", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern bool ConvertSidToStringSid(
            IntPtr pSid, 
            out IntPtr strSid);

    }
    public class Lsa : IDisposable
    {
        IntPtr PolicyHandle;
        enum Access : int
        {
            POLICY_READ = 0x20006,
            POLICY_ALL_ACCESS = 0x00F0FFF,
            POLICY_EXECUTE = 0X20801,
            POLICY_WRITE = 0X207F8
        }

        public Lsa()
            : this(null)
        { }

        public Lsa(string TargetHost)
        {
            OBJECT_ATTRIBUTES ObjectAttributes;
            ObjectAttributes.RootDirectory = IntPtr.Zero;
            ObjectAttributes.ObjectName = IntPtr.Zero;
            ObjectAttributes.Attributes = 0;
            ObjectAttributes.SecurityDescriptor = IntPtr.Zero;
            ObjectAttributes.SecurityQualityOfService = IntPtr.Zero;
            ObjectAttributes.Length = Marshal.SizeOf(typeof(OBJECT_ATTRIBUTES));
            PolicyHandle = IntPtr.Zero;
            UNICODE_STRING[] SystemName = null;
            if (TargetHost != null)
            {
                SystemName = new UNICODE_STRING[1];
                SystemName[0] = InitUnicodeString(TargetHost);
            }

            uint ret = advapi32.LsaOpenPolicy(SystemName, ref ObjectAttributes, (int)Access.POLICY_ALL_ACCESS, out PolicyHandle);
            return;

        }

        public string[] ReadUserRightAssigment(string UserRight)
        {
            UNICODE_STRING[] UserRights = new UNICODE_STRING[1];
            UserRights[0] = InitUnicodeString(UserRight);
            IntPtr EnumerationBuffer;
            int CountReturned = 0;
            uint Status = advapi32.LsaEnumerateAccountsWithUserRight(PolicyHandle, UserRights, out EnumerationBuffer, out CountReturned);
            string[] SidStrings = new string[CountReturned];
            if (Status == 0)
            {

                ENUMERATION_INFORMATION[] EnumInfo = new ENUMERATION_INFORMATION[CountReturned];

                for (int i = 0, BufferOffset = (int)EnumerationBuffer; i < CountReturned; i++)
                {
                    IntPtr ptrSid;
                    EnumInfo[i] = (ENUMERATION_INFORMATION)Marshal.PtrToStructure(
                           (IntPtr)BufferOffset, typeof(ENUMERATION_INFORMATION));
                    advapi32.ConvertSidToStringSid(EnumInfo[i].PSid, out ptrSid);
                    SidStrings[i] = Marshal.PtrToStringAuto(ptrSid);
                    BufferOffset += Marshal.SizeOf(typeof(ENUMERATION_INFORMATION));
                }
            }
            return SidStrings;
        }

        public void Dispose()
        {
            if (PolicyHandle != IntPtr.Zero)
            {
                advapi32.LsaClose(PolicyHandle);
                PolicyHandle = IntPtr.Zero;
            }
            GC.SuppressFinalize(this);
        }
        ~Lsa()
        {
            Dispose();
        }

        static UNICODE_STRING InitUnicodeString(string _string)
        {
            UNICODE_STRING UnicodeString = new UNICODE_STRING();
            UnicodeString.Buffer = _string;
            UnicodeString.Length = (ushort)(_string.Length * sizeof(char));
            UnicodeString.MaximumLength = (ushort)(UnicodeString.Length + sizeof(char));
            return UnicodeString;
        }
    }
	public static bool IsLocalPolicyAllowingNetwork()
	{
        using (RDSHelper.Lsa lsa = new RDSHelper.Lsa())
        {
            string Everyone = "S-1-1-0";
            string AuthenticatedUsers = "S-1-5-11";
            bool Found = false;
            string[] Users = lsa.ReadUserRightAssigment("SeNetworkLogonRight");
           if (((IList)Users).Contains(Everyone) || ((IList)Users).Contains(AuthenticatedUsers))
           {
               Found = true;
           }
		   return Found;
        }
	}
}
"@

Add-Type -TypeDefinition $RDSHelper -IgnoreWarnings

Function Get-RemoteRegistryKeyProperty {
    param(
      $ComputerName = $(throw "Please specify a computer name."),
      $Path = $(throw "Please specify a registry path"),
      $Property = "*"
      ) 


    ## Validate and extract out the registry key
    if($path -match "^HKLM:\\(.*)")
    {
        $baseKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(
            "LocalMachine", $computername)
    }
    elseif($path -match "^HKCU:\\(.*)")
    {
        $baseKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(
            "CurrentUser", $computername)
    }
    else
    {
        Write-Error ("Please specify a fully-qualified registry path " +
            "(i.e.: HKLM:\Software) of the registry key to open.")
        return
    } 

    ## Open the key
    $key = $baseKey.OpenSubKey($matches[1])
    $returnObject = New-Object PsObject 

    ## Go through each of the properties in the key
    foreach($keyProperty in $key.GetValueNames())
    {
        ## If the property matches the search term, add it as a
        ## property to the output
        if($keyProperty -like $property)
        {
            $returnObject |
                Add-Member NoteProperty $keyProperty $key.GetValue($keyProperty)
        }
    } 

    ## Return the resulting object
    $returnObject 

    ## Close the key and base keys
    $key.Close()
    $baseKey.Close()
}

Function GetLSConnectDesc {
    param(
        [int]$ConnectResult = 0
    )
    switch($ConnectResult){
    0{"The connectivity status cannot be determined."}
 
    1{"Remote Desktop Services can connect to the Windows Server 2008 R2 license server."}
 
    2{"Remote Desktop Services can connect to the Windows Server 2008 license server."}
 
    3{"Remote Desktop Services can connect to the license server, but one of the servers is running a beta version of the operating system."}
 
    4{"Remote Desktop Services can connect to the license server, but there is an incompatibility between the license server and the Remote Desktop Services host server."}
 
    5{"Security group policy is enabled in license server, but Remote Desktop Services is not a part of the group policy."}
 
    6{"Remote Desktop Services cannot connect to the license server."}
 
    7{"The license server can be connected to, but the validity of the connection cannot be determined."}
 
    8{"Remote Desktop Services can connect to the license server, but the user account does not have administrator privileges on the license server."}
    
    9{"Remote Desktop Services can connect to the Windows Server 2008 SP1 with VDI support license server."}

	10{"Feature not supported."}

	11{"The license server is valid"}
    }
 
}

Function TSLicensingType {
	param(
		[int]$Type = 5
	)
	switch($Type){
		0{"Personal RD Session Host server."}
		1{"Remote Desktop for Administration."}
		2{"Per Device. Valid for application servers."}
		3{"Invalid!!"}
		4{"Per User. Valid for application servers."}
		5{"Not configured."}

	}
}

Function TSProtocol {
    param(
        [int]$Protocol = 0
    )
    switch($Protocol){
    0{"This session is running on a physical console."}
 
    1{"A proprietary third-party protocol is used for this session."}
 
    2{"Remote Desktop Protocol (RDP) is used for this session."}
 
    }
 
}

Function SessionState {
    param(
        [int]$Session = 0
    )
    switch($Session){
    0{"The session is active."}
 
    1{"The session is disconnected."}
 
    }
 
}

Function ReportError
	{
		param(
			$RootCause = "No known error",
			$Solution = "No known solution",
			$RCNum,
			$Detected = $true
  		)

		$RootCauseName = "RC_RDS" + $RCNum
		"Found Rootcause: " + $RootCause + " Found Solution: " + $Solution | WriteTo-StdOut
		Update-DiagRootCause -Id $RootCauseName -Detected $Detected -Parameter @{"Error" = $RootCause; "Solution" = $Solution}

		# $InformationCollected = new-object PSObject
		# add-member -inputobject $InformationCollected -membertype noteproperty -name $RootCause + " found:"  -value  $RootCause
		# add-member -inputobject $InformationCollected -membertype noteproperty -name $RootCause + " solution: " -value  $Solution 
		# Write-GenericMessage -RootCauseId $RootCauseName  -InformationCollected $InformationCollected -Visibility 4 -Component "Windows Remote Desktop Services"
	}

Function UpdateAndMessage
	{
		param(
			$Id,
			$Detected,
			$RootCause = "",
			$Solution = ""
		)
		"Entering UpdateAnMessage() $Id $Detected" |  WriteTo-StdOut
		Update-DiagRootCause -Id $Id -Detected $Detected
		if ($Detected)
		{
			$InformationCollected = new-object PSObject
				
			if ($RootCause -ne "")
			{
				add-member -inputobject $InformationCollected -membertype noteproperty -name ($Id + " found:")  -value  $RootCause
				if ($Solution -ne "")
				{
					add-member -inputobject $InformationCollected -membertype noteproperty -name ($Id + " solution:") -value  $Solution 
				}
			}
				Add-GenericMessage -Id $Id  -InformationCollected $InformationCollected 

		}

	}

Function SaveAsXml
	{
		param(
			$Object,
			$FileName,
			[array]$OutputFileName
			)
		$PItext = "type='text/xsl' href='RDS.xslt'"
		$File = $PWD.Path  + "\" + $FileName
	    $xml = ConvertTo-Xml $Object
		if($xml.HasChildNodes)
        {
			$Objects = $xml.SelectNodes("Objects/Object/Property")
			if(($Objects -ne $null) -and ($xml.SelectSingleNode("Objects/Object").Attributes.GetNamedItem("Type")."#text" -eq "System.Object[]"))
			{
				foreach( $xmlnode in $Objects)
				{
					$start = ($xmlnode.SelectSingleNode("Property[@Name = 'ClassPath']"))."#text".indexof(':')
					$name = ($xmlnode.SelectSingleNode("Property[@Name = 'ClassPath']"))."#text".Substring($start+1)
					$xmlnode.Attributes.Item(0)."#text" = $name
					$xmlnode.SelectSingleNode("Property[@Name = 'ClassPath']").RemoveAll()
				}
			}
			else
			{
				$xml.SelectSingleNode("Objects/Object").Attributes.RemoveAll()
				$start = ($xml.SelectSingleNode("Objects/Object/Property[@Name = 'ClassPath']"))."#text".indexof(':')
				$name = ($xml.SelectSingleNode("Objects/Object/Property[@Name = 'ClassPath']"))."#text".Substring($start+1)
				$aatr = $xml.CreateAttribute("Type")
				$aatr.Value = $name
				$xml.SelectSingleNode("Objects/Object").Attributes.Append($aatr)
				$xml.SelectSingleNode("Objects/Object/Property[@Name = 'ClassPath']").RemoveAll()
			}
			$newPI = $xml.CreateProcessingInstruction("xml-stylesheet",$PItext)
			$xml.InsertAfter($newPI,$xml.FirstChild)
			$xml.save($File)
			[array]$OutputFileName += $File
			[xml] $xslContent = Get-Content ./rds.xslt
			$xslobject = New-Object system.Xml.Xsl.XslTransform
			$xslobject.Load($xslContent)
			$htmlfile =$File.substring(0,$File.length -4) + ".html"
			$xslobject.Transform($File,$htmlfile)
			[array]$OutputFileName += $htmlfile
		}
		$OutputFileName
	}

Function FilterWMIObject
	{
		param ($Object)
		$Object | Select-Object * -excludeproperty "_*",Options,Properties,Systemproperties,Path,Description,InstallDate,Caption,Scope,Qualifiers,Site,Container,Status
	}

Function SaveRDPFileContents
	{
		param ($Object,
			$ObjectName,
			[array]$OutputFileName)
		
		if ($Object -ne $null)
		{
			
			foreach ($remoteresource in $Object)
			{
				$savepath = $TargetHost +"_" + $remoteresource.Alias + "_" + $ObjectName + ".RDP"
				$remoteresource.RDPFileContents | Out-File $savepath
				[array]$OutputFileName += $savepath
				$remoteresource.RDPFileContents = "Saved as: " + $savepath
			}
			$OutputFileName = SaveAsXml $Object  ($TargetHost +"_" + $ObjectName + ".xml") $OutputFileName
			
		}
		$OutputFileName
	}

Function out-zip 
	{ 
	  Param([string]$ZipPath, $Files) 

	  if (-not $ZipPath.EndsWith('.zip')) {$ZipPath += '.zip'} 

	  if (-not (test-path $ZipPath)) { 
		set-content $ZipPath ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18)) 
	  } 
	  $ZipFile = (new-object -com shell.application).NameSpace($ZipPath) 
	  foreach ($File in $Files)
	  {
		"Saving $File in  $ZipPath"| WriteTo-StdOut
		$ZipFile.CopyHere($File, 1052)
	  } 

	}

Function IsEventLogged
	{
		param($EventLog,
			$EventId)
		$output = wevtutil qe $EventLog "/q:*[System [(EventID = $EventId)]]" /c:1
		if($output -ne $null)
		{
			$true
		}else
		{
			$false
		}
	}

Function WMISecGroupsNotPresent
	{
		$security = Get-CimInstance -Namespace root/cimv2/terminalservices -Class __SystemSecurity
		$converter = new-object system.management.ManagementClass Win32_SecurityDescriptorHelper
		$binarySD = @($null)
		$result = $security.PsBase.InvokeMethod("GetSD",$binarySD)
		$WMIDescriptor = ($converter.BinarySDToWin32SD($binarySD[0])).Descriptor
		$RDSGroup = "RDS Management Servers","RDS Remote Access Servers","RDS Endpoint Servers"
		$Count = 0
		foreach ($DACL in $WMIDescriptor.dacl)
		{
			if ($DACL.Trustee.Name -eq "TS Web Access Computers") {return $false}
			if ($RDSGroup.Contains($DACL.Trustee.Name)){ $Count++}
			if ($Count -eq 3) {return $false}
		}
		$true
	}

function CheckNode
	{
	 Param( $Node, $Checked)
	 if($Node -ne $null)
	 {
	  foreach ($ChildNode in $Node.Nodes)
	  {
		$ChildNode.Checked = $Checked
		if( $ChildNode.Nodes.Count -gt 0)
		{
			CheckNode -Node $ChildNode -Checked $Checked
		}
	   }  
	  }
	}

function GetNodesChecked
	{
		Param ($objTreeView, [array]$ServersToCollect)
		if($objTreeView -ne $null)
		{
			for($x=0; $x -lt $objTreeView.Nodes.GetNodeCount($false);$x++)
			{
				for($y = 0;$y -lt $objTreeView.Nodes.Nodes[$x].GetNodeCount($True); $y++)
				{
					if($objTreeView.Nodes.Nodes[$x].Nodes[$y].Checked -eq $true)
					{
						[array]$ServersToCollect+= $objTreeView.Nodes.Nodes[$x].Nodes[$y].Text
					}

				}
			}
        
		}else
		{
			$ServersToCollect = $null
		}
		$ServersToCollect
	}

function AddCBtoTreeView
	{
		param ($objTreeView, $ConnectionBroker)
		$objTreeNode = New-Object System.Windows.Forms.TreeNode($ConnectionBroker.ConnectionBrokerName)
		$objTreeNode.Name = $ConnectionBroker.ConnectionBrokerName
		$objTreeView.Nodes.Add($objTreeNode)
		foreach($Collect in $ConnectionBroker.Collections)
		{
			$objChildNode = New-Object System.Windows.Forms.TreeNode($Collect.CollectionName);
			$objChildNode.Name = $Collect.CollectionName;
			$objTreeView.Nodes[$ConnectionBroker.ConnectionBrokerName].Nodes.Add($objChildNode);
			foreach($Server in  $Collect.CollectionServers)
			{
				$objServer = New-Object System.Windows.Forms.TreeNode($Server);
				$Server.Name = $Server
				$objTreeView.Nodes[$ConnectionBroker.ConnectionBrokerName].Nodes[$Collect.CollectionName].Nodes.Add($Server);
			}
		}
		$objTreeView.add_AfterCheck({
			if($_.Action -ne [System.Windows.Forms.TreeViewAction]::Unknown)
			{
				if($_.Node.Nodes.Count -gt 0)
				{
    
					CheckNode -Node $_.Node -Checked $_.Node.Checked
				}
			}
		 })
	}


Function CreateTreeViewUI
	{
		param ($ConnectionBroker)
		[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
		[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
		$objForm = New-Object System.Windows.Forms.Form 
		$objForm.Text = "Select a Computer"
		$objForm.Size = New-Object System.Drawing.Size(500,200) 
		$objForm.StartPosition = "CenterScreen"


		$OKButton = New-Object System.Windows.Forms.Button
		$OKButton.Location = New-Object System.Drawing.Size(320,120)
		$OKButton.Size = New-Object System.Drawing.Size(75,23)
		$OKButton.Text = "OK"
		$OKButton.Add_Click({$objForm.Close()})
		$objForm.Controls.Add($OKButton)

		$CancelButton = New-Object System.Windows.Forms.Button
		$CancelButton.Location = New-Object System.Drawing.Size(395,120)
		$CancelButton.Size = New-Object System.Drawing.Size(75,23)
		$CancelButton.Text = "Cancel"
		$CancelButton.Add_Click({$objForm.Close()})
		$objForm.Controls.Add($CancelButton)

		$objLabel = New-Object System.Windows.Forms.Label
		$objLabel.Location = New-Object System.Drawing.Size(10,20) 
		$objLabel.Size = New-Object System.Drawing.Size(480,20) 
		$objLabel.Text = "Please check Computers or Collection to collect data from."
		$objForm.Controls.Add($objLabel) 

		$objTreeView = New-Object System.Windows.Forms.TreeView 
		$objTreeView.Location = New-Object System.Drawing.Size(10,40) 
		$objTreeView.Size = New-Object System.Drawing.Size(460,20) 
		$objTreeView.Height = 80
		$objTreeView.CheckBoxes = $True
	
		AddCBtoTreeView -objTreeView $objTreeView -ConnectionBroker $ConnectionBroker
	
		$objForm.Controls.Add($objTreeView) 
		$objForm.Topmost = $True
		$objForm.Add_Shown({$objForm.Activate()})
		[void] $objForm.ShowDialog()
		$objTreeView
	}

    Function IsRDPDDAccelerated
    {
		if((Get-Item HKLM:SYSTEM\CurrentControlSet\services\rdpdd -EA SilentlyContinue) -ne $null) #_# -EA
		{
			"IsRDPDDAccelerated () Found rdpdd " | WriteTo-StdOut
            foreach($key in Get-ChildItem HKLM:SYSTEM\CurrentControlSet\services\rdpdd)
	       {
                if($key.Name.Contains("Device"))
                {
				"IsRDPDDAccelerated () Found rdpdd\Device " | WriteTo-StdOut
					foreach($property in $key.Property)
					{
						if ($property.Contains("Acceleration.Level"))
                        {
						"IsRDPDDAccelerated () Found rdpdd\Device\Acceleration.Level " | WriteTo-StdOut
                        return $True
                        }
					}
				}
			}              
         }
      return $False
    }

# code for reg permisions checking  on the LICENSE keys
	Function CheckRegPerm
	{
		Param ( $RegPath, $Rights)
		 ((get-acl $RegPath).Access | where-object -Property IdentityReference -Like $Users| where-object -Property RegistryRights -Contains $Rights) -ne $null
	}

	Function IsRegPermIssue
	{
		$RegRights=[System.Security.AccessControl.RegistryRights]("SetValue, CreateSubKey, ReadKey")
		$RegDelRights = [System.Security.AccessControl.RegistryRights]("Delete")
		$Users = [System.Security.Principal.NTAccount]("BUILTIN\Users") 
		if((CheckRegPerm –RegPath "HKLM:\SOFTWARE\Microsoft\MSLicensing\Store"-Rights $RegRights) -eq $false)
		{return $true}

		if( $Licenses = (dir HKLM:\SOFTWARE\Microsoft\MSLicensing\Store).Name.Replace("HKEY_LOCAL_MACHINE", "HKLM:"))
		{
			[array]$Results = $null
			Foreach( $License in $Licenses){ [array]$Results+= CheckRegPerm –RegPath $License -Rights $RegDelRights}
			return $Results.Contains($false) -eq $true
    
		}
		$false
	}

# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCABem6kB6OyvPFZ
# c6M70wouV81ErUhYlOK8XdWqFielf6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg6CNqgWx4
# /HYfmVvgIwCLkn0y6ua2Jn6VBqpQonSXJUIwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBALWa87JTbJUbz+Z6U05Yg+cEgyGTNNkAAXTr/tOs8z92R61pnT0GrX8N
# bEGIjLW8g6DvBXv8VwP32tANCuBjgE+N19XrlnXiS5vSsE2InM2rMCVXA+IsP2Wl
# 7L4+GnnR/iPXsWCzS5NkWlAx34c6rA5cNbbYlKz9wipqixXDDZtTHX9GTNHWvwoH
# Ppua9bmg3fm2rfLtlvAV7Ko2HPTLoI9xPC2uM5vN8vZHbLQ/rdjrd74vg1z7WkhU
# boD1aMWjmSusNUO+hT2jREDXWqUd6o7Y65PYNt41OkAL1GQQCKHzmS4YS4aKe88K
# qQcgKxJs8ynk1cF6SXuUIq73cKZ6k1yhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQg0gV64nnl6sPp5dgqqQ31XTbcy6hW/SeDGGeey464MdECBmGB3Gir
# bRgTMjAyMTExMTExNjUzMzkuNDYxWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYw
# QkMtRTM4My0yNjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFaLLluRDTLbygAAAAAAVowDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE2WhcNMjIwNDExMTkwMjE2WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0yNjM1
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsL1cHFcNrScIrvQd/4aKHo3FGXWYCHMU
# l2iTxuzfGknztMzbysR4eRkBoT4pv0aL1S9OlDfOsRbJZKkhCTLG/9Z/RwiEDWYk
# 6rK7bRM3eX3pm+DNivM7+tCU+9spbv2gA7j5gWx6RAK2vMz2FChLkFgbA+H1DPro
# G5LEf1DB7LA0FCyORWiKSkHGRL4RdIjOltrZp++dExfsst7Z6vJz4+U9eZNI58fV
# Y3KRzbm73OjplfSAB3iNSkHN0wuccK0TrZsvY87TRyYAmyK2qBqi/7eUWt93Sw8A
# LBMY72LKaUmVvaxq/COpKePlHMbhHEbqtTaLt61udBOjNHvc4cwY5QIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFGRzJT/1HI+SftAGhdk5NDzA3jFnMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAAAAbex8WBtSLDiBYxXxU7GVsgb8IgxKJyIO0hmc8vzg
# 4w3iUl5Xkt4mv4dgFyjHmu5Zmbj0rb2IGYm/pWJcy0/zWlhnUQUzvfTpj7MsiH+1
# Lnvg95awe88PRA7FDgc4zYY0+8UB1S+jzPmmBX/kT6U+7rW5QIgFMMRKIc743utq
# CpvcwRM+pEo8s0Alwo8NxqUrOeYY+WfNjo/XOin/tr3RVwEdEopD+FO+f/wLxjpv
# 4y+TmRgmHrso1tVVy64FbIVIxlMcZ6cee4dWD2y8fv6Wb9X/AhtlQookk7QdCbKh
# 3JJ4P8ksLs02wNhGkU37b10tG3HR5bJmiwmZPyopsEgwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0y
# NjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQDMgAWYvcYcdZwAliLeFobCWmUaLqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5TePeDAiGA8y
# MDIxMTExMTE2NDc1MloYDzIwMjExMTEyMTY0NzUyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN494AgEAMAoCAQACAiYUAgH/MAcCAQACAhEuMAoCBQDlOOD4AgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEARgjej0SbSLQSMcUwvN12chrEC28n
# cvB5Y3XUAVhEcy1SU+s/DPBT7RaNwTGRnmi6Mq9YdOCw28LOQagQobT23OIXtlQk
# v6/VnsW+JiF8q2A2Zvn08thSlcdfEr1B4nsYLVrR78o0MGag24mYk75Z6ATsfNVT
# HmPR653hJHGQ0OcxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVosuW5ENMtvKAAAAAABWjANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCChb0WH
# ya/5vo2LWWo2NTNchMKj+kjB4k39VY5Bp9rx9zCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIJP8qCZ0xLLkXTDDghqv1yZ/kizekzSFS4gicvltsX+wMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFaLLluRDTLbygA
# AAAAAVowIgQgMnaZvhznlep5/TqcHsVpqibeOA9Q6qLRQqPN0sxjsvwwDQYJKoZI
# hvcNAQELBQAEggEARH+Lcc0UQ5AqKCW64R5XVFA76iACiNwDqZuq/NlZ3wVQJgAk
# nE2T/apdSGL0bCt2AiFKr88pt2ROseIG0fvTa6YucT7i7n2+YLk1bKctsuqhEGrT
# 2PxhGQybiKWp12zgfh66LCGFsE9mjplAYq2Sfd3tuM/mtEkuJLEwqCMFQwwwqQ08
# sSMKYqGIBu1sOQ45K6TL3F8HiOnd8hEk7HciVTJOYaLJqp9KyqH1jI2yCnE7Ppyn
# 2LgLlT9NcSF07wTjsuYEf9yeaQxYYM2TCVdiVbuvTijlsOP2o0v/cXTDgmYYfa7B
# ypX61b90Vupd98VRNrNQXOTsKAkaGZQmPAjekA==
# SIG # End signature block
