﻿#************************************************
# DC_SurfacePro3.ps1
# Version 1.0.09.19.14: Created and tested SurfacePro3 scripts from Sep12-19
# Version 1.1.10.07.14: Added the "Operating System and SKU section"
# Version 1.2.10.08.14: Modified Surface Pro 3 "Wifi Driver Version" detection method since the same file version is used for MP67 and MP107. (Testing with two SP3s)
# Version 1.3.10.09.14: Added Surface Pro 3 "Wifi Driver Power Management Settings"
# Version 1.4.10.10.14: Added Surface Pro 3 Binary Versions section
# Version 1.5.10.15.14: Added Surface Pro 3 Secure Boot Configuration section
# Version 1.6.10.16.14: Added Surface Pro 3 WMI classes output
# Date: 2014
# Author: Boyd Benson (bbenson@microsoft.com) working with Scott McArthur (scottmca) and Tod Edwards (tode)
# Description: Collects information about Surface Pro 3.
# Called from: Networking and Setup Diagnostics
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_SurfacePro3 -Status $ScriptVariable.ID_SurfacePro3Desc

$sectionDescription = "Surface Pro 3"

# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber
$sku = $((gwmi win32_operatingsystem).OperatingSystemSKU)
$domainRole = (Get-WmiObject -Class Win32_ComputerSystem).DomainRole	# 0 or 1: client; >1: server



Function isOSVersionAffected
{
	if ($bn -ge 9600)
	 {
		return $true
	 }
	 else
	 {
		return $false
	 }
}

Function isSurfacePro3
{
	# Check for: "HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System\BIOS"; SystemSKU = Surface_Pro_3
	$regkeyBIOS = "HKLM:\HARDWARE\DESCRIPTION\System\BIOS"
	If (test-path $regkeyBIOS)
	{
		$regvalueSystemSKUReg = Get-ItemProperty -path $regkeyBIOS -name "SystemSKU" -ErrorAction SilentlyContinue
		$regvalueSystemSKU = $regvalueSystemSKUReg.SystemSKU
		if ($regvalueSystemSKU -eq "Surface_Pro_3")
		{
			return $true
		}
		else
		{
			return $false
		}
	}
}

Function GetOsVerName($bn)
{
	switch ($bn)
	{
		9600  {return "W8.1/WS2012R2"}
		9200  {return "W8/WS2012"}
		7601  {return "W7/WS2008R2 SP1"}
		7600  {return "W7/WS2008R2 RMT"}
	}
}

Function GetOsSkuName($sku)
{
	switch ($sku)
	{
		# GetProductInfo function
		# http://msdn.microsoft.com/en-us/library/ms724358.aspx
		#
		0  {return ""}
		1  {return "Ultimate Edition"}
		2  {return "Home Basic Edition"}
		3  {return "Home Basic Premium Edition"}
		4  {return "Enterprise Edition"}
		5  {return "Home Basic N Edition"}
		6  {return "Business Edition"}
		7  {return "Standard Server Edition"}
		8  {return "Datacenter Server Edition"}
		9  {return "Small Business Server Edition"}
		10 {return "Enterprise Server Edition"}
		11 {return "Starter Edition"}
		12 {return "Datacenter Server Core Edition"}
		13 {return "Standard Server Core Edition"}
		14 {return "Enterprise Server Core Edition"}
		15 {return "Enterprise Server Edition for Itanium-Based Systems"}
		16 {return "Business N Edition"}
		17 {return "Web Server Edition"}
		18 {return "Cluster Server Edition"}
		19 {return "Home Server Edition"}
		20 {return "Storage Express Server Edition"}
		21 {return "Storage Standard Server Edition"}
		22 {return "Storage Workgroup Server Edition"}
		23 {return "Storage Enterprise Server Edition"}
		24 {return "Server For Small Business Edition"}
		25 {return "Small Business Server Premium Edition"} # 0x00000019
		26 {return "Home Premium N Edition"} # 0x0000001a
		27 {return "Enterprise N Edition"} # 0x0000001b
		28 {return "Ultimate N Edition"} # 0x0000001c
		29 {return "Web Server Edition (core installation)"} # 0x0000001d
		30 {return "Windows Essential Business Server Management Server"} # 0x0000001e
		31 {return "Windows Essential Business Server Security Server"} # 0x0000001f
		32 {return "Windows Essential Business Server Messaging Server"} # 0x00000020
		33 {return "Server Foundation"} # 0x00000021
		34 {return "Windows Home Server 2011"} # 0x00000022 not found
		35 {return "Windows Server 2008 without Hyper-V for Windows Essential Server Solutions"} # 0x00000023
		36 {return "Server Standard Edition without Hyper-V (full installation)"} # 0x00000024
		37 {return "Server Datacenter Edition without Hyper-V (full installation)"} # 0x00000025
		38 {return "Server Enterprise Edition without Hyper-V (full installation)"} # 0x00000026
		39 {return "Server Datacenter Edition without Hyper-V (core installation)"} # 0x00000027
		40 {return "Server Standard Edition without Hyper-V (core installation)"} # 0x00000028
		41 {return "Server Enterprise Edition without Hyper-V (core installation)"} # 0x00000029
		42 {return "Microsoft Hyper-V Server"} # 0x0000002a
		43 {return "Storage Server Express (core installation)"} # 0x0000002b
		44 {return "Storage Server Standard (core installation)"} # 0x0000002c
		45 {return "Storage Server Workgroup (core installation)"} # 0x0000002d
		46 {return "Storage Server Enterprise (core installation)"} # 0x0000002e
		47 {return "Starter N"} # 0x0000002f
		48 {return "Professional Edition"} #0x00000030
		49 {return "ProfessionalN Edition"} #0x00000031
		50 {return "Windows Small Business Server 2011 Essentials"} #0x00000032
		51 {return "Server For SB Solutions"} #0x00000033
		52 {return "Server Solutions Premium"} #0x00000034
		53 {return "Server Solutions Premium (core installation)"} #0x00000035
		54 {return "Server For SB Solutions EM"} #0x00000036
		55 {return "Server For SB Solutions EM"} #0x00000037
		55 {return "Windows MultiPoint Server"} #0x00000038
		#not found: 3a
		59 {return "Windows Essential Server Solution Management"} #0x0000003b
		60 {return "Windows Essential Server Solution Additional"} #0x0000003c
		61 {return "Windows Essential Server Solution Management SVC"} #0x0000003d
		62 {return "Windows Essential Server Solution Additional SVC"} #0x0000003e
		63 {return "Small Business Server Premium (core installation)"} #0x0000003f
		64 {return "Server Hyper Core V"} #0x00000040
		 #0x00000041 not found
		 #0x00000042-48 not supported
		76 {return "Windows MultiPoint Server Standard (full installation)"} #0x0000004C
		77 {return "Windows MultiPoint Server Premium (full installation)"} #0x0000004D
		79 {return "Server Standard (evaluation installation)"} #0x0000004F
		80 {return "Server Datacenter (evaluation installation)"} #0x00000050
		84 {return "Enterprise N (evaluation installation)"} #0x00000054
		95 {return "Storage Server Workgroup (evaluation installation)"} #0x0000005F
		96 {return "Storage Server Standard (evaluation installation)"} #0x00000060
		98 {return "Windows 8 N"} #0x00000062
		99 {return "Windows 8 China"} #0x00000063
		100 {return "Windows 8 Single Language"} #0x00000064
		101 {return "Windows 8"} #0x00000065
		102 {return "Professional with Media Center"} #0x00000067
	}	
}



if ((isOSVersionAffected) -and (isSurfacePro3))
{
	$outputFile= $Computername + "_SurfacePro3_info.TXT"
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Surface Pro 3 Configuration Information"				| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Overview" 												| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	"   1. Operating System and SKU"						| Out-File -FilePath $OutputFile -append
	"   2. Wifi Driver Version"								| Out-File -FilePath $OutputFile -append
	"   3. Wifi Driver Power Management Settings"		 	| Out-File -FilePath $OutputFile -append
	"   4. Firmware Versions"								| Out-File -FilePath $OutputFile -append
	"   5. Connected Standby Status"						| Out-File -FilePath $OutputFile -append
	"   6. Connected Standby Configuration"					| Out-File -FilePath $OutputFile -append
	"   7. Secure Boot Configuration"						| Out-File -FilePath $OutputFile -append
	"   8. WMI Class Information"							| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append


	"[info] Operating System and SKU section" 	| WriteTo-StdOut
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Operating System and SKU"  				| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" 										| Out-File -FilePath $OutputFile -append
	$osVerName = GetOsVerName $bn
	"Operating System Name        : $osVerName" | Out-File -FilePath $OutputFile -append
	"Operating System Build Number: $bn" 		| Out-File -FilePath $OutputFile -append
	$osSkuName = GetOsSkuName $sku
	"Operating System SKU Name    : $osSkuName"	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append

	$WinCVRegKey = "HKLM:\Software\Microsoft\Windows\CurrentVersion"
	If (test-path $WinCVRegKey)
	{
		$ImageNameReg   = Get-ItemProperty -Path $WinCVRegKey -Name ImageName
		$ImageName = $ImageNameReg.ImageName
	}
	
	$WinNTCVRegKey = "HKLM:\Software\Microsoft\Windows NT\CurrentVersion"
	If (test-path $WinNTCVRegKey)
	{
		$BuildLabReg    = Get-ItemProperty -Path $WinNTCVRegKey -Name BuildLab
		$BuildLab = $BuildLabReg.BuildLab

		$BuildLabExReg  = Get-ItemProperty -Path $WinNTCVRegKey -Name BuildLabEx 
		$BuildLabEx = $BuildLabExReg.BuildLabEx

		$ProductNameReg = Get-ItemProperty -Path $WinNTCVRegKey -Name ProductName 
		$ProductName = $ProductNameReg.ProductName

		$CurrentBuildReg = Get-ItemProperty -Path $WinNTCVRegKey -Name CurrentBuild 
		$CurrentBuild = $CurrentBuildReg.CurrentBuild

		"Image Name    : $ImageName" | Out-File -FilePath $OutputFile -append		
		"BuildLab      : $BuildLab" | Out-File -FilePath $OutputFile -append
		"BuildLabEx    : $BuildLabEx" | Out-File -FilePath $OutputFile -append
		"ProductName   : $ProductName" | Out-File -FilePath $OutputFile -append
		"CurrentBuild  : $CurrentBuild" | Out-File -FilePath $OutputFile -append
	}
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append



	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Wifi Driver Version" 									| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" 													| Out-File -FilePath $OutputFile -append	
	"[info] Wifi Driver Version section"  | WriteTo-StdOut
	$marvelDriver = join-path $env:windir "\system32\drivers\mrvlpcie8897.sys"
	if (test-path $marvelDriver)
	{
		$marvelDriverInfo = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($marvelDriver)
		$marvelDriverFileBuildPart = $marvelDriverInfo.FileBuildPart
		$marvelDriverProductVersion = $marvelDriverInfo.ProductVersion
		[string]$marvelDriverVersion = [string]$marvelDriverInfo.FileMajorPart + "." + [string]$marvelDriverInfo.FileMinorPart + "." + [string]$marvelDriverInfo.FileBuildPart + "." + [string]$marvelDriverInfo.FilePrivatePart
		# Latest driver (as of 9/9/14): 6.3.9410.0; MP107; DateModified: 8/22/14; Package version online: 15.68.3055.107;
		# Previous driver             : 6.3.9410.0; MP67 ; DateModified: 4/24/14;
		#
		"FileName      : $marvelDriver"					| Out-File -FilePath $OutputFile -append
		"FileVersion   : $marvelDriverVersion"			| Out-File -FilePath $OutputFile -append
		"ProductVersion: $marvelDriverProductVersion"	| Out-File -FilePath $OutputFile -append
		"`n" 											| Out-File -FilePath $OutputFile -append
		
		$marvelDriverProductVersionStartsWithMP = ($marvelDriverProductVersion).StartsWith("MP")
		if ($marvelDriverProductVersionStartsWithMP -eq $true) 
		{
			[int]$marvelDriverProductVersionInt = $marvelDriverProductVersion.Substring(2,$marvelDriverProductVersion.length-2)
		}
		if ($marvelDriverProductVersionInt -gt 107)
		{
			"The driver installed is more recent than the version from 9/9/14." | Out-File -FilePath $OutputFile -append
		}
		elseif ($marvelDriverProductVersionInt -eq 107)
		{
			"The driver installed is the most recent driver (as of 9/9/14)." | Out-File -FilePath $OutputFile -append	
			"Installed: MP107; 6.3.9410.0" | Out-File -FilePath $OutputFile -append
		}
		elseif ($marvelDriverProductVersionInt -eq 67)
		{
			"The driver installed is older than the recommended version." 			| Out-File -FilePath $OutputFile -append
			"The installed driver is MP67 with version 6.3.9410.0." 				| Out-File -FilePath $OutputFile -append
			"The most recent driver (as of 9/9/14) is MP107; 6.3.9410.0." | Out-File -FilePath $OutputFile -append
		}
		else
		{
			"The driver installed is an older version of the driver." 				| Out-File -FilePath $OutputFile -append
		}
		"`n" | Out-File -FilePath $OutputFile -append
		"`n" | Out-File -FilePath $OutputFile -append
		"--------------------------------------" | Out-File -FilePath $OutputFile -append			
		"Please refer to the following article:" 	| Out-File -FilePath $OutputFile -append
		"--------------------------------------" | Out-File -FilePath $OutputFile -append
		"Public Content:"	| Out-File -FilePath $OutputFile -append
		"`"Surface Pro 3 update history`""	| Out-File -FilePath $OutputFile -append
		"http://www.microsoft.com/surface/en-us/support/install-update-activate/pro-3-update-history" 	| Out-File -FilePath $OutputFile -append
	}
	else
	{
		"The driver `"\system32\drivers\mrvlpcie8897.sys`" does not exist on this system." | Out-File -FilePath $OutputFile -append
	}	
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append



	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Wifi Driver Power Management Settings" 				| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" 									| Out-File -FilePath $OutputFile -append	
	"[info] Wifi Driver Version section"	| WriteTo-StdOut
	
	$deviceFound = $false
	$regkeyNicSettingsPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}"
	if (test-path $regkeyNicSettingsPath) 
	{
		if ($marvelDriverProductVersionInt -ge 107)
		{
			$regkeyNicSettings = Get-ItemProperty -Path $regkeyNicSettingsPath
			$regsubkeysNicSettings = Get-ChildItem -Path $regkeyNicSettingsPath -ErrorAction SilentlyContinue
			# using ErrorAction of SilentlyContinue because one subkey, "Properties", cannot be read.

			foreach ($childNicSettings in $regsubkeysNicSettings)
			{
				$childNicSettingsName = $childNicSettings.PSChildName
				if ($childNicSettingsName -eq "Properties")
				{
				}
				else
				{
					$childNicSettingsPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}\$childNicSettingsName"
					if (test-path $childNicSettingsPath)
					{
						$networkAdapterComponentId = (Get-ItemProperty -Path $childNicSettingsPath).ComponentId
						if ($networkAdapterComponentId -eq "pci\ven_11ab&dev_2b38&subsys_045e0001")
						{
							$deviceFound = $true
							
							# ConnectedStandby
							$regkeyPower = "HKLM:\SYSTEM\CurrentControlSet\Control\Power"
							If (test-path $regkeyPower)
							{
								"[info] Power regkey exists"  | WriteTo-StdOut 
								$regvaluePowerCsEnabled = Get-ItemProperty -path $regkeyPower -name "CsEnabled" -ErrorAction SilentlyContinue
								if ($regvaluePowerCsEnabled -ne $null)
								{
									$regvaluePowerCsEnabled = $regvaluePowerCsEnabled.CsEnabled
									"[info] Connected Standby registry value exists: $regvaluePowerCsEnabled"  | WriteTo-StdOut 
									if ($regvaluePowerCsEnabled -ne 1)
									{
										"Connected Standby is currently DISABLED. This exposes the Power Management tab in the properties of the Wireless NIC."	| Out-File -FilePath $OutputFile -append
										"`n" | Out-File -FilePath $OutputFile -append

										# Power Management Settings
										#  ENABLED  and ENABLED:  PnPCapabilities = 0x0  (0)
										#  ENABLED  and DISABLED:  PnPCapabilities = 0x10 (16)
										#  DISABLED and DISABLED:  PnPCapabilities = 0x18 (24)
										$networkAdapterPnPCapabilities = (Get-ItemProperty -Path $childNicSettingsPath).PnPCapabilities
										if ($networkAdapterPnPCapabilities -eq $null)
										{
											"Setting Name   : `"Allow the computer to turn off this device to save power`"" | Out-File -FilePath $OutputFile -append
											"Setting Status : ENABLED" | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append	
											"Setting Name   : `"Allow this device to wake the computer`"" | Out-File -FilePath $OutputFile -append
											"Setting Status : ENABLED" | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append	
											"PnPCapabilities registry value: Does not exist." | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append
										}
										if ($networkAdapterPnPCapabilities -eq 0)
										{
											"Setting Name   : `"Allow the computer to turn off this device to save power`"" | Out-File -FilePath $OutputFile -append
											"Setting Status : ENABLED" | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append	
											"Setting Name   : `"Allow this device to wake the computer`"" | Out-File -FilePath $OutputFile -append
											"Setting Status : ENABLED" | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append	
											"PnPCapabilities registry value: $networkAdapterPnPCapabilities" | Out-File -FilePath $OutputFile -append							
										}
										elseif ($networkAdapterPnPCapabilities -eq 16)
										{
											"Setting Name   : `"Allow the computer to turn off this device to save power`"" | Out-File -FilePath $OutputFile -append
											"Setting Status : ENABLED" | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append	
											"Setting Name   : `"Allow this device to wake the computer`"" | Out-File -FilePath $OutputFile -append
											"Setting Status : DISABLED" | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append	
											"PnPCapabilities registry value: $networkAdapterPnPCapabilities" | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append		
										}
										elseif ($networkAdapterPnPCapabilities -eq 24)
										{
											"Setting Name   : `"Allow the computer to turn off this device to save power`"" | Out-File -FilePath $OutputFile -append
											"Setting Status : DISABLED" | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append	
											"Setting Name   : `"Allow this device to wake the computer`"" | Out-File -FilePath $OutputFile -append
											"Setting Status : DISABLED" | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append	
											"PnPCapabilities registry value: $networkAdapterPnPCapabilities" | Out-File -FilePath $OutputFile -append
											"`n" | Out-File -FilePath $OutputFile -append		
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append

	



	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Firmware Versions" 									| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"[info] Firmware Versions section"  | WriteTo-StdOut 
	"`n" | Out-File -FilePath $OutputFile -append	
	$regkeySamFirmware = "HKLM:\SYSTEM\CurrentControlSet\Control\FirmwareResources\{512B1F42-CCD2-403B-8118-2F54353A1226}"
	If (test-path $regkeySamFirmware)
	{
		$regvalueSamFirmwareFilename = Get-ItemProperty -path $regkeySamFirmware -name "Filename" -ErrorAction SilentlyContinue
		if ($regvalueSamFirmwareFilename -ne $null)
		{
			$regvalueSamFirmwareFilename = $regvalueSamFirmwareFilename.Filename
			$regvalueSamFirmwareFileNameLatest = "SamFirmware.3.9.350.0.cap"
		}
		$regvalueSamFirmwareVersion = Get-ItemProperty -path $regkeySamFirmware -name "Version" -ErrorAction SilentlyContinue
		if ($regvalueSamFirmwareVersion -ne $null)
		{
			$regvalueSamFirmwareVersion = $regvalueSamFirmwareVersion.Version
			"Surface Pro System Aggregator Firmware"									| Out-File -FilePath $OutputFile -append
			"  SamFirmware Installed Version   : $regvalueSamFirmwareFileName"			| Out-File -FilePath $OutputFile -append
			"  SamFirmware Recommended Version : $regvalueSamFirmwareFileNameLatest"	| Out-File -FilePath $OutputFile -append
			if ($regvalueSamFirmwareVersion -lt 50922320)	# Hex 0x03090350
			{
				"  The installed file version is older than the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
			}
			elseif ($regvalueSamFirmwareVersion -eq 50922320)	# Hex 0x03090350
			{
				"  The installed file version matches the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
			}
			elseif ($regvalueSamFirmwareVersion -gt 50922320)	# Hex 0x03090350
			{
				"  The installed file version is newer than the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
			}
		}
	}
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append


	$regkeyECFirmware = "HKLM:\SYSTEM\CurrentControlSet\Control\FirmwareResources\{52D9DA80-3D55-47E4-A9ED-D538A9B88146}"
	If (test-path $regkeyECFirmware)
	{
		$regvalueECFirmwareFileName = Get-ItemProperty -path $regkeyECFirmware -name "FileName" -ErrorAction SilentlyContinue
		if ($regvalueECFirmwareFileName -ne $null)
		{
			$regvalueECFirmwareFileName = $regvalueECFirmwareFileName.FileName
			$regvalueECFirmwareFileNameLatest = "ECFirmware.38.6.50.0.cap"
		}
		$regvalueECFirmwareVersion = Get-ItemProperty -path $regkeyECFirmware -name "Version" -ErrorAction SilentlyContinue
		if ($regvalueECFirmwareVersion -ne $null)
		{
			$regvalueECFirmwareVersion = $regvalueECFirmwareVersion.Version
			"Surface Pro Embedded Controller Firmware"							| Out-File -FilePath $OutputFile -append
			"  ECFirmware Installed Version   : $regvalueECFirmwareFileName"		| Out-File -FilePath $OutputFile -append
			"  ECFirmware Recommended Version : $regvalueECFirmwareFileNameLatest"	| Out-File -FilePath $OutputFile -append
			if ($regvalueECFirmwareVersion -lt 3671632)	# Hex 0x00380650
			{
				"  The installed firmware version is older than the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
			}
			elseif ($regvalueECFirmwareVersion -eq 3671632)	# Hex 0x00380650
			{
				"  The installed firmware version matches the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
			}
			elseif ($regvalueECFirmwareVersion -gt 3671632)	# Hex 0x00380650
			{
				"  The installed firmware version is newer than the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
			}
		}
	}
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append

	

	$regkeyUEFI = "HKLM:\SYSTEM\CurrentControlSet\Control\FirmwareResources\{5A2D987B-CB39-42FE-A4CF-D5D0ABAE3A08}"
	If (test-path $regkeyUEFI)
	{
		$regvalueUEFIFileName = Get-ItemProperty -path $regkeyUEFI -name "FileName" -ErrorAction SilentlyContinue
		if ($regvalueUEFIFileName -ne $null)
		{
			$regvalueUEFIFileName = $regvalueUEFIFileName.FileName
			$regvalueUEFIFileNameLatest = "UEFI.3.10.250.0.cap"
		}
		
		$regvalueUEFIVersion = Get-ItemProperty -path $regkeyUEFI -name "Version" -ErrorAction SilentlyContinue
		if ($regvalueUEFIVersion -ne $null)
		{
			$regvalueUEFIVersion  = $regvalueUEFIVersion.Version
			"Surface Pro UEFI"										| Out-File -FilePath $OutputFile -append
			"  UEFI Installed Version   : $regvalueUEFIFileName"		| Out-File -FilePath $OutputFile -append
			"  UEFI Recommended Version : $regvalueUEFIFileNameLatest"	| Out-File -FilePath $OutputFile -append
			if ($regvalueUEFIVersion -lt 50987258)	# Hex 0x030a00fa
			{
				"  The installed firmware version is older than the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
			}
			elseif ($regvalueUEFIVersion -eq 50987258)	# Hex 0x030a00fa
			{
				"  The installed firmware version matches the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
			}
			elseif ($regvalueUEFIVersion -gt 50987258)	# Hex 0x030a00fa
			{
				"  The installed firmware version is newer than the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
			}
		}
	}
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append



	$regkeyTouchFirmware = "HKLM:\SYSTEM\CurrentControlSet\Control\FirmwareResources\{E5FFF56F-D160-4365-9E21-22B06F6746DD}"
	$regvalueTouchFirmwareFileName = Get-ItemProperty -path $regkeyTouchFirmware -name "FileName" -ErrorAction SilentlyContinue
	if ($regvalueTouchFirmwareFileName -ne $null)
	{
		$regvalueTouchFirmwareFileName = $regvalueTouchFirmwareFileName.FileName
		$regvalueTouchFirmwareFileNameLatest = "TouchFirmware.426.27.66.0.cap"
	}
	$regvalueTouchFirmwareVersion = Get-ItemProperty -path $regkeyTouchFirmware -name "Version" -ErrorAction SilentlyContinue
	if ($regvalueTouchFirmwareVersion -ne $null)
	{
		$regvalueTouchFirmwareVersion = $regvalueTouchFirmwareVersion.Version
		"Surface Pro Touch Controller Firmware"										| Out-File -FilePath $OutputFile -append
		"  TouchFirmware Installed Version   : $regvalueTouchFirmwareFileName"			| Out-File -FilePath $OutputFile -append
		"  TouchFirmware Recommended Version : $regvalueTouchFirmwareFileNameLatest"	| Out-File -FilePath $OutputFile -append
		if ($regvalueTouchFirmwareVersion -lt 27925314)	# Hex 0x01aa1b42
		{
			"  The installed firmware version is older than the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
		}
		elseif ($regvalueTouchFirmwareVersion -eq 27925314)	# Hex 0x01aa1b42
		{
			"  The installed firmware version matches the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
		}
		elseif ($regvalueTouchFirmwareVersion -gt 27925314)	# Hex 0x01aa1b42
		{
			"  The installed firmware version is newer than the firmware update from 09.09.14."	| Out-File -FilePath $OutputFile -append
		}
	}
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"---------------------------------------" | Out-File -FilePath $OutputFile -append	
	"Please refer to the following articles:"	| Out-File -FilePath $OutputFile -append
	"---------------------------------------" | Out-File -FilePath $OutputFile -append	
	"Public Content:"	| Out-File -FilePath $OutputFile -append
	"`"Surface Pro 3, Surface Pro 2, and Surface Pro firmware and driver packs`""	| Out-File -FilePath $OutputFile -append
	"http://www.microsoft.com/en-us/download/details.aspx?id=38826" 	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Internal Content:"	| Out-File -FilePath $OutputFile -append
	"`"2961421 - Surface: How to check firmware versions`""	| Out-File -FilePath $OutputFile -append
	"https://vkbexternal.partners.extranet.microsoft.com/VKBWebService/ViewContent.aspx?scid=B;EN-US;2961421"	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append

	



	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Connected Standby Status" 								| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append	
	"[info] Connected Standby Status section"  | WriteTo-StdOut 
	# Check for HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Power "CsEnabled" = dword:00000000
	$regkeyPower = "HKLM:\SYSTEM\CurrentControlSet\Control\Power"
	If (test-path $regkeyPower)
	{
		"[info] Power regkey exists"  | WriteTo-StdOut 
		$regvaluePowerCsEnabled = Get-ItemProperty -path $regkeyPower -name "CsEnabled" -ErrorAction SilentlyContinue
		if ($regvaluePowerCsEnabled -ne $null)
		{
			$regvaluePowerCsEnabled = $regvaluePowerCsEnabled.CsEnabled
			"[info] Connected Standby registry value exists: $regvaluePowerCsEnabled"  | WriteTo-StdOut 
			if ($regvaluePowerCsEnabled -eq 1)
			{
				"Connected Standby is currently: ENABLED"	| Out-File -FilePath $OutputFile -append
				"CsEnabled = 1"								| Out-File -FilePath $OutputFile -append
			}
			else
			{
				"Connected Standby is currently: DISABLED"	| Out-File -FilePath $OutputFile -append
				"CsEnabled = $regvaluePowerCsEnabled"		| Out-File -FilePath $OutputFile -append
				"CsEnabled should be enabled (set to 1)."	| Out-File -FilePath $OutputFile -append
			}
		}
		"`n" | Out-File -FilePath $OutputFile -append
		"`n" | Out-File -FilePath $OutputFile -append
		
		
		# Checking for Hyper-V
		#
		# Win32_ComputerSystem class
		# http://msdn.microsoft.com/en-us/library/aa394102(v=vs.85).aspx
		#
		"[info] Checking for Windows Optional Feature (client SKUs) or Hyper-V Role (server SKUs)"  | WriteTo-StdOut 
		if ($domainRole -gt 1) 
		{ #Server
			$HyperV = Get-WindowsFeature | Where-Object {($_.installed -eq $true) -and ($_.DisplayName -eq "Hyper-V")}
			If ($HyperV -ne $null)
			{
				"Hyper-V Role: Installed"	| Out-File -FilePath $OutputFile -append
			}
			else
			{
				"Hyper-V Role: Not Installed"	| Out-File -FilePath $OutputFile -append
			}
		}
		else
		{ #Client
			$HypervClient = Get-WindowsOptionalFeature -online | Where-Object {($_.FeatureName -eq "Microsoft-Hyper-V")}
			if ($HyperVClient.State -eq "Enabled")
			{
				"Windows Optional Feature `"Client Hyper-V`": Installed"	| Out-File -FilePath $OutputFile -append
			}
			else
			{
				"Windows Optional Feature `"Client Hyper-V`": Not Installed"	| Out-File -FilePath $OutputFile -append
			}
		}
	}
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"--------------------------------------" | Out-File -FilePath $OutputFile -append	
	"Please refer to the following article:"	| Out-File -FilePath $OutputFile -append
	"--------------------------------------" | Out-File -FilePath $OutputFile -append	
	"Public Content:" | Out-File -FilePath $OutputFile -append
	"`"2973536 - Connected Standby is not available when the Hyper-V role is enabled`"" | Out-File -FilePath $OutputFile -append
	"http://support.microsoft.com/kb/2973536/EN-US" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append



	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Connected Standby Hibernation Configuration" 			| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append	
	"[info] Connected Standby Hibernation Configuration section"  | WriteTo-StdOut 
	#
	# Connected Standby Battery Saver Timeout
	#
	"Connected Standby: Battery Saver Timeout"	| Out-File -FilePath $OutputFile -append
	$regkeyCsBsTimeout = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\381b4222-f694-41f0-9685-ff5bb260df2e\e73a048d-bf27-4f12-9731-8b2076e8891f\7398e821-3937-4469-b07b-33eb785aaca1"
	If (test-path $regkeyCsBsTimeout)
	{
		$regvalueCsBsTimeoutACSettingIndexRecommended = 14400
		$regvalueCsBsTimeoutACSettingIndex = Get-ItemProperty -path $regkeyCsBsTimeout -name "ACSettingIndex" -ErrorAction SilentlyContinue
		if ($regvalueCsBsTimeoutACSettingIndex -ne $null)
		{
			$regvalueCsBsTimeoutACSettingIndex = $regvalueCsBsTimeoutACSettingIndex.ACSettingIndex
			if ($regvalueCsBsTimeoutACSettingIndex -ne $regvalueCsBsTimeoutACSettingIndexRecommended)
			{
				"  ACSettingIndex (Current Setting: Not Optimal)      = $regvalueCsBsTimeoutACSettingIndex" | Out-File -FilePath $OutputFile -append
			}
			else
			{
				"  ACSettingIndex (Current Setting: No Action Needed) = $regvalueCsBsTimeoutACSettingIndex" | Out-File -FilePath $OutputFile -append				
			}
		}
		else
		{
			"  ACSettingIndex registry value does not exist."	| Out-File -FilePath $OutputFile -append
		}
		
		$regvalueCsBsTimeoutDCSettingIndexRecommended = 14400
		$regvalueCsBsTimeoutDCSettingIndex = Get-ItemProperty -path $regkeyCsBsTimeout -name "DCSettingIndex" -ErrorAction SilentlyContinue
		if ($regvalueCsBsTimeoutDCSettingIndex -ne $null)
		{
			$regvalueCsBsTimeoutDCSettingIndex = $regvalueCsBsTimeoutDCSettingIndex.DCSettingIndex
			if ($regvalueCsBsTimeoutDCSettingIndex -ne $regvalueCsBsTimeoutDCSettingIndexRecommended)
			{
				"  DCSettingIndex (Current Setting: Not Optimal)      = $regvalueCsBsTimeoutDCSettingIndex"			| Out-File -FilePath $OutputFile -append
				#"Connected Standby Battery Saver Timeout: DCSettingIndex (Recommended Setting) = $regvalueCsBsTimeoutDCSettingIndexRecommended"	| Out-File -FilePath $OutputFile -append
			}
			else
			{
				"  DCSettingIndex (Current Setting: No Action Needed) = $regvalueCsBsTimeoutDCSettingIndex"			| Out-File -FilePath $OutputFile -append				
			}
		}
		else
		{
			"Connected Standby Battery Saver Timeout DCSettingIndex registry value does not exist."	| Out-File -FilePath $OutputFile -append
		}
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append



	#
	# Connected Standby Battery Saver Trip Point
	#
	"Connected Standby: Battery Saver Trip Point"	| Out-File -FilePath $OutputFile -append
	$regkeyCsBsTripPoint = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\381b4222-f694-41f0-9685-ff5bb260df2e\e73a048d-bf27-4f12-9731-8b2076e8891f\1e133d45-a325-48da-8769-14ae6dc1170b"
	If (test-path $regkeyCsBsTripPoint)
	{
		$regvalueCsBstpACSettingIndexRecommended = 100
		$regvalueCsBstpACSettingIndex = Get-ItemProperty -path $regkeyCsBsTripPoint -name "ACSettingIndex" -ErrorAction SilentlyContinue
		if ($regvalueCsBstpACSettingIndex -ne $null)	
		{
			$regvalueCsBstpACSettingIndex = $regvalueCsBstpACSettingIndex.ACSettingIndex
			if ($regvalueCsBstpACSettingIndex -ne $regvalueCsBstpACSettingIndexRecommended)
			{
				"  ACSettingIndex (Current Setting: Not Optimal)      = $regvalueCsBstpACSettingIndex" | Out-File -FilePath $OutputFile -append
			}
			else
			{
				"  ACSettingIndex (Current Setting: No Action Needed) = $regvalueCsBstpACSettingIndex" | Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"Connected Standby Battery Saver Trip Point: ACSettingIndex registry value does not exist."	| Out-File -FilePath $OutputFile -append
		}
		
		
		$regvalueCsBstpDCSettingIndex = Get-ItemProperty -path $regkeyCsBsTripPoint -name "DCSettingIndex" -ErrorAction SilentlyContinue	
		if ($regvalueCsBstpDCSettingIndex -ne $null)	
		{
			$regvalueCsBstpDCSettingIndexRecommended = 100
			$regvalueCsBstpDCSettingIndex = $regvalueCsBstpDCSettingIndex.DCSettingIndex
			if ($regvalueCsBstpDCSettingIndex -ne $regvalueCsBstpDCSettingIndexRecommended)
			{
				"  DCSettingIndex (Current Setting: Not Optimal)      = $regvalueCsBstpDCSettingIndex"  | Out-File -FilePath $OutputFile -append
			}
			else
			{
				"  DCSettingIndex (Current Setting: No Action Needed) = $regvalueCsBstpDCSettingIndex"  | Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"Connected Standby Battery Saver Trip Point DCSettingIndex registry value does not exist."	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"Connected Standby Battery Saver Trip Point registry key does not exist: $regkeyCsBsTripPoint"	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append


	
	#
	# Connected Standby Battery Saver Action
	#
	"Connected Standby: Battery Saver Action"	| Out-File -FilePath $OutputFile -append
	$regkeyCsBsAction = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\381b4222-f694-41f0-9685-ff5bb260df2e\e73a048d-bf27-4f12-9731-8b2076e8891f\c10ce532-2eb1-4b3c-b3fe-374623cdcf07"
	If (test-path $regkeyCsBsAction)
	{
		$regvalueCsBsActionACSettingIndex = Get-ItemProperty -path $regkeyCsBsAction -name "ACSettingIndex" -ErrorAction SilentlyContinue
		if ($regvalueCsBsActionACSettingIndex -ne $null)
		{
			$regvalueCsBsActionACSettingIndexRecommended = 1
			$regvalueCsBsActionACSettingIndex = $regvalueCsBsActionACSettingIndex.ACSettingIndex
			if ($regvalueCsBsActionACSettingIndex -ne $regvalueCsBsActionACSettingIndexRecommended)
			{
				"  ACSettingIndex (Current Setting: Not Optimal)      = $regvalueCsBsActionACSettingIndex"		| Out-File -FilePath $OutputFile -append
			}
			else
			{
				"  ACSettingIndex (Current Setting: No Action Needed) = $regvalueCsBsActionACSettingIndex"		| Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"  ACSettingIndex registry value does not exist."	| Out-File -FilePath $OutputFile -append
		}

		$regvalueCsBsActionDCSettingIndex = Get-ItemProperty -path $regkeyCsBsAction -name "DCSettingIndex" -ErrorAction SilentlyContinue
		if ($regvalueCsBsActionDCSettingIndex -ne $null)
		{
			$regvalueCsBsActionDCSettingIndexRecommended = 1
			$regvalueCsBsActionDCSettingIndex = $regvalueCsBsActionDCSettingIndex.DCSettingIndex
			if ($regvalueCsBsActionDCSettingIndex -ne $regvalueCsBsActionDCSettingIndexRecommended)
			{
				"  DCSettingIndex (Current Setting: Not Optimal)      = $regvalueCsBsActionDCSettingIndex"  | Out-File -FilePath $OutputFile -append
			}
			else
			{
				"  DCSettingIndex (Current Setting: No Action Needed) = $regvalueCsBsActionDCSettingIndex"  | Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"  DCSettingIndex registry value does not exist."	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"Connected Standby Battery Saver Action registry key does not exist: $regkeyCsBsAction"	| Out-File -FilePath $OutputFile -append
	}
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"--------------------------------------" | Out-File -FilePath $OutputFile -append	
	"Please refer to the following article:"	| Out-File -FilePath $OutputFile -append
	"--------------------------------------" | Out-File -FilePath $OutputFile -append	
	"Internal Content:" | Out-File -FilePath $OutputFile -append
	"`"Surface Pro 3 does not hibernate after 4 hours in connected standby`""	| Out-File -FilePath $OutputFile -append
	"https://vkbexternal.partners.extranet.microsoft.com/VKBWebService/ViewContent.aspx?scid=KB;EN-US;2998588" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append

	
	
	#
	# Secure Boot Overview
	# http://technet.microsoft.com/en-us/library/hh824987.aspx
	#
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Secure Boot Configuration" 							| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append	
	"[info] Secure Boot section"  | WriteTo-StdOut 

	
	"------------------------------"	| Out-File -FilePath $OutputFile -append
	"Secure Boot Status"				| Out-File -FilePath $OutputFile -append
	"  (using Confirm-SecureBootUEFI)"	| Out-File -FilePath $OutputFile -append
	"------------------------------"	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	# Determine if SecureBoot is enabled.
	#
	$secureBootEnabled = $false
	If ((Confirm-SecureBootUEFI) -eq $true)
	{
		$secureBootEnabled = $true
		"Secure Boot: ENABLED"	| Out-File -FilePath $OutputFile -append
	}
	else
	{
		"Secure Boot: DISABLED"	| Out-File -FilePath $OutputFile -append		
	}
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append


	"------------------------------"	| Out-File -FilePath $OutputFile -append
	"Secure Boot Policy UEFI"			| Out-File -FilePath $OutputFile -append
	"  (using Get-SecureBootPolicy)"	 	| Out-File -FilePath $OutputFile -append
	"------------------------------"	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append	
	# Determine what policy is in use for SecureBootUEFI with Get-SecureBootPolicy
	#
	if ($secureBootEnabled)
	{
		$GUID = Get-SecureBootPolicy
		$DebugPolicyString = $Guid.Publisher.ToString()
		$DefaultPolicy = "77FA9ABD-0359-4D32-BD60-28F4E78F784B"
		$DefaultPolicyARM = "77FA9ABD-0359-4D32-BD60-28F4E78F784B"
		$DebugPolicy = "0CDAD82E-D839-4754-89A1-844AB282312B"

		"SecureBoot Policy Mode GUID: $DebugPolicyString" | Out-File -FilePath $OutputFile -append
		if($DebugPolicyString -match $DefaultPolicy) {
			"SecureBoot Policy Mode     : PRODUCTION" | Out-File -FilePath $OutputFile -append
		}
		elseif($DebugPolicyString -match $DefaultPolicyARM) {
			"SecureBoot Policy Mode     : PRODUCTION" | Out-File -FilePath $OutputFile -append
		}
		elseif($DebugPolicyString -match $DebugPolicy) {
			"SecureBoot Policy Mode     : DEBUG" | Out-File -FilePath $OutputFile -append
		}
		else {
			"SecureBoot Policy Mode: Invalid Policy $DebugPolicyString" 
		}
	}
	"`n" | Out-File -FilePath $OutputFile -append	
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append	

	

	"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	"Secure Boot Policy UEFI"								| Out-File -FilePath $OutputFile -append
	"  Using `"Get-SecureBootUefi –Name PK | fl *`")"		| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	# Get-SecureBootUEFI
	"Get-SecureBootUefi –Name PK | fl *" | Out-File -FilePath $OutputFile -append
	Get-SecureBootUefi –Name PK | fl *	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	

	"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	"Secure Boot Policy UEFI"								| Out-File -FilePath $OutputFile -append
	"  Using Output of `"Get-SecureBootUEFI -Name PK -OutputFilePath SecureBootPk.tmp`""	| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	Get-SecureBootUEFI -Name PK -OutputFilePath SecureBootPk.tmp
	$pk = (Get-content SecureBootPk.tmp)
	$pk | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append

	
	

	"===================================================="	| Out-File -FilePath $OutputFile -append
	"WMI Class Information" 								| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append	

	"------------------------------"	| Out-File -FilePath $OutputFile -append
	"WMI Class: win32_baseboard"		| Out-File -FilePath $OutputFile -append
	"------------------------------"	| Out-File -FilePath $OutputFile -append
	$baseboard = Get-WmiObject -Class "win32_baseboard"
	$baseboard | fl *   | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append	
	"`n" | Out-File -FilePath $OutputFile -append	
	"`n" | Out-File -FilePath $OutputFile -append	
	
	"------------------------------"	| Out-File -FilePath $OutputFile -append
	"WMI Class: win32_battery"			| Out-File -FilePath $OutputFile -append
	"------------------------------"	| Out-File -FilePath $OutputFile -append
	$battery = Get-WmiObject -Class "win32_battery"
	$battery | fl *   | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append	
	"`n" | Out-File -FilePath $OutputFile -append	
	"`n" | Out-File -FilePath $OutputFile -append	
	
	
	"------------------------------"	| Out-File -FilePath $OutputFile -append
	"WMI Class: win32_bios"				| Out-File -FilePath $OutputFile -append
	"------------------------------"	| Out-File -FilePath $OutputFile -append
	$bios = Get-WmiObject -Class "win32_bios"
	$bios | fl *   | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append	
	"`n" | Out-File -FilePath $OutputFile -append	
	"`n" | Out-File -FilePath $OutputFile -append	
	
	
	"------------------------------"	| Out-File -FilePath $OutputFile -append
	"WMI Class: win32_computersystem"	| Out-File -FilePath $OutputFile -append
	"------------------------------"	| Out-File -FilePath $OutputFile -append
	$computersystem = Get-WmiObject -Class "win32_computersystem"
	$computersystem | fl *   | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append	
	"`n" | Out-File -FilePath $OutputFile -append	
	"`n" | Out-File -FilePath $OutputFile -append	
	

	CollectFiles -filesToCollect $outputFile -fileDescription "Surface Pro 3 Information" -SectionDescription $sectionDescription

	
	
	
	
	
	
	
	


	$outputFile= $Computername + "_SurfacePro3_binary_versions.TXT"

	function componentSection
	{
		param 
		(
			[string]$component
		)
		$columnWidth = 52
		$componentLen = $component.length
		[int]$headerPrefix = 10
		$buffer = ($columnWidth - $componentLen - $headerPrefix)
		"-" * $headerPrefix + $component + "-" * $buffer	| Out-File -FilePath $OutputFile -append
	}


	function fileVersion
	{
		param
		(
			[string]$filename
		)

		$filenameLen = $filename.length
		$filenameExtPosition = $filenameLen - 4
		
		If ($filename.Substring($filenameExtPosition,4) -match ".sys")
		{
			$wmiQuery = "select * from cim_datafile where name='c:\\windows\\system32\\drivers\\" + $filename + "'" 
		}
		elseif ($filename.Substring($filenameExtPosition,4) -match ".dll")
		{
			$wmiQuery = "select * from cim_datafile where name='c:\\windows\\system32\\" + $filename + "'" 
		}
		elseif ($filename -match "explorer.exe")
		{
			$wmiQuery = "select * from cim_datafile where name='c:\\windows\\" + $filename + "'" 
		}
		elseif ($filename.Substring($filenameExtPosition,4) -match ".exe")
		{
			$wmiQuery = "select * from cim_datafile where name='c:\\windows\\system32\\" + $filename + "'" 
		}

		$fileObj = Get-WmiObject -query $wmiQuery
		$filenameLength = $filename.Length
		$columnLen = 35
		if (($filenameLength + 3) -ge ($columnLen))
		{
			$columnLen = $filenameLength + 3
			$columnDiff = $columnLen - $filenameLength
			$columnPrefix = 3
			$fileLine = " " * ($columnPrefix) + $filename + " " * ($columnDiff) + $fileObj.version
		}
		else
		{
			$columnDiff = $columnLen - $filenameLength
			$columnPrefix = 3
			$fileLine = " " * ($columnPrefix) + $filename + " " * ($columnDiff) + $fileObj.version
		}
		
		return $fileLine
	}


	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Surface Pro 3 Binary Versions"							| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Overview"												| Out-File -FilePath $OutputFile -append
	"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
	"   1. Bluetooth"										| Out-File -FilePath $OutputFile -append
	"   3. Keyboards"										| Out-File -FilePath $OutputFile -append
	"   4. Network Adapters"								| Out-File -FilePath $OutputFile -append
	"   5. System Devices"									| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"[info] Surface Pro 3 Binaries"  | WriteTo-StdOut

	"[info] Surface Pro 3 Binaries: Bluetooth"  | WriteTo-StdOut
	#componentSection -component "Bluetooth"
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Bluetooth"												| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Marvell AVASTAR Bluetooth Radio Adapter"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Bthport.sys	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Bthusb.sys	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Fsquirt.exe	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Microsoft Bluetooth Enumerator"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Bthenum.sys	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Microsoft Bluetooth LE Enumerator"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename bthLEEnum.sys	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append


	"[info] Surface Pro 3 Binaries: Human Interface Devices"  | WriteTo-StdOut
	#componentSection -component "Human Interface Devices"
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Human Interface Devices"								| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Surface Pen Driver"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename "SurfacePenDriver.sys"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename "WdfCoInstaller01011.dll"	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append


	"[info] Surface Pro 3 Binaries: Keyboards"  | WriteTo-StdOut	
	#componentSection -component "Keyboards"
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Keyboards"												| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Surface Type Cover Filter Device"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Kbdclass.sys	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Kbdhid.sys	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append


	"[info] Surface Pro 3 Binaries: Network Adapters"  | WriteTo-StdOut
	#componentSection -component "Network Adapters"
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Network Adapters"										| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"ASIX AX88772 USB2.0 to Fast Ethernet Adapter"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Ax88772.sys				| Out-File -FilePath $OutputFile -append
	fileVersion -filename WdfCoInstaller01011.dll	| Out-File -FilePath $OutputFile -append
	# File versions on SurfacePro3 as of 10.10.14: 
	# Ax88772.sys; 3.16.8.0
	# WdfCoInstaller01011.dll; 1.11.9200.16384
	"`n" | Out-File -FilePath $OutputFile -append
	"Bluetooth Device (Personal Area Network)"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Bthpan.sys			| Out-File -FilePath $OutputFile -append
	# File versions on SurfacePro3 as of 10.10.14: 
	# Bthpan.sys; 6.3.9600.16384
	"`n" | Out-File -FilePath $OutputFile -append
	"Bluetooth Device (RFCOMM Protocol TDI)"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename bthenum.sys			| Out-File -FilePath $OutputFile -append
	fileVersion -filename rfcomm.sys			| Out-File -FilePath $OutputFile -append
	# File versions on SurfacePro3 as of 10.10.14: 
	# bthenum.sys; 6.3.9600.16384
	# rfcomm.sys; 6.3.9600.16520
	"`n" | Out-File -FilePath $OutputFile -append
	"Marvell AVASTAR Wireless-AC Network Controller"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Mrvlpcie8897.sys				| Out-File -FilePath $OutputFile -append
	fileVersion -filename Vwifibus.sys					| Out-File -FilePath $OutputFile -append
	fileVersion -filename WiFiCLass.sys					| Out-File -FilePath $OutputFile -append
	# File versions on SurfacePro3 as of 10.10.14: 
	# Mrvlpcie8897.sys; MP107
	# Vwifibus.sys; 6.3.9600.16384
	# WiFiCLass.sys; 6.3.9715
	"`n" | Out-File -FilePath $OutputFile -append
	"Microsoft Kernel Debug Network Adapter"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Kdnic.sys				| Out-File -FilePath $OutputFile -append
	# File versions on SurfacePro3 as of 10.10.14: 
	# Kdnic.sys; 6.01.00.0000
	"`n" | Out-File -FilePath $OutputFile -append
	"Microsoft Wi-Fi Direct Virtual Adapter"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename Vwifimp.sys			| Out-File -FilePath $OutputFile -append
	# File versions on SurfacePro3 as of 10.10.14: 
	# Vwifimp.sys; 6.3.9600.17111
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append


	"[info] Surface Pro 3 Binaries: System Devices"  | WriteTo-StdOut
	#componentSection -component "System Devices"
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"System Devices"										| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Surface Accessory Device"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename SurfaceAccessoryDevice.sys	| Out-File -FilePath $OutputFile -append
	#SurfaceAccessoryDevice.sys; 2.0.1012.0
	"`n" | Out-File -FilePath $OutputFile -append
	"Surface Cover Telemetry"	| Out-File -FilePath $OutputFile -append
	$filename = "SurfaceCoverTelemetry.dll"
	$wmiQuery = "select * from cim_datafile where name='c:\\windows\\system32\\drivers\\umdf\\" + $filename + "'"
	$fileObj = Get-WmiObject -query $wmiQuery
	$filenameLength = $filename.Length
	$columnLen = 35
	$columnDiff = $columnLen - $filenameLength
	$columnPrefix = 3
	$fileLine = " " * ($columnPrefix) + $filename + " " * ($columnDiff) + $fileObj.version
	$fileLine | Out-File -FilePath $OutputFile -append
	#SurfaceCoverTelemetry.dll (windir\system32\drivers\umdf); 2.0.722.0
	fileVersion -filename WUDFRd.sys	| Out-File -FilePath $OutputFile -append
	#WUDFRd.sys; 6.3.9600.17195
	"`n" | Out-File -FilePath $OutputFile -append
	"Surface Display Calibration"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename SurfaceDisplayCalibration.sys	| Out-File -FilePath $OutputFile -append
	#SurfaceDisplayCalibration.sys; 2.0.1002.0
	"`n" | Out-File -FilePath $OutputFile -append
	"Surface Home Button"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename SurfaceCapacitiveHomeButton.sys	| Out-File -FilePath $OutputFile -append
	#SurfaceCapacitiveHomeButton.sys; 2.0.358.0
	"`n" | Out-File -FilePath $OutputFile -append
	"Surface Integration"	| Out-File -FilePath $OutputFile -append
	fileVersion -filename SurfaceIntegrationDriver.sys	| Out-File -FilePath $OutputFile -append
	#SurfaceIntegrationDriver.sys; 2.0.1102.0
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append

	CollectFiles -filesToCollect $outputFile -fileDescription "Surface Pro 3 Binaries Information" -SectionDescription $sectionDescription

	
	#----------Registry
	$OutputFile= $Computername + "_SurfacePro3_reg_output.TXT"
	$CurrentVersionKeys =   "HKLM\SYSTEM\CurrentControlSet\Enum\UEFI",
							"HKLM\SYSTEM\CurrentControlSet\Control\Power",
							"HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "Surface Pro 3 Registry OutpuT" -SectionDescription $sectionDescription
}

# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAdsTEZV4p9RyG+
# joEj2MyF2s8UNCiKEp8v2/BW6qbHHqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgxBVN5eEK
# 5CKcN2g7OrhiWafLnEXPeJCOCcBoPiuWox8wOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAJsmQoEKE95dnzMIVfHNe18UqDeg7m2bS6sb2m9797e+qlNvQQBOuA6S
# +WbiG+f/eIb6rjPmgRXWBBMieL98ZRvvmemhZpHbp1vmmjXKDxHPIlOHmRwAvyYO
# mu50UvcMpoAy6db4B6Ty5Uc0JJ04Fo2og6CcyoYCNfGIl6Z3figp1XIRqN5NU8tq
# d7dxuajlsPN3S4/8ydiajere0cRe9AuKw5JFp8Zjzt+AWZ5eN3FDl97NLAcPEQNh
# 0iqYixLEyV47DDiYyBwwwExTnpevXERB1ViGMVL9vNJ3Qpfh10MXeFC4ldrER52f
# Jfkvpn7l6RAKUD49kVYeJqpdnrYKiTKhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgFC0HVIAO+afw4QJgMX/YFZkce5WfEWg4P/MBXPQRtCoCBmCJ+dKg
# vBgTMjAyMTA1MTkyMjI0NTUuMzk5WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ2
# MkYtRTMxOS0zRjIwMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFYcFoi976W5gMAAAAAAVgwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE0WhcNMjIwNDExMTkwMjE0WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ2MkYtRTMxOS0zRjIw
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoR8Ll2D1q7DQoAUbC/XvIwUbxJ+qBRQU
# LwPPBryaumzR7KFFDY2/0rv+zP99UTWj/V9mnirhIaK1yyM8a06eNbHjlUgVMg1C
# l2g6Gaw92cXLeAFekwa1N9eouedQTj5WYoLa8CE5nTpTq+3kJzRwmioQm3M5ZHAR
# rPwGhfacJfVEFeQfc+IC7u1Ym/dXzOFFI8sWZ6In4IjBrLTgBSCavBcRAe8keBvo
# +IsLGATZUAEIM1PkJXKJ41qlxmIrHXpBsOV7so7CSMwQgqRzFH7fZ0My3MK2khQO
# CsrGaPH4ab3iMeJ6iE4dS6GXe7eGUBh+/ZID/zpPVQ0CIFCDda73GwIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFEtw2Rt9nRwYH+7nfqB7kyfTovlYMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBADnfKANai9CuHx+6WI1dbQJQFPN8DhKXiH4g8SHmU12u
# EMXLpPgwD2O6nXPOUWSlitRzSxN9AIA6cCOa6c+CeZpLltJ/ZUfwyDfhTaqA8sic
# wCQZoGz8HNpsnrlgp7U/kgpk3taPZtF8IrTcRLyRLuDphAfruLEwJAIsOt5YMoli
# w2zRyE2kk4DPIl4Z/JFR75NRRsXCOwL/XwqZg4NWClFJhnHRbuOsaqUlUR6G7ClI
# iwY5gIEyckM10qc/7XcKDrxxW0I1fqQl29QUfRmK48yUFgPsasI+oBGVKf6/F98y
# K+7YMwkkuR7LDFJ8PnawNX40F/kieK4oVwT3LSb2baMwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ2MkYtRTMxOS0z
# RjIwMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQCpyStzGufRCyGm6jOOn6X4NJ80v6CBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9+azAiGA8y
# MDIxMDUxOTE2MDkxNVoYDzIwMjEwNTIwMTYwOTE1WjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT35rAgEAMAoCAQACAgyqAgH/MAcCAQACAhEVMAoCBQDkUM/rAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAPYKNTrA4Z5n2byC1KZ6daaqIwTbC
# 5ysce8Ylar2oI9Qto6sYab7Ziz7B+TgUhJudvxk2LE6IzItvn2PfhPlxTIBrgZdU
# Y93JcRqtOi/EYmEhywm9pylQS7RSbNZ3Mc7TB9vQ93nYX+YyOtZBVQACGqWI/DZA
# qCMQ0nbH2FJNKxUxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVhwWiL3vpbmAwAAAAABWDANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCD/2LE0
# LM85FtBH+XMZ5gnVQ8FZzzEkRo1qWG8Kl5zRgTCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIPJKM41shjWXbMpPhtriwIjhaQELqwh9H25JU1XHcNMHMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFYcFoi976W5gMA
# AAAAAVgwIgQg7DjdbVbb8vJnVqJWHDriLRBz7rRjLeDflmDsHToIV/gwDQYJKoZI
# hvcNAQELBQAEggEAL1Y8plSJQHs/V3/mU6+C7GspY2lekfaKAYYylEatB/y02scw
# zVPg8vq8yENA7PdXVJJzfkuw0+LtZjMW5YdpcrD5nsboXZdsKOPZI0PKUKAmxw9p
# 6fbzc6szjww8ZqYfnSSIndMQcwxDWEmEgTCz2JAUL0SWj4bBOpKhrueD8UIE9edw
# GJq/2Du3GojKJoOwaM6b8UnHIv/Xwa3lYYUln8bcWzz+ITEila7YCefzr2ULyrck
# S0/nYh5IjXYbyQzw3wpr7eo75IMRg+9bK8Kfsjj0qtJpRTzdiNGCjlcRsUqA3uOw
# YVZ0p/P6C55dNEHwNnkisDu26lRXXUPphOXm9g==
# SIG # End signature block
