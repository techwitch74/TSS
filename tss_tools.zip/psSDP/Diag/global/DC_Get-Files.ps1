﻿###########################################################################
# DC_Get-Files
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Collects relevant files
###########################################################################


Import-LocalizedData -BindingVariable Files -FileName DC_Get-Files -UICulture en-us

$CBSCabs = Get-ChildItem "$ENV:SystemRoot\Logs\CBS" -Exclude *.log 
Write-DiagProgress -Activity $Files.ID_Files  -Status $Files.ID_FilesCab

logstart 

foreach($cab in $CBSCabs)
    {
        $y = ((Get-Date) - $cab.CreationTime).Days
        if ($y -lt 365)
		{
			"Collecting " + $cab.FullName | WriteTo-StdOut 
			CollectFiles -filesToCollect $cab.FullName -fileDescription "CBS Cab File" -sectionDescription "CBS Information"
		}
    }

#CopyDeploymentFile Function
Function CopyDeploymentFile ($sourceFileName, $destinationFileName, $fileDescription) 
{
	
	if (test-path $sourceFileName) {
		$sourceFile = Get-Item $sourceFileName
		#copy the file only if it is not a 0KB file.
		if ($sourceFile.Length -gt 0) 
		{
			$CommandLineToExecute = "cmd.exe /c copy `"$sourceFileName`" `"$destinationFileName`""
			"Collecting " + $sourceFileName | WriteTo-StdOut 
			RunCmD -commandToRun $CommandLineToExecute -sectionDescription $sectionDescription -filesToCollect $destinationFileName -fileDescription $fileDescription
		}
	}
}

Write-DiagProgress -Activity $Files.ID_Files  -Status $Files.ID_FilesLogs
$sourceFileName = "$Env:windir\setupact.log"
$destinationFileName = $computername + "_setupact.log"
$fileDescription = "Setupact.log on Windows folder"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$Env:windir\panther\setupact.log"
$destinationFileName = $computername + "_setupact-panther.log"
$fileDescription = "Setupact.log on Windows\Panther"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$Env:windir\setupact_dpx.log"
$destinationFileName = $computername + "_setuact_dpx.log"
$fileDescription = "setupact_dpx.log on Windows folder"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$Env:windir\inf\setupapi.app.log"
$destinationFileName = $computername + "_setupapi.app.log"
$fileDescription = "setupapi.log on Windows folder"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$Env:windir\inf\setupapi.epp.log"
$destinationFileName = $computername + "_setupapi.epp.log"
$fileDescription = "setupapi.log on Windows folder"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$Env:windir\inf\setupapi.dev.log"
$destinationFileName = $computername + "_setupapi.dev.log"
$fileDescription = "setupapi.log on Windows\inf"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$Env:windir\setuperr_dpx.log"
$destinationFileName = $computername + "_setuperr_dpx.log"
$fileDescription = "setupapi.log on Windows folder"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$Env:windir\panther\setuperr.log"
$destinationFileName = $computername + "_setuperr_panther.log"
$fileDescription = "Setuperr.log on Windows\Panther"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription


$sourceFileName = "$ENV:LOCALAPPDATA\microsoft\windows\windowsupdate.log"
$destinationFileName = $computername + "_WindowsUpdatePerUser.log"
$fileDescription = "WindowsUpdate.log on $AppData"
$sectionDescription = "Windows Update Information"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$ENV:windir\windowsupdate.log"
$destinationFileName = $computername + "_WindowsUpdate.log"
$fileDescription = "WindowsUpdate.log on Windows folder"
$sectionDescription = "Windows Update Information"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$ENV:windir\SoftwareDistribution\ReportingEvents.log"
$destinationFileName = $computername + "_ReportingEvents.log"
$fileDescription = "ReportingEvents.log on Software Distribution Folder"
$sectionDescription = "Windows Update Information"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$ENV:windir\SchedLgU.txt"
$destinationFileName = $computername + "_SchedLgU.txt"
$fileDescription = "SchedLgU.txt on Windows Folder"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$ENV:windir\tasks\SchedLgU.txt"
$destinationFileName = $computername + "_SchedLgU.txt"
$fileDescription = "SchedLgU.txt on Windows\Tasks Folder"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$ENV:windir\debug\mrt.log"
$destinationFileName = $computername + "_mrt.log"
$fileDescription = "mrt.log on Windows\Debug Folder"
$sectionDescription = "System Logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$ENV:windir\Logs\CBS\cbs.log"
$destinationFileName = $computername + "_CBS.log"
$fileDescription = "CBS Log File"
$sectionDescription = "CBS Information"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$ENV:windir\Logs\CBS\CheckSUR.log"
$destinationFileName = $computername + "_CheckSUR.log"
$fileDescription = "mrt.log on Windows\CBS\Logs"
$sectionDescription = "CBS Information"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$ENV:windir\Logs\CBS\CheckSUR.persist.log"
$destinationFileName = $computername + "_CheckSUR.persist.log"
$fileDescription = "mrt.log on Windows\CBS\Logs"
$sectionDescription = "CBS Information"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$ENV:windir\system32\drivers\etc\hosts"
$destinationFileName = $computername + "_Hosts.txt"
$fileDescription = "Windows hosts file"
$sectionDescription = "Network Configuration"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

logstop