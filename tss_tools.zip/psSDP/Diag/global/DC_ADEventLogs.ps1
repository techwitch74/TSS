﻿#************************************************
# DC_ADEventLogs.PS1
# Version 1.0.1
# Date: 07-10-2009, 2020
# Author: Andre Teixeira - andret@microsoft.com
# Description: This script calls TS_GetEvents.ps1 to export AD-related event logs
#************************************************

Import-LocalizedData -BindingVariable ADEventLogsStrings

If(($OSVersion.Build -eq 2600) -or ($OSVersion.Build -eq 3790))
{
	$ExclusionList = "Application",
				 "Security",
				 "System"

	.\TS_GetEvents.ps1 -ExclusionList $ExclusionList

}
else
{
	$EventLogNames = "Active Directory Web Services",
					 "DFS Replication",
					 "Directory Service",
					 "DNS Server",
					 "File Replication Service",
					 "Microsoft-Windows-Application-Experience/Program-Inventory",
					 "Microsoft-Windows-CAPI2/Operational",
					 "Microsoft-Windows-CertificateServicesClient-CredentialRoaming/Operational",
					 "Microsoft-Windows-EnrollmentPolicyWebService/Admin",
					 "Microsoft-Windows-EnrollmentWebService/Admin",
					 "Microsoft-Windows-Folder Redirection/Operational",
					 "Microsoft-Windows-GroupPolicy/Operational",
					 "Microsoft-Windows-NetworkProfile/Operational",
					 "Microsoft-Windows-NlaSvc/Operational",
					 "Microsoft-Windows-NTLM/Operational",
					 "Microsoft-Windows-OfflineFiles/Operational",
					 "Microsoft-Windows-TerminalServices-Licensing/Admin",
					 "Microsoft-Windows-TerminalServices-Licensing/Operational",
					 "Microsoft-Windows-User Profile Service/Operational",
					 "Microsoft-Windows-Winlogon/Operational",
					 "Microsoft-Windows-Folder Redirection/Operational"
					 
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
