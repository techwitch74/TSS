#************************************************
# DC_GetSQLSetupLogs.ps1
# Version 1.0.0
# Date: 8-19-2011
# Author: Shon Hauck - Shonh@Microsoft.com
# Description: Used to Get SQL Setup Logs (Bootstrap Directory for SQL 9, 10 , 10.5, 11)
#
# Date: 4-15-2020
# Modified By: João Polisel - JPolisel@Microsoft.com
# Description: Created function Get-SqlSetupLogs to eliminate code redundancy. Added collection of Bootstrap Logs for SQL 2014 to 2019.
#
# NOTE: 
#
#************************************************

# Copyright ?2008, Microsoft Corporation. All rights reserved.

# You may use this code and information and create derivative works of it,
# provided that the following conditions are met:
# 1. This code and information and any derivative works may only be used for
# troubleshooting a) Windows and b) products for Windows, in either case using
# the Windows Troubleshooting Platform
# 2. Any copies of this code and information
# and any derivative works must retain the above copyright notice, this list of
# conditions and the following disclaimer.
# 3. THIS CODE AND INFORMATION IS PROVIDED ``AS IS'' WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. IF THIS CODE AND
# INFORMATION IS USED OR MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION
# WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER.

if($debug -eq $true){[void]$shell.popup("DC_GetSQLSetupLogs.ps1")}

Import-LocalizedData -BindingVariable GetSQLSetupLogs -FileName GetSQLSetupLogsFile -UICulture en-us

function Get-SqlSetupLogs([string]$SqlVersion)
{
	$SQLPath = (join-path ([Environment]::GetFolderPath("ProgramFiles")) "Microsoft SQL Server\$SqlVersion\Setup Bootstrap\Log")
	if($debug -eq $true){[void]$shell.popup($SQLPath)}

	if ((test-path $SQLPath) -eq $true)
		{
			if($debug -eq $true){[void]$shell.popup("Valid Path")}
			
			$OutputFileName= $ComputerName + "_SQL" + $SqlVersion + "_Bootstrap.Cab"
			if($debug -eq $true){[void]$shell.popup($OutputFileName)}

			#Create Array of Files to Collect
			[Array] $DC_GetSQLLogsOutputFiles = $SQLPath + "\*.htm"
			$DC_GetSQLLogsOutputFiles += $SQLPath + "\*.log"
			$DC_GetSQLLogsOutputFiles += $SQLPath + "\*.xml"
			$DC_GetSQLLogsOutputFiles += $SQLPath + "\*.ico"
			$DC_GetSQLLogsOutputFiles += $SQLPath + "\*.mft"
			$DC_GetSQLLogsOutputFiles += $SQLPath + "\*.Reg_"
			$DC_GetSQLLogsOutputFiles += $SQLPath + "\*.tmp"
			$DC_GetSQLLogsOutputFiles += $SQLPath + "\*.txt"

			CompressCollectFiles -filesToCollect $DC_GetSQLLogsOutputFiles -DestinationFileName $OutputFileName -fileDescription "SQL $SqlVersion Bootstrap Logs" -sectionDescription "Additional Data" -Recursive -ForegroundProcess
		}
		else
			{
				if($debug -eq $true){[void]$shell.popup("IN-Valid Path")}
			}
}

#Collect SQL 90 Setup Logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_Setup_Collect_Bootstrap_Logs -Status $GetSQLSetupLogs.ID_SQL_Setup_Collect_2005_Logs
Get-SqlSetupLogs -SqlVersion "90"

#Collect SQL 100 Setup Logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_Setup_Collect_Bootstrap_Logs -Status $GetSQLSetupLogs.ID_SQL_Setup_Collect_2008_2008R2_Logs
Get-SqlSetupLogs -SqlVersion "100"

#Collect SQL 110 Setup Logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_Setup_Collect_Bootstrap_Logs -Status $GetSQLSetupLogs.ID_SQL_Setup_Collect_2012_Logs
Get-SqlSetupLogs -SqlVersion "110"

#Collect SQL 120 Setup Logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_Setup_Collect_Bootstrap_Logs -Status $GetSQLSetupLogs.ID_SQL_Setup_Collect_2014_Logs
Get-SqlSetupLogs -SqlVersion "120"

#Collect SQL 130 Setup Logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_Setup_Collect_Bootstrap_Logs -Status $GetSQLSetupLogs.ID_SQL_Setup_Collect_2016_Logs
Get-SqlSetupLogs -SqlVersion "130"

#Collect SQL 140 Setup Logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_Setup_Collect_Bootstrap_Logs -Status $GetSQLSetupLogs.ID_SQL_Setup_Collect_2017_Logs
Get-SqlSetupLogs -SqlVersion "140"

#Collect SQL 150 Setup Logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_Setup_Collect_Bootstrap_Logs -Status $GetSQLSetupLogs.ID_SQL_Setup_Collect_2019_Logs
Get-SqlSetupLogs -SqlVersion "150"

