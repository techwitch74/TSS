
# This script has dependencies on utils_CTS and utils_DSD
#
param ( [Object[]] $instances ) 

# 2019-03-17 WalterE added Trap #_#
Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

New-Variable LOGFILE_PATH      -Scope "Global" 

#
# Function : WriteTo-LogFile
# ---------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function should is used to log progress and error messages to the ErrorloLogCollectorResults.log 
#			file and the test harness executes
# 
# Arguments:
#			String to write to file
# 
# Owner:
#			DanSha 
#
function WriteTo-LogFile($StringToWrite)
{
	$Error.Clear()           
    trap 
    {
    	"[WriteTo-LogFile] : [ERROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error 
	}

	"[{0:yyyy-MM-dd HH:mm:ss.fff}] : {1}" -f (Get-Date), $StringToWrite |  Out-File -FilePath $global:LOGFILE_PATH -Append
}

#
# Function : Write-DumpInventory
# ------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
#		    Writes an inventory of all dump files found for target instance
# 
# Arguments:
#			String to write to file
# 
# Owner:
#			DanSha 
#   
function Write-DumpInventory([string]$InstanceName, [string]$DumpDir)
{
    $Error.Clear()           
    trap 
    {
    	"[Write-DumpInventory] : [EROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error
    }
   
    if ($null -ne $InstanceName)
    {
        if ($null -ne $DumpDir)
        {
            # This collector can be configured to collect a subset of the minidumps on a given machine.  
            # As such, for debugging purposes the collector writes a dump inventory that's collected with the dump files  
            $DumpInventoryFile = "{0}_{1}_DumpInventory.log" -f $env:ComputerName, $InstanceName
            New-Item -ItemType file -Name $DumpInventoryFile -Path $PWD.Path -Force | Out-Null
            $global:LOGFILE_PATH = Join-Path -Path $PWD.Path -ChildPath $DumpInventoryFile 
            
            # Is path passed to function in $DumpDir valid?
            if ($true -eq (Test-Path -Path $DumpDir -PathType "Container"))
            {
                # Collect (up to) 10 most recent minidump files for this instance
                $Dumpfiles = get-childitem -Path (Join-Path $Dumpdir "*") -Include "*.mdmp" | sort-object -Property Length -Descending
                
                if ($true -eq (Test-Path -Path $global:LOGFILE_PATH -PathType "Leaf"))
                {
                    WriteTo-LogFile ("Dump inventory for instance: {0}" -f $InstanceName)
                    WriteTo-LogFile ("Dump directory: {0}" -f $DumpDir)
                    
                    if ($null -ne $Dumpfiles) 
                    {
                        if (0 -lt $Dumpfiles.Count) 
                        {
                            WriteTo-LogFile ("Total number of dumps discovered is: {0}" -f $Dumpfiles.Count)
                            
                            foreach($DumpFile in $Dumpfiles)
                            {
                                WriteTo-LogFile ("{0} Creation Time: {1} Size: {2}" -f $DumpFile.Name, $DumpFile.CreationTime, $DumpFile.Length)
                            }
                        }
                    }
                    else
                    {
                        WriteTo-LogFile "No minidumps found ..." 
                    }
            		# Now collect the file so that it will be included in CAB that's uploaded
                	CollectFiles -FilesToCollect $global:LOGFILE_PATH -SectionDescription ("SQL Server minidumps and related files for instance {0}" -f $InstanceName)
                }
            }
            else
            {
                "[Write-DumpInventory] : [ERROR] Invalid path [{0}] passed by caller" -f $DumpDir | WriteTo-StdOut        
            }
            
        } # if ($null -eq $DumpDir)
        else
        {
             '[Write-DumpInventory] : [ERROR] Required parameter -DumpDir was not specified' | WriteTo-StdOut        
        }
        
    } # if ($null -eq $InstanceName)
    else
    {
        '[Write-DumpInventory] : [ERROR] Required parameter -InstanceName was not specified' | WriteTo-StdOut        
    }
}


# This function works with and returns the dump directory as a string so not susceptible to issues caused by
# cluster drive being offline to the node the collector is run against
function Get-DumpDirectory ([string] $SqlInstance)
{
    $Error.Clear()           
	trap 
	{
		"[Get-DumpDirectory] : [ERROR] Trapped exception ..." | WriteTo-Stdout
		Report-Error
	}
    
    if ($null -ne $SqlInstance)
    {
    	$InstanceKey = Get-SqlInstanceRootKey -SqlInstanceName $SqlInstance
        
        if ($null -ne $InstanceKey)
        {
        								
        	if ($true -eq (Test-Path -Path (Join-Path -Path $InstanceKey -ChildPath '\CPE')))
        	{				
        		$CpeRegKey = Join-Path -Path $InstanceKey -ChildPath '\CPE'
        		
                # Test to be sure CpeRegKey is valid
                if ($true -eq (Test-Path -Path $CpeRegKey))
                {
                    # Get the MSSQLServer\Parameters Key
            		$SqlDumpDir = (Get-ItemProperty -Path $CpeRegKey ).ErrorDumpDir
                    
                    if ($true -ne $?)
                    {
                        "[Get-DumpDirectory] : [ERROR] Failed to retrieve ErrorDumpDir registry value from key: [{0}]" -f $CpeRegKey | WriteTo-StdOut
                        Report-Error
                    }
                }  
                else
                {
                    "[Get-DumpDirectory] : [ERROR] Cpe registry key: [{0}] is invalid or does not exist" -f $CpeRegKey | WriteTo-StdOut
                    Report-Error
                }              
                
        	}
        	else
        	{
        		# Report that we could not locate the SQL Server dump directory
        		"[Get-DumpDirectory] : [ERROR] Unable to locate dump directory for SQL Instance: [{0}]" -f $SqlInstance | WriteTo-StdOut
        		"[Get-DumpDirectory] : [ERROR] Registry key: [{0}] is invalid" -f ($InstanceKey + "\CPE") | WriteTo-StdOut
        	}
            
        } # if ($null -ne $InstanceKey)
        else
        {
            '[Get-DumpDirectory] : [ERROR] Get-SqlInstanceRootKey returned a null value' | WriteTo-StdOut
        }
    } 
    else
    {
        '[Get-DumpDirectory] : [ERROR] Required parameter -SqlInstance was not specified' | WriteTo-StdOut
    }
    
	return $SqlDumpDir
}

#
# Function : Collect-SqlServerMinidumps
# --------------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function directly. Instead, call the top-level script and pass args
#			indicating which instances to collect dumps for  
#
# Description:
# 			This function enumerates the minidump files for a given SQL Server installation and 
# 
# Arguments:
#			String to write to file
# 
# Owner:
#			DanSha 
#
function Collect-SqlServerMinidumps ([string]$InstanceToCollect, [bool]$IsClustered )
{
    $Error.Clear()           
    trap 
    {
    	"[Collect-SqlServerMinidumps] : [ERROR] Trapped error ..." | WriteTo-StdOut
    	Report-Error 
    }
	
    If ($null -ne $InstanceToCollect)
    {
        if ($null -ne $IsClustered)
        {
            $DumpDir = Get-DumpDirectory -SqlInstance $InstanceToCollect

        	if ($null -ne $DumpDir)
            {
                # Make sure the dump directory path is valid. 
                # When SQL Server is clustered, the instance could be online to another cluster node
                # If so, the drive where the dumps are stored may be offline from the node where the collector is running
                #
                if (Test-Path -Path $DumpDir -PathType "Container")
                {
                    $DumpCount = get-childitem -Path (Join-Path -Path $Dumpdir -ChildPath "*") -Include "*.mdmp" | Get-Count
                    
                    # Create the dump inventory report ... even if there are no dumps present ... report will indicate this
                    Write-DumpInventory -InstanceName $InstanceToCollect -DumpDir $DumpDir
                    
                    $FileFilters = @('*.mdmp')
                    
                    # First pass, enumerate the files but to not copy
				    $DumpFiles = @()
				    $DumpFiles = Copy-FileSql -SourcePath $DumpDir `
                         -FileFilters $FileFilters `
                         -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_MINIDUMPS `
                         -InstanceName $InstanceToCollect `
						 -EnumerateOnly
                                            
                    #Since forcing an array to be created with above syntax need to check the length to see if there are any entries in array
                    if (($null -ne $DumpFiles) -and (0 -ne $Dumpfiles.Length))
                    {
                        # Need to go get the SQLDUMP*.log and SQLDUMP*.txt files associated with the dumps we just collected
                        foreach ($file in $dumpfiles)
                        {
                           $LogFileFullPath = $file.Replace("mdmp", "log")
                           # Add the .log file to the list of filefilters to enumerate.  No need to test-path as the enumerate/copy routine does this
                           $FileFilters += split-path -Leaf -Path $LogFileFullPath
                           
                           $TxtFileFullPath = $file.Replace("mdmp", "txt")
                           $FileFilters += split-path -Leaf -Path $TxtFileFullPath
                        } 
                        
                        # Add SQLDUMPER_ERRORLOG
                        $FileFilters += "SQLDUMPER_ERRORLOG.log" 
                       
                        # Add exception.log if present
                        $FileFilters += "exception.log" 
                        
                        $MiniDumpArchiveName = "{0}_{1}_{2}_SqlMiniDumps.zip" -f $env:ComputerName, $InstanceToCollect, (Get-LcidForSqlServer -SqlInstanceName $InstanceToCollect)
                    
                        # Re-enumerate, this time copy and compress since we should have all files we want.  FilePolicy is applied "by filter" so no need
                        # to adjust it to account for additional files for this subsequent call
                        $DumpFiles = @()
				        $DumpFiles = Copy-FileSql -SourcePath $DumpDir `
                         -FileFilters $FileFilters `
                         -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_MINIDUMPS `
                         -InstanceName $InstanceToCollect `
                         -SectionDescription ("SQL Server minidumps and related files for instance {0}" -f $InstanceToCollect) `
                         -ZipArchiveName $MiniDumpArchiveName `
                         -CompressCollectedFiles
                         #-RenameCollectedFiles
                         
         
					} # if (($null -ne $DumpFiles) -and (0 -ne $Dumpfiles.Length))
                    else
                    {
                        "[Collect-SqlServerMinidumps] : [INFO] No minidumps found for instance: [{0}]" -f $InstanceToCollect | WriteTo-StdOut
                    }  
                }
                # Test-path failed for $DumpDir ... could be because the cluster resource where the dumpfiles are stored is offline to this cluster node
                else 
            	{
                    if ($true -eq (Check-IsSqlDiskResourceOnline $InstanceToCollect $DumpDir))
                    {
                        "[Check-IsSqlDiskResourceOffline] : [ERROR] Path to minidumps: [{0}] for instance: {1} is invalid" -f $DumpDir, $InstanceToCollect | WriteTo-StdOut
                    }
            	}
                
            } #if ($null -ne $DumpDir)
            else
            {
                '[Collect-SqlServerMinidumps] : [ERROR} Get-Dumpdirectory returned a null dump directory path for instance: [{0}]' -f $InstanceToCollect  | WriteTo-StdOut
            }
            
        } # if ($null -ne $IsClustered)
        else
        {
            '[Collect-SqlServerMinidumps] : [ERROR} Required parameter -IsClustered was not specified' | WriteTo-StdOut
        }
        
    } # If ($null -ne $InstanceToCollect)
    else
    {
        '[Collect-SqlServerMinidumps] : [ERROR} Required parameter -InstanceToCollect was not specified' | WriteTo-StdOut
    }
} 

#
# Script entry point
#
#region: MAIN ::::: 
$Error.Clear()           
trap 
{
	"[DC-CollectSqlSqlMinidumps] : [ERROR] Trapped error ..." | WriteTo-StdOut
	Report-Error
}
	
Import-LocalizedData -BindingVariable minidumpCollectorStrings

# Check to be sure that there is at least one SQL Server installation on target machine before proceeding
#
if ($true -eq (Check-SqlServerIsInstalled))
{
	# If $instance parameter is null, collect minidumps for all instances installed on machine
	#
	if ($null -eq $instances)
	{
		$instances = Enumerate-SqlInstances -Offline
	}
    
    if ($null -ne $instances)
    {
    
        foreach ($instance in $instances)
        {
			"[DC-CollectSqlSqlMinidumps] : Attempting to collect minidumps for SQL instance: [{0}]" -f $instance.InstanceName | WriteTo-StdOut
            Write-DiagProgress -Activity $minidumpCollectorStrings.ID_SQL_CollectSqlMinidumps -Status ($minidumpCollectorStrings.ID_SQL_CollectSqlMinidumpsDesc + ": " + $instance.InstanceName)
			
            # DEFAULT instance name is MSSQLSERVER in registry and filesystem.  Translate it here before doing any work
            if ('DEFAULT' -eq $instance.InstanceName.ToUpper()) {$instance.InstanceName='MSSQLSERVER'}
            
			Collect-SqlServerMinidumps -InstanceToCollect $instance.InstanceName -IsClustered $instance.IsClustered
        }
    }
} # if ($true -eq (Check-SqlServerIsInstalled))
else
{
    "[DC-CollectSqlSqlMinidumps] : [INFO] No SQL Server installation(s) were found on server: [{0}]" -f $env:ComputerName | WriteTo-StdOut
}
#endregion: MAIN ::::: 
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCArWtWQGq3/nd1+
# i/tgSo99AeUDyAEfrpezEWmKDZJ/ZaCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgyf0ezfOn
# d8FDT3ogBEeSsWqTLi67LMHb5dyjRc9mezgwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAFu4FimrFNAmHb/41p0c5zvs1yWKlUpcyaSxLi8ZUsFX2Ft4x7eoDs+t
# IQF4/obr2M7J5Av2Ewze0n1XYq4M+iWtaYuk405rKTwKPUOGvh4ufbmTi1CxN0Oi
# Y7qS8Y5MxVfYDxy5RIblRqiFIWD0F6Z+ebOjHAU5rWx2p90ugtsVES500MxVmLgM
# aPN5iVQLtdJF1rw0G7GOOhFkAqxRJEJ2OWoZ37p3bYpYmB7uRfhnMhLUhjAb87bP
# YQdnD+h7f9z9YpebO2/KZ7jLrBm4pNe0/zQ8Shut2R6InWdPwSVko8lc94dRBfka
# hERlfFpibABkrgMhkRvV5e8nC4fBwnehghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQg2VIbO4UKiCw9ux5htID9c8TbRoLwQ5a+BK5IO3f+K2ECBmGB2SqX
# KxgTMjAyMTExMTExNjUzMzYuMzA0WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3
# QTYtRTI1MS0xNTBBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFZn/x+Xyzq8kMAAAAAAVkwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE1WhcNMjIwNDExMTkwMjE1WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0xNTBB
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArnjEYclnxIdES00igGj0AboyujyARkK3
# xaBX+Y10i3a0w4/fNVhTj6xGwibFPB/MkQMFZpNzsvGUTL/XfTZ9GZ39HanCdjun
# JP3TK9kCZBAtnoP59oYHDCGLmut7+2YEl1sBcVnyovYkNzi3EGffQyvULwMUF2si
# PBs/6LZF0A5pLAiz/FCwx5kDPe/mP1UR3Crz6IzphwtyoqtgDA/44TnzfvVJPmSP
# Z/uq5Oh5NeFK8NzMpitWiQvdmfT4o0CdumnisfW1fKaaBdByBULPUT8TLw0Sy9nU
# WNXlA/qi8MxPxgCjsrNpi9PgjH7ExW9b7X/UydhpqhHxsudDGZNk4wIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFPbQqYVGvK365Osn14jCPLLpN2PnMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAI2RVBLoD4GGt8Y4IBajcpy5Rrh6y2nPKf5kuWSHSkmY
# AmngRQOstayJ5gJ/ajKhzwqNUwL40cUVW8cutIyFadHkW1jqXdnpSv0hMFLPriPn
# BNFETy8ilCIdViNFU08ZHa2Kobmco/n6wPStkjjrg4U3Pift6sMk6lXsibUv+wDB
# 9f4YehziPmt+4C5BMVjzax1i+0czgtPHBX33u6GUWznagdql0VbUpe3q8zERedJf
# yyhB9R34z5ircnu51zpH3jUa7F93oDS95xXnomO+akKeDiNGSq4B7J/90qZBRpHV
# 8q8AsFECZmQBS1aKNL/cyR5C/+VS8dWjsY8XMn87fAkwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0x
# NTBBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQAqdssAjx+E7nxIJaulmde9cRmyEaCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5TeMLjAiGA8y
# MDIxMTExMTE2MzM1MFoYDzIwMjExMTEyMTYzMzUwWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN4wuAgEAMAoCAQACAiZVAgH/MAcCAQACAhF9MAoCBQDlON2uAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAPB+o9P5KuWdUoJBXwoX4L87nThTU
# 2S11U5IDYOUcrI26xNl/t9OaqJWivy8rytDWLl0U61OAH/Jw2SxZ3rdAwBepTDZW
# XANDRvwidcy0kqxaIjbS2bRgBXkoflMeDGktaA077jCjC5wtBW+J2FKoHzH3b8ed
# jKupzCxZBxWH66UxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVmf/H5fLOryQwAAAAABWTANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCBwJzTz
# C5Vsk0Odys8MksofeFNQSVPUMsgJr1DbwD77izCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIAFYG8+/MOZ815LOYlPj50YD66P+qrv98qRSffqvE0PoMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFZn/x+Xyzq8kMA
# AAAAAVkwIgQgcLVW3bJKbJiHgsAuVX1ytoKPdrXTVrHf9HHAbN3hmOwwDQYJKoZI
# hvcNAQELBQAEggEAadXqJR73VSTPlP5ov8OpDT+2HSkcrfDGdCY8CS4Ql6+p1NU+
# WgCfPgkBwC2mJ0sh+apHG1otXAE8xdh+prnVmqU0ojJAzZf1jfNrI5uIbzgo4ktb
# y3IwPSKKVELxcs08OY1U2rwWl8zA/iobQWf4251zoROlLPXnURog6Vy5EZqNG1B0
# fKOq0SMHbdDZ7wjeNmoZPMqzasDQDXE3NlnrFKB3Udh0JDaJcxzJ4MxXDqj9RhzK
# n85fmWg5kNwgXMXysEkCfSaDt5zwLZzEjZb6toAwwupzNbGiW62FaQe8uwAD5G7h
# pOy/qHnW10dOAtrZbyEeRmxbtFUWbNCpTi2+hA==
# SIG # End signature block
