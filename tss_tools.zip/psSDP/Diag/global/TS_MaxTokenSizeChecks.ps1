﻿PARAM ([array]$Principals = ($env:USERNAME), $OSEmulation)
#************************************************
# TS_MaxTokenSizeChecks.ps1
# Version 1.0
# Date: 9-4-2013
# Author: Tspring
# Description: Script to detect user token sizing problems which may effect
#  use of domain services which require authentication.
# Update 10/2014 to add support for claims and parameters for checking multiple users token sizes. 
#************************************************
$global:FormatEnumerationLimit = -1
"Within TS_MaxTokenSizeChecks script prior to trap." | WriteTo-StdOut -ShortFormat
"OSEmulation is set to $OSEmulation" | WriteTo-StdOut -ShortFormat
$OSEmType = $OSEmulation.GetType()
"OSEmulation type is $OSEmType" | WriteTo-StdOut -ShortFormat

Trap [Exception]
		{
		 #Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 WriteTo-StdOut "[info]:An exception occurred." -shortformat
		 WriteTo-StdOut "[info]: Exception.Message $ExceptionMessage."
		 WriteTo-ErrorDebugReport -ErrorRecord $_
		 $Error.Clear()
		 continue
		}

#Define output file for token details outputs
$MaxTokenfileDescription = "Text file export of token information for groups and migrated SIDs for the user."
$DomainInfo = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
$DomainName = $DomainInfo.name
$MaxTokenSettingssectionDescription = "User Token Size Details"
$ExportFile = Join-Path $Pwd.Path ($DomainName  + "_KerberosTokenDetails.txt")
# | Out-File -Encoding UTF8 -FilePath $MaxTokenSettingsOutput -Append


function RC_MaxTokenSize
{	PARAM( $InformationCollected )
	
	$RootCauseName = "RC_MaxTokenSize"
	Update-DiagRootCause -id $RootCauseName -Detected $true
	$Verbosity = "Error"
	$Visibility = "4"
	$SupportTopicsID = "18628"
	$PublicContent = "http://support.microsoft.com/kb/327825"
	Write-GenericMessage -RootCauseId $RootCauseName -PublicContentURL $PublicContent -InformationCollected $InformationCollected -Verbosity $Verbosity -Visibility $Visibility -SupportTopicsID $SupportTopicsID 
}

function RC_MaxTokenSizeWarn
{	PARAM( $InformationCollected )
	
	$RootCauseName = "RC_MaxTokenSizeWarn"
	Update-DiagRootCause -id $RootCauseName -Detected $true
	$Verbosity = "Error"
	$Visibility = "4"
	$SupportTopicsID = "18628"
	$PublicContent = "http://support.microsoft.com/kb/327825"
	Write-GenericMessage -RootCauseId $RootCauseName -PublicContentURL $PublicContent -InformationCollected $InformationCollected -Verbosity $Verbosity -Visibility $Visibility -SupportTopicsID $SupportTopicsID 
}


(Get-Date)  | Out-File $ExportFile -Encoding utf8  

#If OS is not specified to hyptohesize token size let's find the local OS and computer role
if (($OSEmulation -ne "12K") -and ($OSEmulation -ne "48K"))
      {
      $OS = Get-WmiObject -Class Win32_OperatingSystem
      $cs =  gwmi -Namespace "root\cimv2" -class win32_computersystem
      $DomainRole = $cs.domainrole
      switch -regex ($DomainRole) {
            [0-1]{
                  #Workstation.
                  $RoleString = "client"
                  if ($OS.BuildNumber -eq 3790)                                                 
                  {
                  $OperatingSystem = "Windows XP"
                  $OSBuild = $OS.BuildNumber
                  }
                        elseif (($OS.BuildNumber -eq 6001) -or ($OS.BuildNumber -eq 6002))
                              {
                              $OperatingSystem = "Windows Vista"
                              $OSBuild = $OS.BuildNumber
                              }
                                    elseif (($OS.BuildNumber -eq 7600) -or ($OS.BuildNumber -eq 7601))
                                                {
                                                $OperatingSystem = "Windows 7"
                                                $OSBuild = $OS.BuildNumber
                                                }
                                          elseif ($OS.BuildNumber -eq 9200)
                                                {
                                                $OperatingSystem =  "Windows 8"
                                                $OSBuild = $OS.BuildNumber
                                                }
                                                elseif ($OS.BuildNumber -eq 9600)
                                                      {
                                                      $OperatingSystem = "Windows 8.1"
                                                      $OSBuild = $OS.BuildNumber
                                                      }
                  }
            [2-3]{
                  #Member server.
                  $RoleString = "member server"
                  if ($OS.BuildNumber -eq 3790)
                       {
                        $OperatingSystem =  "Windows Server 2003"
                        $OSBuild = $OS.BuildNumber
                        }
                        elseif (($OS.BuildNumber -eq 6001) -or ($OS.BuildNumber -eq 6002))
                              {
                              $OperatingSystem =  "Windows Server 2008 RTM"
                              $OSBuild = $OS.BuildNumber
                              }
                              elseif (($OS.BuildNumber -eq 7600) -or ($OS.BuildNumber -eq 7601))
                                    {
                                    $OperatingSystem =  "Windows Server 2008 R2"
                                    $OSBuild = $OS.BuildNumber
                                    }
                                    elseif ($OS.BuildNumber -eq 9200)
                                          {
                                          $OperatingSystem = "Windows Server 2012"
                                          $OSBuild = $OS.BuildNumber
                                          }
                                          elseif ($OS.BuildNumber -eq 9600)
                                                {
                                                $OperatingSystem = "Windows Server 2012 R2"
                                                $OSBuild = $OS.BuildNumber
                                                }
                  }
            [4-5]{
                  #Domain Controller
                  $RoleString = "domain controller"
                  if ($OS.BuildNumber -eq 3790)
                       {
                        $OperatingSystem =  "Windows Server 2003"
                        $OSBuild = $OS.BuildNumber
                        }
                        elseif (($OS.BuildNumber -eq 6001) -or ($OS.BuildNumber -eq 6002))
                              {
                              $OperatingSystem =  "Windows Server 2008"
                              $OSBuild = $OS.BuildNumber
                              }
                              elseif (($OS.BuildNumber -eq 7600) -or ($OS.BuildNumber -eq 7601))
                                    {
                                    $OperatingSystem =  "Windows Server 2008 R2"
                                    $OSBuild = $OS.BuildNumber
                                    }
                                    elseif ($OS.BuildNumber -eq 9200)
                                          {
                                          $OperatingSystem = "Windows Server 2012"
                                          $OSBuild = $OS.BuildNumber}
                                          elseif ($OS.BuildNumber -eq 9600)
                                          {
                                          $OperatingSystem = "Windows Server 2012 R2"
                                          $OSBuild = $OS.BuildNumber
                                          }
                  }
            }
      }

if (($OSEmulation -eq "12K") -or ($OSEmulation -eq "48K"))
      {
      #Prompt user to choose which OS since they chose to emulate.
	  if ($OSEmulation -match "12K")
		{
		$OSBuild = "7600"
		"Gauging Kerberos token size using the Windows 7/Windows Server 2008 R2 and earlier default token size of 12K." | Out-File $ExportFile -Encoding utf8 -Append  
		}
		elsif ($OSEmulation -match "48K")
			{
			$OSBuild = "9200"
			"Gauging Kerberos token size using the Windows 8/Windows Server 2012 and later default token size of 48K. Note: The 48K setting is optionally configurable for many earlier Windows versions." | Out-File $ExportFile -Encoding utf8 -Append 
			}

      }
      else
            {
            "The computer is $OperatingSystem and is a $RoleString." | Out-File $ExportFile -Encoding utf8 -Append 
            }
	
function GetSIDHistorySIDs
      {     param ([string]$objectname)
      Trap [Exception] 
      {$Script:ExceptionMessage = $_
      $Error.Clear()
     continue}
     $DomainInfo = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
      $RootString = "LDAP://" + $DomainInfo.Name
      $Root = New-Object  System.DirectoryServices.DirectoryEntry($RootString)
      $searcher = New-Object DirectoryServices.DirectorySearcher($Root)
      #$searcher.Filter="(&(userprincipalname=$objectname))"
	  $searcher.Filter="(|(userprincipalname=$objectname)(name=$objectname))"
      $results=$searcher.findone()
      if ($results -ne $null)
            {
            $SIDHistoryResults = $results.properties.sidhistory
            }
      #Clean up the SIDs so they are formatted correctly
      $SIDHistorySids = @()
      foreach ($SIDHistorySid in $SIDHistoryResults)
            {
            $SIDString = (New-Object System.Security.Principal.SecurityIdentifier($SIDHistorySid,0)).Value
            $SIDHistorySids += $SIDString
            }
      return $SIDHistorySids
}

#Fix up list if needed
"Principal list is $Principals" | WriteTo-StdOut -ShortFormat
$Users = @()
foreach ($Principal in $Principals)
	{
	"Within Principals foreach. Current one is $Principal" | WriteTo-StdOut -ShortFormat
	if ($Principal -match " " )
		{
		[array]$TempUserList = $Principal.Split(" ")
		foreach ($TempUser in $TempUserList)
			{
			if ($TempUser -notmatch " " )
				{$Users += $TempUser}
			}
		}
		else
		{$Users += $Principal}

	}

"Users array is $users" | WriteTo-StdOut -ShortFormat

if (($Principals.GetType()) -ne [System.String])
	{
	$NumberofPrincipals = $Users.count
	$UserCountdown = $NumberofPrincipals
	"Within Principals ne string" | WriteTo-StdOut -ShortFormat
	"Principals count for usercountdown is $Usercountdown" | WriteTo-StdOut -ShortFormat
	}
	else
		{
		$NumberofPrincipals = "1"
		"in else statement indicating the principals is a string" | WriteTo-StdOut -ShortFormat
		"PRincipals count for usercountdown is $Usercountdown" | WriteTo-StdOut -ShortFormat
		}


Import-LocalizedData -BindingVariable MaxTokenSizeStrings		
$Activity = $MaxTokenSizeStrings.ID_TokenSizeCheck_Activity -replace("%allusers%", $NumberofPrincipals)

foreach ($Principal in $Users)
      {
	 "Within token checking Foreach. Current user is $Principal" | WriteTo-StdOut -ShortFormat
	  $UpdatedSeconds = $UserCountdown * 120
	  $EstimatedTime = New-TimeSpan -seconds $UpdatedSeconds
	  $Minutes = $EstimatedTime.minutes
	  $Seconds = $EstimatedTime.seconds
	  $Status = $MaxTokenSizeStrings.ID_TokenSizeCheck_Status -replace("%userstogo%", $UserCountdown)
	  $Status = $Status.replace("%minutes%", $Minutes)
	  Write-DiagProgress -Activity $Activity -Status $Status

    Trap [Exception]
		{
		 #Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 WriteTo-StdOut "[info]:An exception occurred." -shortformat
		 WriteTo-StdOut "[info]: Exception.Message $ExceptionMessage."
		 WriteTo-ErrorDebugReport -ErrorRecord $_
		 $Error.Clear()
		 $UserCountdown--
		 continue
		}
	
      #Obtain domain SID for group SID comparisons.
      $UserIdentity = New-Object System.Security.Principal.WindowsIdentity($Principal)
      $Groups = $UserIdentity.get_Groups()
      $DomainSID = $UserIdentity.AccountDomainSid
      $GroupCount = $Groups.Count
	  $GroupDetails = New-Object PSObject
      $AllGroupSIDHistories = @()
      $SecurityGlobalScope  = 0
      $SecurityDomainLocalScope = 0
      $SecurityUniversalInternalScope = 0
      $SecurityUniversalExternalScope = 0
      
      foreach ($GroupSid in $Groups) 
            {     
            $Group = [adsi]"LDAP://<SID=$GroupSid>"
            $GroupType = $Group.groupType
              if ($Group.name -ne $null)
                  {
                  $SIDHistorySids = GetSIDHistorySIDs $Group.name
                  $AllGroupSIDHistories += $SIDHistorySids
                  $GroupName = $Group.name.ToString()
                  
                  #Resolve SIDHistories if possible to give more detail.
                  if ($SIDHistorySids -ne $null)
                        {
                        $GroupSIDHistoryDetails = New-Object PSObject
                        foreach ($GroupSIDHistory in $AllGroupSIDHistories)
                              {
                              #$SIDHistGroup = [adsi]"LDAP://<SID=$GroupSIDHistory>"
                              $SIDHistGroup = New-Object System.Security.Principal.SecurityIdentifier($GroupSIDHistory)
                              $SIDHistGroupName = $SIDHistGroup.Translate([System.Security.Principal.NTAccount])
                              #$SIDHistGroupName = ($SIDHistGroup.displayname).ToString()
                              $GroupSIDHISTString = $GroupName + "--> " + $SIDHistGroupName
                              add-Member -InputObject $GroupSIDHistoryDetails -MemberType NoteProperty -Name $GroupSIDHistory  -Value $GroupSIDHISTString -force
                              }
                        }
                  }
              
            #Count number of security groups in different scopes.
            switch -exact ($GroupType)
                  {"-2147483646"    {
                                    #Domain Global scope
                                    $SecurityGlobalScope++
                                    $GroupNameString = $GroupName + " (" + ($GroupSID.ToString()) + ")"
                                    add-Member -InputObject $GroupDetails -MemberType NoteProperty -Name $GroupNameString  -Value "Domain Global Group"
                                    $GroupNameString = $null
                                    }
                  "-2147483644"     {
                                    #Domain Local scope
                                    $SecurityDomainLocalScope++
                                    $GroupNameString = $GroupName + " (" + ($GroupSID.ToString()) + ")"
                                    Add-Member -InputObject $GroupDetails -MemberType NoteProperty -Name $GroupNameString  -Value "Domain Local Group"
                                    $GroupNameString = $null
                                   }
                  "-2147483640"   {
                                  #Universal scope; must separate local
                                  #domain universal groups from others.
                                  if ($GroupSid -match $DomainSID)
									 {
									 $SecurityUniversalInternalScope++
                                     $GroupNameString = $GroupName + " (" + ($GroupSID.ToString()) + ")"
                                     Add-Member -InputObject $GroupDetails -MemberType NoteProperty -Name  $GroupNameString -Value "Local Universal Group"
                                     $GroupNameString = $null
                                     }
									 else
                                       {
                                       $SecurityUniversalExternalScope++
                                       $GroupNameString =  $GroupName + " (" + ($GroupSID.ToString()) + ")"
                                       Add-Member -InputObject $GroupDetails -MemberType NoteProperty -Name  $GroupNameString -Value "External Universal Group"
                                       $GroupNameString = $null
                                       }
								}

				}

      #Look for claims if OS supports it
      if ($OSBuild -ge 9200)
            {
            $ClaimCounter = 0 #Set to zero in case the script is *gasp* ran twice in the same PS.
            $ClaimsTable = @{}
            $UserIdentity = New-Object System.Security.Principal.WindowsIdentity($Principal)
            if ($UserIdentity.Claims -ne $null)
                  {
                  foreach ($Claim in $UserIdentity.Claims) 
                        {   
                        $ClaimCounter++
                        $LastSlash = $Claim.Type.LastIndexOf('/')
                        $ClaimName = $Claim.Value + " (" + ($Claim.Type.Substring($LastSlash+1)) + ")"
                        $ClaimsTable.Add($ClaimName,$Claim.Value)
                        }
                  }
            }

	}
      #Get user object SIDHistories
      $SIDHistoryResults = GetSIDHistorySIDs $Principal
      $SIDHistoryCounter = $SIDHistoryResults.count
      
      #Resolve SIDHistories if possible to give more detail.
      if ($SIDHistoryResults -ne $null)
            {
            $UserSIDHistoryDetails = New-Object PSObject
            foreach ($SIDHistory in $SIDHistoryResults)
                  {
                  $SIDHist = New-Object System.Security.Principal.SecurityIdentifier($SIDHistory)
                  $SIDHistName = $SIDHist.Translate([System.Security.Principal.NTAccount])
                  add-Member -InputObject $UserSIDHistoryDetails -MemberType NoteProperty -Name $SIDHistName  -Value $SIDHistory -force
                  }
            }
                        
      $GroupSidHistoryCounter = $AllGroupSIDHistories.Count 
      $AllSIDHistories = $SIDHistoryCounter  + $GroupSidHistoryCounter

      #Calculate the current token size.
      $TokenSize = 0 #Set to zero in case the script is *gasp* ran twice in the same PS.
      $TokenSize = 1200 + (40 * ($SecurityDomainLocalScope + $SecurityUniversalExternalScope + $AllSIDHistories + $ClaimCounter)) + (8 * ($SecurityGlobalScope  + $SecurityUniversalInternalScope))
      $DelegatedTokenSize = 2 * (1200 + (40 * ($SecurityDomainLocalScope + $SecurityUniversalExternalScope + $AllSIDHistories + $ClaimCounter)) + (8 * ($SecurityGlobalScope  + $SecurityUniversalInternalScope)))
      
	  #Begin output of details regarding the user into prompt and outfile.
      "`n"  | Out-File $ExportFile -Encoding utf8 -Append 
      "Token Details for user $Principal"  | Out-File $ExportFile -Encoding utf8 -Append 
      "**********************************" | Out-File $ExportFile -Encoding utf8 -Append 
      $Username = $UserIdentity.name
      $PrincipalsDomain = $Username.Split('\')[0]

      $KerbKey = get-item -Path Registry::HKLM\SYSTEM\CurrentControlSet\Control\LSA\Kerberos\Parameters
      $MaxTokenSizeValue = $KerbKey.GetValue('MaxTokenSize')
	  if ($MaxTokenSizeValue -eq $null)
	  	{
		if ($OSBuild -lt 9200)
			{$MaxTokenSizeValue = 12000}
		if ($OSBuild -ge 9200)
			{$MaxTokenSizeValue = 48000}
		}


      #Assess OS so we can alert based on default for proper OS version. Windows 8 and Server 2012 allow for a larger token size safely.
      $ProblemDetected = $false
	  $PotentialProblemDetected = $false
      if (($OSBuild -lt 9200) -and (($Tokensize -ge 12000) -or ((($Tokensize -gt $MaxTokenSizeValue) -or ($DelegatedTokenSize -gt $MaxTokenSizeValue)) -and ($MaxTokenSizeValue -ne $null))))
            {
            #Write-Host "Problem detected. The token was too large for consistent authorization. Alter the maximum size per KB http://support.microsoft.com/kb/327825 and consider reducing direct and transitive group memberships." -backgroundcolor "red"
			$ProblemDetected = $true
			}
      elseif (($OSBuild -ge 9200) -and (($Tokensize -ge 48000) -or ((($Tokensize -gt $MaxTokenSizeValue) -or ($DelegatedTokenSize -gt $MaxTokenSizeValue)) -and ($MaxTokenSizeValue -ne $null))))
            {
            #Write-Host "Problem detected. The token was too large for consistent authorization. Alter the maximum size per KB http://support.microsoft.com/kb/327825 and consider reducing direct and transitive group memberships." -backgroundcolor "red"
			$ProblemDetected = $true
			}
      elseif (($OSBuild -lt 9200) -and (($Tokensize -ge 6000) -or ($DelegatedTokenSize -ge 6000)))
            {
            #Write-Host "WARNING: The token was large enough that it may have problems when being used for Kerberos delegation or for access to Active Directory domain controller services. Alter the maximum size per KB http://support.microsoft.com/kb/327825 and consider reducing direct and transitive group memberships." -backgroundcolor "yellow"
            $PotentialProblemDetected = $true
			}
            else
                {
                #Write-Host "Problem not detected." -backgroundcolor "green"
				$ProblemDetected = $false
				$PotentialProblemDetected = $false
                }

	#####Test Root Cause Triggers - COMMENT IN PROD 
	#####$ProblemDetected = $true
	#####$PotentialProblemDetected = $true
		
        $InformationCollected = New-Object PSObject
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Date" -Value (Get-Date)
		if (($ProblemDetected -eq $true) -or ($PotentialProblemDetected -eq $true))
			{Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Problem Detected" -Value $true}
			else
			{Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Problem Detected" -Value $false}
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "User Name" -Value  $principal
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Domain" -Value (($UserIdentity.name).split("\")[0])
		$TokenSizePropertyName = $principal + "'s Estimated Token Size"
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name $TokenSizePropertyName -Value $Tokensize
		$DelegTokenSizePropertyName = $principal + "'s Estimated Delegation Token Size"
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name $DelegTokenSizePropertyName -Value $DelegatedTokenSize
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Domain Local Groups Count" -Value $SecurityDomainLocalScope 
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Domain Global Groups Count" -Value $SecurityGlobalScope
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Universal Groups Count (Local Domain)" -Value  $SecurityUniversalInternalScope		
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Universal Groups Count (External Domain)" -Value $SecurityUniversalExternalScope
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "User SidHistory SIDs in Token" -Value $SIDHistoryCounter
		Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Group SidHistory SIDs in Token" -Value $GroupSidHistoryCounter
		if ($ClaimCounter -eq $null)
			{add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Windows Claims in Token" -Value "Not Applicable"}
			else
			{add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Windows Claims in Token" -Value $ClaimCounter}
		if ($OSEmulation -eq "12K")
			{Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Tested Maximum Token Size"  -Value $MaxTokenSize}
		if   ($OSEmulation -eq "48K")
			{Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Tested Maximum Token Size" -Value $MaxTokenSize}
		if (($OSEmulation -ne "12K") -and ($OSEmulation -ne "48K"))
			{Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Tested Maximum Token Size" -Value $Maxtokensizevalue}

		$InformationCollected | Out-File -Encoding UTF8 -Width 500 -FilePath $ExportFile -append
		
        if ($OSBuild -ge 9200)
              {
              "There are $ClaimCounter total claims for the user in the token."  | Out-File $ExportFile -Encoding utf8 -Append 
              "`n"  | Out-File $ExportFile -Encoding utf8 -Append 
              "Claim Details" | Out-File $ExportFile -Encoding utf8 -Append 
              $ClaimsTable.Keys | Out-File $ExportFile -Encoding utf8 -Append 
              }
        "`n" | Out-File $ExportFile -Encoding utf8 -Append 
        "Group Details" | Out-File $ExportFile -Encoding utf8 -Append 
        $GroupDetails | Out-File $ExportFile -encoding utf8 -Width 500 -Append
        "`n"  | Out-File $ExportFile -Encoding utf8 -Append 
        
        "Group SIDHistory Details" | Out-File $ExportFile -Encoding utf8 -Append 
        if ($GroupSIDHistoryDetails -eq $null)
              {"[NONE FOUND]" | Out-File $ExportFile -Encoding utf8 -Append }
              else
              {$GroupSIDHistoryDetails | Out-File $ExportFile -encoding utf8 -Width 500 -Append}
        "`n"  | Out-File $ExportFile -Encoding utf8 -Append 
        "User SIDHistory Details" | Out-File $ExportFile -Encoding utf8 -Append 
        if ($UserSIDHistoryDetails -eq $null)
              {"[NONE FOUND]" | Out-File $ExportFile -Encoding utf8 -Append }
              else
              {$UserSIDHistoryDetails | Out-File $ExportFile -encoding utf8 -Width 500 -Append}
        "`n"  | Out-File $ExportFile -Encoding utf8 -Append 
        
        #insert RC firing here
		if ($ProblemDetected -eq $true)
			{
			#Root cause found
			#Trigger the root cause.
			RC_MaxTokenSize $InformationCollected
			}
			elseif ($PotentialProblemDetected -eq $true)
				{
				RC_MaxTokenSizeWarn $InformationCollected
				}
				else
				{
				#Green light.
				#$RootCauseName = "RC_MaxTokenSize"
				#Update-DiagRootCause -id $RootCauseName -Detected $false
				}
		$UserCountdown--
      }


CollectFiles -filesToCollect $ExportFile  -fileDescription $MaxTokenfileDescription  -sectionDescription $MaxTokenSettingssectionDescription  -renameOutput $false


# SIG # Begin signature block
# MIIa9gYJKoZIhvcNAQcCoIIa5zCCGuMCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUPVVgqZYODP6FPJomjUCMsLSK
# RQagghV6MIIEuzCCA6OgAwIBAgITMwAAAFrtL/TkIJk/OgAAAAAAWjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTQwNTIzMTcxMzE1
# WhcNMTUwODIzMTcxMzE1WjCBqzELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# DTALBgNVBAsTBE1PUFIxJzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjpCOEVDLTMw
# QTQtNzE0NDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALMhIt9q0L/7KcnVbHqJqY0T
# vJS16X0pZdp/9B+rDHlhZlRhlgfw1GBLMZsJr30obdCle4dfdqHSxinHljqjXxeM
# duC3lgcPx2JhtLaq9kYUKQMuJrAdSgjgfdNcMBKmm/a5Dj1TFmmdu2UnQsHoMjUO
# 9yn/3lsgTLsvaIQkD6uRxPPOKl5YRu2pRbRptlQmkRJi/W8O5M/53D/aKWkfSq7u
# wIJC64Jz6VFTEb/dqx1vsgpQeAuD7xsIsxtnb9MFfaEJn8J3iKCjWMFP/2fz3uzH
# 9TPcikUOlkYUKIccYLf1qlpATHC1acBGyNTo4sWQ3gtlNdRUgNLpnSBWr9TfzbkC
# AwEAAaOCAQkwggEFMB0GA1UdDgQWBBS+Z+AuAhuvCnINOh1/jJ1rImYR9zAfBgNV
# HSMEGDAWgBQjNPjZUkZwCu1A+3b7syuwwzWzDzBUBgNVHR8ETTBLMEmgR6BFhkNo
# dHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNyb3Nv
# ZnRUaW1lU3RhbXBQQ0EuY3JsMFgGCCsGAQUFBwEBBEwwSjBIBggrBgEFBQcwAoY8
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNyb3NvZnRUaW1l
# U3RhbXBQQ0EuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBBQUA
# A4IBAQAgU4KQrqZNTn4zScizrcTDfhXQEvIPJ4p/W78+VOpB6VQDKym63VSIu7n3
# 2c5T7RAWPclGcLQA0fI0XaejIiyqIuFrob8PDYfQHgIb73i2iSDQLKsLdDguphD/
# 2pGrLEA8JhWqrN7Cz0qTA81r4qSymRpdR0Tx3IIf5ki0pmmZwS7phyPqCNJp5mLf
# cfHrI78hZfmkV8STLdsWeBWqPqLkhfwXvsBPFduq8Ki6ESus+is1Fm5bc/4w0Pur
# k6DezULaNj+R9+A3jNkHrTsnu/9UIHfG/RHpGuZpsjMnqwWuWI+mqX9dEhFoDCyj
# MRYNviGrnPCuGnxA1daDFhXYKPvlMIIE7DCCA9SgAwIBAgITMwAAAMps1TISNcTh
# VQABAAAAyjANBgkqhkiG9w0BAQUFADB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTAeFw0xNDA0MjIxNzM5MDBaFw0xNTA3MjIxNzM5MDBaMIGDMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQD
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCWcV3tBkb6hMudW7dGx7DhtBE5A62xFXNgnOuntm4aPD//ZeM08aal
# IV5WmWxY5JKhClzC09xSLwxlmiBhQFMxnGyPIX26+f4TUFJglTpbuVildGFBqZTg
# rSZOTKGXcEknXnxnyk8ecYRGvB1LtuIPxcYnyQfmegqlFwAZTHBFOC2BtFCqxWfR
# +nm8xcyhcpv0JTSY+FTfEjk4Ei+ka6Wafsdi0dzP7T00+LnfNTC67HkyqeGprFVN
# TH9MVsMTC3bxB/nMR6z7iNVSpR4o+j0tz8+EmIZxZRHPhckJRIbhb+ex/KxARKWp
# iyM/gkmd1ZZZUBNZGHP/QwytK9R/MEBnAgMBAAGjggFgMIIBXDATBgNVHSUEDDAK
# BggrBgEFBQcDAzAdBgNVHQ4EFgQUH17iXVCNVoa+SjzPBOinh7XLv4MwUQYDVR0R
# BEowSKRGMEQxDTALBgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNTk1K2I0MjE4ZjEz
# LTZmY2EtNDkwZi05YzQ3LTNmYzU1N2RmYzQ0MDAfBgNVHSMEGDAWgBTLEejK0rQW
# WAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0FfMDgtMzEtMjAx
# MC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0zMS0yMDEwLmNy
# dDANBgkqhkiG9w0BAQUFAAOCAQEAd1zr15E9zb17g9mFqbBDnXN8F8kP7Tbbx7Us
# G177VAU6g3FAgQmit3EmXtZ9tmw7yapfXQMYKh0nfgfpxWUftc8Nt1THKDhaiOd7
# wRm2VjK64szLk9uvbg9dRPXUsO8b1U7Brw7vIJvy4f4nXejF/2H2GdIoCiKd381w
# gp4YctgjzHosQ+7/6sDg5h2qnpczAFJvB7jTiGzepAY1p8JThmURdwmPNVm52Iao
# AP74MX0s9IwFncDB1XdybOlNWSaD8cKyiFeTNQB8UCu8Wfz+HCk4gtPeUpdFKRhO
# lludul8bo/EnUOoHlehtNA04V9w3KDWVOjic1O1qhV0OIhFeezCCBbwwggOkoAMC
# AQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmSJomT8ixkARkW
# A2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9z
# b2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgzMTIyMTkzMloX
# DTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAgQpl2U2w+G9Zv
# zMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn08GisTUuNpb15
# S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqelcnNW8ReU5P01
# lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQwWfjSjWL9y8lf
# RjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vXT2Pn0i1i8UU9
# 56wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJXwPTAgMBAAGj
# ggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK0rQWWAHJNy4z
# Fha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEE
# AYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGCNxQCBAweCgBT
# AHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ5KQwUAYDVR0f
# BEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEBBEgwRjBEBggr
# BgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNy
# b3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5Pn8mRq/rb0Cx
# MrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9MuqKoVpzjcLu4
# tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOlVuC4iktX8pVC
# nPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7IG9KPcpUqcW2b
# Gvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/TartSCMm78pJUT
# 5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhcyTUWX92THUmO
# Lb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zKwexwo1eSV32U
# jaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K3RDeZPRvzkbU
# 0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO7bN2edgKNAlt
# HIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdibIa4NXJzwoq6G
# aIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HOiMm4GPoOco3B
# oz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZoNAAAAAAAHDAN
# BgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkwFwYKCZImiZPy
# LGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAzMTMwMzA5WjB3
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQDExhN
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7Rp9FMrXQwIBHr
# B9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y9GccLPx754gd
# 6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYuJ6yGT1VSDOQD
# LPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdmEScpZqiX5NMG
# gUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68eeEExd8yb3zuD
# k6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAPBgNVHRMBAf8E
# BTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzALBgNVHQ8EBAMC
# AYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyCYEBWJ5flJRP8
# KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAXBgoJkiaJk/Is
# ZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8ESTBHMEWgQ6BB
# hj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9taWNy
# b3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsGAQUFBzAChjho
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jvc29mdFJvb3RD
# ZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQUFAAOCAgEA
# EJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxtYrhXAstOIBNQ
# md16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1Pq5Lk541q1YDB
# 5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxnLcVRDupiXD8W
# mIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/xTUrXqO/67x9
# C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW6J1wlGysOUzU
# 9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146SodDW4TsVxIxIm
# dgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD6Svpu/RIzCzU
# 2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9iaF2YbRuoROm
# v6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpjtHhUBdRBLlCs
# lLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J4PcBZW+JC33I
# acjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTmMIIE4gIBATCBkDB5
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMwIQYDVQQDExpN
# aWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAMps1TISNcThVQABAAAAyjAJ
# BgUrDgMCGgUAoIH/MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQB
# gjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBTYpId2jK7IRORW
# UR9XkUpOCRN+UDCBngYKKwYBBAGCNwIBDDGBjzCBjKBygHAARABJAEEARwBfAEMA
# VABTAEEAYwB0AGkAdgBlAEQAaQByAGUAYwB0AG8AcgB5AF8AZwBsAG8AYgBhAGwA
# XwBUAFMAXwBNAGEAeABUAG8AawBlAG4AUwBpAHoAZQBDAGgAZQBjAGsAcwAuAHAA
# cwAxoRaAFGh0dHA6Ly9taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAHXM
# RcefrQAIQ4cvKYFQSApQyyDi4dwymXELKF3HdTrNskdMtSgcLb+eFIOb17ZwgmW5
# le2UEN84SYCyvx0MLQ3P8kzzPMpBZivBG6GY6AXUy/bHk5SNlxMR4iBZrK96ZQep
# icWDucjDziPdaxtNzYfY3VRRkv+8T/GTeEsXQ+ukP0XX/+cSoj20ZjjJBb0WEj87
# V9caGpGg8o7ffua2CaXC/yczcCn2qpoUOmT+uNfkWkPWU6fHScJII3Rllr6MT/T8
# xRjNJrvxsHF5RgHyORSRaXujeEK8YPqlL0wBkNjjmy1Et13H0AyfwMP2evgs/Vh1
# /buM1Kj+gNTHYmuXrbShggIoMIICJAYJKoZIhvcNAQkGMYICFTCCAhECAQEwgY4w
# dzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMY
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBAhMzAAAAWu0v9OQgmT86AAAAAABaMAkG
# BSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJ
# BTEPFw0xNDEwMTYxNTE1MzFaMCMGCSqGSIb3DQEJBDEWBBRHXOsw512kYJM+1dvN
# 60gho0BebTANBgkqhkiG9w0BAQUFAASCAQA8YkgwM/zzxj8nH1KNXNA1OQ4VXZKb
# M8uWNG5iPuYV7KU8j1+QlJv11SYCr3kbltPzueiR8x66xc8T22El1wmSAdWh/pQi
# 3/Tm8sqjIWysMF6nfd7aFCHi3IqqhJTBe7ZYjhI7bb11KfmHsZtJuZP2Y3/ZkWhh
# Fcf7tpg648HlQ17DGVtWD3J0m2cczUEOth92WvnTnup4GfC5k7zlh5NWb9t2Qw79
# /iM5D8H1XT/C2Q/ufvRZ1/QMvcZeJTp4Ky+YHy10mck+eWfQaG+JpWbqAGS8/8PF
# juQcp8B8MMObrIAE2yd2SZWIMxQVNJfT44gf7XIHWQo78d078ACP5U8a
# SIG # End signature block
