﻿###########################################################################
# DC_Office Inventory
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Executes ROIScan.vbs to collect office inventory
###########################################################################

Import-LocalizedData -BindingVariable Office -FileName DC_Office_Inventory -UICulture en-us
Write-DiagProgress -Activity $Office.ID_OfficeInv

$PreOutputFile = $ComputerName + "_ROIScan.log"
$OutputFile = $ComputerName + "_OfficeInventory.txt"

logstart 

$CommandLineToExecute = "cmd.exe /c cscript.exe ROIScan.vbs"
"Running " + $CommandLineToExecute | WriteTo-StdOut 
RunCMD -commandToRun $CommandLineToExecute 
#Invoke-Expression "cscript.exe ROIScan.vbs"

if (Test-path $PreOutputFile) { 
	"Renaming " + $PreOutputFile | WriteTo-StdOut 
	Rename-Item $PreOutputFile $OutputFile }

CollectFiles -filesToCollect $OutputFile -fileDescription "Office Inventory" -sectionDescription "Office Inventory"

logstop