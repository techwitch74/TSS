#************************************************
# DC_NLB-Component.ps1
# Version 1.0
# Date: 2009
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about NLB.
# Called from: Main Networking Diag
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}


Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSNLB -Status $ScriptVariable.ID_CTSNLBDescription

# detect OS version and SKU
$wmiOSVersion = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber


function runPS ([string]$runPScmd="")
{
	$runPScmdLength = $runPScmd.Length
	"-" * ($runPScmdLength) | Out-File -FilePath $outputFile -append
	"$runPScmd" | Out-File -FilePath $outputFile -append
	"-" * ($runPScmdLength) | Out-File -FilePath $outputFile -append
	Invoke-Expression $runPScmd | out-file -FilePath $outputFile -append
}


$sectionDescription = "NLB"

$outputFile = $Computername + "_NLB_info_pscmdlets.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"Network Load Balancing (NLB) Powershell Cmdlets"		| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. Get-NlbCluster"									| Out-File -FilePath $OutputFile -append
"   2. Get-NlbClusterNode"								| Out-File -FilePath $OutputFile -append
"   3. Get-NlbClusterNodeNetworkInterface"				| Out-File -FilePath $OutputFile -append
"   4. Get-NlbClusterPortRule"							| Out-File -FilePath $OutputFile -append
"   5. Get-NlbClusterVip"								| Out-File -FilePath $OutputFile -append
"   6. Get-NlbClusterNodeDip"							| Out-File -FilePath $OutputFile -append	#_# renamed NlbClusterDip to NlbClusterNodeDip
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n`n`n`n`n"											| Out-File -FilePath $OutputFile -append


$SvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\WLBS"
if ($bn -ge 9200)
{
	if (Test-Path $SvcKey) 
	{
		# conditional run on how many clusters are configured, so leaving out for now.
			# runPS "Get-NlbClusterDriverInfo"
		runPS "Get-NlbCluster"
		runPS "Get-NlbClusterNode"
		runPS "Get-NlbClusterNodeNetworkInterface"
		runPS "Get-NlbClusterPortRule"
		runPS "Get-NlbClusterVip"
		runPS "Get-NlbClusterNodeDip"
	}
	else
	{
		"The `"WLBS`" registry location does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The Get-Nlb* powershell cmdlets are only available on W8/WS2012 and later. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}

CollectFiles -filesToCollect $outputFile -fileDescription "NLB Information" -SectionDescription $sectionDescription



$OutputFile= $Computername + "_NLB_info.txt"
"===================================================="	| Out-File -FilePath $OutputFile -append
"Network Load Balancing (NLB) Output"					| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. nlb display"										| Out-File -FilePath $OutputFile -append
"   2. nlb query"										| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n`n`n`n`n"											| Out-File -FilePath $OutputFile -append

$SvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\WLBS"
if (Test-Path $SvcKey) 
{
		#----------NLB display
		$CommandToExecute = "cmd.exe /c nlb.exe display >> $OutputFile"
		RunCmD -commandToRun $CommandToExecute -CollectFiles $false
		"`n`n`n"												| Out-File -FilePath $OutputFile -append
		"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
		"nlb query"												| Out-File -FilePath $OutputFile -append
		"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
		#----------NLB query (running this because "nlb display" sometimes does not show the converged state.
		$CommandToExecute = "cmd.exe /c nlb.exe query >> $OutputFile"
		RunCmD -commandToRun $CommandToExecute -CollectFiles $false
		"`n`n`n"												| Out-File -FilePath $OutputFile -append
}
else
{
	"The `"WLBS`" registry location does not exist. Not running NLB commands."	| Out-File -FilePath $OutputFile -append
}

CollectFiles -filesToCollect $OutputFile -fileDescription "NLB Output (nlb display; nlb query)" -SectionDescription $sectionDescription


#----------Registry
$OutputFile= $Computername + "_NLB_reg.TXT"
$CurrentVersionKeys = "HKLM\SYSTEM\CurrentControlSet\services\WLBS"
$sectionDescription = "NLB"
RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "NLB Registry Key" -SectionDescription $sectionDescription

