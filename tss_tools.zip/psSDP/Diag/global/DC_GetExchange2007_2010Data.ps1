﻿#################################################################################
# Copyright © 2008, Microsoft Corporation. All rights reserved.
#
# You may use this code and information and create derivative works of it, provided that the following conditions are met:
# 1. This code and information and any derivative works may only be used for # troubleshooting a) Windows and b) products for Windows, in either case using the Windows Troubleshooting Platform
# 2. Any copies of this code and information and any derivative works must retain the above copyright notice, this list of # conditions and the following disclaimer.
# 3. THIS CODE AND INFORMATION IS PROVIDED ``AS IS'' WITHOUT WARRANTY OF ANY KIND,
#    WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
#    OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. IF THIS CODE AND
#    INFORMATION IS USED OR MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION
#    WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER.
#################################################################################
# DC_GetExchange2007_2010Data.ps1
# Version 3.7.0
# Date: 2013-04-25
# Author: Brian Prince - brianpr@microsoft.com
# Description: Collects Exchange Server 2007 and Exchange Server 2010 information
#################################################################################

PARAM ([switch]$getSetupLogs, [switch]$getExBPA)

######################
## Output Functions ##
######################

function out-zip ($FilePath,$zipFileName){
        $oZipFileName = $zipFileName
        $ZipFileName = ($PWD.Path) + "\" + ($env:COMPUTERNAME + "_") + $zipFileName
        if (-not $zipFileName.EndsWith('.zip')) {$zipFileName += '.zip'} 
        
        Write-DiagProgress -Activity ($GetExchDataStrings.ID_GetExchDataCompressingAct) -Status ($GetExchDataStrings.ID_GetExchDataCompressingStatus + " " + $oZipFileName + ".zip")
        
        if (-not (Test-Path($ZipFileName))) {Set-Content $ZipFileName ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))}
        
        $ZipFileObj = (new-object -com Shell.Application).NameSpace($ZipFileName)
        
        $sleepCounter = 0
        $zipItemCounter = 0
        $itemsToZipCount = $FilePath.count
        $InitialZipItemCount = 0
        $InitialZipItemCount = $ZipFileObj.Items().Count            
        
        foreach ($file in $FilePath){
        
            $ZipFileObj.CopyHere($file.FullName)
            $zipItemCounter += 1
            
            do{
                sleep -Milliseconds 500
                $sleepCounter += 1
            } while (($ZipFileObj.Items().Count -lt $zipItemCounter) -and ($sleepCounter -lt 600))
        }

        return $zipFileName
}

Function New-DDF($path,$filePath)
{
 $ddfFile = Join-Path -path $path -childpath temp.ddf
 $cabName = Split-Path -path $filepath -leaf
 #"DDF file path is $ddfFile"
 $ddfHeader =@"
;*** MakeCAB Directive file
;
.OPTION EXPLICIT      
.Set CabinetNameTemplate=$cabName.cab
.set DiskDirectory1=$path
.set CompressionType=MSZIP
.Set MaxDiskSize=0
.Set Cabinet=on
.Set Compress=on
"@
 #"Writing ddf file header to $ddfFile" 
 $ddfHeader | Out-File -filepath $ddfFile -force -encoding ASCII
 #"Generating collection of files from $filePath"
 Get-ChildItem -path $filePath | Where-Object { !$_.psiscontainer } | ForEach-Object `
 { 
 '"' + $_.fullname.tostring() + '"' | 
 Out-File -filepath $ddfFile -encoding ASCII -append
 }
 #"ddf file is created. Calling New-Cab function"
 New-Cab($ddfFile)
} #end New-DDF

Function New-Cab($ddfFile)
{
 #"Entering the New-Cab function. The DDF File is $ddfFile"
 makecab /f $ddfFile | Out-Null
} #end New-Cab

#############################################
#############################################
##                                         ##
##  Begin Exchange Data Collection Section ##
##                                         ##
#############################################
#############################################

################
# Main Exchange Data Collection Function
################
function Get-ExchangeData {
    "Starting Get-ExchangeData" | WriteTo-StdOut
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    #Get the machine name
    $machineName = ${env:computername}
    
    #Initialize the Output Filename Prefix and Exchange Server Name variables
    $script:rootOutFile = Join-Path $pwd.Path.ToString() $machinename
    $Script:ExchangeServerName = $null
    Write-DebugLog ("Calling utils_exchange Function: GetExchangeVersionInstalled")
    
    If (($global:ExchInstalled -eq $true) -and ($global:IsExchPSSnapin -eq $true)) #values should be populated by utils_exchange
	{
        if (Get-ExchangeServerLocalCached){#($isExchServerFound = $true){
            Write-DebugLog ("Exchange Server Name: $Script:ExchangeServerName")
            $ExVersion = (Get-ExchangeServerLocalCached).AdminDisplayVersion.Major 
            if ($ExVersion -eq 8){[bool]$script:Exchange2007 = $true}
            elseif ($ExVersion -eq 14){[bool]$script:Exchange2010 = $true}
            Write-DebugLog ("Exchange Version: $ExVersion")

            $ExchangeServer = Get-ExchangeServerLocalCached
			$Script:ExchangeServerName = $ExchangeServer.Name
          
            Write-DebugLog ("Function: GetCommonServerData")
            GetCommonServerData

            Write-DebugLog ("Function: GetIISInfo")
            GetIISInfo

            if($ExchangeServer.IsMailboxServer){
                Write-DebugLog ("Function: GetMailboxServerData")
                GetMailboxServerData
            }
            if($ExchangeServer.IsClientAccessServer){
                Write-DebugLog ("Function: GetClientAccessServerData")
                GetClientAccessServerData
            }
            if($ExchangeServer.IsHubTransportServer){
                Write-DebugLog ("Function: GetHubTransportServerData")
                GetHubTransportServerData
            }
            if($ExchangeServer.IsUnifiedMessagingServer){
                Write-DebugLog ("Function: GetUnifiedMessagingServerData")
                GetUnifiedMessagingServerData
            }
            if(((Test-Path "HKLM:\SYSTEM\CurrentControlSet\Services\ExchangeDominoConnector") -eq $true)-or ((Test-Path "HKLM:\SYSTEM\CurrentControlSet\Services\MSExchangeCalcon")-eq $true)){
                Write-DebugLog ("Function: GetTransporterSuite")
                GetTransporterSuite
            }
            
            Write-DebugLog ("Done!")
                    
            CollectFiles -filestocollect ($script:rootOutFile + "__GetExchangeData_LOG.TXT") -filedescription ("Get-ExchangeData Script Log" ) -sectiondescription ("zExchange Troubleshooter Logs") -noFileExtensionsOnDescription
            CollectFiles -filestocollect ($script:rootOutFile + "__GetExchangeData_No_Result.TXT") -filedescription "Get-ExchangeData Script cmd without result" -sectiondescription ("zExchange Troubleshooter Logs") -noFileExtensionsOnDescription
        }

    }    
    Else{
        "Exchange Server Not Installed or Exchange Powershell Snapin Failed to Load or Get-ExchangeServer Failed." | WriteTo-StdOut
    }
#
#"Clearing Error." | WriteTo-StdOut
#$Error.Clear()
}

#############################
# Basic data collected for all Exchange server roles
#############################
function GetCommonServerData {
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Server and Organization Baseline"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerCommon)
    #[void]$shell.popup($script:RActivity)
    #[void]$shell.popup($GetExchDataStrings.ID_GetExchDataCollectingAct)
    
    $installPath = $global:exinstall
    $exSetup = (Join-Path $installPath \bin\exsetup.exe)
    $script:productversion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($exSetup).ProductVersion
	
	#Detect Service Pack
	$script:SPInstalled = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($exSetup).ProductMinorPart
	
	#Detect Update Rollup
	If (Test-Path HKLM\SOFTWARE\MICROSOFT\UPDATES)
	{
		$UpdatedProducts = Resolve-Path -Path 'HKLM:SOFTWARE\MICROSOFT\UPDATES\*'
		ForEach ($Product in $UpdatedProducts)
		{
			If ($Product = "Exchange 2007")
			{
				$E2K7Updates_SP = Resolve-Path -Path 'HKLM:SOFTWARE\MICROSOFT\UPDATES\EXCHANGE 2007\*'
				Foreach ($E2K7UpdateSP in $E2K7Updates_SP)
				{
					$E2K7Updates_KB = Resolve-Path -Path 'HKLM:SOFTWARE\MICROSOFT\UPDATES\EXCHANGE 2007\*'
				}
			}
			If ($Product = "Exchange 2010")
			{
			
			}
			
		}
	}
	
    
	#Detect Interim Updates
    $IUDetected = $global:exregSetupKey.GetValue("InterimUpdate")
    If ($IUDetected){
        $script:IUInstalled = $IUDetected.ToString()
    } 
    Else{
        $script:IUInstalled = "None"
    }
    
    # Update MSDT report with Exchange Server version and roles if run under WTP / PowerShell 2.0
    if($Host.Version.Major -ge 2){
        displayExchangeServers
    }

    ExportResults -cmdlet "Write-Output '$Script:ExchangeServerName exsetup.exe ProductVersion: $script:productversion' ; Get-ExchangeServer | Select-Object Name,AdminDisplayVersion,Site,ServerRole" -outformat "FL" -filename "AllExchangeServers" -filedescription "All Exchange Servers - Version Site and Roles"
    ExportResults -cmdlet "Get-ExchangeCertificate" -outformat "FL" -filename "ExchangeCertificate"
    ExportResults -cmdlet "Get-ExchangeServer -identity $Script:ExchangeServerName -status"
    ExportResults -cmdlet "Get-AcceptedDomain"
    ExportResults -cmdlet "Get-RemoteDomain"
    ExportResults -cmdlet "Get-OrganizationConfig"
    ExportResults -cmdlet "Get-EmailAddressPolicy"
    ExportResults -cmdlet "Get-AvailabilityAddressSpace"
    ExportResults -cmdlet "Get-AvailabilityConfig"
    
##### Exchange 2010-specific output #########
    if ($ExchangeVersion -eq 14){
        ExportResults -cmdlet "Get-UserPrincipalNamesSuffix"
        ExportResults -cmdlet "Get-ThrottlingPolicy" #56c20cd2-91c7-48d3-889d-be2a9510569a
        ExportResults -cmdlet "Get-PowerShellVirtualDirectory -Server '$Script:ExchangeServerName'" -outformat "FL"
        If (Get-FederationTrust){
            ExportResults -cmdlet "Get-FederationTrust"
            ExportResults -cmdlet "Test-FederationTrustCertificate"
            ExportResults -cmdlet "Get-FederatedOrganizationIdentifier -IncludeExtendedDomainInfo ?Verbose"
            ExportResults -cmdlet "Get-OrganizationRelationship"
            # Get-FederationInformation -Domain <the hosted Exchange domain namespace> - run against all domains in accepteddomain
			# on O365, run against verified domains from MSOL
			# Get-MSOLDomain returns all domains. One of the properties is status "verified" or "not verified"
			# http://support.microsoft.com/kb/2626696/EN-US
            
        }
        GetHybridConfigLogs
        
    }
#####/End Exchange 2010-specific output #####
#############################################

    Write-DebugLog ("Function: GetFiles -sourcePath $exinstall -targetFolder 'ExchangeConfigFiles' -reportsection 'Exchange Setup Information' -include '*.config' -recurse -cab")
    GetFiles -sourcePath $exinstall -targetFolder "ExchangeConfigFiles" -reportsection "Exchange Setup Information" -include "*.config" -recurse -cab
    
    
    if ($script:paramGetSetupLogs -eq $true){
        $ExchangeSetupLogPath = (Join-Path $global:SystemDrv "ExchangeSetupLogs")
		If (Test-Path $ExchangeSetupLogPath)
		{
			$ExchangeSetupLogPath = Join-Path -Path $ExchangeSetupLogPath -ChildPath "\*.*"
        	CompressCollectFiles -filesToCollect $ExchangeSetupLogPath -fileDescription ("Setup logs modified in past 14 days") -DestinationFileName "ExchangeSetupLogs.zip" -sectionDescription "Exchange Setup Information" -NumberOfDays 14 -Recursive 
        }
    }
    
    
    Write-DebugLog ("Function: GetExchangeRegistryKeys")
    GetExchangeRegistryKeys

#### Exchange Toolbox Output Collection #####
    #Get files from most recent Exchange Performance Troubleshooting Analyzer if less than 14 days old.
    If (Test-Path HKCU:Software\Microsoft\ExchangeServer\v14\ExPTA){
        $PTADataFolderPath = (Get-ItemProperty HKCU:Software\Microsoft\ExchangeServer\v14\ExPTA).DefaultDataFolder
    }
    If (Test-Path HKCU:Software\Microsoft\Exchange\ExPTA){
        $PTADataFolderPath = (Get-ItemProperty -Path HKCU:Software\Microsoft\Exchange\ExPTA -Name DefaultDataFolder)
    }
    If ($PTADataFolderPath -ne $null){
        $PTADataFolder = "ExPTA_" + (Split-Path $PTADataFolderPath -Leaf)
        If ((Test-Path $PTADataFolderPath)-and ((Get-Item $PTADataFolderPath).CreationTime -ge (get-date).AddDays(-14))){
            Write-DebugLog ("Function: GetFiles -sourcePath '$PTADataFolderPath' -targetFolder 'ExPTAData' -filedescription 'Exchange Performance Troubleshooting Assistant Files' -include '*.*' -recurse -cab")
            GetFiles -sourcePath "$PTADataFolderPath" -targetFolder "ExPTAData" -filedescription "Exchange Performance Troubleshooting Assistant Files" -reportsection "Exchange Toolbox" -include "*.*" -recurse -cab
        }
    }
    
    #Get files from Exchange Troubleshooting Analyzer Tracing
    $LogLocationXMLFileName = Join-Path -Path $global:exbin -childpath TraceFileConfig.xml
    If (Test-Path $LogLocationXMLFileName){
        [xml]$LogLocationXML = Get-Content -Path $LogLocationXMLFileName
        $ETLLogpath = ($LogLocationXML.selectsinglenode("TraceFile")).getattribute("FilePath")
        If ((Get-ChildItem $ETLlogpath -include *.etl -Recurse) -ne $null){
            Write-DebugLog ("Function: GetFiles -sourcePath '$ETLLogpath' -targetFolder 'ExTRATrace' -filedescription 'Exchange Troubleshooting Analyzer Trace Files' -include '*.etl' -recurse -cab")
            GetFiles -sourcePath "$ETLlogpath" -targetFolder "ExTRATrace" -filedescription "Exchange Troubleshooting Assistant Trace Files" -reportsection "Exchange Toolbox" -include "*.etl" -recurse -agemaxdays "14" -cab
        }
    }
}

#======================================
# Write Exchange Server version and role(s) information to MSDT diagnostic report when running under Win7 Troubleshooting Framework
#======================================
function displayExchangeServers{
    trap [System.Exception]{
    Write-DebugLog ("ERROR: " + $_); Continue}
    
    $allExchangeServers = (Get-ExchangeServer $Script:ExchangeServerName)
    $allExchangeServers_Summary = New-Object PSCustomObject
    #$script:IUInstalled
    foreach ($Server in $allExchangeServers)
	{
        $exServername = $Server.Name
        If ($script:IUInstalled -eq "None"){
            $exServerVersionRole = "ProductVersion:" + $script:productversion + "<br/>" + "InterimUpdate: " + $script:IUInstalled + "<br/>" + "Site: " + $Server.Site + "<br/>" + "Role(s): " + ([system.string]::join(",",($Server.ServerRole)))
        }
        Else{
            $exServerVersionRole = "ProductVersion:" + $script:productversion + "<br/>" + "InterimUpdate: " + $script:IUInstalled + "<br/>" + "Site: " + $Server.Site + "<br/>" + "Role(s): " + ([system.string]::join(",",($Server.ServerRole)))
        }
        Add-Member -InputObject $allExchangeServers_Summary -MemberType NoteProperty -Name $exServername -Value $exServerVersionRole
			# Site
    $sb.AppendFormat("Site: {0}<br/>", $server.Site) | Out-Null
    }
    $allExchangeServers_Summary | ConvertTo-Xml2 | Update-DiagReport -Id 00_ExchangeServer_Summary -Name "Exchange Server Version Site and Role" -Verbosity informational #Get Name from Strings File
    #[void]$shell.popup(($allExchangeServers_Summary | ConvertTo-Xml2).innerxml)
}


##################
# Data Collected for Exchange Mailbox Server Role
##################

function GetMailboxServerData{
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Mailbox Server Role"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerMailbox)

    $mailboxDatabases = Get-MailboxDatabase -server $ExchangeServer
    $publicFolderDatabases = Get-PublicFolderDatabase -server $ExchangeServer
    $WorkingDirPath = (get-itemproperty -path HKLM:\SYSTEM\CurrentControlSet\Services\MSExchangeIS\ParametersSystem)."Working Directory"
    
    ExportResults -cmdlet "Get-MailboxServer -identity $Script:ExchangeServerName -Status" -outformat "FL"

    #Dump properties and EDB File Path inventory for each Mailbox Database
    foreach($mailboxDatabase in $mailboxDatabases){
        $mbEdbFilePath = Split-Path -Path ($mailboxDatabase.EdbFilePath) -Parent
        if ($ExchangeVersion -eq 8){
            $mbdbn = ("SG_" + $mailboxDatabase.StorageGroupName + "_DBMb_" + $mailboxDatabase.Name + "_")
            $edbfp = ("SG_" + $mailboxDatabase.StorageGroupName + "_DBMb_" + $mailboxDatabase.name + "_EDBFilePath")
        }
        if ($ExchangeVersion -eq 14){
            $mbdbn = ("DBMb_" + $mailboxDatabase.Name + "_")
            $edbfp = ("DBMb_" + $mailboxDatabase.name + "_EDBFilePath_Contents")
        }
        ExportResults -cmdlet "Get-MailboxDatabase '$mailboxDatabase' -Status" -outformat "FL" -filename "$mbdbn"
        ExportResults -cmdlet "Get-Childitem -path '$mbEdbFilePath'" -outformat "FT" -filename "$edbfp"
    }
    
    #Dump properties, \NON_IPM_SUBTREE and EDB File Path inventory for each Public Folder Database
    if ($publicFolderDatabases -ne $null){
        foreach($publicFolderDatabase in $publicFolderDatabases){
            $pfEDBFilePath = Split-Path -Path ($publicFolderDatabase.EdbFilePath) -Parent
            if ($ExchangeVersion -eq 8){
                $pfdbn = ("SG_" + $publicFolderDatabase.StorageGroupName + "_DBPf_" + $publicFolderDatabase.Name + "_")
                $edbfp = ("SG_" + $publicFolderDatabase.StorageGroupName + "_DBPf_" + $publicFolderDatabase.name + "_EDBFilePath")
                $nipmflds = ("SG_" + $publicFolderDatabase.StorageGroupName + "_DBPf_" + $publicFolderDatabase.name + "_NON_IPM_SUBTREE")
            }
            if ($ExchangeVersion -eq 14){
                $pfdbn = ("DBPf_" + $publicFolderDatabase.Name + "_")
                $edbfp = ("DBPf_" + $publicFolderDatabase.name + "_EDBFilePath")
                $nipmflds = ("DBPf_" + $publicFolderDatabase.name + "_NON_IPM_SUBTREE")
            }
            ExportResults -cmdlet "Get-PublicFolderDatabase '$publicFolderDatabase'" -outformat "FL" -filename "$pfdbn"
            ExportResults -cmdlet "Get-Childitem -path '$pfEDBFilePath'" -outformat "FT" -filename "$edbfp"    
            ExportResults -cmdlet "Get-PublicFolder -server '$ExchangeServer' -identity '\NON_IPM_SUBTREE' -Recurse" -outformat "FT FL CSV" -filename "$nipmflds"
        }
    }
    
    ## Collect any Store.FCL files that are present under Exchange/Logging folder if last write time less than 14 days.
    $FCLLoggingPath = Join-Path $global:exinstall Logging
    $FCLFiles = Get-ChildItem $FCLLoggingPath -Filter *.fcl
    
    If ($FCLFiles -ne $null){
        ForEach ($file in $FCLFiles){
            If ($file.LastWriteTime -ge (Get-Date).AddDays(-14)){
                $collectFCL = $true
            }
        }
        $StoreFCLFolder = "ExchangeStoreFCL" #+ (Split-Path $FCLLoggingPath -Leaf)
        If ($collectFCL -eq $true){
            Write-DebugLog ("Function: GetFiles -sourcePath '$FCLLoggingPath' -targetFolder '$StoreFCLFolder' -filedescription 'Exchange Store.FCL File(s)' -include '*.fcl' -recurse -cab")
            GetFiles -sourcePath "$FCLLoggingPath" -targetFolder "$StoreFCLFolder" -filedescription "Exchange Store.FCL File(s)" -include "*.fcl" -recurse -cab
        }
    }
    


    ###################
    #Exchange 2007-only
    ###################
    if ($ExchangeVersion -eq 8){
        $storageGroups = Get-StorageGroup -Server $ExchangeServer

        #Dump properties for each Storage Group, and log & system folder directory inventory 
        foreach($storageGroup in $storageGroups)
        {
        $sgName = ("SG_" + $storageGroup.name + "_")
        $SgLf = ("SG_" + $storageGroup.name + "_LogFolderPath")
        $SgSf = ("SG_" + $storageGroup.name + "_SystemFolderPath")
        $LogFldPath = $storageGroup.LogFolderPath.PathName
        $SysFldPath = $storageGroup.SystemFolderPath.PathName
            ExportResults -cmdlet "Get-StorageGroup '$storageGroup'" -outformat "FL" -filename "$sgName"
            ExportResults -cmdlet "Get-ChildItem -path '$LogFldPath'" -outformat "FT" -filename "$SgLf"
            ExportResults -cmdlet "Get-ChildItem -path '$SysFldPath'" -outformat "FT" -filename "$SgSf"
        }
        if ($ExchangeServer.IsMemberOfCluster -eq "Yes"){
            ExportResults -cmdlet "Get-ClusteredMailboxServerStatus -Identity '$Script:ExchangeServerName'" -outformat "FL"
            ExportResults -cmdlet "Get-StorageGroupCopyStatus" -outformat "FL"
            
            #Export status of SCR-enabled storage groups if present - Added 04/30/2010
            $SCRSGs = Get-StorageGroup -Server $ExchangeServer | Where-Object {$_.StandbyMachines.Count -gt 0} 
            If ($SCRSGs -ne $null){
                ForEach ($SG in $SCRSGs){
                    $SCRStandbyMachines = $SCRSGs | ForEach-Object {$_.standbymachines}
                    ForEach ($node in $SCRStandbyMachines){
                        $nn = ($node.NodeName).tostring()
                        $fn = ("SG_" + $SG.name + "_StandbyMachine_" + $nn)
                        ExportResults -cmdlet "Get-StorageGroupCopyStatus -Identity '$SG' -StandbyMachine '$nn'" -outformat "FL" -filename "$fn"
                    }    
                }
            }
        }
    }
    
    ###################
    #Begin Exchange 2010-only section
    ###################
    if ($ExchangeVersion -eq 14){
        ExportResults -cmdlet "Get-MailboxDatabaseCopyStatus -Server '$ExchangeServer'" -outformat "FL"
        ExportResults -cmdlet "Get-StoreUsageStatistics -Server '$ExchangeServer'" -outformat "FL"
    
        #Dump Log Folder Path, Database Availability Group properties for each Mailbox Database
        $DAGnames = $null
        foreach($mailboxDatabase in $mailboxDatabases){
            $mbLogFolderPath = $mailboxDatabase.LogFolderPath.PathName
            
            if ($mbEdbFilePath -ne $mbLogFolderPath){
                $fn = ("DBMb_" + $mailboxDatabase.name + "_LogFolderPath")
                ExportResults -cmdlet "Get-ChildItem -path '$mbLogFolderPath'" -outformat "FT" -filename "$fn"
            }
            if ($mailboxDatabase.MasterType -eq "DatabaseAvailabilityGroup"){
                $DAGnames += $mailboxDatabase.MasterServerOrAvailabilityGroup
            }
        }

        if ($DAGnames -ne $null){
            $uDagNames = ($DAGNames | Get-Unique)
            foreach($uDAG in $uDagNames){
                ExportResults -cmdlet "Get-DatabaseAvailabilityGroup -id '$uDAG' -Status" -filename "DAG_$uDAG" 
            }
            ExportResults -cmdlet "Get-DatabaseAvailabilityGroupNetwork -server '$ExchangeServer'" -filename "DAGNetworks" -outformat "FL"
        }
        
        
        #Dump Log Folder Path inventory for each Public Folder Database
        if ($publicFolderDatabases -ne $null){
            foreach($publicFolderDatabase in $publicFolderDatabases){
                $pfLogFolderPath = $publicFolderDatabase.LogFolderPath.PathName
                $fn = ("DBPf_" + $publicFolderDatabase.name + "_LogFolderPath")
                ExportResults -cmdlet "Get-ChildItem -path '$pfLogFolderPath'" -outformat "FT" -filename "$fn"
            }
        }
    }
    
    ##
    #End version-specific information
    ##
    
    #Properties of the server InformationStore object from Active Directory via ADSI
    $ExchangeServerDn = $ExchangeServer.DistinguishedName
      $isDn = "CN=InformationStore," + $ExchangeServerDn
      $LDAPAddress = "LDAP://" + $isDN
      $InformationStore = [ADSI]$LDAPAddress
    $ADSI_MSExchISPropertiesFromAD = $InformationStore.psBase.Properties
    ExportResults -cmdlet ('$ADSI_MSExchISPropertiesFromAD') -outformat "FT FL" -filename "InformationStore_ADSIProperties"
    
    #Inventory of files, if any, in MSExchangeIS Working Directory
    If ((Get-Childitem -path $WorkingDirPath) -ne $null){
        ExportResults -cmdlet "Get-ChildItem -Path '$WorkingDirPath' -recurse -Include *.* | Where-Object { !`$_.psiscontainer } | Select-Object DirectoryName, FullName, Length, IsReadOnly, CreationTimeUtc, LastWriteTimeUtc" -outformat "FL" -filename "MSExchangeIS_WorkingDirectory"
    }
}

##################
# Data Collected for Exchange Client Access Server Role
##################

function GetClientAccessServerData {
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Client Access Server Role"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerCAS)
    
    Write-DebugLog (Get-ReportSection)
    ExportResults -cmdlet "Get-ClientAccessServer -Identity '$Script:ExchangeServerName'"
    ExportResults -cmdlet "Get-PopSettings -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-ImapSettings -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-ActiveSyncVirtualDirectory -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-ActiveSyncMailboxPolicy"
    ExportResults -cmdlet "Get-OutlookAnywhere -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-OutlookProvider" #Added 10/29/2010 brianpr
    ExportResults -cmdlet "Get-AutodiscoverVirtualDirectory -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-OabVirtualDirectory -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-OwaVirtualDirectory -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-WebServicesVirtualDirectory -Server '$ExchangeServer'"
    
    $regkeys = "HKLM:SOFTWARE\Microsoft\Rpc\RpcProxy"
      $outfile = ($script:rootOutFile + "_REG_RPCPROXY.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:SOFTWARE\Microsoft\Rpc\RpcProxy*") -sectiondescription (Get-ReportSection) -Recursive $true
    
    Write-DebugLog ("Function: GetIISLogs")
    GetIISLogs
    
    ###################
    #Exchange 2010-only cmdlets
    ###################
    if ($ExchangeVersion -eq 14){
        ExportResults -cmdlet "Get-RPCClientAccess"
        Write-DebugLog ("Function: GetRPCClientAccessLogs")
        GetRPCClientAccessLogs
        Write-DebugLog ("Function: GetAddressBookServiceLogs")
        GetAddressBookServiceLogs
        
        # RID:2944 SSID:f446a1fe-2d73-4adb-91e3-a913afeafae2 DA:20120229
            ExportResults -cmdlet "Get-EcpVirtualDirectory -Server '$ExchangeServer'"
        
        
    }
    
    #####
    #ToDo
    #####
    #Need to get the list of mobile devices to support the following command
    #InvokeExpression(("Get-ActiveSyncDeviceStatistics -Server " + $ExchangeServer.identity))
}

##################
# Data Collected for All Transport Server Roles
##################
function GetCommonTransportServerData(){
    trap [Exception] {
        Log-Error $_
        Continue
    }
    #global:section = "Exchange Transport Server Roles"

    ExportResults -cmdlet "Get-TransportConfig"
    ExportResults -cmdlet "Get-TransportServer -identity '$Script:ExchangeServerName'"
    ExportResults -cmdlet "Get-ReceiveConnector -server '$ExchangeServer'"
    ExportResults -cmdlet "Get-SendConnector"
    ExportResults -cmdlet "Get-TransportAgent"
    ExportResults -cmdlet "Get-TransportPipeline"
    ExportResults -cmdlet "Get-EdgeSubscription"
    ExportResults -cmdlet "Get-Queue"
    
    #Get the newest 4 routing logs
    $TransportServer = Get-TransportServer -identity $Script:ExchangeServerName
    $routingLogPath = ($TransportServer.RoutingTableLogPath.PathName + "\")
    GetFiles -sourcePath "$routingLogPath" -targetFolder "Logs_Routing" -include "Routing*.xml" -Recurse -newest "4" -cab

    #Get the newest 5 agent logs
    If (Test-Path (Join-Path $global:exinstall TransportRoles\Logs\AgentLog\*.log)){
        $AgentLogPath = (Join-Path $global:exinstall TransportRoles\Logs\AgentLog)
        GetFiles -sourcePath "$AgentLogPath" -targetFolder "Logs_Agent" -include "*.log" -Recurse -newest "5" -cab
    }
    
    Write-DebugLog ("Function: GetMessageTrackingLogs")
    GetMessageTrackingLogs
	
	Write-DebugLog ("Function: GetConnectivitylogs")
	GetConnectivitylogs

    ###################
    #Exchange 2010-only
    ###################
    if ($ExchangeVersion -eq 14){
        ExportResults -cmdlet "Get-EdgeSyncServiceConfig"
    }
    
    
    Write-DebugLog ("GetTransportRules")
    GetTransportRules
    
    Write-DebugLog ("GetAntispamConfig")
    GetAntispamConfig
}

function GetTransportRules
{
    trap [Exception] {
        Log-Error $_
        Continue
    }

    ExportResults -cmdlet "Get-TransportRule" -outformat "FL"
    
    if ($ExchangeVersion -eq 8){
        
        #Delete the TransportRuleCollection if it already exists, otherwise script may hang here
        $ExportedTransportRules = $script:rootOutFile + "_ExportedTransportRules.xml"
        If( [System.IO.File]::Exists($ExportedTransportRules) ){
            Remove-Item $ExportedTransportRules
        }
        
        Write-DebugLog ("Export-TransportRuleCollection $ExportedTransportRules")
        Export-TransportRuleCollection $ExportedTransportRules
        CollectFiles -filestocollect ($ExportedTransportRules) -filedescription ("Export-TransportRuleCollection") -sectiondescription (Get-ReportSection) -noFileExtensionsOnDescription
    }
    
    if ($ExchangeVersion -eq 14){
        $ExportedTransportRules = Export-TransportRuleCollection
        Set-Content -Path ($script:rootOutFile + "_ExportedTransportRules.xml") -Value $ExportedTransportRules.FileData -Encoding Byte

        $ExportedLegacyTransportRules = Export-TransportRuleCollection -ExportLegacyRules
        Set-Content -Path ($script:rootOutFile + "_ExportedLegacyTransportRules.xml") -Value $ExportedLegacyTransportRules.FileData -Encoding Byte
        CollectFiles -filestocollect ($script:rootOutFile + "_ExportedTransportRules.xml") -filedescription ("Export-TransportRuleCollection") -sectiondescription (Get-ReportSection) -noFileExtensionsOnDescription
        CollectFiles -filestocollect ($script:rootOutFile + "_ExportedLegacyTransportRules.xml") -filedescription ("Export-TransportRuleCollection -ExportLegacyRules") -sectiondescription (Get-ReportSection) -noFileExtensionsOnDescription    
    }
}

function GetAntiSpamConfig(){
  trap [Exception] {
        Log-Error $_
        Continue
    }

    ExportResults -cmdlet "Get-ContentFilterConfig"
    ExportResults -cmdlet "Get-ContentFilterPhrase"
    ExportResults -cmdlet "Get-IPBlockListConfig"
    ExportResults -cmdlet "Get-IPBlockListEntry"
    ExportResults -cmdlet "Get-IPBlockListProvidersConfig"
    ExportResults -cmdlet "Get-IPBlockListProvider"
    ExportResults -cmdlet "Get-IPAllowListConfig"
    ExportResults -cmdlet "Get-IPAllowListEntry"
    ExportResults -cmdlet "Get-IPAllowListProvidersConfig"
    ExportResults -cmdlet "Get-IPAllowListProvider"
    ExportResults -cmdlet "Get-SenderIdConfig"
    ExportResults -cmdlet "Get-SenderReputationConfig"
    ExportResults -cmdlet "Get-SenderFilterConfig"
    ExportResults -cmdlet "Get-RecipientFilterConfig"
    ExportResults -cmdlet "Get-AntispamUpdates -identity '$Script:ExchangeServerName'"
    
}


##################
# Data Collected for Exchange Hub Server Role
##################
function GetHubTransportServerData(){
	trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Hub Transport Server Role"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerHub)

      Write-DebugLog ("GetCommonTransportServerData")
        GetCommonTransportServerData
    
    ExportResults -cmdlet "Get-ForeignConnector"
    ExportResults -cmdlet "Get-RoutingGroupConnector"
    ExportResults -cmdlet "Get-JournalRule" -outformat "FL" -filename "JournalRules"
    
    ###################
    #Exchange 2010-only
    ###################
    if ($ExchangeVersion -eq 14){
        ExportResults -cmdlet "Get-IRMConfiguration"
    }
}

##################
# Data Collected for Exchange Edge Server Role
##################
function GetEdgeServerData(){
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Edge Server Role"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerEdge)

      Write-DebugLog ("GetCommonTransportServerData")
        GetCommonTransportServerData
    ExportResults -cmdlet "Get-AddressRewriteEntry"
    ExportResults -cmdlet "Get-AttachmentFilterListConfig"
    ExportResults -cmdlet "Get-AttachmentFilterEntry"
}

##################
# Data Collected for Exchange Unified Messaging Server Role
##################
function GetUnifiedMessagingServerData(){
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Unified Messaging Server Role"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerUM)
    
    ExportResults -cmdlet "Get-UMServer -identity $Script:ExchangeServerName"
    ExportResults -cmdlet "Get-UMDialPlan"
    ExportResults -cmdlet "Get-UMIPGateway"
    ExportResults -cmdlet "Get-UMHuntGroup"
    ExportResults -cmdlet "Get-UMMailboxPolicy"
    ExportResults -cmdlet "Get-UMVirtualDirectory"
    ExportResults -cmdlet "Get-UMAutoAttendant"
    
    foreach ($dialplan in Get-UMDialPlan){
        $DialPlanInCountryOrRegionGroups = $dialplan.ConfiguredInCountryOrRegionGroups
        $DialPlanInternationalGroups = $dialplan.ConfiguredInternationalGroups
        $cFileDialPlanName = ("UMDialPlan_" + $dialplan.Name + "_CountryOrRegionGroups")
        $iFileDialPlanName = ("UMDialPlan_" + $dialplan.Name + "_InternationalGroups")
        ExportResults -cmdlet "'$DialPlanInCountryOrRegionGroups'" -filename "'$cFileDialPlanName'"
        ExportResults -cmdlet "'$DialPlanInternationalGroups'" -filename "'$iFileDialPlanName'"
    }
    
    foreach ($UMAutoAttendant in Get-UMAutoAttendant){
        $UMAA_BusinessHoursKeyMapping = $UMAutoAttendant.BusinessHoursKeyMapping
        $UMAA_AfterHoursKeyMapping = $UMAutoAttendant.AfterHoursKeyMapping
        $bFileUMAAName = ("UMAutoAttendant_" + $UMAutoAttendant.Name + "_BusinessHoursKeyMapping")
        $aFileUMAAName = ("UMAutoAttendant_" + $UMAutoAttendant.Name + "_AfterHoursKeyMapping")
        ExportResults -cmdlet "'$UMAA_BusinessHoursKeyMapping'" -filename "'$bFileUMAAName'"
        ExportResults -cmdlet "'$UMAA_AfterHoursKeyMapping'" -filename "'$aFileUMAAName'"
    }
}

Function GetExchangeRegistryKeys {
    trap [Exception] {
        Log-Error $_
        Continue
    }

    #Collect Exchange HKLM:SYSTEM\CCS\SVCS registry keys and values
    $regkey = "HKLM:SYSTEM\CurrentControlSet\Services"
    $regKeys = Get-ChildItem $regKey | where{$_.Name -like "*Exchange*"} | FOREACH-OBJECT {$_.name -replace ("HKEY_LOCAL_MACHINE\\","HKLM:")}
    $outfile = ($script:rootOutFile + "_REG_SERVICES_EXCHANGE.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:SYSTEM\CCS\SVCS\*Exchange*") -sectiondescription (Get-ReportSection) -Recursive $true

    #Collect Exchange HKLM:Software\Microsoft\Exchange* keys and values
    $regkey = "HKLM:SOFTWARE\Microsoft" 
    $regKeys = Get-ChildItem $regKey | where{$_.Name -like "*Exchange*"} | FOREACH-OBJECT {$_.name -replace ("HKEY_LOCAL_MACHINE\\","HKLM:")}
    $outfile = ($script:rootOutFile + "_REG_SOFTWARE_EXCHANGE.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:Software\Microsoft\Exchange*") -sectiondescription (Get-ReportSection) -Recursive $true
    
    #Colect HKLM:Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options keys and values
    $regkey = "HKLM:SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options" 
    $regKeys = Get-ChildItem $regKey | FOREACH-OBJECT {$_.name -replace ("HKEY_LOCAL_MACHINE\\","HKLM:")}
    $outfile = ($script:rootOutFile + "_REG_ImageFileExecutionOptions.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:Software\...ImageFileExecutionOptions") -sectiondescription (Get-ReportSection) -Recursive $true

    #Collect Exchange trace key if it is present (unlikely)
    $regkeys = "HKLM:Software\Microsoft\MosTrace"
    $outfile = ($script:rootOutFile + "_REG_MOSTRACE.TXT")

    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:Software\Microsoft\MosTrace") -sectiondescription (Get-ReportSection) -Recursive $true

    #Collect Windows Installer keys and values for the installed version of Exchange
    If ($global:ExchangeVersion -eq "14"){
        [array]$regkeys = "HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\AE1D439464EB1B8488741FFA028E291C"
    }
    Else{
        [array]$regkeys = "HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\461C2B4266EDEF444B864AD6D9E5B613"
    }
    
    #If found, add Windows Installer Patch keys for the installed version of Exchange
    $exchPatchesKey = Join-Path $regkeys[0] Patches
    If ((Get-ChildItem $exchPatchesKey).count -gt 0){
        $regkeys += Get-ChildItem $exchPatchesKey | ForEach-Object {Join-Path HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Patches (Split-Path $_.Name -Leaf)}
    }
    
    $outfile = ($script:rootOutFile + "_REG_INSTALLER_EXCHANGE.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:SOFTWARE\..\Installer\[Exchange]") -sectiondescription "Exchange Setup Information" -Recursive $true
}

function GetTransporterSuite(){
    Set-ReportSection "Exchange Transporter Suite"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerTransSuite)
    trap [Exception] {
        Log-Error $_
        Continue
    }
    $ExchangeDominoConnector = $null
    $CalCon = $null
    
    $ExchangeDominoConnector = (get-item HKLM:\SYSTEM\CurrentControlSet\Services\ExchangeDominoConnector)
    $CalCon = (Get-Item HKLM:\SYSTEM\CurrentControlSet\Services\MSExchangeCalcon)
    
    #Load snap-ins if either of these is available
    if(($ExchangeDominoConnector -ne $null) -or ($CalCon -ne $null)){
        Add-PSSnapin -Name "Microsoft.Exchange.Transporter.DominoConnector"
        Add-PSSnapin -Name "Microsoft.Exchange.Transporter"
    }
    $TransporterBin = (Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Transporter).ApplicationBase
    
    #Calendar Connector is installed
    if($CalCon -ne $null){
        ExportResults -cmdlet "Get-DominoFreeBusyConnector"
    }
    
    #Exchange Domino Connector is installed
    if($ExchangeDominoConnector -ne $null){
        ExportResults -cmdlet "Get-DominoDirectoryConnector"
        
        $DominoDirectoryConnectors = Get-DominoDirectoryConnector
        foreach($dominoDirectoryConnector in $DominoDirectoryConnectors){
            #Try to get the Notes.ini file
            $notesini = $dominoDirectoryConnector.NotesINIFile
            
            if($notesini -ne $null){
                if([System.IO.File]::Exists($notesini)){
                    $iniFile = ($pwd.Path.ToString() + "\" + $dominoDirectoryConnector.Name.ToString() + "_Notes.ini")
                    copy-item -path $notesini -destination $iniFile -recurse
                    GetFiles -sourcePath "$iniFile" -recurse
                }
                else{
                    $iniFileMissing = ($pwd.Path.ToString() + "\" + $dominoDirectoryConnector.Name.ToString() + "_Missing_Notes.ini")
                    out-file -filepath $iniFileMissing -InputObject ("Notes.INI file for " + $dominoDirectoryConnector.Name.ToString() + " is missing!!!")
                    GetFiles -sourcePath "$iniFileMissing"
                }
            }
        }
    }
}

##################
# Collect IIS-related information
##################
function GetIISInfo {
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Server IIS Information"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerIIS)

    $CopyToPath = ($pwd.Path.ToString())
    $inetSrvPath = (join-path $env:systemroot system32\inetsrv)
    $metabase_xml = ($env:systemroot + "\system32\inetsrv\metabase.xml")
    $filePrefix = ($env:COMPUTERNAME + "_")
    $regkeys = "HKLM:SYSTEM\CurrentControlSet\Services\IISADMIN", "HKLM:SYSTEM\CurrentControlSet\Services\InetInfo","HKLM:SYSTEM\CurrentControlSet\Services\W3SVC", "HKLM:SYSTEM\CurrentControlSet\Services\msdtc", "HKLM:SOFTWARE\Microsoft\Transaction Server", "HKLM:SOFTWARE\Microsoft\InetStp", "HKLM:SOFTWARE\Microsoft\InetMGR", "HKLM:SOFTWARE\Microsoft\Keyring"
    $outfile = ($script:rootOutFile + "_REG_IIS.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("IIS and Related Registry Keys/Values") -sectiondescription (Get-ReportSection) -Recursive $true

    GetFiles -sourcePath "$metabase_xml" -filedescription "IIS Metabase" -prefix $filePrefix -sectiondescription (Get-ReportSection)
}
########################
# Collect and .cab two most recent IIS logs for every website (called only if CAS role is detected)
########################
function GetIISLogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }

    $server = $env:computername
    $iis = [ADSI]"IIS://$server/W3SVC" 
    $sites = $iis.psbase.children | where { $_.keyType -eq "IIsWebServer"}
    foreach($site in $sites){
        $sp = $site.psbase.path
        $lfd = $site.logfiledirectory
        $slf = $sp.substring($sp.indexof("W3SVC")) | %{$_.replace("/","")}
        $w3logpath = Join-Path -Path $lfd -ChildPath $slf
        $tfldr = ($slf + "LogFiles")
        if  (Test-Path $w3logpath){
            GetFiles -sourcePath $w3logpath -targetFolder "$tfldr" -reportsection "Exchange Server IIS Information" -filedescription "Logs_$slf (newest two)" -include "*.log" -recurse -cab -newest "2"
        }
        Else{
            Write-DebugLog ("GetIISLogs: IIS Log Path was expected but not found on filesystem: " + $w3logpath)
        }
    }
}

########################
# Collect and .zip two most recent RPC Client Access Logs (called only if CAS role is detected)
########################
function GetRPCClientAccessLogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    $LogLocationXMLFileName = Join-Path -Path $global:exbin -childpath Microsoft.Exchange.RpcClientAccess.Service.exe.config
    If (Test-Path $LogLocationXMLFileName)
	{
        [xml]$LogLocationXML = Get-Content -Path $LogLocationXMLFileName
        $RPCLogPathFromConfig = $loglocationxml.configuration.appsettings.selectsinglenode("add[@key='LogPath']").value
        If ($rpclogpathfromconfig.tolower().startswith("%exchangeinstalldir%") -eq $true)
		{
            $RPCLogPath = $RPCLogPathFromConfig.replace("%ExchangeInstallDir%\",$global:exinstall)
        }
        Else
		{
            $RPCLogPath = $RPCLogPathFromConfig
        }
    }
    
    if (Test-Path $RPCLogPath){
		If ($rpclogpathfromconfig.tolower().endswith("\") -eq $false)
		{
			$RPCLogPath += "\"
		}
		Write-DebugLog ("RPC Client Access Log Path: '$RPCLogPath'")
        CompressCollectFiles -filesToCollect ($RPCLogPath + '*.log')-fileDescription ("RPCClientAccess logs modified in past 5 days") -DestinationFileName "Logs_RPCClientAccess.zip" -sectionDescription (Get-ReportSection) -NumberOfDays 5 #-Recursive 
    }
	Else
	{
        Write-DebugLog ("Logs_RPCCLientAccess: No Files Found to Zip At '$RPCLogPath'")
	}
}

########################
# Collect and .zip two most recent AddressBook Service Logs (called only if CAS role is detected)
########################
function GetAddressBookServiceLogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    $LogLocationXMLFileName = Join-Path -Path $global:exbin -childpath Microsoft.Exchange.addressbook.Service.exe.config
    If (Test-Path $LogLocationXMLFileName){
        [xml]$LogLocationXML = Get-Content -Path $LogLocationXMLFileName
        $ABServiceLogPath = $loglocationxml.configuration.appsettings.selectsinglenode("add[@key='LogFilePath']").value
    }
    
    If (Test-Path $ABServiceLogPath){
        $ABServiceLogs = Get-ChildItem $ABServiceLogPath | Where-Object {!$_.psiscontainer } | sort LastWriteTime -Descending | select-object -First 2
        "ABService Logs: " + $ABServiceLogs | WriteTo-StdOut
        if ($ABServiceLogs.length -gt 0){
            $ABServiceLogsZipFile = out-zip -FilePath $ABServiceLogs -zipFileName "Logs_AddressBookService"
            CollectFiles -filestocollect ($ABServiceLogsZipFile) -filedescription ("Logs_AddressBookService") -sectiondescription (Get-ReportSection) #-noFileExtensionsOnDescription
        }
            Else{
            Write-DebugLog ("Logs_AddressBookService: No Files Found to Zip At '$ABServiceLogPath'")
        }
    }
}

########################
# Collect and .zip 5 most recent Connectivity Logs (called only if Transport role is detected)
########################
function GetConnectivitylogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }
 
    $Connectivitylogpath = (Get-TransportServerCached).connectivitylogpath.PathName

    
    If (Test-Path $Connectivitylogpath){
        $ConnectivityLogs = Get-ChildItem $Connectivitylogpath | Where-Object {!$_.psiscontainer } | sort LastWriteTime -Descending | select-object -First 5
        "Connectivity Logs: " + $ConnectivityLogs | WriteTo-StdOut
        if ($ConnectivityLogs.length -gt 0){
            $ConnectivityLogsZipFile = out-zip -FilePath $ConnectivityLogs -zipFileName "Logs_Connectivity"
            CollectFiles -filestocollect ($ConnectivityLogsZipFile) -filedescription ("Logs_Connectivity") -sectiondescription (Get-ReportSection) #-noFileExtensionsOnDescription
        }
            Else{
            Write-DebugLog ("Logs_Connectivity: No Files Found to Zip At '$Connectivitylogpath'")
        }
    }
}


########################
# Collect and .zip 5 most recent Message Tracking Logs (called only if Transport role is detected)
########################
function GetMessageTrackingLogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }

    $MessageTrackingLogPath = (Get-TransportServerCached).MessageTrackingLogPath.PathName
    
    If (Test-Path $MessageTrackingLogPath){
        $MessageTrackingLogs = Get-ChildItem $MessageTrackingLogPath | Where-Object {!$_.psiscontainer } | sort LastWriteTime -Descending | select-object -First 5
        "Message Tracking Logs: " + $MessageTrackingLogs | WriteTo-StdOut
        if ($MessageTrackingLogs.length -gt 0){
            $MessageTrackingLogsZipFile = out-zip -FilePath $MessageTrackingLogs -zipFileName "Logs_MessageTracking"
            CollectFiles -filestocollect ($MessageTrackingLogsZipFile) -filedescription ("Logs_MessageTracking") -sectiondescription (Get-ReportSection) #-noFileExtensionsOnDescription
        }
            Else{
            Write-DebugLog ("Logs_MessageTracking: No Files Found to Zip At '$MessageTrackingLogPath'")
        }
    }
}

########################
# Collect and .zip two most recent Update-HybridConfiguration Logs if present
########################
function GetHybridConfigLogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    $HybridConfigLogPath = Join-Path -Path $global:exinstall -ChildPath "Logging\Update-HybridConfiguration"
    
    If (Test-Path $HybridConfigLogPath){
        $HybridConfigLogs = Get-ChildItem $HybridConfigLogPath | Where-Object {!$_.psiscontainer } | sort LastWriteTime -Descending | select-object -First 2
        "HybridConfiguration Logs: " + $HybridConfigLogs | WriteTo-StdOut
        if ($HybridConfigLogs.length -gt 0){
            $HybridConfigLogsZipFile = out-zip -FilePath $HybridConfigLogs -zipFileName "Logs_Update-HybridConfiguration"
            CollectFiles -filestocollect ($HybridConfigLogsZipFile) -filedescription ("Logs_Update-HybridConfiguration") -sectiondescription (Get-ReportSection) #-noFileExtensionsOnDescription
        }
            Else{
            Write-DebugLog ("Logs_Update-HybridConfiguration: No Files Found to Zip At '$HybridConfigLogPath'")
        }
    }
}

############################################################# 
#                                                           # 
# Script Starts Here                                        #
#                                                           #
#############################################################
    
#======================================
# Load localized strings
#======================================
Import-LocalizedData -BindingVariable GetExchDataStrings

#======================================
# Set global variables regardless of Exchange version inestalled
#======================================
$global:SystemDrv = (Get-ChildItem env:systemdrive).value


#======================================
# Tracks Script Execution count and disables confirmation
#======================================
$script:count = 0
$ConfirmPreference = "NONE"
$script:executedNoResults

If ($getExBPA){$script:paramGetExBPA = $true}
If ($getSetupLogs){$script:paramGetSetupLogs = $true}
#======================================
# Call the  Get-ExchangeData function
#======================================

"Calling Get-ExchangeData" | WriteTo-StdOut
    Get-ExchangeData

# Collect Debug logs
Collect-DebugLog

# SIG # Begin signature block
# MIIbDgYJKoZIhvcNAQcCoIIa/zCCGvsCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUYTtoWxQWrUzM4eb8LB6U+tYl
# 02ygghWCMIIEwzCCA6ugAwIBAgITMwAAAEyh6E3MtHR7OwAAAAAATDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTMxMTExMjIxMTMx
# WhcNMTUwMjExMjIxMTMxWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkMwRjQtMzA4Ni1ERUY4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsdj6GwYrd6jk
# lF18D+Z6ppLuilQdpPmEdYWXzMtcltDXdS3ZCPtb0u4tJcY3PvWrfhpT5Ve+a+i/
# ypYK3EbxWh4+AtKy4CaOAGR7vjyT+FgyeYfSGl0jvJxRxA8Q+gRYtRZ2buy8xuW+
# /K2swUHbqs559RyymUGneiUr/6t4DVg6sV5Q3mRM4MoVKt+m6f6kZi9bEAkJJiHU
# Pw0vbdL4d5ADbN4UEqWM5zYf9IelsEEXb+NNdGbC/aJxRjVRzGsXUWP6FZSSml9L
# KLrmFkVJ6Sy1/ouHr/ylbUPcpjD6KSjvmw0sXIPeEo1qtNtx71wUWiojKP+BcFfx
# jAeaE9gqUwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFLkNrbNN9NqfGrInJlUNIETY
# mOL0MB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAAmKTgav6O2Czx0HftcqpyQLLa+aWyR/lHEMVYgkGlIVY+KQ
# TQVKmEqc++GnbWhVgrkp6mmpstXjDNrR1nolN3hnHAz72ylaGpc4KjlWRvs1gbnk
# PUZajuT8dTdYWUmLTts8FZ1zUkvreww6wi3Bs5tSLeA1xbnBV7PoPaE8RPIjFh4K
# qlk3J9CVUl6ofz9U8IHh3Jq9ZdV49vdMObvd4NY3DpGah4xz53FkUvc+A9jGzXK4
# NDSYW4zT9Qim63jGUaANDm/0azxAGmAWLKkGUp0cE5DObwIe6nucs/b4l2DyZdHR
# H4c6wXXwQo167Yxysnv7LIq0kUdU4i5pzBZUGlkwggTsMIID1KADAgECAhMzAAAA
# sBGvCovQO5/dAAEAAACwMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTEzMDEyNDIyMzMzOVoXDTE0MDQyNDIyMzMzOVowgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAOivXKIgDfgofLwFe3+t7ut2rChTPzrbQH2zjjPmVz+l
# URU0VKXPtIupP6g34S1Q7TUWTu9NetsTdoiwLPBZXKnr4dcpdeQbhSeb8/gtnkE2
# KwtA+747urlcdZMWUkvKM8U3sPPrfqj1QRVcCGUdITfwLLoiCxCxEJ13IoWEfE+5
# G5Cw9aP+i/QMmk6g9ckKIeKq4wE2R/0vgmqBA/WpNdyUV537S9QOgts4jxL+49Z6
# dIhk4WLEJS4qrp0YHw4etsKvJLQOULzeHJNcSaZ5tbbbzvlweygBhLgqKc+/qQUF
# 4eAPcU39rVwjgynrx8VKyOgnhNN+xkMLlQAFsU9lccUCAwEAAaOCAWAwggFcMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBRZcaZaM03amAeA/4Qevof5cjJB
# 8jBRBgNVHREESjBIpEYwRDENMAsGA1UECxMETU9QUjEzMDEGA1UEBRMqMzE1OTUr
# NGZhZjBiNzEtYWQzNy00YWEzLWE2NzEtNzZiYzA1MjM0NGFkMB8GA1UdIwQYMBaA
# FMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY0NvZFNpZ1BDQV8w
# OC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljQ29kU2lnUENBXzA4LTMx
# LTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQAx124qElczgdWdxuv5OtRETQie
# 7l7falu3ec8CnLx2aJ6QoZwLw3+ijPFNupU5+w3g4Zv0XSQPG42IFTp8263Os8ls
# ujksRX0kEVQmMA0N/0fqAwfl5GZdLHudHakQ+hywdPJPaWueqSSE2u2WoN9zpO9q
# GqxLYp7xfMAUf0jNTbJE+fA8k21C2Oh85hegm2hoCSj5ApfvEQO6Z1Ktwemzc6bS
# Y81K4j7k8079/6HguwITO10g3lU/o66QQDE4dSheBKlGbeb1enlAvR/N6EXVruJd
# PvV1x+ZmY2DM1ZqEh40kMPfvNNBjHbFCZ0oOS786Du+2lTqnOOQlkgimiGaCMIIF
# vDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZIm
# iZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQD
# EyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMTAwODMx
# MjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJyWVwZMGS/HZpgICBC
# mXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay7P/ewkJOI9VyANs1VwqJyq4gSfTw
# aKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB2/O98jakyVxF3K+tPeAoaJcap6Vy
# c1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpnUo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ
# +NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049oDI9kM2hOAaFXE5WgigqBTK3S9dP
# Y+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJGzzc8OJ60d1ylF56NyxGPVjzBrAlf
# A9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFMsR6MrS
# tBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIBhjASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGYYDuoMW+mPLzYLTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAWgBQOrIJgQFYnl+UlE/wq4QpTlVnk
# pDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEE
# SDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDANBgkqhkiG9w0BAQUFAAOCAgEAWTk+
# fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddDrQv+y+ktMaMjzHxQmIAhXaw9L0y6
# oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6WcIC36C1DEVs0t40rSvHDnqA2iA6VW
# 4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqkghyT4pQHHfLiTviMocroE6WRTsgb
# 0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5Y1ZEolHN+emjWFbdmwJFRC9f9Nqu
# 1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6EiYJZTiU8XofSrvR4Vbo0HiWGFzJ
# NRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjHCe6FDoxPbQ4TTj18KUicctHzbMrB
# 7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI5nI3EvRvsTxngvlSso0zFmUeDord
# EN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMnQK3k+eGpf0a7B2BHZWBATrBC7E7t
# s3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9QFi58vwUheuKVQSdpw5OPlcmN2Jsh
# rg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMkuYjPaqhHMS+a3ONxPdcAfmJH0c6I
# ybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjWwz0wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TGCBPYwggTy
# AgEBMIGQMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAh
# BgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBAhMzAAAAsBGvCovQO5/d
# AAEAAACwMAkGBSsOAwIaBQCgggEOMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBQM
# h4kfqQv3Cz58qgerPEFR9rJUrjCBrQYKKwYBBAGCNwIBDDGBnjCBm6CBgIB+AEQA
# SQBBAEcAXwBDAFQAUwBfAEcAZQBuAGUAcgBhAGwAXwBSAGUAcABvAHIAdABzAF8A
# ZwBsAG8AYgBhAGwAXwBEAEMAXwBHAGUAdABFAHgAYwBoAGEAbgBnAGUAMgAwADAA
# NwBfADIAMAAxADAARABhAHQAYQAuAHAAcwAxoRaAFGh0dHA6Ly9taWNyb3NvZnQu
# Y29tMA0GCSqGSIb3DQEBAQUABIIBAEUz/c2CakCzuS50QiE35NlFAMozVcbWs5O9
# hmmtSpLVbyhUnUOIGRwtJB9eBVjahVl6Twy6hJwThBo4GjOeWgttdNG1Ci2bLpdg
# Ll5AsKeN+sTjy52+zO3vETwyABExX423B/8OktUt7PqOF5q0fjE5AKGFKDoSfv6I
# Ir+JKMK55MbOiFOZAg7YH/L1zUOnQKYIJZs50pO3O4g49cKHbiPZA6GmAgPTNblH
# 55QAKaw7oZ5CmGeLKEPKK4N/E5T0d/mITuCFfY9E1Vb1/u4zVp3JEipIm5GGyF3b
# XPpyqHoZXVqmYr/Q3evehgDrdxaRccSMtR+vjv43De+JIipuDnahggIoMIICJAYJ
# KoZIhvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# AhMzAAAATKHoTcy0dHs7AAAAAABMMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMx
# CwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0xNDAyMjQxNzM3NTZaMCMGCSqG
# SIb3DQEJBDEWBBQfSvAi3LZTnQpkGEMBRadRKOjnyzANBgkqhkiG9w0BAQUFAASC
# AQBd5Doiyf6uQAImLWt+ETdl0xDxkWwlVnT7/mIpS/cgNRz7KsJuObbTNbu4uuph
# akWeFNcZv3rEFlP7NRQwmI4WPDVlnnUQzCchUGku2CCQn5gTy6EvFkpY6FvArOW/
# FKHwSDemvrA2f8j6pMXdfJlMvjSGBlJ4cPwTz9iisk+ukwID0Q25UoZIC8pPrVpJ
# MVU6HTXjCodgWcYMZCvc2zkRtOtJx0QHrpKTK0PkDZQaOn4elyS+NS+++HVKIa/d
# vaQEI9xMFQVduhkG5VVDhBu/UaZabYrQtLvFFQ+ZqFFJH37ASEhIcupNLm4FQ029
# 0Wrdqy6xKm1L3f6K+FnDvVDw
# SIG # End signature block
