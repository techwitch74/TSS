﻿#************************************************
# TS_AppCompatDisabledCheck.ps1
# Version 1.0.1
# Date: 6/8/2012
# Author: v-blchen
# Description:  [Idea ID 3317] [Windows] DisableEngine reg entry can cause app install or registration failure
# Rule number:  3317
# Rule URL:  http://sharepoint/sites/rules/Rule Submissions/Forms/DispForm.aspx?ID=3317
#************************************************

Import-LocalizedData -BindingVariable ScriptStrings
Display-DefaultActivity -Rule -RuleNumber 3317

$RuleApplicable = $false
$RootCauseDetected = $false
$RootCauseName = "RC_AppCompatDisabledCheck"
$PublicContent = ""
$InternalContent = "https://vkbexternal.partners.extranet.microsoft.com/VKBWebService/ViewContent.aspx?scid=B;EN-US;2694134"
$Verbosity = "Warning"
$Visibility = "3"
$SupportTopicsID = "8022"
$Title = $ScriptStrings.ID_AppCompatDisabledCheck_ST

$InformationCollected = new-object PSObject

# ***************************
# Data Gathering
# ***************************

# check whether is applies to current system
Function AppliesToSystem
{
	if ((($OSVersion.Major -eq 6) -and ($OSVersion.Minor -eq 0)) -or # Server 2008 / Vista
	   (($OSVersion.Major -eq 6) -and ($OSVersion.Minor -eq 1)) -or # Win 7/R2
	   (($OSVersion.Major -eq 6) -and  ($OSVersion.Minor -eq 2)) -or # Win8/Server 2012
	   ($OSVersion.Major -eq 10) ) # Win10
	   {
		 return $true
	   }
	   else
	   {
		  return $false
	   }
}
# check whether the state of ApplicationCompatibilityEngine is set to 1
Function CheckStateOfApplicationCompatibilityEngine
{
	$AppCompatkey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat"
	if(Test-Path $AppCompatkey)
	{
		$DisableEngineValue = (Get-ItemProperty -Path $AppCompatkey).DisableEngine
		if($DisableEngineValue -eq 1)
		{
			return $true
		}
	}
	return $false
}



# **************
# Detection Logic
# **************

#Check to see if rule is applicable to this computer
if (AppliesToSystem)
{
	$RuleApplicable = $true
	
	if ($true)
	{
		$RootCauseDetected = CheckStateOfApplicationCompatibilityEngine
	}
}	
	

# *********************
# Root Cause processing
# *********************

if ($RuleApplicable)
{
	if ($RootCauseDetected)
	{
		# Red/ Yellow Light
		Update-DiagRootCause -id $RootCauseName -Detected $true
		Write-GenericMessage -RootCauseId $RootCauseName -PublicContentURL $PublicContent -InformationCollected $InformationCollected -Verbosity $Verbosity -Visibility $Visibility -SupportTopicsID $SupportTopicsID -InternalContentURL $InternalContent -SolutionTitle $Title
	}
	else
	{
		# Green Light
		Update-DiagRootCause -id $RootCauseName -Detected $false
	}
}


