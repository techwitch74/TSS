﻿
###########################################################################
# DC_FileVersions
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Collects File Versions
###########################################################################

Import-LocalizedData -BindingVariable FileVer -FileName DC_FileVersions -UICulture en-us
Write-DiagProgress -Activity $FileVer.ID_FileVer

$OutputFile = $ComputerName + "_FileVersions.txt"

logstart

Set-Content $OutputFile "" -Encoding Unknown

Function FileVersions ($File, $Header)
{
	Add-Content $OutputFile $Header -Encoding Unknown 
	Get-ChildItem $System32 | Where-Object {$File -contains $_.Name} | Format-Table Name, @{Name="Size (KB)";Expression={"{0:0}" -f ($_.Length/1KB)}}, `
	@{ Label = 'File Version'; Expression = { $_.VersionInfo.ProductVersion }}, @{Name="File Date"; Expression={$_.LastWriteTime}} -AutoSize | Out-File -Append $OutputFile
	
}

#Get the File Versions for WU Files listed as #WuFiles

$File = ("wuauserv.dll", "wuaueng.dll", "wuapi.dll", "wuauclt.exe", "wups2.dll", "wups.dll", "wuweb.dll", `
"wuaucpl.cpl", "wuaueng1.dll", "wucltui.dll", "wusetupr.dll", "cdm.dll", "muweb.cll", "mucltui.dll", "iuengine.dll", `
"wuauclt1.exe", "wuauhelp.chm")
$Header = "Windows Update Agent (AU Client) File Versions: "
FileVersions $File $Header 

#Get the File Versions for MSVCRT.dll
$File = "msvcrt.dll"
$Header = "MSVCRT.DLL File Versions: "
FileVersions $File $Header 


#Get the File Versions for MSXML
$File = ("msxml3.dll", "MSXML3R.DLL") 
$Header = "MSXML File Versions:"
FileVersions $File $Header 

#Get the File Versions for BITS/WinHTTP
$File = ("bitsprx2.dll", "bitsprx3.dll", "qmgr.dll","qmgrprxy.dll", "http.sys", "winhttp.dll", "xpob2res.dll") 
$Header = "BITS / WinHTTP File Versions:"
FileVersions $File $Header 


#Get the File Versions for Windows Installer (MSI)
$File = ("msi.dll", "msiexec.exe", "msihnd.dll", "msimsg.dll", "msisip.dll") 
$Header = "Windows Installer (MSI) File Versions:"
FileVersions $File $Header 

#Get the File Versions for Windows Jet and Server DB Files
$File = ("esent.dll", "msjet40.dll", "msjet35.dll") 
$Header = "Windows Jet and Server Database files (Jet and esent) File Versions:"
FileVersions $File $Header 


CollectFiles -filesToCollect $OutputFile -fileDescription "File Versions" -sectionDescription "Windows Update Information"

logstop