# ***********************************************************************************************************************************
# Version 1.0
# Date: 03-25-2012, 2021
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects basic Networking Information.
#		Base script taken from SharedComponents\Scripts\NetworkBasicInfo.
#		1. Gets IP Details.
#		2. Gets Proxy Information
#		3. Gets Active BITS Jobs
#		4. Gets Enabled Firewall Rules
#		5. Gets TCP/IP Information
#		6. Gets SMB Information
#		7. Summarizes all data to a text file for better readability.
# ***********************************************************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

Function RunCommand ([string]$cmdToRun="", [string]$OutputFile, [string]$FileDescription="", [string]$CollectFile=$false)
{
	"`r`n" + "-" * ($cmdToRun.Length + 2) + "`r`n[" + $cmdToRun + "]`r`n" + "-" * ($cmdToRun.Length + 2) + "`r`n" | Out-File -FilePath $OutputFile -Append
	$CommandLineToExecute = "cmd.exe /c $cmdToRun >> `"$OutputFile`""

	if ($CollectFile -ne $true)
	{
		$X = RunCmD -commandToRun $CommandLineToExecute -filesToCollect $OutputFile -CollectFiles $false
	} else {
		$x = RunCmD -commandToRun $CommandLineToExecute -sectionDescription $NetBasicInfoStrings.ID_NetBasicInfo -filesToCollect $OutputFile -fileDescription $FileDescription -noFileExtensionsOnDescription
	}
}

TraceOut "Started"

Import-LocalizedData -BindingVariable NetBasicInfoStrings
$sectiondescription = "Networking Information"
$NetInfoFile = Join-Path $Pwd.Path ($ComputerName + "__NET_Summary.txt")

# -----------
# IP Address
# -----------
"------------" | Out-File $NetInfoFile
"IP Details:" | Out-File $NetInfoFile -Append
"------------" | Out-File $NetInfoFile -Append
Get-CimInstance -namespace root\cimv2 -class Win32_NetworkAdapterConfiguration | Where { $_.IPAddress -ne $null } | `
	Select-Object DNSHostName,IpAddress,DefaultIPGateway,IPSubnet,MACAddress,DHCPEnabled -Unique | `
	Out-File $NetInfoFile -Append

# -----------------
# Proxy Information
# -----------------
$TempFileName = $ComputerName + "_OS_ProxyInfo.txt"
$ProxyFile = Join-Path $Pwd.Path $TempFileName
"-----------------------------------" | Out-File $NetInfoFile -Append
"Proxy Information (System and User)" | Out-File $NetInfoFile -Append
"-----------------------------------" | Out-File $NetInfoFile -Append
"    Review $TempFileName" | Out-File $NetInfoFile -Append

# System Proxy
"==========================" | Out-File $ProxyFile -Append
"Proxy Information (System)" | Out-File $ProxyFile -Append
"==========================" | Out-File $ProxyFile -Append
if ($OSVersion.Major -ge 6)
{
	RunCmD -commandToRun "psexec.exe /accepteula -s netsh winhttp show proxy >> $ProxyFile" -collectFiles $false
}
else
{
	RunCmD -commandToRun "psexec.exe /accepteula -s proxycfg >> $ProxyFile" -collectFiles $false
}

# User Proxy
"========================" | Out-File $ProxyFile -Append
"Proxy Information (User)" | Out-File $ProxyFile -Append
"========================" | Out-File $ProxyFile -Append
if ($OSVersion.Major -ge 6)
{
	RunCmd -commandToRun "netsh winhttp show proxy >> $ProxyFile" -collectFiles $false
}
else
{
	RunCmd -commandToRun "proxycfg >> $ProxyFile" -collectFiles $false
}

"=================================" | Out-File $ProxyFile -Append
"Proxy Information (Registry Keys)" | Out-File $ProxyFile -Append
"=================================" | Out-File $ProxyFile -Append
$ProxyRegKey = "HKLM\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
Export-RegKey -RegKey $ProxyRegKey -outFile $ProxyFile -collectFiles $false -Recurse $false -UpdateDiagReport $false

$ProxyRegKey = "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
Export-RegKey -RegKey $ProxyRegKey -outFile $ProxyFile -collectFiles $false -Recurse $false -UpdateDiagReport $false

$ProxyRegKey = "HKU\.DEFAULT\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
Export-RegKey -RegKey $ProxyRegKey -outFile $ProxyFile -collectFiles $false -Recurse $false -UpdateDiagReport $false

CollectFiles -filesToCollect $ProxyFile -fileDescription "Proxy Configuration" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $NetBasicInfoStrings.ID_SCCM_ACTIVITY_NetworkInfo -Status $NetBasicInfoStrings.ID_SCCM_NetworkInfo_BITS

# -------------------
# Get Bits Transfers
# -------------------
"" | Out-File $NetInfoFile -Append
"-----------------" | Out-File $NetInfoFile -Append
"Active BITS Jobs" | Out-File $NetInfoFile -Append
"-----------------" | Out-File $NetInfoFile -Append
$TempFileName = $ComputerName + "_OS_BITSTransfers.txt"
$BitsFile = Join-Path $Pwd.Path $TempFileName
$CmdToRun = "psexec.exe /accepteula -s bitsadmin.exe /RAWRETURN /list /allusers /verbose >> $BitsFile"
$RetVal = RunCmd -commandToRun $CmdToRun -collectFiles $false -useSystemDiagnosticsObject
If ($RetVal -eq 0) {
	If ((Get-Content $BitsFile) -ne $null) {
		# BitsAdmin.exe executed succesfully, and output file was not empty
		CollectFiles -filesToCollect $BitsFile -fileDescription "Active BITS Jobs" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
		"    Review $TempFileName" | Out-File $NetInfoFile -Append
	}
	Else {
		# BitsAdmin.exe executed succesfully, but output file was empty
		"    No Active Bits Jobs Found" | Out-File $NetInfoFile -Append
	}
}
Else {
	"    Failed to run bitsadmin command. Error $RetVal" | Out-File $NetInfoFile -Append
}

# ---------------
# Firewall Rules
# ---------------
"" | Out-File $NetInfoFile -Append
"-----------------------" | Out-File $NetInfoFile -Append
"Enabled Firewall Rules" | Out-File $NetInfoFile -Append
"-----------------------" | Out-File $NetInfoFile -Append
$TempFileName = $ComputerName + "_OS_EnabledFirewallRules.txt"
$fwFile = Join-Path $Pwd.Path $TempFileName
"===================================" | Out-File $fwFile -Append -Width 1000
$Temp = (Get-Service | Where {$_.DisplayName -match 'Windows Firewall'} | Select-Object Status)
"Firewall Service Status = " + $Temp.Status | Out-File $fwFile -Append -Width 1000
"===================================" | Out-File $fwFile -Append -Width 1000

If ($OSVersion.Major -ge 6) {
	trap [Exception]
	{
		"    ERROR: " + ($_.Exception.Message) | Out-File $NetInfoFile -Append
	}
	$fw = New-Object -ComObject hnetcfg.fwpolicy2 -ErrorAction SilentlyContinue -ErrorVariable FWError
	If ($FWError.Count -eq 0) {
		$fw.Rules | Where-Object {$_.Enabled} | Sort-Object Name | `
			Format-Table -Property Name,Direction,Protocol,LocalPorts,RemotePorts,LocalAddresses,RemoteAddresses,ServiceName,ApplicationName -AutoSize | `
			Out-File $fwFile -Append -Width 1000
		CollectFiles -filesToCollect $fwFile -fileDescription "Enabled Firewall Rules" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
		"    Review $TempFileName" | Out-File $NetInfoFile -Append
	}
}
Else {
	$CmdToRun = "netsh firewall show config >> " + $fwFile
	RunCmd -commandToRun $CmdToRun -filesToCollect $fwFile -fileDescription "Enabled Firewall Rules" -sectionDescription "Networking Information" -noFileExtensionsOnDescription
	"    Review $TempFileName" | Out-File $NetInfoFile -Append
}

# ---------------------------
# TCP/IP and SMB Information
# ---------------------------
$OutputFile = $ComputerName + "_OS_TCPIP-Info.txt"
"" | Out-File $NetInfoFile -Append
"-------------------" | Out-File $NetInfoFile -Append
"TCP/IP Information" | Out-File $NetInfoFile -Append
"-------------------" | Out-File $NetInfoFile -Append
"    Review $OutputFile" | Out-File $NetInfoFile -Append

RunCommand -cmdToRun "hostname" -OutputFile $OutputFile
RunCommand -cmdToRun "ipconfig /all" -OutputFile $OutputFile
RunCommand -cmdToRun "arp -a" -OutputFile $OutputFile
RunCommand -cmdToRun "nbtstat -n" -OutputFile $OutputFile
RunCommand -cmdToRun "netstat -ano" -OutputFile $OutputFile
RunCommand -cmdToRun "netstat -anob" -OutputFile $OutputFile
RunCommand -cmdToRun "reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -OutputFile $OutputFile
if ($OSVersion.Major -ge 6)
{
	RunCommand -cmdToRun "netsh int tcp show global" -OutputFile $OutputFile
	RunCommand -cmdToRun "netsh int ipv4 show offload" -OutputFile $OutputFile
	RunCommand -cmdToRun "netstat -nato -p tcp" -FileDescription "TCP/IP Information" -OutputFile $OutputFile -CollectFile $true
}
else
{
	RunCommand -cmdToRun "netstat -ano -p tcp" -FileDescription "TCP/IP Information" -OutputFile $OutputFile -CollectFile $true
}

$OutputFile = $ComputerName + "_OS_SMB-Info.txt"
"" | Out-File $NetInfoFile -Append
"----------------" | Out-File $NetInfoFile -Append
"SMB Information" | Out-File $NetInfoFile -Append
"----------------" | Out-File $NetInfoFile -Append
"    Review $OutputFile" | Out-File $NetInfoFile -Append

if ((Get-TSRemote) -lt 2)
{
	RunCommand -cmdToRun "net config workstation" -OutputFile $OutputFile
}

if ((Get-Service "lanmanserver").Status -eq 'Running')
{
	RunCommand -cmdToRun "net config server" -OutputFile $OutputFile
	RunCommand -cmdToRun "net share" -OutputFile $OutputFile
	#RunCommand -cmdToRun "net statistics server" -OutputFile $OutputFile
}

RunCommand -cmdToRun "net sessions" -OutputFile $OutputFile
RunCommand -cmdToRun "net use" -OutputFile $OutputFile
RunCommand -cmdToRun "net accounts" -OutputFile $OutputFile
RunCommand -cmdToRun "net statistics workstation" -OutputFile $OutputFile -FileDescription "SMB Information" -CollectFile $true

# .\DC_NetBasicInfo.ps1

CollectFiles -filesToCollect $NetInfoFile -fileDescription "Network Information"  -sectionDescription $global:SummarySectionDescription -noFileExtensionsOnDescription

TraceOut "Completed"

# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAHrMN8JelFEqcD
# 45q8S2KhoMglranljR4P0asf48uDuKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgX6QilZUz
# vJW+TbZF765uapzm2TKrofYbw/aBOBtoQv4wOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBADawGbrOBUAkDe29gb2qiWlQUbEM2/XQkzw7vaCegJhX60O6KR1Vzeq2
# mTjUoD6LKuejLo9GD5NUGVYt0xftj2xoAaxetA2/TmnnJmNz3NNAKPtu1f/ER/Xd
# beY3Jx8OQQzUh4qvAtj+5tqexEeIc2BSsyrqhXRbaQk6DHQBPxzch0ZeD+V7gwmS
# GPLGVJKefD2TC2+2BmOqwDZIkNN8GLgrUEZAtTonqSwsvqPgIab6c5dciUfBpP8k
# pRy/TbsOwfsU1kCau8xD5+ubLebLYEcK289RBDGtwNxNedSLnU8lDsFKyFraS8XA
# egaIAyZ54eAFH41b0kNrueE3+oY35wGhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgbQtDhnzbJwnfxMAfg55fC+8KXBkdPbqaVBM64JgXPAICBmGB2SqX
# HRgTMjAyMTExMTExNjUzMzYuMTczWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3
# QTYtRTI1MS0xNTBBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFZn/x+Xyzq8kMAAAAAAVkwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE1WhcNMjIwNDExMTkwMjE1WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0xNTBB
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArnjEYclnxIdES00igGj0AboyujyARkK3
# xaBX+Y10i3a0w4/fNVhTj6xGwibFPB/MkQMFZpNzsvGUTL/XfTZ9GZ39HanCdjun
# JP3TK9kCZBAtnoP59oYHDCGLmut7+2YEl1sBcVnyovYkNzi3EGffQyvULwMUF2si
# PBs/6LZF0A5pLAiz/FCwx5kDPe/mP1UR3Crz6IzphwtyoqtgDA/44TnzfvVJPmSP
# Z/uq5Oh5NeFK8NzMpitWiQvdmfT4o0CdumnisfW1fKaaBdByBULPUT8TLw0Sy9nU
# WNXlA/qi8MxPxgCjsrNpi9PgjH7ExW9b7X/UydhpqhHxsudDGZNk4wIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFPbQqYVGvK365Osn14jCPLLpN2PnMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAI2RVBLoD4GGt8Y4IBajcpy5Rrh6y2nPKf5kuWSHSkmY
# AmngRQOstayJ5gJ/ajKhzwqNUwL40cUVW8cutIyFadHkW1jqXdnpSv0hMFLPriPn
# BNFETy8ilCIdViNFU08ZHa2Kobmco/n6wPStkjjrg4U3Pift6sMk6lXsibUv+wDB
# 9f4YehziPmt+4C5BMVjzax1i+0czgtPHBX33u6GUWznagdql0VbUpe3q8zERedJf
# yyhB9R34z5ircnu51zpH3jUa7F93oDS95xXnomO+akKeDiNGSq4B7J/90qZBRpHV
# 8q8AsFECZmQBS1aKNL/cyR5C/+VS8dWjsY8XMn87fAkwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY3QTYtRTI1MS0x
# NTBBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQAqdssAjx+E7nxIJaulmde9cRmyEaCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5TeMLjAiGA8y
# MDIxMTExMTE2MzM1MFoYDzIwMjExMTEyMTYzMzUwWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN4wuAgEAMAoCAQACAiZVAgH/MAcCAQACAhF9MAoCBQDlON2uAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAPB+o9P5KuWdUoJBXwoX4L87nThTU
# 2S11U5IDYOUcrI26xNl/t9OaqJWivy8rytDWLl0U61OAH/Jw2SxZ3rdAwBepTDZW
# XANDRvwidcy0kqxaIjbS2bRgBXkoflMeDGktaA077jCjC5wtBW+J2FKoHzH3b8ed
# jKupzCxZBxWH66UxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVmf/H5fLOryQwAAAAABWTANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCBjF8Er
# Jjy/0RQexTFomnjmhfJnYTem1scg/Z2bSsifCzCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIAFYG8+/MOZ815LOYlPj50YD66P+qrv98qRSffqvE0PoMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFZn/x+Xyzq8kMA
# AAAAAVkwIgQgcLVW3bJKbJiHgsAuVX1ytoKPdrXTVrHf9HHAbN3hmOwwDQYJKoZI
# hvcNAQELBQAEggEAjfj5U0P8m0r5d53CHoTqbEJ3kLIyDSygxGSqQE4iU/7N/lx4
# eNufBkT5SFpfsGvL80rkJ1TGzNrWKLZG5RLkn8VQiO1YHXqkksJLbCMByKUFzEqp
# CSq+fXjchqi6hnmMGHdYUHKgFkOrkyr9pTkiHwJ20AGnfJZWvanFAO2ttNA3hjvn
# GVeqGVSllrc0rxtwb3OnTaYpULAYBmea0o/9fwwCuhXvY0JYOPStNlP9vPOl1VRD
# pv5H+cHfSH/gKt4WzxqSvFMvKHeH5YI/QQah/XBqYtKoxRHdF9FZUZ/hBHbp8C4X
# g/kZICjVs4R1pvzIEdmDxRCT1QmXFH/IjPQ7yQ==
# SIG # End signature block
