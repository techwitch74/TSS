﻿#************************************************
# DC_SmbClient-Component.ps1
# Version 1.1
# Date: 2009-2019
# Author: Boyd Benson (bbenson@microsoft.com) +WalterE
# Description: Collects information about the SMB Client.
# Called from: Main Networking Diag, etc.
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBClient -Status $ScriptVariable.ID_CTSSMBClientDescription

function RunNet ([string]$NetCommandToExecute="")
{
	
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBClient -Status "net $NetCommandToExecute"
	
	$NetCommandToExecuteLength = $NetCommandToExecute.Length + 6
	"`n`n`n" + "=" * ($NetCommandToExecuteLength) + "`r`n" + "net $NetCommandToExecute" + "`r`n" + "=" * ($NetCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c net.exe " + $NetCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}


$sectionDescription = "SMB Client"


#----------W8/WS2012 powershell cmdlets
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber


$outputFile= $Computername + "_SmbClient_info_pscmdlets.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"SMB Client Powershell Cmdlets"							| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview" 												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. Get-SmbMapping"									| Out-File -FilePath $OutputFile -append
"   2. Get-SmbClientConfiguration"						| Out-File -FilePath $OutputFile -append
"   3. Get-SmbClientNetworkInterface"					| Out-File -FilePath $OutputFile -append
"   4. Get-SmbConnection"								| Out-File -FilePath $OutputFile -append
"   5. Get-SmbMultichannelConnection"					| Out-File -FilePath $OutputFile -append
"   6. Get-SmbMultichannelConstraint"					| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append

$smbClientServiceStatus = get-service * | where {$_.name -eq "lanmanworkstation"}	
if ($smbClientServiceStatus -ne $null)
{
	if ((Get-Service "lanmanworkstation").Status -eq 'Running')
	{
		if ($bn -ge 9200)
		{
			# Reference:
			#	The basics of SMB PowerShell, a feature of Windows Server 2012 and SMB 3.0
			#   http://blogs.technet.com/b/josebda/archive/2012/06/27/the-basics-of-smb-powershell-a-feature-of-windows-server-2012-and-smb-3-0.aspx
			RunPS "Get-SmbMapping"					-ft	# W8/WS2012, W8.1/WS2012R2	#default <unknown>
			RunPS "Get-SmbClientConfiguration"			# W8/WS2012, W8.1/WS2012R2	# defaults to fl
			RunPS "Get-SmbClientNetworkInterface" 	-ft	# W8/WS2012, W8.1/WS2012R2	# defaults to ft
			RunPS "Get-SmbConnection"				-ft	# W8/WS2012, W8.1/WS2012R2	# defaults to ft
			RunPS "Get-SmbMultichannelConnection"	-ft	# W8/WS2012, W8.1/WS2012R2	# defaults to ft		# run on both client and server
			RunPS "Get-SmbMultichannelConstraint"		# W8/WS2012, W8.1/WS2012R2	# defaults to <unknown>	# run on both client and server
		}
	}
	else
	{
		"The `"Workstation`" service is not running. Not running pscmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Workstation`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}

CollectFiles -filesToCollect $OutputFile -fileDescription "SMB Client Information from Powershell cmdlets" -SectionDescription $sectionDescription



#----------Net Commands
$OutputFile= $Computername + "_SmbClient_info_net.TXT"



"===================================================="	| Out-File -FilePath $OutputFile -append
"SMB Client Netsh Commands"								| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview" 												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. net config workstation"							| Out-File -FilePath $OutputFile -append
"   2. net statistics workstation"						| Out-File -FilePath $OutputFile -append
"   3. net use"											| Out-File -FilePath $OutputFile -append
"   4. net accounts"									| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append


$smbClientServiceStatus = get-service * | where {$_.name -eq "lanmanworkstation"}	
if ($smbClientServiceStatus -ne $null)
{
	if ((Get-Service "lanmanworkstation").Status -eq 'Running')
	{
		RunNet "config workstation"
		RunNet "statistics workstation"
	}
	else
	{
		"The `"Workstation`" service is not running. Not running pscmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Workstation`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}
	RunNet "use"
	RunNet "accounts"

CollectFiles -filesToCollect $OutputFile -fileDescription "SMB Client Information from Net.exe" -SectionDescription $sectionDescription


#----------Registry
$OutputFile= $Computername + "_SmbClient_reg_output.TXT"

$CurrentVersionKeys =   "HKLM\SYSTEM\CurrentControlSet\services\LanManWorkstation",
						"HKLM\SYSTEM\CurrentControlSet\services\lmhosts",
						"HKLM\SYSTEM\CurrentControlSet\services\MrxSmb",
						"HKLM\SYSTEM\CurrentControlSet\services\MrxSmb10",
						"HKLM\SYSTEM\CurrentControlSet\services\MrxSmb20",
						"HKLM\SYSTEM\CurrentControlSet\services\MUP",
						"HKLM\SYSTEM\CurrentControlSet\services\NetBIOS",
						"HKLM\SYSTEM\CurrentControlSet\services\NetBT",
						"HKCU\Network",
						"HKLM\SYSTEM\CurrentControlSet\Control\NetworkProvider",
						"HKLM\SYSTEM\CurrentControlSet\services\Rdbss",
						"HKLM\SYSTEM\CurrentControlSet\Control\SMB",
						"HKLM\SYSTEM\CurrentControlSet\Control\Computername"
RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "SMB Client registry output" -SectionDescription $sectionDescription


#W8/WS2012 and later
if ($bn -gt 9000)
{
	#----------SMBClient / Operational
	$sectionDescription = "SMBClient EventLogs"
	$EventLogNames = "Microsoft-Windows-SMBClient/Connectivity", "Microsoft-Windows-SMBClient/Operational", "Microsoft-Windows-SMBClient/Security", "Microsoft-Windows-SMBWitnessClient/Admin", "Microsoft-Windows-SMBWitnessClient/Informational", "Microsoft-Windows-SMBClient/Audit", "Microsoft-Windows-SMBClient/Diagnostic", "Microsoft-Windows-SMBClient/HelperClassDiagnostic", "Microsoft-Windows-SMBClient/ObjectStateDiagnostic", "Microsoft-Windows-SMBClient/XperfAnalytic"
	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}

