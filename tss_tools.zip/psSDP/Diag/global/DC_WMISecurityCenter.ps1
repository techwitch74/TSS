﻿
Import-LocalizedData -BindingVariable WMIStrings -FileName DC_WMISecurityCenter -UICulture en-us
Write-DiagProgress -Activity $WMIStrings.ID_SecurityCenter -Status $WMIStrings.ID_SecurityCenterDesc

$OutputFile = $ComputerName + "_SecurityCenter.txt"
$file = new-item -type file $OutputFile

# Computer name
$strComputer = "."

 # Antivirus Product
"========================================================" >> $OutputFile
"Antivirus Product" >> $OutputFile
"========================================================" >> $OutputFile
#$colItems = get-wmiobject -class "AntivirusProduct" -Recurse -namespace "root\securitycenter2" -computername $strComputer | Select-Object * -ExcludeProperty "__*","Site","Container","Qualifiers","SystemProperties","instanceGuid","Options"
get-wmiobject -class "AntivirusProduct" -Recurse -namespace "root\securitycenter2" -computername $strComputer | Select-Object * -ExcludeProperty "__*","Site","Container","Qualifiers","SystemProperties","instanceGuid","Options" | Out-File -append $outputfile | Format-wide

#$colItems >> $OutputFile

"" >> $OutputFile

# AntiSpyware Product
"========================================================" >> $OutputFile
"AntiSpyware Product" >> $OutputFile
"========================================================" >> $OutputFile
 #$colItems = get-wmiobject -class "AntiSpywareProduct" -Recurse -namespace "root\securitycenter2" -computername $strComputer | Select-Object * -ExcludeProperty "__*","Site","Container","Qualifiers","SystemProperties","instanceGuid","Options"
 get-wmiobject -class "AntiSpywareProduct" -Recurse -namespace "root\securitycenter2" -computername $strComputer | Select-Object * -ExcludeProperty "__*","Site","Container","Qualifiers","SystemProperties","instanceGuid","Options" | Out-File -Append $OutputFile | Format-Wide
 
 #$colItems >> $OutputFile


CollectFiles -filesToCollect $OutputFile -fileDescription "Security Center.log" -sectionDescription "System Information" 
 
