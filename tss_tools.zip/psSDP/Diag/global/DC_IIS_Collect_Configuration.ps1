﻿# Copyright ? 2011, Microsoft Corporation. All rights reserved.
# This script will collect the metabase.xml or applicationHost.config file, along with all web.config files
# Collects Framework directory Configuration files
# for the web sites passed into the script
# Written By:   Bret Bentzinger
# Date:			July 7, 2011
# Version:      1.0
#
# Updated:      N/A
#
# Script Logic:  Copies the applicationHost.config, or metabase.xml into $PWD.Path
#   Copies the administration.config and redirection.config files
#	Copies all framework directory configuration to Files named Framework_vxxx_config file name
#   Iterrates through IIS Sites/Applciations looking for all web.config files and Copies Then to files name Site_APP_VDir_Web.config
#   Calls CompressCollectFiles on the $files array to put into IISConfigFiles.zip
# Input Parameters - 
#		$args[0] - Array of strings containing the site names.  Access using $_ with ForEach-Object
param([string[]]$sites)

$script:ErrorActionPreference = "SilentlyContinue"

trap [Exception] 
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

# Helper Function to find next available drive for IIS 7.0 Shared configuration file copy
function Get-NextFreeDrive {  68..90 | ForEach-Object { "$([char]$_):" } |   Where-Object { 'h:', 'k:', 'z:' -notcontains $_  } |   Where-Object {     (new-object System.IO.DriveInfo $_).DriveType -eq 'noRootdirectory'   }}

# Import strings from en-us.xml to use via IISStrings object
Import-LocalizedData -BindingVariable IISStrings

# Define array of files we will eventually collect
$files = @()

# Collect machine.config and web.config for all framework versions:
Write-DiagProgress -Activity $IISStrings.ID_DSI_ActivityIISConfiguration -Status $IISStrings.ID_DSI_CollectingAspNetConfiguration

$FrameworkPath = Join-Path $env:windir "Microsoft.Net"
Get-ChildItem $FrameworkPath -include web.config, machine.config, aspnet.config -recurse | ForEach-Object `
{
	# Strip C:\Windows\Microsoft.NET\Framework and .config
	$NewFileName = ($_.FullName.TrimStart($FrameworkPath)).TrimEnd(".config")
	# Replace the "." and "\"
	$NewFileName = $NewFileName.Replace("\","_")
	$NewFileName = $NewFileName.Replace(".", "_")
	# Add .config
	$NewFileName = $NewFileName + ".config"
	
	# Copy Item for data collection
	$NewFileName = Join-Path $PWD.Path $NewFileName
	Copy-Item $_.FullName $NewFileName
	
	# Add file to array of files to be collected
	$files += $NewFileName
}


if($OSVersion.Major -eq 6)
{
	# IIS 7.0 and Higher
	# Create Server manager object
	[System.Reflection.Assembly]::LoadFrom( "C:\windows\system32\inetsrv\Microsoft.Web.Administration.dll" )
	$serverManager = (New-Object Microsoft.Web.Administration.ServerManager)


	# Copy Config files to data collection directory
	$path = (Join-Path $env:windir "system32\inetsrv\config\applicationHost.config")
	if(Test-Path $path) {$files += $path}
	$path = (Join-Path $env:windir "system32\inetsrv\config\administration.config")
	if(Test-Path $path) {$files += $path}
	$path = (Join-Path $env:windir "system32\inetsrv\config\redirection.config")
	if(Test-Path $path) 
	{
		$files += $path

		# Look for configuration redirection
		$configRedir = $serverManager.GetRedirectionConfiguration()
  		$config = $configRedir.GetSection( "configurationRedirection", "MACHINE/REDIRECTION" )
		if($config.Attributes["enabled"].Value -eq "True")
		{
			Write-DiagProgress -Activity $IISStrings.ID_DSI_ActivityIISConfiguration -Status "Collecting Shared Configuration"

			# Copy over the shared configuration files
			$userName = $config.Attributes["userName"].Value
			$pDub = $config.Attributes["password"].Value
			$path = $config.Attributes["path"].Value

			$net = new-object -ComObject Wscript.Network
			$drive = (Get-NextFreeDrive)[0]

			Trap {Continue;}
			$net.MapNetworkDrive($drive,$path ,$false,$userName,$pDub)

			if(Test-Path $drive)
			{

				$pathAppHost = Join-Path $path "applicationHost.config"
				$pathAdmin = Join-Path $path "administration.config"

				if(Test-Path $pathAppHost)
				{
					$tempFile = "SharedConfiguration_applicationHost.config"
					$tempFile = Join-Path $PWD.Path $tempFile
					Copy-Item $pathAppHost $tempFile
					$files += $tempFile
				}

				if(Test-Path $pathAdmin)
				{
					$tempFile = "SharedConfiguration_administration.config"
					$tempFile = Join-Path $PWD.Path $tempFile
					Copy-Item $pathAdmin $tempFile
					$files += $tempFile
				}

				$net.RemoveNetworkDrive($drive,$true, $false)
			}
		}
	}

	$sites | ForEach-Object `
	{
		# Build Filename in this format  SITE_APP_VDIR_Web.config
		Write-DiagProgress -Activity $IISStrings.ID_DSI_ActivityIISConfiguration -Status ($IISStrings.ID_DSI_CollectingIISConfiguration + ": " + $_)

		$currentSiteName = $_
		$currentSite = $serverManager.Sites[$currentSiteName]
		$currentSite.Applications | ForEach-Object `
		{
			$AppPath = $_.Path
			$_.VirtualDirectories | ForEach-Object `
			{
				$VDirPath = $_.Path
				$path = $_.PhysicalPath
				$path = (Join-Path ([environment]::ExpandEnvironmentVariables($path)) "web.config")
				if(Test-Path $path)
				{
					$NewFileName = $currentSiteName + $AppPath + $VDirPath + "_web.config"
					$NewFileName = $NewFileName.Replace("/", "_")
					$NewFileName = Join-Path $PWD.Path $NewFileName
					Copy-Item $path $NewFileName
					$files += $NewFileName

					# Output the effectiveConfiguration at this level as well
					# Site_App_VDir_EffectiveConfiguration.config
					$NewFileName = $currentSiteName + $AppPath + $VDirPath + "_EffectiveConfiguration.config"
					$NewFileName = $NewFileName.Replace("/", "_")
					$NewFileName = Join-Path $PWD.Path $NewFileName
					$configPath =  $currentSiteName + $AppPath + $VDirPath
					$configPath = $configPath.TrimEnd("/")
					$cmdToRun = $env:WinDir + "\system32\inetsrv\appcmd.exe list config """ + $configPath + """ >""" + $NewFileName + """"
					RunCmd -commandToRun $cmdToRun -collectFiles $false
					$files += $NewFileName
				}

				# Look for administration.config at this level too
				$path = $_.PhysicalPath
				$path = (Join-Path ([environment]::ExpandEnvironmentVariables($path)) "administration.config")
				if(Test-Path $path)
				{
					# Collect the administration.config
					$NewFileName = $currentSiteName + $AppPath + $VDirPath + "_administration.config"
					$NewFileName = $NewFileName.Replace("/", "_")
					$NewFileName = Join-Path $PWD.Path $NewFileName
					Copy-Item $path $NewFileName
					$files += $NewFileName
				}
			}
		}

	}
	
}
else
{
	# IIS 6.0 

	# Copy metabase.xml to data collection directory
	$files += (Join-Path $env:windir "system32\inetsrv\metabase.xml")
	
	# Copy Web.config for each site/application to data collection directory
	$sites | ForEach-Object `
	{
	   Write-DiagProgress -Activity $IISStrings.ID_DSI_ActivityIISConfiguration -Status ($IISStrings.ID_DSI_CollectingIISConfiguration + ": " + $_)

	   $currentSiteName = $_
	   $siteQuery = "Select * From IIsWebServerSetting Where ServerComment = '{0}'" -f $currentSiteName
		Get-WMIObject -Namespace "root/MicrosoftIISv2" -Query $siteQuery | ForEach-Object `
		{
			$appQuery = "Select * From IIsWebVirtualDirSetting Where Name LIKE '%{0}/%'" -f $_.Name
			Get-WMIObject -namespace "root/MicrosoftIISv2" -Query $appQuery | ForEach-Object `
			{
				$path =	$_.Path
				$VDirPath = $_.Name
				$path = (Join-Path ([environment]::ExpandEnvironmentVariables($path)) "web.config")
				if(Test-Path $path)
				{
					$NewFileName = $VDirPath + "_web.config"
					$NewFileName = $NewFileName.Replace("/", "_")
					$NewFileName = Join-Path $PWD.Path $NewFileName
					Copy-Item $path $NewFileName
					$files += $NewFileName
				}
			}
		}
	}
}

# Compress all files to IISConfiguration.zip
CompressCollectFiles -filesToCollect $files -fileDescription $IISStrings.ID_DSI_IISASPNetConfigurationFilesOutput -DestinationFileName "IISConfiguration.zip" -sectionDescription $IISStrings.ID_DSI_SectionIISConfiguration
# SIG # Begin signature block
# MIIbBAYJKoZIhvcNAQcCoIIa9TCCGvECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUMXfGSkstJ+217DzfU7Zd+Qfx
# MI+gghWDMIIEwzCCA6ugAwIBAgITMwAAAMZ4gDYBdRppcgAAAAAAxjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODUz
# WhcNMTgwOTA3MTc1ODUzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArQsjG6jKiCgU
# NuPDaF0GhCh1QYcSqJypNAJgoa1GtgoNrKXTDUZF6K+eHPNzXv9v/LaYLZX2GyOI
# 9lGz55tXVv1Ny6I1ueVhy2cUAhdE+IkVR6AtCo8Ar8uHwEpkyTi+4Ywr6sOGM7Yr
# wBqw+SeaBjBwON+8E8SAz0pgmHHj4cNvt5A6R+IQC6tyiFx+JEMO1qqnITSI2qx3
# kOXhD3yTF4YjjRnTx3HGpfawUCyfWsxasAHHlILEAfsVAmXsbr4XAC2HBZGKXo03
# jAmfvmbgbm3V4KBK296Unnp92RZmwAEqL08n+lrl+PEd6w4E9mtFHhR9wGSW29C5
# /0bOar9zHwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFNS/9jKwiDEP5hmU8T6/Mfpb
# Ag8JMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJhbANzvo0iL5FA5Z5QkwG+PvkDfOaYsTYksqFk+MgpqzPxc
# FwSYME/S/wyihd4lwgQ6CPdO5AGz3m5DZU7gPS5FcCl10k9pTxZ4s857Pu8ZrE2x
# rnUyUiQFl5DYSNroRPuQYRZZXs2xK1WVn1JcwcAwJwfu1kwnebPD90o1DRlNozHF
# 3NMaIo0nCTRAN86eSByKdYpDndgpVLSoN2wUnsh4bLcZqod4ozdkvgGS7N1Af18R
# EFSUBVraf7MoSxKeNIKLLyhgNxDxZxrUgnPb3zL73zOj40A1Ibw3WzJob8vYK+gB
# YWORl4jm6vCwAq/591z834HDNH60Ud0bH+xS7PowggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTrMIIE
# 5wIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIIBAzAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQU
# wpblMoX3Wn1+5QPGh7tR363aUw0wgaIGCisGAQQBgjcCAQwxgZMwgZCgdoB0AEQA
# SQBBAEcAXwBDAFQAUwBfAFMAQwBDAE0AXwAyADAAMQAyAF8AZwBsAG8AYgBhAGwA
# XwBEAEMAXwBJAEkAUwBfAEMAbwBsAGwAZQBjAHQAXwBDAG8AbgBmAGkAZwB1AHIA
# YQB0AGkAbwBuAC4AcABzADGhFoAUaHR0cDovL21pY3Jvc29mdC5jb20wDQYJKoZI
# hvcNAQEBBQAEggEAKStJXWMG64Rra2fr4BSIa5USbHjEw7s7Noh75OmaF378melf
# lR9lhV+U6qfeL1t2d3LtKD0UjKTdMd6vaPe/Ei/uo3eJuAmNV8VQgvWBV8Czo5aB
# EJOjDIQC/F7NTAXFoM2dTkQeFVE+m8YWQDmB+1Vgu8Gop+tnov7ZTSsVUT77ZP9j
# ftmN2AWfY/WuisSYuTjDJAXXf9qmWYTeGMM8VT6XffYRfjM5Ip9DqmCnGzHwG7/G
# 9TiLts/6yiPijbQ3tu4TiOBCWIT4J8P9MMDda6fx3cwNj/Saf5WmprPdAE39yVM8
# JXq84SIoo7Fo+2VVYy1sCDrQ1RrXaYb97jqG6aGCAigwggIkBgkqhkiG9w0BCQYx
# ggIVMIICEQIBATCBjjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSEwHwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0ECEzMAAADGeIA2
# AXUaaXIAAAAAAMYwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0B
# BwEwHAYJKoZIhvcNAQkFMQ8XDTE3MDQyNzE0MjMzMVowIwYJKoZIhvcNAQkEMRYE
# FLDNkea2gRwfbR1/CgBkUFE5mk/NMA0GCSqGSIb3DQEBBQUABIIBAAzEckAV1NgZ
# PrByXMet/5CEsxjx7jLn6QQmOTiwWmCrtxsaHnTQWYWgJ5wFMmN70ywiKHbCb8NC
# /TyByVkX0qTZXZJIBQWj/yf1PEYkr3uQ24w3+6ANUOKyqhKbL0ynS2/4EHEuyerF
# 5RjSMy2dLNTG8EuRq5SW6MiIHUQH4j6+/GirP6mDG+gI1PTZpmygyNfeK14HN9aE
# 7XdM4HUOY+gpMg+hCJPLLbSFAig/Hqrg28kfdVOBN+WSpp9pKXRQtmOwWQN+BFBv
# YC71YEv9ESKWtvjuC8nwHE/9Tbxtq6MbohJfrruOLJKCf/hIxZ0YAl4BVAccbHRo
# ykH3HyEc6LQ=
# SIG # End signature block
