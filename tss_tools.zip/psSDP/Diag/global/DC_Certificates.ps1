﻿###########################################################################
# DC_Certificates
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Collects Certificate information required for AU/WU/MU/WSUS
###########################################################################

Import-LocalizedData -BindingVariable Certs -FileName DC_Certificates -UICulture en-us
Write-DiagProgress -Activity $Certs.ID_Certs -Status $Certs.ID_CertsDesc

$OutputFile = $ComputerName + "_Certificates_Info.txt"
logstart

set-Content $OutputFile "Verify that the following Root CA Certs are present for AU/WU/MU/WSUS: `n`
The following Certs are required by AU and the installer...`n`
-----------------------------------------------------------`n`
Microsoft Root Authority `nGTE CyberTrust `nThawte Timestamping CA `nNO LIABILITY ACCEPTED`n`n`
The following Certs were found on $ComputerName`n" 

function get-cert ($Issuer)
	{
		#$CommandLineToExecute = "cmd.exe /c certutil -store root | find /i `"Issuer: $Issuer`" >> $OutputFile"
		#RunCmd -commandToRun $CommandLineToExecute
		Invoke-Expression "CertUtil -store root | find /i `"Issuer: $Issuer`"" | Out-File -Append $OutputFile -Encoding ascii 
		#$CommandLineToExecute = "cmd.exe /c certutil -store authroot | find /i `"Issuer: $Issuer`" >> $OutputFile" 
		#RunCmd -commandToRun $CommandLineToExecute
		Invoke-Expression "CertUtil -store authroot | find /i `"Issuer: $Issuer`"" | Out-File -Append $OutputFile -Encoding ascii 
	}

get-cert "CN=Microsoft Root Authority"
get-cert "CN=GTE CyberTrust"
get-cert "OU=NO LIABILITY ACCEPTED"
get-cert "CN=Thawte Timestamping CA"

Add-Content $OutputFile "`nMore information: KB822798,KB836937, SOX060106700026`n`
================================================================================`n`
All Root Certificate Authorities listed below:`n`n"

#$CommandLineToExecute = "cmd.exe /c certutil -store root >> $OutputFile" 
#Invoke-Expression "CertUtil -store root" | Out-File -Append $OutputFile -Encoding ascii
Get-ChildItem cert:\localmachine\root | Format-List | Out-File -append $OutputFile -Encoding ascii
#RunCmd -commandToRun $CommandLineToExecute 

#$CommandLineToExecute = "cmd.exe /c certutil -store authroot >> $OutputFile"
#Invoke-Expression "certutil -store authroot" | Out-File -Append $OutputFile -Encoding ascii
						
Add-Content $OutputFile "--------------------------------------------------- `n`
All authroot Certificate Authorities listed below: `n`
---------------------------------------------------"
Get-ChildItem cert:\localmachine\authroot | Format-List | Out-File -append $Outputfile -Encoding ascii
#RunCmd -commandToRun $CommandLineToExecute 

Add-Content $OutputFile "================================================================================`n" -Encoding Ascii 

invoke-expression "reg.exe query HKLM\Software\Policies\Microsoft\SystemCertificates" | Out-File -Append $outputfile -Encoding ascii  
#RunCmd -commandToRun $CommandLineToExecute 

invoke-expression "reg.exe query HKCU\Software\Policies\Microsoft\SystemCertificates /s" | Out-File -Append $outputfile -Encoding ascii  
#RunCmd -commandToRun $CommandLineToExecute 

CollectFiles -filesToCollect $OutputFile -fileDescription "Certificates" -sectionDescription "Certificates Information"
logstop






