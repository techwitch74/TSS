﻿###########################################################################
# DC_Handles
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Runs handle.exe to list open handles
###########################################################################

Import-LocalizedData -BindingVariable Handles -FileName DC_Handles -UICulture en-us
Write-DiagProgress -Activity $Handles.ID_Handles -Status $Handles.ID_HandlesStatus

$OutputFile = $ComputerName + "_Handle.txt"
"Start collecting " + $OutputFile | WriteTo-StdOut 

$CommandLineToExecute = "cmd.exe /c Handle.exe -accepteula -s > $OutputFile"
$CommandLineToExecute | WriteTo-StdOut 
RunCmD -commandToRun $CommandLineToExecute 

$CommandLineToExecute = "cmd.exe /c Handle.exe -accepteula -a >> $OutputFile"
$CommandLineToExecute | WriteTo-StdOut 
RunCmD -commandToRun $CommandLineToExecute -filesToCollect ($OutputFile) -fileDescription "Handle" -sectionDescription "System State Information"

"Finished collecting " + $OutputFile | WriteTo-StdOut 