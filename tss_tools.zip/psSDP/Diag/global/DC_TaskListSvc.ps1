﻿#************************************************
# DC_TaskListSvc.ps1
# Version 1.1
# Date: 2014,2019
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about running services
# Called from: Networking Diagnostics
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
# Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBClient -Status $ScriptVariable.ID_CTSSMBClientDescription

function RunTaskListSvc ([string]$TaskListSvcCommandToExecute="")
{
	$TaskListSvcCommandToExecuteLength = $TaskListSvcCommandToExecute.Length + 6
	"=" * ($TaskListSvcCommandToExecuteLength) 		| Out-File -FilePath $OutputFile -append
	"tasklist $TaskListSvcCommandToExecute" 		| Out-File -FilePath $OutputFile -append
	"=" * ($TaskListSvcCommandToExecuteLength) 		| Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c tasklist.exe " + $TaskListSvcCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
}

$sectionDescription = "TaskListSvc"
$OutputFile= $Computername + "_TaskListSvc_info.TXT"

"===================================================="	| Out-File -FilePath $OutputFile -append
"TaskList Output with SvcHost Information"				| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview" 												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. tasklist /svc"									| Out-File -FilePath $OutputFile -append
"   2. tasklist /v"										| Out-File -FilePath $OutputFile -append
"   3. tasklist /M"										| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
"`n"													| Out-File -FilePath $OutputFile -append
RunTaskListSvc "/svc"
RunTaskListSvc "/v"	#_#
RunTaskListSvc "/M"	#_#

CollectFiles -filesToCollect $OutputFile -fileDescription "TaskList Output with SvcHost Information" -SectionDescription $sectionDescription
