# 2019-03-17 WalterE added Trap #_#
<#
Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}
#>
# Load Common Library
# Load Reporting Utilities
#_#$debug = $false

. ./utils_cts.ps1
. ./TS_RemoteSetup.ps1

$FirstTimeExecution = FirstTimeExecution

if ($FirstTimeExecution) {
	if (Test-Path 'HKLM:\Cluster') #_#
	{
		[Array] $NodeNames = (Get-ClusterNode | where-object {$_.State -match "up"}).Nodename #_#
	}
	else
	{
		$NodeNames = $ComputerName
	}
	
	if ($Global:localNodeOnly -ne $true) {
	#_#[Array] $NodeNames = .\TS_SelectClusterNodes.ps1
		if ($NodeNames -ne $null) 
		{
			$ExpressionArray = @()
			$ItemNumber = 0	
			
			$ExpressionToRunOnMachine = @'
			Run-DiagExpression .\DC_BasicSystemInformation.ps1 -MachineName $Env:COMPUTERNAME
			Run-DiagExpression .\DC_ClusterLogs.ps1 -LocalOnly
			Run-DiagExpression .\TS_DumpCollector.ps1 -CopyWERMinidumps -CopyMachineMiniDumps -MaxFileSize 300 -CopyMachineMemoryDump
			.\TS_AutoAddCommands_Cluster.ps1
			Run-DiagExpression .\DC_SummaryReliability.ps1
'@
			
			#_#if (($NodeNames.Count -eq 1) -and ($NodeNames[0] = $ComputerName))
			if (($NodeNames -is [string]) -or (($NodeNames.Count -eq 1) -and ($NodeNames[0] -eq $ComputerName)))
			{
				if ($NodeNames.Count -eq 1)
				{
					"User/script selected local machine. Running package locally instead of using TS_Remote" | WriteTo-StdOut -ShortFormat
					$ExpressionToRunOnMachine += "`r`n Run-DiagExpression .\TS_BasicClusterInfo.ps1"
				}
				Invoke-Expression $ExpressionToRunOnMachine
			}
			else
			{
				foreach ($MachineName in $NodeNames)
				{
					if ($ItemNumber -eq 0) 
					{
						#Execute TS_BasicClusterInfo only in one node
						$ExpressionArray += ($ExpressionToRunOnMachine + "`r`n Run-DiagExpression .\TS_BasicClusterInfo.ps1")
					} else {
						$ExpressionArray += $ExpressionToRunOnMachine
					}
					
					$ItemNumber += 1
				}
				
				"Running package using TS_Remote on $NodeNames" | WriteTo-StdOut -ShortFormat #_#
				#_#ExecuteRemoteExpression -ComputerNames $NodeNames -Expression $ExpressionArray -ShowDialog
				ExecuteRemoteExpression -ComputerNames $NodeNames -Expression $ExpressionArray
			}
			
			if ($NodeNames -contains $ComputerName)
			{
				#TS_ClusterValidationTests.ps1 can be executed only locally due the issue with double hop authentication.
				"Running ClusterValidationTests on $ComputerName" | WriteTo-StdOut -ShortFormat #_#
				Run-DiagExpression .\TS_ClusterValidationTests.ps1
			}
		}
	}
	else { # run on localNodeOnly
		"User/script selected localNodeOnly. Running package locally instead of using TS_Remote" | WriteTo-StdOut -ShortFormat
		"User/script selected localNodeOnly." | Write-host
		Run-DiagExpression .\TS_BasicClusterInfo.ps1
		Run-DiagExpression .\DC_BasicSystemInformation.ps1 -MachineName $Env:COMPUTERNAME
		Run-DiagExpression .\DC_ClusterLogs.ps1 -LocalOnly
		Run-DiagExpression .\TS_DumpCollector.ps1 -CopyWERMinidumps -CopyMachineMiniDumps -MaxFileSize 300 -CopyMachineMemoryDump
		.\TS_AutoAddCommands_Cluster.ps1
		Run-DiagExpression .\DC_SummaryReliability.ps1
		"Running ClusterValidationTests on $ComputerName" | WriteTo-StdOut -ShortFormat #_#
		Run-DiagExpression .\TS_ClusterValidationTests.ps1
	}
	EndDataCollection

}
 else {
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
