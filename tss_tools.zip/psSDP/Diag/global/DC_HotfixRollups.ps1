﻿#************************************************
# DC_HotfixRollups.ps1
# Version 1.0.04.02.14: Created script to easily view what rollups are installed for W7/WS2008R2, W8/WS2012, and W8.1/WS2012R2
# Version 1.1.05.16.14: Added W8.1 Update1 (April2014 rollup);  Added OS Version below each heading.
# Version 1.6.10.16.14: Added Oct2014 updates for W8/W8.1
# Date: 2019,2020
# Author: Boyd Benson (bbenson@microsoft.com) +WalterE
# Description: Creates output to easily identify what rollups are installed on W7/WS2008R2 and later.
# Called from: Networking Diagnostics, and all psSDP
#  ToDo: read latest KB# from \xray\xray_WU.psm1 -or- KBonlyRollup_* from RFL
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable

$OutputFile = $ComputerName + "_HotfixRollups.TXT"
$sectionDescription = "Hotfix Rollups"


function CheckForHotfix ($hotfixID, $title, $Warn="")
{
	$hotfixesWMIQuery = "SELECT * FROM Win32_QuickFixEngineering WHERE HotFixID='KB$hotfixID'"
	$hotfixesWMI = Get-CimInstance -query $hotfixesWMIQuery #_# or PS > Get-HotFix
	$link = "http://support.microsoft.com/kb/" + $hotfixID
	if ($hotfixesWMI -eq $null)
	{
		"No          $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
		If ($Warn -match "Yes") {
			Write-Host -ForegroundColor Red "*** [WARNING] latest OS cumulative KB $hotfixID is missing.`n Please update this machine with recommended Microsoft KB $hotfixID and verify if your issue is resolved."
			$Global:MissingCU = $hotfixID
		}
	}
	else
	{
		"Yes         $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
	}
}

#----------detect OS version and SKU
	$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
	[int]$bn = [int]$wmiOSVersion.BuildNumber
	$sku = $((gwmi win32_operatingsystem).OperatingSystemSKU)

if ($bn -match 2200) # Win 11 = 22000
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 11 " | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009566 -title "January 11, 2022—KB5009566 (OS Build 22000.434)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008215 -title "December 14, 2021-KB5008215 (OS Build 22000.376)"
	CheckForHotfix -hotfixID 5007215 -title "November 9, 2021-KB5007215 (OS Build 22000.318)"
	CheckForHotfix -hotfixID 5006674 -title "October 12, 2021-KB5006674 (OS Build 22000.258)"
}

elseif ($bn -match 20348) # Server 2022 = 20348
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Server 2022 " | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009555 -title "January 11, 2022-KB5009555 (OS Build 20348.469)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008223 -title "December 14, 2021-KB5008223 (OS Build 20348.405)"
	CheckForHotfix -hotfixID 5007205 -title "November 9, 2021-KB5007205 (OS Build 20348.350)"
	CheckForHotfix -hotfixID 5006699 -title "October 12, 2021-KB5006699 (OS Build 20348.288)"
}
elseif ($bn -match 1904) # 2004 = 19041, 20H2 = 19042, 21H1 = 19043, 21H2 = 19044
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 20H1 v2004/20H2/21H1/21H2 and Windows Server 2019 20H1/20H2/21H1/21H2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009543 -title "January 11, 2022-KB5009543 (OS Builds 19042.1466, 19043.1466, and 19044.1466)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008212 -title "December 14, 2021-KB5008212 (OS Builds 19041.1415, 19042.1415, 19043.1415, and 19044.1415)"
	CheckForHotfix -hotfixID 5007186 -title "November 9, 2021-KB5007186 (OS Builds 19041.1348, 19042.1348, and 19043.1348)"
	CheckForHotfix -hotfixID 5006670 -title "October 12, 2021-KB5006670 (OS Builds 19041.1288, 19042.1288, and 19043.1288)"
	CheckForHotfix -hotfixID 5005611 -title "September 30, 2021-KB5005611 (OS Builds 19041.1266, 19042.1266, and 19043.1266) Preview"
	CheckForHotfix -hotfixID 5005565 -title "September 14, 2021-KB5005565 (OS Builds 19041.1237, 19042.1237, and 19043.1237)"
	CheckForHotfix -hotfixID 5005033 -title "August 10, 2021-KB5005033 (OS Builds 19041.1165, 19042.1165, and 19043.1165))"
	CheckForHotfix -hotfixID 5004237 -title "July 13, 2021-KB5004237 (OS Builds 19041.1110, 19042.1110, and 19043.1110)"
	CheckForHotfix -hotfixID 5003637 -title "June 8, 2021-KB5003637 (OS Builds 19041.1052, 19042.1052, and 19043.1052)"
	CheckForHotfix -hotfixID 5003173 -title "May 11, 2021-KB5003173 (OS Builds 19041.985 and 19042.985)"
	CheckForHotfix -hotfixID 5001330 -title "April 13, 2021-KB5001330 (OS Builds 19041.928 and 19042.928)"
	CheckForHotfix -hotfixID 5001649 -title "March 18, 2021-KB5001649 (OS Builds 19041.870 and 19042.870) Out-of-band"
	CheckForHotfix -hotfixID 4601319 -title "February 9, 2021-KB4601319 (OS Builds 19041.804 and 19042.804)"
	CheckForHotfix -hotfixID 4598242 -title "January 12, 2021-KB4598242 (OS Builds 19041.746 and 19042.746)"
	CheckForHotfix -hotfixID 4592438 -title "December 8, 2020-KB4592438 (OS Builds 19041.685 and 19042.685)"
	CheckForHotfix -hotfixID 4586781 -title "November 10, 2020-KB4586781 (OS Builds 19041.630 and 19042.630)"
	CheckForHotfix -hotfixID 4579311 -title "October 13, 2020-KB4579311 (OS Build 19041.572)"
	CheckForHotfix -hotfixID 4571756 -title "September 8, 2020-KB4571756 (OS Build 19041.508)"
	CheckForHotfix -hotfixID 4566782 -title "August 11, 2020-KB4566782 (OS Build 19041.450)"
	CheckForHotfix -hotfixID 4565503 -title "July 14, 2020-KB4565503 (OS Build 19041.388)"
	CheckForHotfix -hotfixID 4557957 -title "June 9, 2020-KB4557957 (OS Build 19041.329)"
	CheckForHotfix -hotfixID 4598481 -title "Servicing stack update for Windows 10, version 2004 and 20H2: January 12, 2021"
}
elseif ($bn -match  1836) # 1903 = 18362, 1909 = 18363
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 19H2 v1909 and Windows Server 2019 19H2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009545 -title "January 11, 2022-KB5009545 (OS Build 18363.2037)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008206 -title "December 14, 2021-KB5008206 (OS Build 18363.1977)"
	CheckForHotfix -hotfixID 5007189 -title "November 9, 2021-KB5007189 (OS Build 18362.1916)"
	CheckForHotfix -hotfixID 5006667 -title "October 12, 2021-KB5006667 (OS Build 18363.1854)"
	CheckForHotfix -hotfixID 5005566 -title "September 14, 2021-KB5005566 (OS Build 18363.1801)"
	CheckForHotfix -hotfixID 5005031 -title "August 10, 2021-KB5005031 (OS Build 18363.1734)"
	CheckForHotfix -hotfixID 5004245 -title "July 13, 2021-KB5004245 (OS Build 18363.1679)"
	CheckForHotfix -hotfixID 5003635 -title "June 8, 2021-KB5003635 (OS Build 18363.1621)"
	CheckForHotfix -hotfixID 5003169 -title "May 11, 2021-KB5003169 (OS Build 18363.1556)"
	CheckForHotfix -hotfixID 5001337 -title "April 13, 2021-KB5001337 (OS Build 18363.1500)"
	CheckForHotfix -hotfixID 5001648 -title "March 18, 2021-KB5001648 (OS Build 18363.1443) Out-of-band"
	CheckForHotfix -hotfixID 4601315 -title "February 9, 2021-KB4601315 (OS Build 18363.1377)"
	CheckForHotfix -hotfixID 4598229 -title "January 12, 2021-KB4598229 (OS Build 18363.1316)"
	CheckForHotfix -hotfixID 4592449 -title "December 8, 2020-KB4592449 (OS Builds 18362.1256 and 18363.1256)"
	CheckForHotfix -hotfixID 4586786 -title "November 10, 2020-KB4586786 (OS Builds 18362.1198 and 18363.1198)"
	CheckForHotfix -hotfixID 4577671 -title "October 13, 2020-KB4577671 (OS Builds 18362.1139 and 18363.1139)"
	CheckForHotfix -hotfixID 4574727 -title "September 8, 2020-KB4574727 (OS Builds 18362.1082 and 18363.1082)"
	CheckForHotfix -hotfixID 4565351 -title "August 11, 2020-KB4565351 (OS Builds 18362.1016 and 18363.1016)"
	CheckForHotfix -hotfixID 4565483 -title "July 14, 2020-KB4565483 (OS Builds 18362.959 and 18363.959)"
	CheckForHotfix -hotfixID 4560960 -title "June 9, 2020-KB4560960 (OS Builds 18362.900 and 18363.900)"
	CheckForHotfix -hotfixID 4556799 -title "May 12, 2020-KB4556799 (OS Builds 18362.836 and 18363.836)" 
	CheckForHotfix -hotfixID 4549951 -title "April 14, 2020-KB4549951 (OS Builds 18362.778 and 18363.778)"
	CheckForHotfix -hotfixID 4540673 -title "March 10, 2020-KB4540673 (OS Builds 18362.719 and 18363.719)"
	CheckForHotfix -hotfixID 4532693 -title "February 11, 2020-KB4532693 (OS Builds 18362.657 and 18363.657)"
	CheckForHotfix -hotfixID 4528760 -title "January 14, 2020-KB4528760 (OS Builds 18362.592 and 18363.592)"
	CheckForHotfix -hotfixID 4530684 -title "December 10, 2019-KB4530684 (OS Builds 18362.535 and 18363.535)"
	CheckForHotfix -hotfixID 4601395 -title "KB4601395: Servicing stack update for Windows 10, version 1903: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 17763)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS5 v1809 and Windows Server 2019 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009557 -title "January 11, 2022-KB5009557 (OS Build 17763.2452)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008218 -title "December 14, 2021-KB5008218 (OS Build 17763.2366)"
	CheckForHotfix -hotfixID 5007206 -title "November 9, 2021-KB5007206 (OS Build 17763.2300)"
	CheckForHotfix -hotfixID 5006672 -title "October 12, 2021-KB5006672 (OS Build 17763.2237)"
	CheckForHotfix -hotfixID 5005568 -title "September 14, 2021-KB5005568 (OS Build 17763.2183)"
	CheckForHotfix -hotfixID 5005030 -title "August 10, 2021-KB5005030 (OS Build 17763.2114"
	CheckForHotfix -hotfixID 5004244 -title "July 13, 2021-KB5004244 (OS Build 17763.2061)"
	CheckForHotfix -hotfixID 5003646 -title "June 8, 2021-KB5003646 (OS Build 17763.1999)"
	CheckForHotfix -hotfixID 5003171 -title "May 11, 2021-KB5003171 (OS Build 17763.1935)"
	CheckForHotfix -hotfixID 5001342 -title "April 13, 2021-KB5001342 (OS Build 17763.1879)"
	CheckForHotfix -hotfixID 5001638 -title "March 18, 2021-KB5001638 (OS Build 17763.1823) Out-of-band"
	CheckForHotfix -hotfixID 4601345 -title "February 9, 2021-KB4601345 (OS Build 17763.1757)"
	CheckForHotfix -hotfixID 4598230 -title "January 12, 2021-KB4598230 (OS Build 17763.1697)"
	CheckForHotfix -hotfixID 4592440 -title "December 8, 2020-KB4592440 (OS Build 17763.1637)"
	CheckForHotfix -hotfixID 4586793 -title "November 10, 2020-KB4586793 (OS Build 17763.1577)"
	CheckForHotfix -hotfixID 4577668 -title "October 13, 2020-KB4577668 (OS Build 17763.1518)"
	CheckForHotfix -hotfixID 4570333 -title "September 8, 2020-KB4570333 (OS Build 17763.1457)"
	CheckForHotfix -hotfixID 4565349 -title "August 11, 2020-KB4565349 (OS Build 17763.1397)"
	CheckForHotfix -hotfixID 4558998 -title "July 14, 2020-KB4558998 (OS Build 17763.1339)"
	CheckForHotfix -hotfixID 4561608 -title "June 9, 2020-KB4561608 (OS Build 17763.1282)"
	CheckForHotfix -hotfixID 4551853 -title "May 12, 2020-KB4551853 (OS Build 17763.1217)" 
	CheckForHotfix -hotfixID 4549949 -title "April 14, 2020-KB4549949 (OS Build 17763.1158)"
	CheckForHotfix -hotfixID 4538461 -title "March 10, 2020-KB4538461 (OS Build 17763.1098)"
	CheckForHotfix -hotfixID 4532691 -title "February 11, 2020-KB4532691 (OS Build 17763.1039)"
	CheckForHotfix -hotfixID 4534273 -title "January 14, 2020-KB4534273 (OS Build 17763.973)"
	CheckForHotfix -hotfixID 4530715 -title "December 10, 2019-KB4530715 (OS Build 17763.914)"
	CheckForHotfix -hotfixID 4601393 -title "KB4601393: Servicing stack update for Windows 10, version 1809: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 14393)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS1 v1607 and Windows Server 2016 RS1 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009546 -title "January 11, 2022-KB5009546 (OS Build 14393.4886)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008207 -title "December 14, 2021-KB5008207 (OS Build 14393.4825)"
	CheckForHotfix -hotfixID 5007192 -title "November 9, 2021-KB5007192 (OS Build 14393.4770)"
	CheckForHotfix -hotfixID 5006669 -title "October 12, 2021-KB5006669 (OS Build 14393.4704)"
	CheckForHotfix -hotfixID 5005573 -title "September 14, 2021-KB5005573 (OS Build 14393.4651)"
	CheckForHotfix -hotfixID 5005043 -title "August 10, 2021-KB5005043 (OS Build 14393.4583)"
	CheckForHotfix -hotfixID 5004238 -title "July 13, 2021-KB5004238 (OS Build 14393.4530)"
	CheckForHotfix -hotfixID 5003638 -title "June 8, 2021-KB5003638 (OS Build 14393.4467)"
	CheckForHotfix -hotfixID 5003197 -title "May 11, 2021-KB5003197 (OS Build 14393.4402)"
	CheckForHotfix -hotfixID 5001347 -title "April 13, 2021-KB5001347 (OS Build 14393.4350)"
	CheckForHotfix -hotfixID 5001633 -title "March 18 2021-KB5001633 (OS Build 14393.4288) Out-of-band"
	CheckForHotfix -hotfixID 4601318 -title "February 9, 2021-KB4601318 (OS Build 14393.4225)" 
	CheckForHotfix -hotfixID 4598243 -title "January 12, 2021-KB4598243 (OS Build 14393.4169)"
	CheckForHotfix -hotfixID 4593226 -title "December 8, 2020-KB4593226 (OS Build 14393.4104)"
	CheckForHotfix -hotfixID 4586830 -title "November 10, 2020-KB4586830 (OS Build 14393.4046)"
	CheckForHotfix -hotfixID 4580346 -title "October 13, 2020-KB4580346 (OS Build 14393.3986)"
	CheckForHotfix -hotfixID 4577015 -title "September 8, 2020-KB4577015 (OS Build 14393.3930)"
	CheckForHotfix -hotfixID 4571694 -title "August 11, 2020-KB4571694 (OS Build 14393.3866)"
	CheckForHotfix -hotfixID 4565511 -title "July 14, 2020-KB4565511 (OS Build 14393.3808)"
	CheckForHotfix -hotfixID 4561616 -title "June 9, 2020-KB4561616 (OS Build 14393.3750)"
	CheckForHotfix -hotfixID 4556813 -title "May 12, 2020-KB4556813 (OS Build 14393.3686)"
	CheckForHotfix -hotfixID 4550929 -title "April 14, 2020-KB4550929 (OS Build 14393.3630)"
	CheckForHotfix -hotfixID 4540670 -title "March 10, 2020-KB4540670 (OS Build 14393.3564)"
	CheckForHotfix -hotfixID 4537764 -title "February 11, 2020-KB4537764 (OS Build 14393.3504)"
	CheckForHotfix -hotfixID 4534271 -title "January 14, 2020-KB4534271 (OS Build 14393.3443)"
	CheckForHotfix -hotfixID 4530689 -title "December 10, 2019-KB4530689 (OS Build 14393.3384)"
	CheckForHotfix -hotfixID 4601392 -title "Servicing stack update for Windows 10, version 1607: Februar 9, 2021" -Warn "Yes"
}	
elseif ($bn -eq 10240)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 and Windows Server 2016 RTM Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009585 -title "January 11, 2022-KB5009585 (OS Build 10240.19177)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008230 -title "December 14, 2021-KB5008230 (OS Build 10240.19145)"
	CheckForHotfix -hotfixID 5007207 -title "November 9, 2021-KB5007207 (OS Build 10240.19119)"
	CheckForHotfix -hotfixID 5006675 -title "October 12, 2021-KB5006675 (OS Build 10240.19086)"
	CheckForHotfix -hotfixID 5005569 -title "September 14, 2021-KB5005569 (OS Build 10240.19060)"
	CheckForHotfix -hotfixID 5005040 -title "August 10, 2021-KB5005040 (OS Build 10240.19022)"
	CheckForHotfix -hotfixID 5004249 -title "July 13, 2021-KB5004249 (OS Build 10240.19003)"
	CheckForHotfix -hotfixID 5003687 -title "June 8, 2021-KB5003687 (OS Build 10240.18967)"
	CheckForHotfix -hotfixID 5003172 -title "May 11, 2021-KB5003172 (OS Build 10240.18932)"
	CheckForHotfix -hotfixID 5001340 -title "April 13, 2021-KB5001340 (OS Build 10240.18906)"
	CheckForHotfix -hotfixID 5001631 -title "March 18, 2021-KB5001631 (OS Build 10240.18875) Out-of-band"
	CheckForHotfix -hotfixID 4601331 -title "February 9, 2021-KB4601331 (OS Build 10240.18842)"
	CheckForHotfix -hotfixID 4598231 -title "January 12, 2021-KB4598231 (OS Build 10240.18818)"
	CheckForHotfix -hotfixID 4592464 -title "December 8, 2020-KB4592464 (OS Build 10240.18782)"
	CheckForHotfix -hotfixID 4586787 -title "November 10, 2020-KB4586787 (OS Build 10240.18756)"
	CheckForHotfix -hotfixID 4580327 -title "October 13, 2020-KB4580327 (OS Build 10240.18725)"
	CheckForHotfix -hotfixID 4577049 -title "September 8, 2020-KB4577049 (OS Build 10240.18696)"
	CheckForHotfix -hotfixID 4571692 -title "August 11, 2020-KB4571692 (OS Build 10240.18666)"
	CheckForHotfix -hotfixID 4565513 -title "July 14, 2020-KB4565513 (OS Build 10240.18638)"
	CheckForHotfix -hotfixID 4561649 -title "June 9, 2020-KB4561649 (OS Build 10240.18608)"
	CheckForHotfix -hotfixID 4556826 -title "May 12, 2020-KB4556826 (OS Build 10240.18575)"
	CheckForHotfix -hotfixID 4550930 -title "April 14, 2020-KB4550930 (OS Build 10240.18545)"
	CheckForHotfix -hotfixID 4540693 -title "March 10, 2020-KB4540693 (OS Build 10240.18519)"
	CheckForHotfix -hotfixID 4537776 -title "February 11, 2020-KB4537776 (OS Build 10240.18486)"
	CheckForHotfix -hotfixID 4534306 -title "January 14, 2020-KB4534306 (OS Build 10240.18453)"
	CheckForHotfix -hotfixID 4530681 -title "December 10, 2019-KB4530681 (OS Build 10240.18427)"
	CheckForHotfix -hotfixID 4601390 -title "KB4601390: Servicing stack update for Windows 10: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 9600)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 8.1 and Windows Server 2012 R2 Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009624 -title "January 11, 2022-KB5009624 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008263 -title "December 14, 2021-KB5008263 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5007247 -title "November 9, 2021-KB5007247 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5006714 -title "October 12, 2021-KB5006714 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005613 -title "September 14, 2021-KB5005613 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005076 -title "August 10, 2021-KB5005076 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5004298 -title "July 13, 2021-KB5004298 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003671 -title "June 8, 2021-KB5003671 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003209 -title "May 11, 2021-KB5003209 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001382 -title "April 13, 2021-KB5001382 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000848 -title "March 9, 2021-KB5000848 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601384 -title "February 9, 2021-KB4601384 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598285 -title "January 12, 2021-KB4598285 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592484 -title "December 8, 2020-KB4592484 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4586845 -title "November 10, 2020-KB4586845 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4580347 -title "October 13, 2020-KB4580347 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4577066 -title "September 8, 2020-KB4577066 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4571703 -title "August 11, 2020-KB4571703 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4565541 -title "July 14, 2020-KB4565541 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4561666 -title "June 9, 2020-KB4561666 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4556846 -title "May 12, 2020-KB4556846 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4550961 -title "April 14, 2020-KB4550961 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4566425 -title "Servicing stack update for Windows 8.1, RT 8.1, and Server 2012 R2: July 14, 2020" -Warn "Yes"
	CheckForHotfix -hotfixID 4541509 -title "March 10, 2020-KB4541509 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4537821 -title "February 11, 2020-KB4537821 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4534297 -title "January 14, 2020-KB4534297 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4530702 -title "December 10, 2019-KB4530702 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3123245 -title "Update improves port exhaustion identification in Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3179574 -title "August 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3172614 -title "July 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3013769 -title "December 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3000850 -title "November 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 2919355 -title "[Windows 8.1 Update 1] Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2 Update: April 2014"
	CheckForHotfix -hotfixID 2883200 -title "Windows 8.1 and Windows Server 2012 R2 General Availability Update Rollup"
}
elseif ($bn -eq 9200)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Server 2012 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append
	
	CheckForHotfix -hotfixID 5009586 -title "January 11, 2022-KB5009586 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008277 -title "December 14, 2021-KB5008277 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5007260 -title "November 9, 2021-KB5007260 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5006739 -title "October 12, 2021-KB5006739 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005623 -title "September 14, 2021-KB5005623 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005099 -title "August 10, 2021-KB5005099 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5004294 -title "July 13, 2021-KB5004294 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003697 -title "June 8, 2021-KB5003697 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003208 -title "May 11, 2021-KB5003208 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001387 -title "April 13, 2021-KB5001387 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000847 -title "March 9, 2021-KB5000847 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601348 -title "February 9, 2021-KB4601348 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598278 -title "January 12, 2021-KB4598278 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592468 -title "December 8, 2020-KB4592468 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3179575 -title "August 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3172615 -title "July 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3161609 -title "June 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3156416 -title "May 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3013767 -title "December 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 3000853 -title "November 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2995388 -title "October 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012 "
	CheckForHotfix -hotfixID 2984005 -title "September 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2975331 -title "August 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2967916 -title "July 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012" 
	CheckForHotfix -hotfixID 2962407 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2014" 
	CheckForHotfix -hotfixID 2955163 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: May 2014"
	CheckForHotfix -hotfixID 2934016 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: April 2014" 	
	CheckForHotfix -hotfixID 2928678 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: March 2014" 	
	CheckForHotfix -hotfixID 2919393 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: February 2014"
	CheckForHotfix -hotfixID 2911101 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: January 2014"
	CheckForHotfix -hotfixID 2903938 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: December 2013"
	CheckForHotfix -hotfixID 2889784 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: November 2013"
	CheckForHotfix -hotfixID 2883201 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: October 2013"
	CheckForHotfix -hotfixID 2876415 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: September 2013"
	CheckForHotfix -hotfixID 2862768 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: August 2013"	
	CheckForHotfix -hotfixID 2855336 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: July 2013"	
	CheckForHotfix -hotfixID 2845533 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2013"	
	CheckForHotfix -hotfixID 2836988 -title "Windows 8 and Windows Server 2012 Update Rollup: May 2013" 				
	CheckForHotfix -hotfixID 2822241 -title "Windows 8 and Windows Server 2012 Update Rollup: April 2013"				
	CheckForHotfix -hotfixID 2811660 -title "Windows 8 and Windows Server 2012 Update Rollup: March 2013"				
	CheckForHotfix -hotfixID 2795944 -title "Windows 8 and Windows Server 2012 Update Rollup: February 2013"			
	CheckForHotfix -hotfixID 2785094 -title "Windows 8 and Windows Server 2012 Update Rollup: January 2013"				
	CheckForHotfix -hotfixID 2779768 -title "Windows 8 and Windows Server 2012 Update Rollup: December 2012"			
	CheckForHotfix -hotfixID 2770917 -title "Windows 8 and Windows Server 2012 Update Rollup: November 2012"			
	CheckForHotfix -hotfixID 2756872 -title "Windows 8 Client and Windows Server 2012 General Availability Update Rollup"
}
elseif ($bn -eq 7601)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 7 and Windows Server 2008 R2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=7600, SP1=7601)" | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009610 -title "January 11, 2022-KB5009610 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008244 -title "December 14, 2021-KB5008244 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5007236 -title "November 9, 2021-KB5007236 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5006743 -title "October 12, 2021-KB5006743 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005633 -title "September 14, 2021-KB5005633 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005088 -title "August 10, 2021-KB5005088 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5004289 -title "July 13, 2021-KB5004289 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003667 -title "June 8, 2021-KB5003667 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003233 -title "May 11, 2021-KB5003233 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001335 -title "April 13, 2021-KB5001335 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000841 -title "March 9, 2021-KB5000841 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601347 -title "February 9, 2021-KB4601347 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598279 -title "January 12, 2021-KB4598279 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592471 -title "December 8, 2020-KB4592471 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3125574 -title "Convenience roll-up update for Windows 7 SP1 and Windows Server 2008 R2 SP1" -Warn "Yes"
	CheckForHotfix -hotfixID 4490628 -title "Servicing stack update for Windows 7 SP1 and Windows Server 2008 R2 SP1: March 12, 2019"
	CheckForHotfix -hotfixID 4580970 -title "Servicing stack update for Windows 7 SP1 and Server 2008 R2 SP1: October 13, 2020" -Warn "Yes"
	CheckForHotfix -hotfixID 4538483 -title "Extended Security Updates (ESU) Licensing Preparation Package for Windows 7 SP1 and Windows Server 2008 R2 SP1"
	CheckForHotfix -hotfixID 2775511 -title "An enterprise hotfix rollup is available for Windows 7 SP1 and Windows Server 2008 R2 SP1"
}
elseif (($bn -eq 6002) -or ($bn -eq 6003))
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Vista and Windows Server 2008 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=6000, SP2=6002 or 6003)" | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009627 -title "January 11, 2022-KB5009627 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008274 -title "December 14, 2021-KB5008274 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5007263 -title "November 9, 2021-KB5007263 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5006736 -title "October 12, 2021-KB5006736 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005606 -title "September 14, 2021-KB5005606 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005090 -title "August 10, 2021-KB5005090 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 5004305 -title "July 13, 2021-KB5004305 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003661 -title "June 8, 2021-KB5003661 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003210 -title "May 11, 2021-KB5003210 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001389 -title "April 13, 2021-KB5001389 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000844 -title "March 9, 2021-KB5000844 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601360 -title "February 9, 2021-KB4601360 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598288 -title "January 12, 2021-KB4598288 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592498 -title "December 8, 2020-KB4592498 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4517134 -title "Servicing stack update for Windows Server 2008 SP2: September 10, 2019"
	CheckForHotfix -hotfixID 4572374 -title "Servicing stack update for Windows Server 2008 SP2: August 11, 2020" -Warn "Yes"
}

	CollectFiles -filesToCollect $OutputFile -fileDescription "Hotfix Rollups" -SectionDescription $sectionDescription



# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCs+tcFqjj3l9n3
# RAFIs2vlpA5iHlTO9ag49fUcVdkOGqCCDYEwggX/MIID56ADAgECAhMzAAACUosz
# qviV8znbAAAAAAJSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMjU5WhcNMjIwOTAxMTgzMjU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDQ5M+Ps/X7BNuv5B/0I6uoDwj0NJOo1KrVQqO7ggRXccklyTrWL4xMShjIou2I
# sbYnF67wXzVAq5Om4oe+LfzSDOzjcb6ms00gBo0OQaqwQ1BijyJ7NvDf80I1fW9O
# L76Kt0Wpc2zrGhzcHdb7upPrvxvSNNUvxK3sgw7YTt31410vpEp8yfBEl/hd8ZzA
# v47DCgJ5j1zm295s1RVZHNp6MoiQFVOECm4AwK2l28i+YER1JO4IplTH44uvzX9o
# RnJHaMvWzZEpozPy4jNO2DDqbcNs4zh7AWMhE1PWFVA+CHI/En5nASvCvLmuR/t8
# q4bc8XR8QIZJQSp+2U6m2ldNAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUNZJaEUGL2Guwt7ZOAu4efEYXedEw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDY3NTk3MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAFkk3
# uSxkTEBh1NtAl7BivIEsAWdgX1qZ+EdZMYbQKasY6IhSLXRMxF1B3OKdR9K/kccp
# kvNcGl8D7YyYS4mhCUMBR+VLrg3f8PUj38A9V5aiY2/Jok7WZFOAmjPRNNGnyeg7
# l0lTiThFqE+2aOs6+heegqAdelGgNJKRHLWRuhGKuLIw5lkgx9Ky+QvZrn/Ddi8u
# TIgWKp+MGG8xY6PBvvjgt9jQShlnPrZ3UY8Bvwy6rynhXBaV0V0TTL0gEx7eh/K1
# o8Miaru6s/7FyqOLeUS4vTHh9TgBL5DtxCYurXbSBVtL1Fj44+Od/6cmC9mmvrti
# yG709Y3Rd3YdJj2f3GJq7Y7KdWq0QYhatKhBeg4fxjhg0yut2g6aM1mxjNPrE48z
# 6HWCNGu9gMK5ZudldRw4a45Z06Aoktof0CqOyTErvq0YjoE4Xpa0+87T/PVUXNqf
# 7Y+qSU7+9LtLQuMYR4w3cSPjuNusvLf9gBnch5RqM7kaDtYWDgLyB42EfsxeMqwK
# WwA+TVi0HrWRqfSx2olbE56hJcEkMjOSKz3sRuupFCX3UroyYf52L+2iVTrda8XW
# esPG62Mnn3T8AuLfzeJFuAbfOSERx7IFZO92UPoXE1uEjL5skl1yTZB3MubgOA4F
# 8KoRNhviFAEST+nG8c8uIsbZeb08SeYQMqjVEmkwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAlKLM6r4lfM52wAAAAACUjAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgBtI0fq+E
# ZDp0gtQm4K5w832hPPHefTRp+qq6y2N+nEIwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQA81jrjb2s2grsKGjRdoLZQnKB6+zvg45sFSVv8GNQ2
# hlB8HSS1Kg8AqzEaWmsnP1ahJEttDJT2T0dqHGa/CiY0sDOx/DMldziVDcSbETTS
# epykXSTB4MJjPUHsDC8HX5Ce+MmDE5aoYDlBnQdJA3UlPkshdIgG6B1+lfWosGUP
# NM4CY1tZAhGtQMKd9YYqeJ7Aq5y+YNLoHlomsbjbG6YvvVYmjqpbLh2gX82cF1sX
# ueKZxJ/XAdF+1j9x1R0sBrGdVA+wTaiieloYpvKQ0+vDNPnG1ZFTEsEc4EX25MZZ
# oEypak1dG+9tvJErX88Mq+Mo29FowGQIYSSMDqlde7m0oYIS8TCCEu0GCisGAQQB
# gjcDAwExghLdMIIS2QYJKoZIhvcNAQcCoIISyjCCEsYCAQMxDzANBglghkgBZQME
# AgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIG9WQNLN1UwmqzK3xREUUQL5nrRaFu6tvAboOzgD
# /Pg7AgZh8DIbkwQYEzIwMjIwMTI4MTkyNzUxLjU2MVowBIACAfSggdSkgdEwgc4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjo2MEJDLUUzODMtMjYzNTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDkQwggT1MIID3aADAgECAhMzAAABWiy5bkQ0y28oAAAA
# AAFaMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIxMDExNDE5MDIxNloXDTIyMDQxMTE5MDIxNlowgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo2MEJD
# LUUzODMtMjYzNTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALC9XBxXDa0nCK70Hf+G
# ih6NxRl1mAhzFJdok8bs3xpJ87TM28rEeHkZAaE+Kb9Gi9UvTpQ3zrEWyWSpIQky
# xv/Wf0cIhA1mJOqyu20TN3l96ZvgzYrzO/rQlPvbKW79oAO4+YFsekQCtrzM9hQo
# S5BYGwPh9Qz66BuSxH9QweywNBQsjkVoikpBxkS+EXSIzpba2afvnRMX7LLe2ery
# c+PlPXmTSOfH1WNykc25u9zo6ZX0gAd4jUpBzdMLnHCtE62bL2PO00cmAJsitqga
# ov+3lFrfd0sPACwTGO9iymlJlb2savwjqSnj5RzG4RxG6rU2i7etbnQTozR73OHM
# GOUCAwEAAaOCARswggEXMB0GA1UdDgQWBBRkcyU/9RyPkn7QBoXZOTQ8wN4xZzAf
# BgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNU
# aW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAAAG3sfFgbUiw4gWMV8VOxlbIG/CIM
# SiciDtIZnPL84OMN4lJeV5LeJr+HYBcox5ruWZm49K29iBmJv6ViXMtP81pYZ1EF
# M7306Y+zLIh/tS574PeWsHvPD0QOxQ4HOM2GNPvFAdUvo8z5pgV/5E+lPu61uUCI
# BTDESiHO+N7ragqb3METPqRKPLNAJcKPDcalKznmGPlnzY6P1zop/7a90VcBHRKK
# Q/hTvn/8C8Y6b+Mvk5kYJh67KNbVVcuuBWyFSMZTHGenHnuHVg9svH7+lm/V/wIb
# ZUKKJJO0HQmyodySeD/JLC7NNsDYRpFN+29dLRtx0eWyZosJmT8qKbBIMIIGcTCC
# BFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcN
# MjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0
# VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEw
# RA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQe
# dGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKx
# Xf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4G
# kbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEA
# AaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0g
# AQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYB
# BQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUA
# bQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOh
# IW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS
# +7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlK
# kVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon
# /VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOi
# PPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/
# fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCII
# YdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0
# cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7a
# KLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQ
# cdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+
# NR4Iuto229Nfj950iEkSoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo2
# MEJDLUUzODMtMjYzNTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAzIAFmL3GHHWcAJYi3haGwlplGi6ggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOWepQUwIhgPMjAyMjAxMjgyMTIzMTdaGA8yMDIyMDEyOTIxMjMxN1owdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5Z6lBQIBADAKAgEAAgIfywIB/zAHAgEAAgIQ9jAK
# AgUA5Z/2hQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBABac0X3TC54TCdv2
# lO5wS5KpMEyp3MVLOEOQl6POhVtx7eeUL9sWI2/YjhCDK/cGy7p7IEqncNC90wQG
# xj4DILFpxLgSQlO35WO1y8fHVkLzmS05lGmGZL6ttc1ETREYZzK5qA28eBgkGQYS
# 6niGkWbaccT4RdJxCa46Zetcl3ipMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFaLLluRDTLbygAAAAAAVowDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgPhCQ3l4LVvGzpAWKBTq+InpHA0nS9bu4XBR+s1RpRCcwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCCT/KgmdMSy5F0ww4Iar9cmf5Is3pM0hUuIInL5
# bbF/sDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# Wiy5bkQ0y28oAAAAAAFaMCIEII1PdIVahXwWsjuhZACB1Dr3SJGE1yhXC3x6una6
# lbqiMA0GCSqGSIb3DQEBCwUABIIBAKUHWYwkje7o41AGhebdZ4g5JQCOPJ4YAE1a
# QAOrGsyD662vBrcsMCPaJpakPibFGyv487oJjYve5P9Bk9lqrLXqnR8PYXPXXye3
# oHG+9OfGlFGFqqO5pvOgpIZOHS6Uz6fBWctFoaU8bX+qqrrE6NWa8N/6Bp0APJFm
# pmzyv049ZNpStDJqpMtYPzh8V2j12VkY0Z2OtIAocNKxRe0dIWVlgYUdL7pQDqfF
# Nlv0IVkpi9/J/RFAWv7MXNxULThxJbS8AoRUn415+02Rcew1rxWwFpfzhCY14P06
# jp8PKvjC32HC5hbzDKIFR8decPQ3vDlMFfyEnL1zPCE+ZueuM/M=
# SIG # End signature block
