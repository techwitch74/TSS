﻿#************************************************
# DC_HotfixRollups.ps1
# Version 1.0.04.02.14: Created script to easily view what rollups are installed for W7/WS2008R2, W8/WS2012, and W8.1/WS2012R2
# Version 1.1.05.16.14: Added W8.1 Update1 (April2014 rollup);  Added OS Version below each heading.
# Version 1.6.10.16.14: Added Oct2014 updates for W8/W8.1
# Date: 2019,2020
# Author: Boyd Benson (bbenson@microsoft.com) +WalterE
# Description: Creates output to easily identify what rollups are installed on W7/WS2008R2 and later.
# Called from: Networking Diagnostics, and all psSDP
#  ToDo: read latest KB# from \xray\xray_WU.psm1 -or- KBonlyRollup_* from RFL
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable

$OutputFile = $ComputerName + "_HotfixRollups.TXT"
$sectionDescription = "Hotfix Rollups"


function CheckForHotfix ($hotfixID, $title, $Warn="")
{
	$hotfixesWMIQuery = "SELECT * FROM Win32_QuickFixEngineering WHERE HotFixID='KB$hotfixID'"
	$hotfixesWMI = Get-CimInstance -query $hotfixesWMIQuery											# or PS > Get-HotFix
	$link = "http://support.microsoft.com/kb/" + $hotfixID
	if ($hotfixesWMI -eq $null)
	{
		"No          $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
		If ($Warn -match "Yes") {
			Write-Host -ForegroundColor Red "*** [WARNING] latest OS cumulative KB $hotfixID is missing.`n Please update this machine with recommended Microsoft KB $hotfixID and verify if your issue is resolved."
			$Global:MissingCU = $hotfixID
		}
	}
	else
	{
		"Yes         $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
	}
}

#----------detect OS version and SKU
	$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
	[int]$bn = [int]$wmiOSVersion.BuildNumber
	$sku = $((gwmi win32_operatingsystem).OperatingSystemSKU)

if ($bn -match 2200) # Win 11 = 22000
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 11 " | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009566 -title "January 11, 2022—KB5009566 (OS Build 22000.434)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008215 -title "December 14, 2021-KB5008215 (OS Build 22000.376)"
	CheckForHotfix -hotfixID 5007215 -title "November 9, 2021-KB5007215 (OS Build 22000.318)"
	CheckForHotfix -hotfixID 5006674 -title "October 12, 2021-KB5006674 (OS Build 22000.258)"
}

elseif ($bn -match 20348) # Server 2022 = 20348
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Server 2022 " | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009555 -title "January 11, 2022-KB5009555 (OS Build 20348.469)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008223 -title "December 14, 2021-KB5008223 (OS Build 20348.405)"
	CheckForHotfix -hotfixID 5007205 -title "November 9, 2021-KB5007205 (OS Build 20348.350)"
	CheckForHotfix -hotfixID 5006699 -title "October 12, 2021-KB5006699 (OS Build 20348.288)"
}
elseif ($bn -match 1904) # 2004 = 19041, 20H2 = 19042, 21H1 = 19043, 21H2 = 19044
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 20H1 v2004/20H2/21H1/21H2 and Windows Server 2019 20H1/20H2/21H1/21H2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009543 -title "January 11, 2022-KB5009543 (OS Builds 19042.1466, 19043.1466, and 19044.1466)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008212 -title "December 14, 2021-KB5008212 (OS Builds 19041.1415, 19042.1415, 19043.1415, and 19044.1415)"
	CheckForHotfix -hotfixID 5007186 -title "November 9, 2021-KB5007186 (OS Builds 19041.1348, 19042.1348, and 19043.1348)"
	CheckForHotfix -hotfixID 5006670 -title "October 12, 2021-KB5006670 (OS Builds 19041.1288, 19042.1288, and 19043.1288)"
	CheckForHotfix -hotfixID 5005611 -title "September 30, 2021-KB5005611 (OS Builds 19041.1266, 19042.1266, and 19043.1266) Preview"
	CheckForHotfix -hotfixID 5005565 -title "September 14, 2021-KB5005565 (OS Builds 19041.1237, 19042.1237, and 19043.1237)"
	CheckForHotfix -hotfixID 5005033 -title "August 10, 2021-KB5005033 (OS Builds 19041.1165, 19042.1165, and 19043.1165))"
	CheckForHotfix -hotfixID 5004237 -title "July 13, 2021-KB5004237 (OS Builds 19041.1110, 19042.1110, and 19043.1110)"
	CheckForHotfix -hotfixID 5003637 -title "June 8, 2021-KB5003637 (OS Builds 19041.1052, 19042.1052, and 19043.1052)"
	CheckForHotfix -hotfixID 5003173 -title "May 11, 2021-KB5003173 (OS Builds 19041.985 and 19042.985)"
	CheckForHotfix -hotfixID 5001330 -title "April 13, 2021-KB5001330 (OS Builds 19041.928 and 19042.928)"
	CheckForHotfix -hotfixID 5001649 -title "March 18, 2021-KB5001649 (OS Builds 19041.870 and 19042.870) Out-of-band"
	CheckForHotfix -hotfixID 4601319 -title "February 9, 2021-KB4601319 (OS Builds 19041.804 and 19042.804)"
	CheckForHotfix -hotfixID 4598242 -title "January 12, 2021-KB4598242 (OS Builds 19041.746 and 19042.746)"
	CheckForHotfix -hotfixID 4592438 -title "December 8, 2020-KB4592438 (OS Builds 19041.685 and 19042.685)"
	CheckForHotfix -hotfixID 4586781 -title "November 10, 2020-KB4586781 (OS Builds 19041.630 and 19042.630)"
	CheckForHotfix -hotfixID 4579311 -title "October 13, 2020-KB4579311 (OS Build 19041.572)"
	CheckForHotfix -hotfixID 4571756 -title "September 8, 2020-KB4571756 (OS Build 19041.508)"
	CheckForHotfix -hotfixID 4566782 -title "August 11, 2020-KB4566782 (OS Build 19041.450)"
	CheckForHotfix -hotfixID 4565503 -title "July 14, 2020-KB4565503 (OS Build 19041.388)"
	CheckForHotfix -hotfixID 4557957 -title "June 9, 2020-KB4557957 (OS Build 19041.329)"
	CheckForHotfix -hotfixID 4598481 -title "Servicing stack update for Windows 10, version 2004 and 20H2: January 12, 2021"
}
elseif ($bn -match  1836) # 1903 = 18362, 1909 = 18363
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 19H2 v1909 and Windows Server 2019 19H2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009545 -title "January 11, 2022-KB5009545 (OS Build 18363.2037)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008206 -title "December 14, 2021-KB5008206 (OS Build 18363.1977)"
	CheckForHotfix -hotfixID 5007189 -title "November 9, 2021-KB5007189 (OS Build 18362.1916)"
	CheckForHotfix -hotfixID 5006667 -title "October 12, 2021-KB5006667 (OS Build 18363.1854)"
	CheckForHotfix -hotfixID 5005566 -title "September 14, 2021-KB5005566 (OS Build 18363.1801)"
	CheckForHotfix -hotfixID 5005031 -title "August 10, 2021-KB5005031 (OS Build 18363.1734)"
	CheckForHotfix -hotfixID 5004245 -title "July 13, 2021-KB5004245 (OS Build 18363.1679)"
	CheckForHotfix -hotfixID 5003635 -title "June 8, 2021-KB5003635 (OS Build 18363.1621)"
	CheckForHotfix -hotfixID 5003169 -title "May 11, 2021-KB5003169 (OS Build 18363.1556)"
	CheckForHotfix -hotfixID 5001337 -title "April 13, 2021-KB5001337 (OS Build 18363.1500)"
	CheckForHotfix -hotfixID 5001648 -title "March 18, 2021-KB5001648 (OS Build 18363.1443) Out-of-band"
	CheckForHotfix -hotfixID 4601315 -title "February 9, 2021-KB4601315 (OS Build 18363.1377)"
	CheckForHotfix -hotfixID 4598229 -title "January 12, 2021-KB4598229 (OS Build 18363.1316)"
	CheckForHotfix -hotfixID 4592449 -title "December 8, 2020-KB4592449 (OS Builds 18362.1256 and 18363.1256)"
	CheckForHotfix -hotfixID 4586786 -title "November 10, 2020-KB4586786 (OS Builds 18362.1198 and 18363.1198)"
	CheckForHotfix -hotfixID 4577671 -title "October 13, 2020-KB4577671 (OS Builds 18362.1139 and 18363.1139)"
	CheckForHotfix -hotfixID 4574727 -title "September 8, 2020-KB4574727 (OS Builds 18362.1082 and 18363.1082)"
	CheckForHotfix -hotfixID 4565351 -title "August 11, 2020-KB4565351 (OS Builds 18362.1016 and 18363.1016)"
	CheckForHotfix -hotfixID 4565483 -title "July 14, 2020-KB4565483 (OS Builds 18362.959 and 18363.959)"
	CheckForHotfix -hotfixID 4560960 -title "June 9, 2020-KB4560960 (OS Builds 18362.900 and 18363.900)"
	CheckForHotfix -hotfixID 4556799 -title "May 12, 2020-KB4556799 (OS Builds 18362.836 and 18363.836)" 
	CheckForHotfix -hotfixID 4549951 -title "April 14, 2020-KB4549951 (OS Builds 18362.778 and 18363.778)"
	CheckForHotfix -hotfixID 4540673 -title "March 10, 2020-KB4540673 (OS Builds 18362.719 and 18363.719)"
	CheckForHotfix -hotfixID 4532693 -title "February 11, 2020-KB4532693 (OS Builds 18362.657 and 18363.657)"
	CheckForHotfix -hotfixID 4528760 -title "January 14, 2020-KB4528760 (OS Builds 18362.592 and 18363.592)"
	CheckForHotfix -hotfixID 4530684 -title "December 10, 2019-KB4530684 (OS Builds 18362.535 and 18363.535)"
	CheckForHotfix -hotfixID 4601395 -title "KB4601395: Servicing stack update for Windows 10, version 1903: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 17763)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS5 v1809 and Windows Server 2019 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009557 -title "January 11, 2022-KB5009557 (OS Build 17763.2452)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008218 -title "December 14, 2021-KB5008218 (OS Build 17763.2366)"
	CheckForHotfix -hotfixID 5007206 -title "November 9, 2021-KB5007206 (OS Build 17763.2300)"
	CheckForHotfix -hotfixID 5006672 -title "October 12, 2021-KB5006672 (OS Build 17763.2237)"
	CheckForHotfix -hotfixID 5005568 -title "September 14, 2021-KB5005568 (OS Build 17763.2183)"
	CheckForHotfix -hotfixID 5005030 -title "August 10, 2021-KB5005030 (OS Build 17763.2114"
	CheckForHotfix -hotfixID 5004244 -title "July 13, 2021-KB5004244 (OS Build 17763.2061)"
	CheckForHotfix -hotfixID 5003646 -title "June 8, 2021-KB5003646 (OS Build 17763.1999)"
	CheckForHotfix -hotfixID 5003171 -title "May 11, 2021-KB5003171 (OS Build 17763.1935)"
	CheckForHotfix -hotfixID 5001342 -title "April 13, 2021-KB5001342 (OS Build 17763.1879)"
	CheckForHotfix -hotfixID 5001638 -title "March 18, 2021-KB5001638 (OS Build 17763.1823) Out-of-band"
	CheckForHotfix -hotfixID 4601345 -title "February 9, 2021-KB4601345 (OS Build 17763.1757)"
	CheckForHotfix -hotfixID 4598230 -title "January 12, 2021-KB4598230 (OS Build 17763.1697)"
	CheckForHotfix -hotfixID 4592440 -title "December 8, 2020-KB4592440 (OS Build 17763.1637)"
	CheckForHotfix -hotfixID 4586793 -title "November 10, 2020-KB4586793 (OS Build 17763.1577)"
	CheckForHotfix -hotfixID 4577668 -title "October 13, 2020-KB4577668 (OS Build 17763.1518)"
	CheckForHotfix -hotfixID 4570333 -title "September 8, 2020-KB4570333 (OS Build 17763.1457)"
	CheckForHotfix -hotfixID 4565349 -title "August 11, 2020-KB4565349 (OS Build 17763.1397)"
	CheckForHotfix -hotfixID 4558998 -title "July 14, 2020-KB4558998 (OS Build 17763.1339)"
	CheckForHotfix -hotfixID 4561608 -title "June 9, 2020-KB4561608 (OS Build 17763.1282)"
	CheckForHotfix -hotfixID 4551853 -title "May 12, 2020-KB4551853 (OS Build 17763.1217)" 
	CheckForHotfix -hotfixID 4549949 -title "April 14, 2020-KB4549949 (OS Build 17763.1158)"
	CheckForHotfix -hotfixID 4538461 -title "March 10, 2020-KB4538461 (OS Build 17763.1098)"
	CheckForHotfix -hotfixID 4532691 -title "February 11, 2020-KB4532691 (OS Build 17763.1039)"
	CheckForHotfix -hotfixID 4534273 -title "January 14, 2020-KB4534273 (OS Build 17763.973)"
	CheckForHotfix -hotfixID 4530715 -title "December 10, 2019-KB4530715 (OS Build 17763.914)"
	CheckForHotfix -hotfixID 4601393 -title "KB4601393: Servicing stack update for Windows 10, version 1809: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 14393)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS1 v1607 and Windows Server 2016 RS1 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009546 -title "January 11, 2022-KB5009546 (OS Build 14393.4886)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008207 -title "December 14, 2021-KB5008207 (OS Build 14393.4825)"
	CheckForHotfix -hotfixID 5007192 -title "November 9, 2021-KB5007192 (OS Build 14393.4770)"
	CheckForHotfix -hotfixID 5006669 -title "October 12, 2021-KB5006669 (OS Build 14393.4704)"
	CheckForHotfix -hotfixID 5005573 -title "September 14, 2021-KB5005573 (OS Build 14393.4651)"
	CheckForHotfix -hotfixID 5005043 -title "August 10, 2021-KB5005043 (OS Build 14393.4583)"
	CheckForHotfix -hotfixID 5004238 -title "July 13, 2021-KB5004238 (OS Build 14393.4530)"
	CheckForHotfix -hotfixID 5003638 -title "June 8, 2021-KB5003638 (OS Build 14393.4467)"
	CheckForHotfix -hotfixID 5003197 -title "May 11, 2021-KB5003197 (OS Build 14393.4402)"
	CheckForHotfix -hotfixID 5001347 -title "April 13, 2021-KB5001347 (OS Build 14393.4350)"
	CheckForHotfix -hotfixID 5001633 -title "March 18 2021-KB5001633 (OS Build 14393.4288) Out-of-band"
	CheckForHotfix -hotfixID 4601318 -title "February 9, 2021-KB4601318 (OS Build 14393.4225)" 
	CheckForHotfix -hotfixID 4598243 -title "January 12, 2021-KB4598243 (OS Build 14393.4169)"
	CheckForHotfix -hotfixID 4593226 -title "December 8, 2020-KB4593226 (OS Build 14393.4104)"
	CheckForHotfix -hotfixID 4586830 -title "November 10, 2020-KB4586830 (OS Build 14393.4046)"
	CheckForHotfix -hotfixID 4580346 -title "October 13, 2020-KB4580346 (OS Build 14393.3986)"
	CheckForHotfix -hotfixID 4577015 -title "September 8, 2020-KB4577015 (OS Build 14393.3930)"
	CheckForHotfix -hotfixID 4571694 -title "August 11, 2020-KB4571694 (OS Build 14393.3866)"
	CheckForHotfix -hotfixID 4565511 -title "July 14, 2020-KB4565511 (OS Build 14393.3808)"
	CheckForHotfix -hotfixID 4561616 -title "June 9, 2020-KB4561616 (OS Build 14393.3750)"
	CheckForHotfix -hotfixID 4556813 -title "May 12, 2020-KB4556813 (OS Build 14393.3686)"
	CheckForHotfix -hotfixID 4550929 -title "April 14, 2020-KB4550929 (OS Build 14393.3630)"
	CheckForHotfix -hotfixID 4540670 -title "March 10, 2020-KB4540670 (OS Build 14393.3564)"
	CheckForHotfix -hotfixID 4537764 -title "February 11, 2020-KB4537764 (OS Build 14393.3504)"
	CheckForHotfix -hotfixID 4534271 -title "January 14, 2020-KB4534271 (OS Build 14393.3443)"
	CheckForHotfix -hotfixID 4530689 -title "December 10, 2019-KB4530689 (OS Build 14393.3384)"
	CheckForHotfix -hotfixID 4601392 -title "Servicing stack update for Windows 10, version 1607: Februar 9, 2021" -Warn "Yes"
}	
elseif ($bn -eq 10240)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 and Windows Server 2016 RTM Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009585 -title "January 11, 2022-KB5009585 (OS Build 10240.19177)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008230 -title "December 14, 2021-KB5008230 (OS Build 10240.19145)"
	CheckForHotfix -hotfixID 5007207 -title "November 9, 2021-KB5007207 (OS Build 10240.19119)"
	CheckForHotfix -hotfixID 5006675 -title "October 12, 2021-KB5006675 (OS Build 10240.19086)"
	CheckForHotfix -hotfixID 5005569 -title "September 14, 2021-KB5005569 (OS Build 10240.19060)"
	CheckForHotfix -hotfixID 5005040 -title "August 10, 2021-KB5005040 (OS Build 10240.19022)"
	CheckForHotfix -hotfixID 5004249 -title "July 13, 2021-KB5004249 (OS Build 10240.19003)"
	CheckForHotfix -hotfixID 5003687 -title "June 8, 2021-KB5003687 (OS Build 10240.18967)"
	CheckForHotfix -hotfixID 5003172 -title "May 11, 2021-KB5003172 (OS Build 10240.18932)"
	CheckForHotfix -hotfixID 5001340 -title "April 13, 2021-KB5001340 (OS Build 10240.18906)"
	CheckForHotfix -hotfixID 5001631 -title "March 18, 2021-KB5001631 (OS Build 10240.18875) Out-of-band"
	CheckForHotfix -hotfixID 4601331 -title "February 9, 2021-KB4601331 (OS Build 10240.18842)"
	CheckForHotfix -hotfixID 4598231 -title "January 12, 2021-KB4598231 (OS Build 10240.18818)"
	CheckForHotfix -hotfixID 4592464 -title "December 8, 2020-KB4592464 (OS Build 10240.18782)"
	CheckForHotfix -hotfixID 4586787 -title "November 10, 2020-KB4586787 (OS Build 10240.18756)"
	CheckForHotfix -hotfixID 4580327 -title "October 13, 2020-KB4580327 (OS Build 10240.18725)"
	CheckForHotfix -hotfixID 4577049 -title "September 8, 2020-KB4577049 (OS Build 10240.18696)"
	CheckForHotfix -hotfixID 4571692 -title "August 11, 2020-KB4571692 (OS Build 10240.18666)"
	CheckForHotfix -hotfixID 4565513 -title "July 14, 2020-KB4565513 (OS Build 10240.18638)"
	CheckForHotfix -hotfixID 4561649 -title "June 9, 2020-KB4561649 (OS Build 10240.18608)"
	CheckForHotfix -hotfixID 4556826 -title "May 12, 2020-KB4556826 (OS Build 10240.18575)"
	CheckForHotfix -hotfixID 4550930 -title "April 14, 2020-KB4550930 (OS Build 10240.18545)"
	CheckForHotfix -hotfixID 4540693 -title "March 10, 2020-KB4540693 (OS Build 10240.18519)"
	CheckForHotfix -hotfixID 4537776 -title "February 11, 2020-KB4537776 (OS Build 10240.18486)"
	CheckForHotfix -hotfixID 4534306 -title "January 14, 2020-KB4534306 (OS Build 10240.18453)"
	CheckForHotfix -hotfixID 4530681 -title "December 10, 2019-KB4530681 (OS Build 10240.18427)"
	CheckForHotfix -hotfixID 4601390 -title "KB4601390: Servicing stack update for Windows 10: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 9600)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 8.1 and Windows Server 2012 R2 Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009624 -title "January 11, 2022-KB5009624 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008263 -title "December 14, 2021-KB5008263 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5007247 -title "November 9, 2021-KB5007247 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5006714 -title "October 12, 2021-KB5006714 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005613 -title "September 14, 2021-KB5005613 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005076 -title "August 10, 2021-KB5005076 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5004298 -title "July 13, 2021-KB5004298 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003671 -title "June 8, 2021-KB5003671 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003209 -title "May 11, 2021-KB5003209 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001382 -title "April 13, 2021-KB5001382 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000848 -title "March 9, 2021-KB5000848 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601384 -title "February 9, 2021-KB4601384 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598285 -title "January 12, 2021-KB4598285 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592484 -title "December 8, 2020-KB4592484 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4586845 -title "November 10, 2020-KB4586845 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4580347 -title "October 13, 2020-KB4580347 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4577066 -title "September 8, 2020-KB4577066 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4571703 -title "August 11, 2020-KB4571703 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4565541 -title "July 14, 2020-KB4565541 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4561666 -title "June 9, 2020-KB4561666 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4556846 -title "May 12, 2020-KB4556846 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4550961 -title "April 14, 2020-KB4550961 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4566425 -title "Servicing stack update for Windows 8.1, RT 8.1, and Server 2012 R2: July 14, 2020" -Warn "Yes"
	CheckForHotfix -hotfixID 4541509 -title "March 10, 2020-KB4541509 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4537821 -title "February 11, 2020-KB4537821 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4534297 -title "January 14, 2020-KB4534297 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4530702 -title "December 10, 2019-KB4530702 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3123245 -title "Update improves port exhaustion identification in Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3179574 -title "August 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3172614 -title "July 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3013769 -title "December 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3000850 -title "November 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 2919355 -title "[Windows 8.1 Update 1] Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2 Update: April 2014"
	CheckForHotfix -hotfixID 2883200 -title "Windows 8.1 and Windows Server 2012 R2 General Availability Update Rollup"
}
elseif ($bn -eq 9200)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Server 2012 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append
	
	CheckForHotfix -hotfixID 5009586 -title "January 11, 2022-KB5009586 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008277 -title "December 14, 2021-KB5008277 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5007260 -title "November 9, 2021-KB5007260 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5006739 -title "October 12, 2021-KB5006739 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005623 -title "September 14, 2021-KB5005623 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005099 -title "August 10, 2021-KB5005099 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5004294 -title "July 13, 2021-KB5004294 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003697 -title "June 8, 2021-KB5003697 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003208 -title "May 11, 2021-KB5003208 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001387 -title "April 13, 2021-KB5001387 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000847 -title "March 9, 2021-KB5000847 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601348 -title "February 9, 2021-KB4601348 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598278 -title "January 12, 2021-KB4598278 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592468 -title "December 8, 2020-KB4592468 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3179575 -title "August 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3172615 -title "July 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3161609 -title "June 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3156416 -title "May 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3013767 -title "December 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 3000853 -title "November 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2995388 -title "October 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012 "
	CheckForHotfix -hotfixID 2984005 -title "September 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2975331 -title "August 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2967916 -title "July 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012" 
	CheckForHotfix -hotfixID 2962407 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2014" 
	CheckForHotfix -hotfixID 2955163 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: May 2014"
	CheckForHotfix -hotfixID 2934016 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: April 2014" 	
	CheckForHotfix -hotfixID 2928678 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: March 2014" 	
	CheckForHotfix -hotfixID 2919393 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: February 2014"
	CheckForHotfix -hotfixID 2911101 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: January 2014"
	CheckForHotfix -hotfixID 2903938 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: December 2013"
	CheckForHotfix -hotfixID 2889784 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: November 2013"
	CheckForHotfix -hotfixID 2883201 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: October 2013"
	CheckForHotfix -hotfixID 2876415 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: September 2013"
	CheckForHotfix -hotfixID 2862768 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: August 2013"	
	CheckForHotfix -hotfixID 2855336 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: July 2013"	
	CheckForHotfix -hotfixID 2845533 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2013"	
	CheckForHotfix -hotfixID 2836988 -title "Windows 8 and Windows Server 2012 Update Rollup: May 2013" 				
	CheckForHotfix -hotfixID 2822241 -title "Windows 8 and Windows Server 2012 Update Rollup: April 2013"				
	CheckForHotfix -hotfixID 2811660 -title "Windows 8 and Windows Server 2012 Update Rollup: March 2013"				
	CheckForHotfix -hotfixID 2795944 -title "Windows 8 and Windows Server 2012 Update Rollup: February 2013"			
	CheckForHotfix -hotfixID 2785094 -title "Windows 8 and Windows Server 2012 Update Rollup: January 2013"				
	CheckForHotfix -hotfixID 2779768 -title "Windows 8 and Windows Server 2012 Update Rollup: December 2012"			
	CheckForHotfix -hotfixID 2770917 -title "Windows 8 and Windows Server 2012 Update Rollup: November 2012"			
	CheckForHotfix -hotfixID 2756872 -title "Windows 8 Client and Windows Server 2012 General Availability Update Rollup"
}
elseif ($bn -eq 7601)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 7 and Windows Server 2008 R2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=7600, SP1=7601)" | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009610 -title "January 11, 2022-KB5009610 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008244 -title "December 14, 2021-KB5008244 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5007236 -title "November 9, 2021-KB5007236 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5006743 -title "October 12, 2021-KB5006743 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005633 -title "September 14, 2021-KB5005633 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005088 -title "August 10, 2021-KB5005088 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5004289 -title "July 13, 2021-KB5004289 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003667 -title "June 8, 2021-KB5003667 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003233 -title "May 11, 2021-KB5003233 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001335 -title "April 13, 2021-KB5001335 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000841 -title "March 9, 2021-KB5000841 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601347 -title "February 9, 2021-KB4601347 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598279 -title "January 12, 2021-KB4598279 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592471 -title "December 8, 2020-KB4592471 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3125574 -title "Convenience roll-up update for Windows 7 SP1 and Windows Server 2008 R2 SP1" -Warn "Yes"
	CheckForHotfix -hotfixID 4490628 -title "Servicing stack update for Windows 7 SP1 and Windows Server 2008 R2 SP1: March 12, 2019"
	CheckForHotfix -hotfixID 4580970 -title "Servicing stack update for Windows 7 SP1 and Server 2008 R2 SP1: October 13, 2020" -Warn "Yes"
	CheckForHotfix -hotfixID 4538483 -title "Extended Security Updates (ESU) Licensing Preparation Package for Windows 7 SP1 and Windows Server 2008 R2 SP1"
	CheckForHotfix -hotfixID 2775511 -title "An enterprise hotfix rollup is available for Windows 7 SP1 and Windows Server 2008 R2 SP1"
}
elseif (($bn -eq 6002) -or ($bn -eq 6003))
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Vista and Windows Server 2008 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=6000, SP2=6002 or 6003)" | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5009627 -title "January 11, 2022-KB5009627 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5008274 -title "December 14, 2021-KB5008274 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5007263 -title "November 9, 2021-KB5007263 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5006736 -title "October 12, 2021-KB5006736 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005606 -title "September 14, 2021-KB5005606 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005090 -title "August 10, 2021-KB5005090 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 5004305 -title "July 13, 2021-KB5004305 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003661 -title "June 8, 2021-KB5003661 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003210 -title "May 11, 2021-KB5003210 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001389 -title "April 13, 2021-KB5001389 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000844 -title "March 9, 2021-KB5000844 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601360 -title "February 9, 2021-KB4601360 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598288 -title "January 12, 2021-KB4598288 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592498 -title "December 8, 2020-KB4592498 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4517134 -title "Servicing stack update for Windows Server 2008 SP2: September 10, 2019"
	CheckForHotfix -hotfixID 4572374 -title "Servicing stack update for Windows Server 2008 SP2: August 11, 2020" -Warn "Yes"
}

	CollectFiles -filesToCollect $OutputFile -fileDescription "Hotfix Rollups" -SectionDescription $sectionDescription



# SIG # Begin signature block
# MIInvQYJKoZIhvcNAQcCoIInrjCCJ6oCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBQnvZ8oIgqgXYX
# nCLi8pGLFLIYaScXGNd47eD2776jCaCCDYUwggYDMIID66ADAgECAhMzAAACU+OD
# 3pbexW7MAAAAAAJTMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMzAwWhcNMjIwOTAxMTgzMzAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDLhxHwq3OhH+4J+SX4qS/VQG8HybccH7tnG+BUqrXubfGuDFYPZ29uCuHfQlO1
# lygLgMpJ4Geh6/6poQ5VkDKfVssn6aA1PCzIh8iOPMQ9Mju3sLF9Sn+Pzuaie4BN
# rp0MuZLDEXgVYx2WNjmzqcxC7dY9SC3znOh5qUy2vnmWygC7b9kj0d3JrGtjc5q5
# 0WfV3WLXAQHkeRROsJFBZfXFGoSvRljFFUAjU/zdhP92P+1JiRRRikVy/sqIhMDY
# +7tVdzlE2fwnKOv9LShgKeyEevgMl0B1Fq7E2YeBZKF6KlhmYi9CE1350cnTUoU4
# YpQSnZo0YAnaenREDLfFGKTdAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUlZpLWIccXoxessA/DRbe26glhEMw
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQ2NzU5ODAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# AKVY+yKcJVVxf9W2vNkL5ufjOpqcvVOOOdVyjy1dmsO4O8khWhqrecdVZp09adOZ
# 8kcMtQ0U+oKx484Jg11cc4Ck0FyOBnp+YIFbOxYCqzaqMcaRAgy48n1tbz/EFYiF
# zJmMiGnlgWFCStONPvQOBD2y/Ej3qBRnGy9EZS1EDlRN/8l5Rs3HX2lZhd9WuukR
# bUk83U99TPJyo12cU0Mb3n1HJv/JZpwSyqb3O0o4HExVJSkwN1m42fSVIVtXVVSa
# YZiVpv32GoD/dyAS/gyplfR6FI3RnCOomzlycSqoz0zBCPFiCMhVhQ6qn+J0GhgR
# BJvGKizw+5lTfnBFoqKZJDROz+uGDl9tw6JvnVqAZKGrWv/CsYaegaPePFrAVSxA
# yUwOFTkAqtNC8uAee+rv2V5xLw8FfpKJ5yKiMKnCKrIaFQDr5AZ7f2ejGGDf+8Tz
# OiK1AgBvOW3iTEEa/at8Z4+s1CmnEAkAi0cLjB72CJedU1LAswdOCWM2MDIZVo9j
# 0T74OkJLTjPd3WNEyw0rBXTyhlbYQsYt7ElT2l2TTlF5EmpVixGtj4ChNjWoKr9y
# TAqtadd2Ym5FNB792GzwNwa631BPCgBJmcRpFKXt0VEQq7UXVNYBiBRd+x4yvjqq
# 5aF7XC5nXCgjbCk7IXwmOphNuNDNiRq83Ejjnc7mxrJGMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGY4wghmKAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAJT44Pelt7FbswAAAAA
# AlMwDQYJYIZIAWUDBAIBBQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIG5u
# B9RbbpmY9qg7vhaLqXnRy5WTTfuE8bvS0H3Zis1YMEQGCisGAQQBgjcCAQwxNjA0
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQu
# Y29tIDANBgkqhkiG9w0BAQEFAASCAQBzacX/uDqySZa/zaq652fKiAho+Qp79BfY
# jRNhLR8BI2rcAHg48aIeAIZ21I+EVxJyGR6zxOxkB9diZmR762A1kPII4vdzsCbp
# MYgU3XCM55xabIIwoGHibGCpJ7BPSp81lQ8TFWX5IVlvhg/c5ixixRERv73cpJJD
# CIFZPoWLmvjcMGm7LnvYz2AoubkXoKQR19Ukx3u2fAwzCTOwlAEHL0HynzZppiQG
# z0HBaJPasai9Wd5h9U7y2xi0eg8KBiXkctXt12Dvsubemmd9CYWyLuHp4rOdEs2r
# 7q3V0Ved8AC4wBDqWj0JhtUOMzU9azhk8fGuhRgQX/mpH25m6JfAoYIXFjCCFxIG
# CisGAQQBgjcDAwExghcCMIIW/gYJKoZIhvcNAQcCoIIW7zCCFusCAQMxDzANBglg
# hkgBZQMEAgEFADCCAVkGCyqGSIb3DQEJEAEEoIIBSASCAUQwggFAAgEBBgorBgEE
# AYRZCgMBMDEwDQYJYIZIAWUDBAIBBQAEIFhc4LPvrWb+h/CdXXBiO0MKokBPvKMP
# i7cWUKwmGoeBAgZhwh7ZT9kYEzIwMjIwMTE0MDcxNTA3LjEyNVowBIACAfSggdik
# gdUwgdIxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNV
# BAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UE
# CxMdVGhhbGVzIFRTUyBFU046MkFENC00QjkyLUZBMDExJTAjBgNVBAMTHE1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFNlcnZpY2WgghFlMIIHFDCCBPygAwIBAgITMwAAAYZ4
# 5RmJ+CRLzAABAAABhjANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
# cCBQQ0EgMjAxMDAeFw0yMTEwMjgxOTI3MzlaFw0yMzAxMjYxOTI3MzlaMIHSMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNy
# b3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxl
# cyBUU1MgRVNOOjJBRDQtNEI5Mi1GQTAxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# wI3G2Wpv6B4IjAfrgfJpndPOPYO1Yd8+vlfoIxMW3gdCDT+zIbafg14pOu0t0ekU
# Qx60p7PadH4OjnqNIE1q6ldH9ntj1gIdl4Hq4rdEHTZ6JFdE24DSbVoqqR+R4Iw4
# w3GPbfc2Q3kfyyFyj+DOhmCWw/FZiTVTlT4bdejyAW6r/Jn4fr3xLjbvhITatr36
# VyyzgQ0Y4Wr73H3gUcLjYu0qiHutDDb6+p+yDBGmKFznOW8wVt7D+u2VEJoE6JlK
# 0EpVLZusdSzhecuUwJXxb2uygAZXlsa/fHlwW9YnlBqMHJ+im9HuK5X4x8/5B5dk
# uIoX5lWGjFMbD2A6Lu/PmUB4hK0CF5G1YaUtBrME73DAKkypk7SEm3BlJXwY/GrV
# oXWYUGEHyfrkLkws0RoEMpoIEgebZNKqjRynRJgR4fPCKrEhwEiTTAc4DXGci4HH
# Om64EQ1g/SDHMFqIKVSxoUbkGbdKNKHhmahuIrAy4we9s7rZJskveZYZiDmtAtBt
# /gQojxbZ1vO9C11SthkrmkkTMLQf9cDzlVEBeu6KmHX2Sze6ggne3I4cy/5IULnH
# Z3rM4ZpJc0s2KpGLHaVrEQy4x/mAn4yaYfgeH3MEAWkVjy/qTDh6cDCF/gyz3TaQ
# DtvFnAK70LqtbEvBPdBpeCG/hk9l0laYzwiyyGY/HqMCAwEAAaOCATYwggEyMB0G
# A1UdDgQWBBQZtqNFA+9mdEu/h33UhHMN6whcLjAfBgNVHSMEGDAWgBSfpxVdAF5i
# XYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENB
# JTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRp
# bWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4ICAQDD7mehJY3fTHKC4hj+
# wBWB8544uaJiMMIHnhK9ONTM7VraTYzx0U/TcLJ6gxw1tRzM5uu8kswJNlHNp7Re
# dsAiwviVQZV9AL8IbZRLJTwNehCwk+BVcY2gh3ZGZmx8uatPZrRueyhhTTD2PvFV
# Lrfwh2liDG/dEPNIHTKj79DlEcPIWoOCUp7p0ORMwQ95kVaibpX89pvjhPl2Fm0C
# BO3pXXJg0bydpQ5dDDTv/qb0+WYF/vNVEU/MoMEQqlUWWuXECTqx6TayJuLJ6uU7
# K5QyTkQ/l24IhGjDzf5AEZOrINYzkWVyNfUOpIxnKsWTBN2ijpZ/Tun5qrmo9vNI
# DT0lobgnulae17NaEO9oiEJJH1tQ353dhuRi+A00PR781iYlzF5JU1DrEfEyNx8C
# WgERi90LKsYghZBCDjQ3DiJjfUZLqONeHrJfcmhz5/bfm8+aAaUPpZFeP0g0Iond
# 6XNk4YiYbWPFoofc0LwcqSALtuIAyz6f3d+UaZZsp41U4hCIoGj6hoDIuU839bo/
# mZ/AgESwGxIXs0gZU6A+2qIUe60QdA969wWSzucKOisng9HCSZLF1dqc3QUawr0C
# 0U41784Ko9vckAG3akwYuVGcs6hM/SqEhoe9jHwe4Xp81CrTB1l9+EIdukCbP0ky
# zx0WZzteeiDN5rdiiQR9mBJuljCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkA
# AAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUA
# A4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX
# 9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1q
# UoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8d
# q6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byN
# pOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2k
# rnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4d
# Pf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgS
# Uei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8
# QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6Cm
# gyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzF
# ER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQID
# AQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQU
# KqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1
# GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0
# dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0
# bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMA
# QTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbL
# j+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1p
# Y3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIz
# LmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwU
# tj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN
# 3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU
# 5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5
# KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGy
# qVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB6
# 2FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltE
# AY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFp
# AUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcd
# FYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRb
# atGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQd
# VTNYs6FwZvKhggLUMIICPQIBATCCAQChgdikgdUwgdIxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5k
# IE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MkFE
# NC00QjkyLUZBMDExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZp
# Y2WiIwoBATAHBgUrDgMCGgMVAAGu2DRzWkKljmXySX1korHL4fMnoIGDMIGApH4w
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDl
# i5fNMCIYDzIwMjIwMTE0MTQzMzQ5WhgPMjAyMjAxMTUxNDMzNDlaMHQwOgYKKwYB
# BAGEWQoEATEsMCowCgIFAOWLl80CAQAwBwIBAAICHKowBwIBAAICEYUwCgIFAOWM
# 6U0CAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAweh
# IKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQCD+s9HMfEDA3mBnZV0OHBx
# WoCv1yYEDcXFTZj9adrLQsqLdB//joVl3VXhTU7LZ5JUGUkWHUVsXmofSTzDCRhd
# pYsi0dbWYgBH5w3JMFfBBeQoSs4OJhTew1OGRd33r4i36wTdkfZ1nN2ZEX/x733x
# DvZ68E0iX59B5yiV4oTjeTGCBA0wggQJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwAhMzAAABhnjlGYn4JEvMAAEAAAGGMA0GCWCGSAFlAwQCAQUA
# oIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIE
# IDfCZQ+PAV7nvnuGG1wTRHS408swrhzuK8jTsz5241vPMIH6BgsqhkiG9w0BCRAC
# LzGB6jCB5zCB5DCBvQQgGpmI4LIsCFTGiYyfRAR7m7Fa2guxVNIw17mcAiq8Qn4w
# gZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAYZ45RmJ
# +CRLzAABAAABhjAiBCCPTqj5r4OmvVFR/rhJ7TjPZHlYB/WXiGQ03Shs+rjRlDAN
# BgkqhkiG9w0BAQsFAASCAgAYRz5FG5tZxbdwdHbdoWvreDQRXUIU1QLvfHt+Sk8i
# jOzJseaZjjEY0mJ7tdNWfiwWrbC7BvM0MpSRUUIAKe0sCLjlhFDFbCVNxSRYAYeI
# yQjnPRRewNHcD72MsyMn9tl4HGuZLK+Li4nEhb7m0dBSDyTHcEKHp9LjNzXsnI09
# UlW4d0Gl9o7Pc/GQRpWg1v61TRCwr5O46aYRJppkgtTFWa50MgDh0bRKnav77HNn
# TtTusmLnMOM5+S5PMeVbi9um3dZyBeu2qj5rVOrfdT9Jbb0DSBg3B8ZepITe+YIa
# NynAX4++pZ+QWEueAm6w4YvQHyNRM2MGe9X1KGky3GH/Jlw7EtyriHYqL23HfG99
# Mu2+AVMCeexvjioZEDxtp4bU/Cna6+ooTxNpVuFpo2+N9UBQ6o+8l/CxVxBMijd9
# BCWb8cAlAWaMiTOeVMMydffREJdwnJwuyH7H9oelNylQv4sgHoAFHLw13y2nZqc/
# maYltTdWPQDgYd6Bkg4Qygdhqu2zZ4TZUefErZ3iwuJEs/yIOQ4TX6wEGxvCEWU2
# FTWi9dLUf/oVoPaNF1xJI106xYP54UWHJHdhxm872p4xBlP2urEEZgZwM0RLxI0G
# SywfKEQWkiWQ+Kh6Nzbc4WhENlEwmleF454riWfQmMGRPb1pZAL15hlGs1ogkPqV
# pg==
# SIG # End signature block
