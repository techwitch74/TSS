﻿#************************************************
# DC_HotfixRollups.ps1
# Version 1.0.04.02.14: Created script to easily view what rollups are installed for W7/WS2008R2, W8/WS2012, and W8.1/WS2012R2
# Version 1.1.05.16.14: Added W8.1 Update1 (April2014 rollup);  Added OS Version below each heading.
# Version 1.2.05.19.14: Added May2014 updates for W8/W8.1
# Version 1.3.07.23.14: Added June and July, 2014
# Version 1.4.08.13.14: Added Aug2014 updates for W8/W8.1
# Version 1.5.09.17.14: Added Sep2014 updates for W8/W8.1
# Version 1.6.10.16.14: Added Oct2014 updates for W8/W8.1
# Date: 2019,2020
# Author: Boyd Benson (bbenson@microsoft.com) +WalterE
# Description: Creates output to easily identify what rollups are installed on W7/WS2008R2 and later.
# Called from: Networking Diagnostics, and all psSDP
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable

$OutputFile = $ComputerName + "_HotfixRollups.TXT"
$sectionDescription = "Hotfix Rollups"


function CheckForHotfix ($hotfixID, $title, $Warn="")
{
	$hotfixesWMIQuery = "SELECT * FROM Win32_QuickFixEngineering WHERE HotFixID='KB$hotfixID'"
	$hotfixesWMI = get-wmiobject -query $hotfixesWMIQuery											# or PS > Get-HotFix
	$link = "http://support.microsoft.com/kb/" + $hotfixID
	if ($hotfixesWMI -eq $null)
	{
		"No          $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
		If (($bn -lt 10240) -and ($Warn -match "Yes")) {Write-Host -ForegroundColor Red "*** WARNING latest OS cumulative KB $hotfixID is missing"}
	}
	else
	{
		"Yes         $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
	}
}

#----------detect OS version and SKU
	$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
	[int]$bn = [int]$wmiOSVersion.BuildNumber
	$sku = $((gwmi win32_operatingsystem).OperatingSystemSKU)

if (($bn -eq 19041) -or ($bn -eq 19042))
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 20H1 v2004/20H2 and Windows Server 2019 20H1/20H2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4601319 -title "February 9, 2021-KB4601319 (OS Builds 19041.804 and 19042.804)" -Warn "Yes"
	CheckForHotfix -hotfixID 4598242 -title "January 12, 2021-KB4598242 (OS Builds 19041.746 and 19042.746)"
	CheckForHotfix -hotfixID 4592438 -title "December 8, 2020-KB4592438 (OS Builds 19041.685 and 19042.685)"
	CheckForHotfix -hotfixID 4586781 -title "November 10, 2020-KB4586781 (OS Builds 19041.630 and 19042.630)"
	CheckForHotfix -hotfixID 4579311 -title "October 13, 2020-KB4579311 (OS Build 19041.572)"
	CheckForHotfix -hotfixID 4571756 -title "September 8, 2020—KB4571756 (OS Build 19041.508)"
	CheckForHotfix -hotfixID 4566782 -title "August 11, 2020-KB4566782 (OS Build 19041.450)"
	CheckForHotfix -hotfixID 4565503 -title "July 14, 2020-KB4565503 (OS Build 19041.388)"
	CheckForHotfix -hotfixID 4557957 -title "June 9, 2020-KB4557957 (OS Build 19041.329)"
	CheckForHotfix -hotfixID 4598481 -title "Servicing stack update for Windows 10, version 2004 and 20H2: January 12, 2021" -Warn "Yes"
}
elseif (($bn -eq 18362) -or ($bn -eq 18363))
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 19H1/H2 v1903/09 and Windows Server 2019 19H1/19H2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4601315 -title "February 9, 2021-KB4601315 (OS Build 18363.1377)" -Warn "Yes"
	CheckForHotfix -hotfixID 4598229 -title "January 12, 2021-KB4598229 (OS Build 18363.1316)"
	CheckForHotfix -hotfixID 4592449 -title "December 8, 2020-KB4592449 (OS Builds 18362.1256 and 18363.1256)"
	CheckForHotfix -hotfixID 4586786 -title "November 10, 2020-KB4586786 (OS Builds 18362.1198 and 18363.1198)"
	CheckForHotfix -hotfixID 4577671 -title "October 13, 2020-KB4577671 (OS Builds 18362.1139 and 18363.1139)"
	CheckForHotfix -hotfixID 4574727 -title "September 8, 2020-KB4574727 (OS Builds 18362.1082 and 18363.1082)"
	CheckForHotfix -hotfixID 4565351 -title "August 11, 2020-KB4565351 (OS Builds 18362.1016 and 18363.1016)"
	CheckForHotfix -hotfixID 4565483 -title "July 14, 2020-KB4565483 (OS Builds 18362.959 and 18363.959)"
	CheckForHotfix -hotfixID 4560960 -title "June 9, 2020-KB4560960 (OS Builds 18362.900 and 18363.900)"
	CheckForHotfix -hotfixID 4556799 -title "May 12, 2020-KB4556799 (OS Builds 18362.836 and 18363.836)" 
	CheckForHotfix -hotfixID 4549951 -title "April 14, 2020-KB4549951 (OS Builds 18362.778 and 18363.778)"
	CheckForHotfix -hotfixID 4540673 -title "March 10, 2020-KB4540673 (OS Builds 18362.719 and 18363.719)"
	CheckForHotfix -hotfixID 4532693 -title "February 11, 2020-KB4532693 (OS Builds 18362.657 and 18363.657)"
	CheckForHotfix -hotfixID 4528760 -title "January 14, 2020-KB4528760 (OS Builds 18362.592 and 18363.592)"
	CheckForHotfix -hotfixID 4530684 -title "December 10, 2019-KB4530684 (OS Builds 18362.535 and 18363.535)"
	CheckForHotfix -hotfixID 4524570 -title "November 12, 2019-KB4524570 (OS Builds 18362.476 and 18363.476)" 
	CheckForHotfix -hotfixID 4517389 -title "October 8, 2019-KB4517389 (OS Build 18362.418)"
	CheckForHotfix -hotfixID 4515384 -title "September 10, 2019-KB4515384 (OS Build 18362.356)"
	CheckForHotfix -hotfixID 4512508 -title "August 13, 2019-KB4512508 (OS Build 18362.295)"
	CheckForHotfix -hotfixID 4507453 -title "July 9, 2019-KB4507453 (OS Build 18362.239)"
	CheckForHotfix -hotfixID 4503293 -title "June 11, 2019-KB4503293 (OS Build 18362.175)"
	CheckForHotfix -hotfixID 4505057 -title "2019-KB4505057 Update for Windows 10, version 1903: May 19, 2019"
	CheckForHotfix -hotfixID 4601395 -title "KB4601395: Servicing stack update for Windows 10, version 1903: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 17763)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS5 v1809 and Windows Server 2019 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4601345 -title "February 9, 2021-KB4601345 (OS Build 17763.1757)" -Warn "Yes"
	CheckForHotfix -hotfixID 4598230 -title "January 12, 2021-KB4598230 (OS Build 17763.1697)"
	CheckForHotfix -hotfixID 4592440 -title "December 8, 2020-KB4592440 (OS Build 17763.1637)"
	CheckForHotfix -hotfixID 4586793 -title "November 10, 2020-KB4586793 (OS Build 17763.1577)"
	CheckForHotfix -hotfixID 4577668 -title "October 13, 2020-KB4577668 (OS Build 17763.1518)"
	CheckForHotfix -hotfixID 4570333 -title "September 8, 2020-KB4570333 (OS Build 17763.1457)"
	CheckForHotfix -hotfixID 4565349 -title "August 11, 2020-KB4565349 (OS Build 17763.1397)"
	CheckForHotfix -hotfixID 4558998 -title "July 14, 2020-KB4558998 (OS Build 17763.1339)"
	CheckForHotfix -hotfixID 4561608 -title "June 9, 2020-KB4561608 (OS Build 17763.1282)"
	CheckForHotfix -hotfixID 4551853 -title "May 12, 2020-KB4551853 (OS Build 17763.1217)" 
	CheckForHotfix -hotfixID 4549949 -title "April 14, 2020-KB4549949 (OS Build 17763.1158)"
	CheckForHotfix -hotfixID 4538461 -title "March 10, 2020-KB4538461 (OS Build 17763.1098)"
	CheckForHotfix -hotfixID 4532691 -title "February 11, 2020-KB4532691 (OS Build 17763.1039)"
	CheckForHotfix -hotfixID 4534273 -title "January 14, 2020-KB4534273 (OS Build 17763.973)"
	CheckForHotfix -hotfixID 4530715 -title "December 10, 2019-KB4530715 (OS Build 17763.914)"
	CheckForHotfix -hotfixID 4523205 -title "November 12, 2019-KB4523205 (OS Build 17763.864)" 
	CheckForHotfix -hotfixID 4519338 -title "October 8, 2019-KB4519338 (OS Build 17763.806)"
	CheckForHotfix -hotfixID 4512578 -title "September 10, 2019-KB4512578 (OS Build 17763.737)"
	CheckForHotfix -hotfixID 4511553 -title "August 13, 2019-KB4511553 (OS Build 17763.678)"
	CheckForHotfix -hotfixID 4507469 -title "July 9, 2019-KB4507469 (OS Build 17763.615)"
	CheckForHotfix -hotfixID 4503327 -title "June 11, 2019-KB4503327 (OS Build 17763.557)"
	CheckForHotfix -hotfixID 4505056 -title "May 19, 2019-KB4505056 (OS Build 17763.504)"
	CheckForHotfix -hotfixID 4493509 -title "April 9, 2019-KB4493509 (OS Build 17763.437)"
	CheckForHotfix -hotfixID 4489899 -title "March 12, 2019-KB4489899 (OS Build 17763.379)"
	CheckForHotfix -hotfixID 4487044 -title "February 12, 2019-KB4487044 (OS Build 17763.316)"
	CheckForHotfix -hotfixID 4480116 -title "January 8, 2019-KB4480116 (OS Build 17763.253)"
	CheckForHotfix -hotfixID 4471332 -title "December 11, 2018-KB4471332 (OS Build 17763.194)"
	CheckForHotfix -hotfixID 4601393 -title "KB4601393: Servicing stack update for Windows 10, version 1809: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 17134)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS4 v1803 and Windows Server 2016 RS4 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4601354 -title "February 9, 2021-KB4601354 (OS Build 17134.2026)" -Warn "Yes"
	CheckForHotfix -hotfixID 4598245 -title "January 12, 2021-KB4598245 (OS Build 17134.1967)"
	CheckForHotfix -hotfixID 4592446 -title "December 8, 2020-KB4592446 (OS Build 17134.1902)"
	CheckForHotfix -hotfixID 4586785 -title "November 10, 2020-KB4586785 (OS Build 17134.1845)"
	CheckForHotfix -hotfixID 4580330 -title "October 13, 2020-KB4580330 (OS Build 17134.1792)"
	CheckForHotfix -hotfixID 4577032 -title "September 8, 2020-KB4577032 (OS Build 17134.1726)"
	CheckForHotfix -hotfixID 4571709 -title "August 11, 2020-KB4571709 (OS Build 17134.1667)"
	CheckForHotfix -hotfixID 4565489 -title "July 14, 2020-KB4565489 (OS Build 17134.1610)"
	CheckForHotfix -hotfixID 4561621 -title "June 9, 2020-KB4561621 (OS Build 17134.1550)"
	CheckForHotfix -hotfixID 4556807 -title "May 12, 2020-KB4556807 (OS Build 17134.1488)"
	CheckForHotfix -hotfixID 4550922 -title "April 14, 2020-KB4550922 (OS Build 17134.1425)"
	CheckForHotfix -hotfixID 4540689 -title "March 10, 2020-KB4540689 (OS Build 17134.1365)"
	CheckForHotfix -hotfixID 4537762 -title "February 11, 2020-KB4537762 (OS Build 17134.1304)"
	CheckForHotfix -hotfixID 4534293 -title "January 14, 2020-KB4534293 (OS Build 17134.1246)"
	CheckForHotfix -hotfixID 4530717 -title "December 10, 2019-KB4530717 (OS Build 17134.1184)"
	CheckForHotfix -hotfixID 4525237 -title "November 12, 2019-KB4525237 (OS Build 17134.1130)" 
	CheckForHotfix -hotfixID 4520008 -title "October 8, 2019-KB4520008 (OS Build 17134.1069)"
	CheckForHotfix -hotfixID 4516058 -title "September 10, 2019-KB4516058 (OS Build 17134.1006)"
	CheckForHotfix -hotfixID 4512501 -title "August 13, 2019-KB4512501 (OS Build 17134.950)"
	CheckForHotfix -hotfixID 4507435 -title "July 9, 2019-KB4507435 (OS Build 17134.885)"
	CheckForHotfix -hotfixID 4503286 -title "June 11, 2019-KB4503286 (OS Build 17134.829)"
	CheckForHotfix -hotfixID 4505064 -title "May 19, 2019-KB4505064 (OS Build 17134.766)"
	CheckForHotfix -hotfixID 4493464 -title "April 9, 2019-KB4493464 (OS Build 17134.706) "
	CheckForHotfix -hotfixID 4489868 -title "March 12, 2019-KB4489868 (OS Build 17134.648) "
	CheckForHotfix -hotfixID 4487017 -title "February 12, 2019-KB4487017 (OS Build 17134.590)"
	CheckForHotfix -hotfixID 4480966 -title "January 8, 2019-KB4480966 (OS Build 17134.523)"
	CheckForHotfix -hotfixID 4471324 -title "December 11, 2018-KB4471324 (OS Build 17134.471)"
	CheckForHotfix -hotfixID 4580398 -title "Servicing stack update for Windows 10, version 1803: October 13, 2020" -Warn "Yes"
}
elseif ($bn -eq 15063)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS2 v1703 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4601330 -title "February 9, 2021-KB4601330 (OS Build 15063.2642)" -Warn "Yes"
	CheckForHotfix -hotfixID 4599208 -title "January 12, 2021-KB4599208 (OS Build 15063.2614)"
	CheckForHotfix -hotfixID 4592473 -title "December 8, 2020-KB4592473 (OS Build 15063.2584)"
	CheckForHotfix -hotfixID 4586782 -title "November 10, 2020-KB4586782 (OS Build 15063.2554)"
	CheckForHotfix -hotfixID 4580370 -title "October 13, 2020-KB4580370 (OS Build 15063.2525)"
	CheckForHotfix -hotfixID 4577021 -title "September 8, 2020-KB4577021 (OS Build 15063.2500)"
	CheckForHotfix -hotfixID 4571689 -title "August 11, 2020-KB4571689 (OS Build 15063.2467)"
	CheckForHotfix -hotfixID 4565499 -title "July 14, 2020-KB4565499 (OS Build 15063.2439)"
	CheckForHotfix -hotfixID 4561605 -title "June 9, 2020-KB4561605 (OS Build 15063.2409)"
	CheckForHotfix -hotfixID 4556804 -title "May 12, 2020-KB4556804 (OS Build 15063.2375)"
	CheckForHotfix -hotfixID 4550939 -title "April 14, 2020-KB4550939 (OS Build 15063.2346)"
	CheckForHotfix -hotfixID 4540705 -title "March 10, 2020-KB4540705 (OS Build 15063.2313)"
	CheckForHotfix -hotfixID 4537765 -title "February 11, 2020-KB4537765 (OS Build 15063.2284)"
	CheckForHotfix -hotfixID 4534296 -title "January 14, 2020-KB4534296 (OS Build 15063.2254)"
	CheckForHotfix -hotfixID 4530711 -title "December 10, 2019-KB4530711 (OS Build 15063.2224)"
	CheckForHotfix -hotfixID 4525245 -title "November 12, 2019-KB4525245 (OS Build 15063.2172)" 
	CheckForHotfix -hotfixID 4520010 -title "October 8, 2019-KB4520010 (OS Build 15063.2108)"
	CheckForHotfix -hotfixID 4516068 -title "September 10, 2019-KB4516068 (OS Build 15063.2045)"
	CheckForHotfix -hotfixID 4512507 -title "August 13, 2019-KB4512507 (OS Build 15063.1988)"
	CheckForHotfix -hotfixID 4507450 -title "July 9, 2019-KB4507450 (OS Build 15063.1928)"
	CheckForHotfix -hotfixID 4503279 -title "June 11, 2019-KB4503279 (OS Build 15063.1868)"
	CheckForHotfix -hotfixID 4499181 -title "May 14, 2019-KB4499181 (OS Build 15063.1805)"
	CheckForHotfix -hotfixID 4493474 -title "April 9, 2019-KB4493474 (OS Build 15063.1746)"
	CheckForHotfix -hotfixID 4489871 -title "March 12, 2019-KB4489871 (OS Build 15063.1689)"
	CheckForHotfix -hotfixID 4487020 -title "February 12, 2019-KB4487020 (OS Build 15063.1631)"
	CheckForHotfix -hotfixID 4480973 -title "January 8, 2019-KB4480973 (OS Build 15063.1563)"
	CheckForHotfix -hotfixID 4471327 -title "December 11, 2018-KB4471327 (OS Build 15063.1506)"
	CheckForHotfix -hotfixID 4565551 -title "Servicing stack update for Windows 10, version 1703: July 14, 2020" -Warn "Yes"
}
elseif ($bn -eq 14393)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS1 v1607 and Windows Server 2016 RS1 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4601318 -title "February 9, 2021-KB4601318 (OS Build 14393.4225)" -Warn "Yes"
	CheckForHotfix -hotfixID 4598243 -title "January 12, 2021-KB4598243 (OS Build 14393.4169)"
	CheckForHotfix -hotfixID 4593226 -title "December 8, 2020-KB4593226 (OS Build 14393.4104)"
	CheckForHotfix -hotfixID 4586830 -title "November 10, 2020-KB4586830 (OS Build 14393.4046)"
	CheckForHotfix -hotfixID 4580346 -title "October 13, 2020-KB4580346 (OS Build 14393.3986)"
	CheckForHotfix -hotfixID 4577015 -title "September 8, 2020-KB4577015 (OS Build 14393.3930)"
	CheckForHotfix -hotfixID 4571694 -title "August 11, 2020-KB4571694 (OS Build 14393.3866)"
	CheckForHotfix -hotfixID 4565511 -title "July 14, 2020-KB4565511 (OS Build 14393.3808)"
	CheckForHotfix -hotfixID 4561616 -title "June 9, 2020-KB4561616 (OS Build 14393.3750)"
	CheckForHotfix -hotfixID 4556813 -title "May 12, 2020-KB4556813 (OS Build 14393.3686)"
	CheckForHotfix -hotfixID 4550929 -title "April 14, 2020-KB4550929 (OS Build 14393.3630)"
	CheckForHotfix -hotfixID 4540670 -title "March 10, 2020-KB4540670 (OS Build 14393.3564)"
	CheckForHotfix -hotfixID 4537764 -title "February 11, 2020-KB4537764 (OS Build 14393.3504)"
	CheckForHotfix -hotfixID 4534271 -title "January 14, 2020-KB4534271 (OS Build 14393.3443)"
	CheckForHotfix -hotfixID 4530689 -title "December 10, 2019-KB4530689 (OS Build 14393.3384)"
	CheckForHotfix -hotfixID 4525236 -title "November 12, 2019-KB4525236 (OS Build 14393.3326)" 
	CheckForHotfix -hotfixID 4519998 -title "October 8, 2019-KB4519998 (OS Build 14393.3274)"
	CheckForHotfix -hotfixID 4516044 -title "September 10, 2019-KB4516044 (OS Build 14393.3204)"
	CheckForHotfix -hotfixID 4512517 -title "August 13, 2019-KB4512517 (OS Build 14393.3144)"
	CheckForHotfix -hotfixID 4507460 -title "July 9, 2019-KB4507460 (OS Build 14393.3085)"
	CheckForHotfix -hotfixID 4503267 -title "June 11, 2019-KB4503267 (OS Build 14393.3025)"
	CheckForHotfix -hotfixID 4494440 -title "May 14, 2019-KB4494440 (OS Build 14393.2969)"
	CheckForHotfix -hotfixID 4493470 -title "April 9, 2019-KB4493470 (OS Build 14393.2906)"
	CheckForHotfix -hotfixID 4489882 -title "March 12, 2019-KB4489882 (OS Build 14393.2848)"
	CheckForHotfix -hotfixID 4487026 -title "February 12, 2019-KB4487026 (OS Build 14393.2791)"
	CheckForHotfix -hotfixID 4480961 -title "January 8, 2019-KB4480961 (OS Build 14393.2724)"
	CheckForHotfix -hotfixID 4471321 -title "December 11, 2018-KB4471321 (OS Build 14393.2665)"
	CheckForHotfix -hotfixID 4601392 -title "Servicing stack update for Windows 10, version 1607: Februar 9, 2021" -Warn "Yes"
}	
elseif ($bn -eq 10240)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 and Windows Server 2016 RTM Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4601331 -title "February 9, 2021-KB4601331 (OS Build 10240.18842)" -Warn "Yes"
	CheckForHotfix -hotfixID 4598231 -title "January 12, 2021-KB4598231 (OS Build 10240.18818)"
	CheckForHotfix -hotfixID 4592464 -title "December 8, 2020-KB4592464 (OS Build 10240.18782)"
	CheckForHotfix -hotfixID 4586787 -title "November 10, 2020-KB4586787 (OS Build 10240.18756)"
	CheckForHotfix -hotfixID 4580327 -title "October 13, 2020-KB4580327 (OS Build 10240.18725)"
	CheckForHotfix -hotfixID 4577049 -title "September 8, 2020-KB4577049 (OS Build 10240.18696)"
	CheckForHotfix -hotfixID 4571692 -title "August 11, 2020-KB4571692 (OS Build 10240.18666)"
	CheckForHotfix -hotfixID 4565513 -title "July 14, 2020-KB4565513 (OS Build 10240.18638)"
	CheckForHotfix -hotfixID 4561649 -title "June 9, 2020-KB4561649 (OS Build 10240.18608)"
	CheckForHotfix -hotfixID 4556826 -title "May 12, 2020-KB4556826 (OS Build 10240.18575)"
	CheckForHotfix -hotfixID 4550930 -title "April 14, 2020-KB4550930 (OS Build 10240.18545)"
	CheckForHotfix -hotfixID 4540693 -title "March 10, 2020-KB4540693 (OS Build 10240.18519)"
	CheckForHotfix -hotfixID 4537776 -title "February 11, 2020-KB4537776 (OS Build 10240.18486)"
	CheckForHotfix -hotfixID 4534306 -title "January 14, 2020-KB4534306 (OS Build 10240.18453)"
	CheckForHotfix -hotfixID 4530681 -title "December 10, 2019-KB4530681 (OS Build 10240.18427)"
	CheckForHotfix -hotfixID 4525232 -title "November 12, 2019-KB4525232 (OS Build 10240.18395)" 
	CheckForHotfix -hotfixID 4520011 -title "October 8, 2019-KB4520011 (OS Build 10240.18368)"
	CheckForHotfix -hotfixID 4516070 -title "September 10, 2019-KB4516070 (OS Build 10240.18333)"
	CheckForHotfix -hotfixID 4512497 -title "August 13, 2019-KB4512497 (OS Build 10240.18305)"
	CheckForHotfix -hotfixID 4507458 -title "July 9, 2019-KB4507458 (OS Build 10240.18275)"
	CheckForHotfix -hotfixID 4503291 -title "June 11, 2019-KB4503291 (OS Build 10240.18244)"
	CheckForHotfix -hotfixID 4499154 -title "May 14, 2019-KB4499154 (OS Build 10240.18215)"
	CheckForHotfix -hotfixID 4493475 -title "April 9, 2019-KB4493475 (OS Build 10240.18186)"
	CheckForHotfix -hotfixID 4489872 -title "March 12, 2019-KB4489872 (OS Build 10240.18158)"
	CheckForHotfix -hotfixID 4487018 -title "February 12, 2019-KB4487018 (OS Build 10240.18132)"
	CheckForHotfix -hotfixID 4480962 -title "January 8, 2019-KB4480962 (OS Build 10240.18094)"
	CheckForHotfix -hotfixID 4471323 -title "December 11, 2018-KB4471323 (OS Build 10240.18063)"
	CheckForHotfix -hotfixID 4601390 -title "KB4601390: Servicing stack update for Windows 10: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 9600)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 8.1 and Windows Server 2012 R2 Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4601384 -title "February 9, 2021-KB4601384 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 4598285 -title "January 12, 2021-KB4598285 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592484 -title "December 8, 2020-KB4592484 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4586845 -title "November 10, 2020-KB4586845 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4580347 -title "October 13, 2020-KB4580347 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4577066 -title "September 8, 2020-KB4577066 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4571703 -title "August 11, 2020-KB4571703 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4565541 -title "July 14, 2020-KB4565541 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4561666 -title "June 9, 2020-KB4561666 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4556846 -title "May 12, 2020-KB4556846 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4550961 -title "April 14, 2020-KB4550961 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4566425 -title "Servicing stack update for Windows 8.1, RT 8.1, and Server 2012 R2: July 14, 2020" -Warn "Yes"
	CheckForHotfix -hotfixID 4541509 -title "March 10, 2020-KB4541509 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4537821 -title "February 11, 2020-KB4537821 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4534297 -title "January 14, 2020-KB4534297 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4530702 -title "December 10, 2019-KB4530702 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4525243 -title "November 12, 2019-KB4525243 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 4520005 -title "October 8, 2019-KB4520005 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4516067 -title "September 10, 2019-KB4516067 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4512488 -title "August 13, 2019-KB4512488 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4507448 -title "July 9, 2019-KB4507448 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503276 -title "June 11, 2019-KB4503276 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499151 -title "May 14, 2019-KB4499151 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493446 -title "April 9, 2019-KB4493446 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489881 -title "March 12, 2019-KB4489881 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487000 -title "February 12, 2019-KB4487000 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480963 -title "January 8, 2019-KB4480963 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471320 -title "December 11, 2018-KB4471320 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3123245 -title "Update improves port exhaustion identification in Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3179574 -title "August 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3172614 -title "July 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3013769 -title "December 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3000850 -title "November 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 2919355 -title "[Windows 8.1 Update 1] Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2 Update: April 2014"
	CheckForHotfix -hotfixID 2883200 -title "Windows 8.1 and Windows Server 2012 R2 General Availability Update Rollup"
}
elseif ($bn -eq 9200)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Server 2012 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append
	
	CheckForHotfix -hotfixID 4601348 -title "February 9, 2021-KB4601348 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 4598278 -title "January 12, 2021-KB4598278 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592468 -title "December 8, 2020-KB4592468 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4586834 -title "November 10, 2020-KB4586834 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4580382 -title "October 13, 2020-KB4580382 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4577038 -title "September 8, 2020-KB4577038 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4571736 -title "August 11, 2020-KB4571736 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4565537 -title "July 14, 2020-KB4565537 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4561612 -title "June 9, 2020-KB4561612 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4556840 -title "May 12, 2020-KB4556840 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4550917 -title "April 14, 2020-KB4550917 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4566426 -title "Servicing stack update for Windows Server 2012: July 14, 2020" -Warn "Yes"
	CheckForHotfix -hotfixID 4541510 -title "March 10, 2020-KB4541510 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4537814 -title "February 11, 2020-KB4537814 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4534283 -title "January 14, 2020-KB4534283 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4530691 -title "December 10, 2019-KB4530691 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4525246 -title "November 12, 2019-KB4525246 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 4520007 -title "October 8, 2019-KB4520007 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4516055 -title "September 10, 2019-KB4516055 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4512518 -title "August 13, 2019-KB4512518 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4507462 -title "July 9, 2019-KB4507462 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503285 -title "June 11, 2019-KB4503285 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499171 -title "May 14, 2019-KB4499171 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493451 -title "April 9, 2019-KB4493451 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489891 -title "March 12, 2019-KB4489891 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487025 -title "February 12, 2019-KB4487025 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480975 -title "January 8, 2019-KB4480975 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471330 -title "December 11, 2018-KB4471330 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3179575 -title "August 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3172615 -title "July 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3161609 -title "June 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3156416 -title "May 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3013767 -title "December 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 3000853 -title "November 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2995388 -title "October 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012 "
	CheckForHotfix -hotfixID 2984005 -title "September 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2975331 -title "August 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2967916 -title "July 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012" 
	CheckForHotfix -hotfixID 2962407 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2014" 
	CheckForHotfix -hotfixID 2955163 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: May 2014"
	CheckForHotfix -hotfixID 2934016 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: April 2014" 	
	CheckForHotfix -hotfixID 2928678 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: March 2014" 	
	CheckForHotfix -hotfixID 2919393 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: February 2014"
	CheckForHotfix -hotfixID 2911101 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: January 2014"
	CheckForHotfix -hotfixID 2903938 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: December 2013"
	CheckForHotfix -hotfixID 2889784 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: November 2013"
	CheckForHotfix -hotfixID 2883201 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: October 2013"
	CheckForHotfix -hotfixID 2876415 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: September 2013"
	CheckForHotfix -hotfixID 2862768 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: August 2013"	
	CheckForHotfix -hotfixID 2855336 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: July 2013"	
	CheckForHotfix -hotfixID 2845533 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2013"	
	CheckForHotfix -hotfixID 2836988 -title "Windows 8 and Windows Server 2012 Update Rollup: May 2013" 				
	CheckForHotfix -hotfixID 2822241 -title "Windows 8 and Windows Server 2012 Update Rollup: April 2013"				
	CheckForHotfix -hotfixID 2811660 -title "Windows 8 and Windows Server 2012 Update Rollup: March 2013"				
	CheckForHotfix -hotfixID 2795944 -title "Windows 8 and Windows Server 2012 Update Rollup: February 2013"			
	CheckForHotfix -hotfixID 2785094 -title "Windows 8 and Windows Server 2012 Update Rollup: January 2013"				
	CheckForHotfix -hotfixID 2779768 -title "Windows 8 and Windows Server 2012 Update Rollup: December 2012"			
	CheckForHotfix -hotfixID 2770917 -title "Windows 8 and Windows Server 2012 Update Rollup: November 2012"			
	CheckForHotfix -hotfixID 2756872 -title "Windows 8 Client and Windows Server 2012 General Availability Update Rollup"
}
elseif ($bn -eq 7601)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 7 and Windows Server 2008 R2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=7600, SP1=7601)" | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4601347 -title "February 9, 2021-KB4601347 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 4598279 -title "January 12, 2021-KB4598279 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592471 -title "December 8, 2020-KB4592471 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4586827 -title "November 10, 2020-KB4586827 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4580345 -title "October 13, 2020-KB4580345 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4577051 -title "September 8, 2020-KB4577051 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4571729 -title "August 11, 2020-KB4571729 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4565524 -title "July 14, 2020-KB4565524 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4561643 -title "June 9, 2020-KB4561643 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4556836 -title "May 12, 2020-KB4556836 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 4550964 -title "April 14, 2020-KB4550964 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4540688 -title "March 10, 2020-KB4540688 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4537820 -title "February 11, 2020-KB4537820 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4534310 -title "January 14, 2020-KB4534310 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4530734 -title "December 10, 2019-KB4530734 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4525235 -title "November 12, 2019-KB4525235 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 4519976 -title "October 8, 2019-KB4519976 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4516065 -title "September 10, 2019-KB4516065 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4512506 -title "August 13, 2019-KB4512506 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4507449 -title "July 9, 2019-KB4507449 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503292 -title "June 11, 2019-KB4503292 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499164 -title "May 14, 2019-KB4499164 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493472 -title "April 9, 2019-KB4493472 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489878 -title "March 12, 2019-KB4489878 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4486563 -title "February 12, 2019-KB4486563 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480970 -title "January 8, 2019-KB4480970 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471318 -title "December 11, 2018-KB4471318 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3125574 -title "Convenience roll-up update for Windows 7 SP1 and Windows Server 2008 R2 SP1" -Warn "Yes"
	CheckForHotfix -hotfixID 4490628 -title "Servicing stack update for Windows 7 SP1 and Windows Server 2008 R2 SP1: March 12, 2019"
	CheckForHotfix -hotfixID 4580970 -title "Servicing stack update for Windows 7 SP1 and Server 2008 R2 SP1: October 13, 2020" -Warn "Yes"
	CheckForHotfix -hotfixID 4538483 -title "Extended Security Updates (ESU) Licensing Preparation Package for Windows 7 SP1 and Windows Server 2008 R2 SP1"
	CheckForHotfix -hotfixID 2775511 -title "An enterprise hotfix rollup is available for Windows 7 SP1 and Windows Server 2008 R2 SP1"
}
elseif ($bn -eq 6002)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Vista and Windows Server 2008 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=6000, SP2=6002)" | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4601360 -title "February 9, 2021-KB4601360 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 4598288 -title "January 12, 2021-KB4598288 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592498 -title "December 8, 2020-KB4592498 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4586807 -title "November 10, 2020-KB4586807 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4580378 -title "October 13, 2020-KB4580378 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4577064 -title "September 8, 2020-KB4577064 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4571730 -title "August 11, 2020-KB4571730 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4565536 -title "July 14, 2020-KB4565536 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4561670 -title "June 9, 2020-KB4561670 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4556860 -title "May 12, 2020-KB4556860 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4550951 -title "April 14, 2020-KB4550951 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4541506 -title "March 10, 2020-KB4541506 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4537810 -title "February 11, 2020-KB4537810 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4534303 -title "January 14, 2020-KB4534303 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4530695 -title "December 10, 2019-KB4530695 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4525234 -title "November 12, 2019-KB4525234 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 4520002 -title "October 8, 2019-KB4520002 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4516026 -title "September 10, 2019-KB4516026 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4512476 -title "August 13, 2019-KB4512476 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4507452 -title "July 9, 2019-KB4507452 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503273 -title "June 11, 2019-KB4503273 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499149 -title "May 14, 2019-KB4499149 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493471 -title "April 9, 2019-KB4493471 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489880 -title "March 12, 2019-KB4489880 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487023 -title "February 12, 2019-KB4487023 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480968 -title "January 8, 2019-KB4480968 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471325 -title "December 11, 2018-KB4471325 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4517134 -title "Servicing stack update for Windows Server 2008 SP2: September 10, 2019"
	CheckForHotfix -hotfixID 4572374 -title "Servicing stack update for Windows Server 2008 SP2: August 11, 2020" -Warn "Yes"
}

	CollectFiles -filesToCollect $OutputFile -fileDescription "Hotfix Rollups" -SectionDescription $sectionDescription

