﻿#************************************************
# DC_HotfixRollups.ps1
# Version 1.0.04.02.14: Created script to easily view what rollups are installed for W7/WS2008R2, W8/WS2012, and W8.1/WS2012R2
# Version 1.1.05.16.14: Added W8.1 Update1 (April2014 rollup);  Added OS Version below each heading.
# Version 1.2.05.19.14: Added May2014 updates for W8/W8.1
# Version 1.3.07.23.14: Added June and July, 2014
# Version 1.4.08.13.14: Added Aug2014 updates for W8/W8.1
# Version 1.5.09.17.14: Added Sep2014 updates for W8/W8.1
# Version 1.6.10.16.14: Added Oct2014 updates for W8/W8.1
# Date: 2019,2020
# Author: Boyd Benson (bbenson@microsoft.com) +WalterE
# Description: Creates output to easily identify what rollups are installed on W7/WS2008R2 and later.
# Called from: Networking Diagnostics, and all psSDP
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable

$OutputFile = $ComputerName + "_HotfixRollups.TXT"
$sectionDescription = "Hotfix Rollups"


function CheckForHotfix ($hotfixID, $title, $Warn="")
{
	$hotfixesWMIQuery = "SELECT * FROM Win32_QuickFixEngineering WHERE HotFixID='KB$hotfixID'"
	$hotfixesWMI = get-wmiobject -query $hotfixesWMIQuery											# or PS > Get-HotFix
	$link = "http://support.microsoft.com/kb/" + $hotfixID
	if ($hotfixesWMI -eq $null)
	{
		"No          $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
		If ($Warn -match "Yes") {
			Write-Host -ForegroundColor Red "*** [WARNING] latest OS cumulative KB $hotfixID is missing.`n Please update this machine with recommended Microsoft KB $hotfixID and verify if your issue is resolved."
			$Global:MissingCU = $hotfixID
		}
	}
	else
	{
		"Yes         $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
	}
}

#----------detect OS version and SKU
	$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
	[int]$bn = [int]$wmiOSVersion.BuildNumber
	$sku = $((gwmi win32_operatingsystem).OperatingSystemSKU)

if ($bn -match 2200) # Win 11 = 22000
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 11 " | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5006674 -title "October 12, 2021—KB5006674 (OS Build 22000.258)" -Warn "Yes"
}

elseif ($bn -match 20348) # Server 2022 = 20348
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Server 2022 " | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5006699 -title "October 12, 2021—KB5006699 (OS Build 20348.288)" -Warn "Yes"	
}
elseif ($bn -match 1904) # 2004 = 19041, 20H2 = 19042, 21H1 = 19043, 21H2 = 19044
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 20H1 v2004/20H2/21H1/21H2 and Windows Server 2019 20H1/20H2/21H1/21H2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5006670 -title "October 12, 2021—KB5006670 (OS Builds 19041.1288, 19042.1288, and 19043.1288)" -Warn "Yes"
	CheckForHotfix -hotfixID 5005611 -title "September 30, 2021—KB5005611 (OS Builds 19041.1266, 19042.1266, and 19043.1266) Preview"
	CheckForHotfix -hotfixID 5005565 -title "September 14, 2021—KB5005565 (OS Builds 19041.1237, 19042.1237, and 19043.1237)"
	CheckForHotfix -hotfixID 5005033 -title "August 10, 2021—KB5005033 (OS Builds 19041.1165, 19042.1165, and 19043.1165))"
	CheckForHotfix -hotfixID 5004237 -title "July 13, 2021—KB5004237 (OS Builds 19041.1110, 19042.1110, and 19043.1110)"
	CheckForHotfix -hotfixID 5003637 -title "June 8, 2021—KB5003637 (OS Builds 19041.1052, 19042.1052, and 19043.1052)"
	CheckForHotfix -hotfixID 5003173 -title "May 11, 2021—KB5003173 (OS Builds 19041.985 and 19042.985)"
	CheckForHotfix -hotfixID 5001330 -title "April 13, 2021—KB5001330 (OS Builds 19041.928 and 19042.928)"
	CheckForHotfix -hotfixID 5001649 -title "March 18, 2021—KB5001649 (OS Builds 19041.870 and 19042.870) Out-of-band"
	CheckForHotfix -hotfixID 4601319 -title "February 9, 2021-KB4601319 (OS Builds 19041.804 and 19042.804)"
	CheckForHotfix -hotfixID 4598242 -title "January 12, 2021-KB4598242 (OS Builds 19041.746 and 19042.746)"
	CheckForHotfix -hotfixID 4592438 -title "December 8, 2020-KB4592438 (OS Builds 19041.685 and 19042.685)"
	CheckForHotfix -hotfixID 4586781 -title "November 10, 2020-KB4586781 (OS Builds 19041.630 and 19042.630)"
	CheckForHotfix -hotfixID 4579311 -title "October 13, 2020-KB4579311 (OS Build 19041.572)"
	CheckForHotfix -hotfixID 4571756 -title "September 8, 2020—KB4571756 (OS Build 19041.508)"
	CheckForHotfix -hotfixID 4566782 -title "August 11, 2020-KB4566782 (OS Build 19041.450)"
	CheckForHotfix -hotfixID 4565503 -title "July 14, 2020-KB4565503 (OS Build 19041.388)"
	CheckForHotfix -hotfixID 4557957 -title "June 9, 2020-KB4557957 (OS Build 19041.329)"
	CheckForHotfix -hotfixID 4598481 -title "Servicing stack update for Windows 10, version 2004 and 20H2: January 12, 2021"
}
elseif ($bn -match  1836) # 1903 = 18362, 1909 = 18363
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 19H2 v1909 and Windows Server 2019 19H2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5006667 -title "October 12, 2021—KB5006667 (OS Build 18363.1854)" -Warn "Yes"
	CheckForHotfix -hotfixID 5005566 -title "September 14, 2021—KB5005566 (OS Build 18363.1801)"
	CheckForHotfix -hotfixID 5005031 -title "August 10, 2021—KB5005031 (OS Build 18363.1734)"
	CheckForHotfix -hotfixID 5004245 -title "July 13, 2021—KB5004245 (OS Build 18363.1679)"
	CheckForHotfix -hotfixID 5003635 -title "June 8, 2021—KB5003635 (OS Build 18363.1621)"
	CheckForHotfix -hotfixID 5003169 -title "May 11, 2021—KB5003169 (OS Build 18363.1556)"
	CheckForHotfix -hotfixID 5001337 -title "April 13, 2021—KB5001337 (OS Build 18363.1500)"
	CheckForHotfix -hotfixID 5001648 -title "March 18, 2021—KB5001648 (OS Build 18363.1443) Out-of-band"
	CheckForHotfix -hotfixID 4601315 -title "February 9, 2021-KB4601315 (OS Build 18363.1377)"
	CheckForHotfix -hotfixID 4598229 -title "January 12, 2021-KB4598229 (OS Build 18363.1316)"
	CheckForHotfix -hotfixID 4592449 -title "December 8, 2020-KB4592449 (OS Builds 18362.1256 and 18363.1256)"
	CheckForHotfix -hotfixID 4586786 -title "November 10, 2020-KB4586786 (OS Builds 18362.1198 and 18363.1198)"
	CheckForHotfix -hotfixID 4577671 -title "October 13, 2020-KB4577671 (OS Builds 18362.1139 and 18363.1139)"
	CheckForHotfix -hotfixID 4574727 -title "September 8, 2020-KB4574727 (OS Builds 18362.1082 and 18363.1082)"
	CheckForHotfix -hotfixID 4565351 -title "August 11, 2020-KB4565351 (OS Builds 18362.1016 and 18363.1016)"
	CheckForHotfix -hotfixID 4565483 -title "July 14, 2020-KB4565483 (OS Builds 18362.959 and 18363.959)"
	CheckForHotfix -hotfixID 4560960 -title "June 9, 2020-KB4560960 (OS Builds 18362.900 and 18363.900)"
	CheckForHotfix -hotfixID 4556799 -title "May 12, 2020-KB4556799 (OS Builds 18362.836 and 18363.836)" 
	CheckForHotfix -hotfixID 4549951 -title "April 14, 2020-KB4549951 (OS Builds 18362.778 and 18363.778)"
	CheckForHotfix -hotfixID 4540673 -title "March 10, 2020-KB4540673 (OS Builds 18362.719 and 18363.719)"
	CheckForHotfix -hotfixID 4532693 -title "February 11, 2020-KB4532693 (OS Builds 18362.657 and 18363.657)"
	CheckForHotfix -hotfixID 4528760 -title "January 14, 2020-KB4528760 (OS Builds 18362.592 and 18363.592)"
	CheckForHotfix -hotfixID 4530684 -title "December 10, 2019-KB4530684 (OS Builds 18362.535 and 18363.535)"
	CheckForHotfix -hotfixID 4524570 -title "November 12, 2019-KB4524570 (OS Builds 18362.476 and 18363.476)" 
	CheckForHotfix -hotfixID 4517389 -title "October 8, 2019-KB4517389 (OS Build 18362.418)"
	CheckForHotfix -hotfixID 4515384 -title "September 10, 2019-KB4515384 (OS Build 18362.356)"
	CheckForHotfix -hotfixID 4512508 -title "August 13, 2019-KB4512508 (OS Build 18362.295)"
	CheckForHotfix -hotfixID 4507453 -title "July 9, 2019-KB4507453 (OS Build 18362.239)"
	CheckForHotfix -hotfixID 4503293 -title "June 11, 2019-KB4503293 (OS Build 18362.175)"
	CheckForHotfix -hotfixID 4505057 -title "2019-KB4505057 Update for Windows 10, version 1903: May 19, 2019"
	CheckForHotfix -hotfixID 4601395 -title "KB4601395: Servicing stack update for Windows 10, version 1903: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 17763)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS5 v1809 and Windows Server 2019 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5006672 -title "October 12, 2021—KB5006672 (OS Build 17763.2237)" -Warn "Yes"
	CheckForHotfix -hotfixID 5005568 -title "September 14, 2021—KB5005568 (OS Build 17763.2183)"
	CheckForHotfix -hotfixID 5005030 -title "August 10, 2021—KB5005030 (OS Build 17763.2114"
	CheckForHotfix -hotfixID 5004244 -title "July 13, 2021—KB5004244 (OS Build 17763.2061)"
	CheckForHotfix -hotfixID 5003646 -title "June 8, 2021—KB5003646 (OS Build 17763.1999)"
	CheckForHotfix -hotfixID 5003171 -title "May 11, 2021—KB5003171 (OS Build 17763.1935)"
	CheckForHotfix -hotfixID 5001342 -title "April 13, 2021—KB5001342 (OS Build 17763.1879)"
	CheckForHotfix -hotfixID 5001638 -title "March 18, 2021—KB5001638 (OS Build 17763.1823) Out-of-band"
	CheckForHotfix -hotfixID 4601345 -title "February 9, 2021-KB4601345 (OS Build 17763.1757)"
	CheckForHotfix -hotfixID 4598230 -title "January 12, 2021-KB4598230 (OS Build 17763.1697)"
	CheckForHotfix -hotfixID 4592440 -title "December 8, 2020-KB4592440 (OS Build 17763.1637)"
	CheckForHotfix -hotfixID 4586793 -title "November 10, 2020-KB4586793 (OS Build 17763.1577)"
	CheckForHotfix -hotfixID 4577668 -title "October 13, 2020-KB4577668 (OS Build 17763.1518)"
	CheckForHotfix -hotfixID 4570333 -title "September 8, 2020-KB4570333 (OS Build 17763.1457)"
	CheckForHotfix -hotfixID 4565349 -title "August 11, 2020-KB4565349 (OS Build 17763.1397)"
	CheckForHotfix -hotfixID 4558998 -title "July 14, 2020-KB4558998 (OS Build 17763.1339)"
	CheckForHotfix -hotfixID 4561608 -title "June 9, 2020-KB4561608 (OS Build 17763.1282)"
	CheckForHotfix -hotfixID 4551853 -title "May 12, 2020-KB4551853 (OS Build 17763.1217)" 
	CheckForHotfix -hotfixID 4549949 -title "April 14, 2020-KB4549949 (OS Build 17763.1158)"
	CheckForHotfix -hotfixID 4538461 -title "March 10, 2020-KB4538461 (OS Build 17763.1098)"
	CheckForHotfix -hotfixID 4532691 -title "February 11, 2020-KB4532691 (OS Build 17763.1039)"
	CheckForHotfix -hotfixID 4534273 -title "January 14, 2020-KB4534273 (OS Build 17763.973)"
	CheckForHotfix -hotfixID 4530715 -title "December 10, 2019-KB4530715 (OS Build 17763.914)"
	CheckForHotfix -hotfixID 4523205 -title "November 12, 2019-KB4523205 (OS Build 17763.864)" 
	CheckForHotfix -hotfixID 4519338 -title "October 8, 2019-KB4519338 (OS Build 17763.806)"
	CheckForHotfix -hotfixID 4512578 -title "September 10, 2019-KB4512578 (OS Build 17763.737)"
	CheckForHotfix -hotfixID 4511553 -title "August 13, 2019-KB4511553 (OS Build 17763.678)"
	CheckForHotfix -hotfixID 4507469 -title "July 9, 2019-KB4507469 (OS Build 17763.615)"
	CheckForHotfix -hotfixID 4503327 -title "June 11, 2019-KB4503327 (OS Build 17763.557)"
	CheckForHotfix -hotfixID 4505056 -title "May 19, 2019-KB4505056 (OS Build 17763.504)"
	CheckForHotfix -hotfixID 4493509 -title "April 9, 2019-KB4493509 (OS Build 17763.437)"
	CheckForHotfix -hotfixID 4489899 -title "March 12, 2019-KB4489899 (OS Build 17763.379)"
	CheckForHotfix -hotfixID 4487044 -title "February 12, 2019-KB4487044 (OS Build 17763.316)"
	CheckForHotfix -hotfixID 4480116 -title "January 8, 2019-KB4480116 (OS Build 17763.253)"
	CheckForHotfix -hotfixID 4471332 -title "December 11, 2018-KB4471332 (OS Build 17763.194)"
	CheckForHotfix -hotfixID 4601393 -title "KB4601393: Servicing stack update for Windows 10, version 1809: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 14393)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS1 v1607 and Windows Server 2016 RS1 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5006669 -title "October 12, 2021—KB5006669 (OS Build 14393.4704)" -Warn "Yes"
	CheckForHotfix -hotfixID 5005573 -title "September 14, 2021—KB5005573 (OS Build 14393.4651)"
	CheckForHotfix -hotfixID 5005043 -title "August 10, 2021—KB5005043 (OS Build 14393.4583)"
	CheckForHotfix -hotfixID 5004238 -title "July 13, 2021—KB5004238 (OS Build 14393.4530)"
	CheckForHotfix -hotfixID 5003638 -title "June 8, 2021—KB5003638 (OS Build 14393.4467)"
	CheckForHotfix -hotfixID 5003197 -title "May 11, 2021—KB5003197 (OS Build 14393.4402)"
	CheckForHotfix -hotfixID 5001347 -title "April 13, 2021—KB5001347 (OS Build 14393.4350)"
	CheckForHotfix -hotfixID 5001633 -title "March 18 2021—KB5001633 (OS Build 14393.4288) Out-of-band"
	CheckForHotfix -hotfixID 4601318 -title "February 9, 2021-KB4601318 (OS Build 14393.4225)" 
	CheckForHotfix -hotfixID 4598243 -title "January 12, 2021-KB4598243 (OS Build 14393.4169)"
	CheckForHotfix -hotfixID 4593226 -title "December 8, 2020-KB4593226 (OS Build 14393.4104)"
	CheckForHotfix -hotfixID 4586830 -title "November 10, 2020-KB4586830 (OS Build 14393.4046)"
	CheckForHotfix -hotfixID 4580346 -title "October 13, 2020-KB4580346 (OS Build 14393.3986)"
	CheckForHotfix -hotfixID 4577015 -title "September 8, 2020-KB4577015 (OS Build 14393.3930)"
	CheckForHotfix -hotfixID 4571694 -title "August 11, 2020-KB4571694 (OS Build 14393.3866)"
	CheckForHotfix -hotfixID 4565511 -title "July 14, 2020-KB4565511 (OS Build 14393.3808)"
	CheckForHotfix -hotfixID 4561616 -title "June 9, 2020-KB4561616 (OS Build 14393.3750)"
	CheckForHotfix -hotfixID 4556813 -title "May 12, 2020-KB4556813 (OS Build 14393.3686)"
	CheckForHotfix -hotfixID 4550929 -title "April 14, 2020-KB4550929 (OS Build 14393.3630)"
	CheckForHotfix -hotfixID 4540670 -title "March 10, 2020-KB4540670 (OS Build 14393.3564)"
	CheckForHotfix -hotfixID 4537764 -title "February 11, 2020-KB4537764 (OS Build 14393.3504)"
	CheckForHotfix -hotfixID 4534271 -title "January 14, 2020-KB4534271 (OS Build 14393.3443)"
	CheckForHotfix -hotfixID 4530689 -title "December 10, 2019-KB4530689 (OS Build 14393.3384)"
	CheckForHotfix -hotfixID 4525236 -title "November 12, 2019-KB4525236 (OS Build 14393.3326)" 
	CheckForHotfix -hotfixID 4519998 -title "October 8, 2019-KB4519998 (OS Build 14393.3274)"
	CheckForHotfix -hotfixID 4516044 -title "September 10, 2019-KB4516044 (OS Build 14393.3204)"
	CheckForHotfix -hotfixID 4512517 -title "August 13, 2019-KB4512517 (OS Build 14393.3144)"
	CheckForHotfix -hotfixID 4507460 -title "July 9, 2019-KB4507460 (OS Build 14393.3085)"
	CheckForHotfix -hotfixID 4503267 -title "June 11, 2019-KB4503267 (OS Build 14393.3025)"
	CheckForHotfix -hotfixID 4494440 -title "May 14, 2019-KB4494440 (OS Build 14393.2969)"
	CheckForHotfix -hotfixID 4493470 -title "April 9, 2019-KB4493470 (OS Build 14393.2906)"
	CheckForHotfix -hotfixID 4489882 -title "March 12, 2019-KB4489882 (OS Build 14393.2848)"
	CheckForHotfix -hotfixID 4487026 -title "February 12, 2019-KB4487026 (OS Build 14393.2791)"
	CheckForHotfix -hotfixID 4480961 -title "January 8, 2019-KB4480961 (OS Build 14393.2724)"
	CheckForHotfix -hotfixID 4471321 -title "December 11, 2018-KB4471321 (OS Build 14393.2665)"
	CheckForHotfix -hotfixID 4601392 -title "Servicing stack update for Windows 10, version 1607: Februar 9, 2021" -Warn "Yes"
}	
elseif ($bn -eq 10240)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 and Windows Server 2016 RTM Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5006675 -title "October 12, 2021—KB5006675 (OS Build 10240.19086)" -Warn "Yes"
	CheckForHotfix -hotfixID 5005569 -title "September 14, 2021—KB5005569 (OS Build 10240.19060)"
	CheckForHotfix -hotfixID 5005040 -title "August 10, 2021—KB5005040 (OS Build 10240.19022)"
	CheckForHotfix -hotfixID 5004249 -title "July 13, 2021—KB5004249 (OS Build 10240.19003)"
	CheckForHotfix -hotfixID 5003687 -title "June 8, 2021-KB5003687 (OS Build 10240.18967)"
	CheckForHotfix -hotfixID 5003172 -title "May 11, 2021—KB5003172 (OS Build 10240.18932)"
	CheckForHotfix -hotfixID 5001340 -title "April 13, 2021—KB5001340 (OS Build 10240.18906)"
	CheckForHotfix -hotfixID 5001631 -title "March 18, 2021—KB5001631 (OS Build 10240.18875) Out-of-band"
	CheckForHotfix -hotfixID 4601331 -title "February 9, 2021-KB4601331 (OS Build 10240.18842)"
	CheckForHotfix -hotfixID 4598231 -title "January 12, 2021-KB4598231 (OS Build 10240.18818)"
	CheckForHotfix -hotfixID 4592464 -title "December 8, 2020-KB4592464 (OS Build 10240.18782)"
	CheckForHotfix -hotfixID 4586787 -title "November 10, 2020-KB4586787 (OS Build 10240.18756)"
	CheckForHotfix -hotfixID 4580327 -title "October 13, 2020-KB4580327 (OS Build 10240.18725)"
	CheckForHotfix -hotfixID 4577049 -title "September 8, 2020-KB4577049 (OS Build 10240.18696)"
	CheckForHotfix -hotfixID 4571692 -title "August 11, 2020-KB4571692 (OS Build 10240.18666)"
	CheckForHotfix -hotfixID 4565513 -title "July 14, 2020-KB4565513 (OS Build 10240.18638)"
	CheckForHotfix -hotfixID 4561649 -title "June 9, 2020-KB4561649 (OS Build 10240.18608)"
	CheckForHotfix -hotfixID 4556826 -title "May 12, 2020-KB4556826 (OS Build 10240.18575)"
	CheckForHotfix -hotfixID 4550930 -title "April 14, 2020-KB4550930 (OS Build 10240.18545)"
	CheckForHotfix -hotfixID 4540693 -title "March 10, 2020-KB4540693 (OS Build 10240.18519)"
	CheckForHotfix -hotfixID 4537776 -title "February 11, 2020-KB4537776 (OS Build 10240.18486)"
	CheckForHotfix -hotfixID 4534306 -title "January 14, 2020-KB4534306 (OS Build 10240.18453)"
	CheckForHotfix -hotfixID 4530681 -title "December 10, 2019-KB4530681 (OS Build 10240.18427)"
	CheckForHotfix -hotfixID 4525232 -title "November 12, 2019-KB4525232 (OS Build 10240.18395)" 
	CheckForHotfix -hotfixID 4520011 -title "October 8, 2019-KB4520011 (OS Build 10240.18368)"
	CheckForHotfix -hotfixID 4516070 -title "September 10, 2019-KB4516070 (OS Build 10240.18333)"
	CheckForHotfix -hotfixID 4512497 -title "August 13, 2019-KB4512497 (OS Build 10240.18305)"
	CheckForHotfix -hotfixID 4507458 -title "July 9, 2019-KB4507458 (OS Build 10240.18275)"
	CheckForHotfix -hotfixID 4503291 -title "June 11, 2019-KB4503291 (OS Build 10240.18244)"
	CheckForHotfix -hotfixID 4499154 -title "May 14, 2019-KB4499154 (OS Build 10240.18215)"
	CheckForHotfix -hotfixID 4493475 -title "April 9, 2019-KB4493475 (OS Build 10240.18186)"
	CheckForHotfix -hotfixID 4489872 -title "March 12, 2019-KB4489872 (OS Build 10240.18158)"
	CheckForHotfix -hotfixID 4487018 -title "February 12, 2019-KB4487018 (OS Build 10240.18132)"
	CheckForHotfix -hotfixID 4480962 -title "January 8, 2019-KB4480962 (OS Build 10240.18094)"
	CheckForHotfix -hotfixID 4471323 -title "December 11, 2018-KB4471323 (OS Build 10240.18063)"
	CheckForHotfix -hotfixID 4601390 -title "KB4601390: Servicing stack update for Windows 10: February 9, 2021" -Warn "Yes"
}
elseif ($bn -eq 9600)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 8.1 and Windows Server 2012 R2 Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5006714 -title "October 12, 2021—KB5006714 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5005613 -title "September 14, 2021—KB5005613 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005076 -title "August 10, 2021—KB5005076 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5004298 -title "July 13, 2021—KB5004298 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003671 -title "June 8, 2021—KB5003671 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003209 -title "May 11, 2021—KB5003209 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001382 -title "April 13, 2021—KB5001382 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000848 -title "March 9, 2021-KB5000848 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601384 -title "February 9, 2021-KB4601384 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598285 -title "January 12, 2021-KB4598285 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592484 -title "December 8, 2020-KB4592484 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4586845 -title "November 10, 2020-KB4586845 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4580347 -title "October 13, 2020-KB4580347 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4577066 -title "September 8, 2020-KB4577066 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4571703 -title "August 11, 2020-KB4571703 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4565541 -title "July 14, 2020-KB4565541 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4561666 -title "June 9, 2020-KB4561666 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4556846 -title "May 12, 2020-KB4556846 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4550961 -title "April 14, 2020-KB4550961 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4566425 -title "Servicing stack update for Windows 8.1, RT 8.1, and Server 2012 R2: July 14, 2020" -Warn "Yes"
	CheckForHotfix -hotfixID 4541509 -title "March 10, 2020-KB4541509 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4537821 -title "February 11, 2020-KB4537821 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4534297 -title "January 14, 2020-KB4534297 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4530702 -title "December 10, 2019-KB4530702 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4525243 -title "November 12, 2019-KB4525243 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 4520005 -title "October 8, 2019-KB4520005 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4516067 -title "September 10, 2019-KB4516067 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4512488 -title "August 13, 2019-KB4512488 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4507448 -title "July 9, 2019-KB4507448 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503276 -title "June 11, 2019-KB4503276 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499151 -title "May 14, 2019-KB4499151 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493446 -title "April 9, 2019-KB4493446 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489881 -title "March 12, 2019-KB4489881 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487000 -title "February 12, 2019-KB4487000 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480963 -title "January 8, 2019-KB4480963 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471320 -title "December 11, 2018-KB4471320 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3123245 -title "Update improves port exhaustion identification in Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3179574 -title "August 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3172614 -title "July 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3013769 -title "December 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3000850 -title "November 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 2919355 -title "[Windows 8.1 Update 1] Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2 Update: April 2014"
	CheckForHotfix -hotfixID 2883200 -title "Windows 8.1 and Windows Server 2012 R2 General Availability Update Rollup"
}
elseif ($bn -eq 9200)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Server 2012 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append
	
	CheckForHotfix -hotfixID 5006739 -title "October 12, 2021—KB5006739 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5005623 -title "September 14, 2021—KB5005623 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005099 -title "August 10, 2021—KB5005099 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5004294 -title "July 13, 2021—KB5004294 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003697 -title "June 8, 2021—KB5003697 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003208 -title "May 11, 2021—KB5003208 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001387 -title "April 13, 2021—KB5001387 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000847 -title "March 9, 2021-KB5000847 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601348 -title "February 9, 2021-KB4601348 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598278 -title "January 12, 2021-KB4598278 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592468 -title "December 8, 2020-KB4592468 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4586834 -title "November 10, 2020-KB4586834 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4580382 -title "October 13, 2020-KB4580382 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4577038 -title "September 8, 2020-KB4577038 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4571736 -title "August 11, 2020-KB4571736 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4565537 -title "July 14, 2020-KB4565537 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4561612 -title "June 9, 2020-KB4561612 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4556840 -title "May 12, 2020-KB4556840 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4550917 -title "April 14, 2020-KB4550917 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4566426 -title "Servicing stack update for Windows Server 2012: July 14, 2020" -Warn "Yes"
	CheckForHotfix -hotfixID 4541510 -title "March 10, 2020-KB4541510 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4537814 -title "February 11, 2020-KB4537814 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4534283 -title "January 14, 2020-KB4534283 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4530691 -title "December 10, 2019-KB4530691 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4525246 -title "November 12, 2019-KB4525246 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 4520007 -title "October 8, 2019-KB4520007 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4516055 -title "September 10, 2019-KB4516055 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4512518 -title "August 13, 2019-KB4512518 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4507462 -title "July 9, 2019-KB4507462 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503285 -title "June 11, 2019-KB4503285 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499171 -title "May 14, 2019-KB4499171 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493451 -title "April 9, 2019-KB4493451 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489891 -title "March 12, 2019-KB4489891 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487025 -title "February 12, 2019-KB4487025 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480975 -title "January 8, 2019-KB4480975 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471330 -title "December 11, 2018-KB4471330 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3179575 -title "August 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3172615 -title "July 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3161609 -title "June 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3156416 -title "May 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3013767 -title "December 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 3000853 -title "November 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2995388 -title "October 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012 "
	CheckForHotfix -hotfixID 2984005 -title "September 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2975331 -title "August 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2967916 -title "July 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012" 
	CheckForHotfix -hotfixID 2962407 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2014" 
	CheckForHotfix -hotfixID 2955163 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: May 2014"
	CheckForHotfix -hotfixID 2934016 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: April 2014" 	
	CheckForHotfix -hotfixID 2928678 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: March 2014" 	
	CheckForHotfix -hotfixID 2919393 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: February 2014"
	CheckForHotfix -hotfixID 2911101 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: January 2014"
	CheckForHotfix -hotfixID 2903938 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: December 2013"
	CheckForHotfix -hotfixID 2889784 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: November 2013"
	CheckForHotfix -hotfixID 2883201 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: October 2013"
	CheckForHotfix -hotfixID 2876415 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: September 2013"
	CheckForHotfix -hotfixID 2862768 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: August 2013"	
	CheckForHotfix -hotfixID 2855336 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: July 2013"	
	CheckForHotfix -hotfixID 2845533 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2013"	
	CheckForHotfix -hotfixID 2836988 -title "Windows 8 and Windows Server 2012 Update Rollup: May 2013" 				
	CheckForHotfix -hotfixID 2822241 -title "Windows 8 and Windows Server 2012 Update Rollup: April 2013"				
	CheckForHotfix -hotfixID 2811660 -title "Windows 8 and Windows Server 2012 Update Rollup: March 2013"				
	CheckForHotfix -hotfixID 2795944 -title "Windows 8 and Windows Server 2012 Update Rollup: February 2013"			
	CheckForHotfix -hotfixID 2785094 -title "Windows 8 and Windows Server 2012 Update Rollup: January 2013"				
	CheckForHotfix -hotfixID 2779768 -title "Windows 8 and Windows Server 2012 Update Rollup: December 2012"			
	CheckForHotfix -hotfixID 2770917 -title "Windows 8 and Windows Server 2012 Update Rollup: November 2012"			
	CheckForHotfix -hotfixID 2756872 -title "Windows 8 Client and Windows Server 2012 General Availability Update Rollup"
}
elseif ($bn -eq 7601)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 7 and Windows Server 2008 R2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=7600, SP1=7601)" | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5006743 -title "October 12, 2021—KB5006743 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5005633 -title "September 14, 2021—KB5005633 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005088 -title "August 10, 2021—KB5005088 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5004289 -title "July 13, 2021—KB5004289 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003667 -title "June 8, 2021—KB5003667 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003233 -title "May 11, 2021—KB5003233 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001335 -title "April 13, 2021—KB5001335 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000841 -title "March 9, 2021—KB5000841 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601347 -title "February 9, 2021-KB4601347 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598279 -title "January 12, 2021-KB4598279 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592471 -title "December 8, 2020-KB4592471 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4586827 -title "November 10, 2020-KB4586827 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4580345 -title "October 13, 2020-KB4580345 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4577051 -title "September 8, 2020-KB4577051 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4571729 -title "August 11, 2020-KB4571729 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4565524 -title "July 14, 2020-KB4565524 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4561643 -title "June 9, 2020-KB4561643 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4556836 -title "May 12, 2020-KB4556836 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 4550964 -title "April 14, 2020-KB4550964 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4540688 -title "March 10, 2020-KB4540688 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4537820 -title "February 11, 2020-KB4537820 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4534310 -title "January 14, 2020-KB4534310 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4530734 -title "December 10, 2019-KB4530734 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4525235 -title "November 12, 2019-KB4525235 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 4519976 -title "October 8, 2019-KB4519976 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4516065 -title "September 10, 2019-KB4516065 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4512506 -title "August 13, 2019-KB4512506 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4507449 -title "July 9, 2019-KB4507449 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503292 -title "June 11, 2019-KB4503292 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499164 -title "May 14, 2019-KB4499164 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493472 -title "April 9, 2019-KB4493472 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489878 -title "March 12, 2019-KB4489878 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4486563 -title "February 12, 2019-KB4486563 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480970 -title "January 8, 2019-KB4480970 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471318 -title "December 11, 2018-KB4471318 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3125574 -title "Convenience roll-up update for Windows 7 SP1 and Windows Server 2008 R2 SP1" -Warn "Yes"
	CheckForHotfix -hotfixID 4490628 -title "Servicing stack update for Windows 7 SP1 and Windows Server 2008 R2 SP1: March 12, 2019"
	CheckForHotfix -hotfixID 4580970 -title "Servicing stack update for Windows 7 SP1 and Server 2008 R2 SP1: October 13, 2020" -Warn "Yes"
	CheckForHotfix -hotfixID 4538483 -title "Extended Security Updates (ESU) Licensing Preparation Package for Windows 7 SP1 and Windows Server 2008 R2 SP1"
	CheckForHotfix -hotfixID 2775511 -title "An enterprise hotfix rollup is available for Windows 7 SP1 and Windows Server 2008 R2 SP1"
}
elseif ($bn -eq 6002)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Vista and Windows Server 2008 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=6000, SP2=6002)" | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5006736 -title "October 12, 2021—KB5006736 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5005606 -title "September 14, 2021—KB5005606 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5005090 -title "August 10, 2021—KB5005090 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 5004305 -title "July 13, 2021—KB5004305 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003661 -title "June 8, 2021—KB5003661 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5003210 -title "May 11, 2021—KB5003210 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5001389 -title "April 13, 2021—KB5001389 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5000844 -title "March 9, 2021—KB5000844 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4601360 -title "February 9, 2021-KB4601360 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4598288 -title "January 12, 2021-KB4598288 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592498 -title "December 8, 2020-KB4592498 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4586807 -title "November 10, 2020-KB4586807 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4580378 -title "October 13, 2020-KB4580378 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4577064 -title "September 8, 2020-KB4577064 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4571730 -title "August 11, 2020-KB4571730 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4565536 -title "July 14, 2020-KB4565536 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4561670 -title "June 9, 2020-KB4561670 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4556860 -title "May 12, 2020-KB4556860 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4550951 -title "April 14, 2020-KB4550951 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4541506 -title "March 10, 2020-KB4541506 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4537810 -title "February 11, 2020-KB4537810 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4534303 -title "January 14, 2020-KB4534303 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4530695 -title "December 10, 2019-KB4530695 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4525234 -title "November 12, 2019-KB4525234 (Monthly Rollup)" 
	CheckForHotfix -hotfixID 4520002 -title "October 8, 2019-KB4520002 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4516026 -title "September 10, 2019-KB4516026 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4512476 -title "August 13, 2019-KB4512476 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4507452 -title "July 9, 2019-KB4507452 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503273 -title "June 11, 2019-KB4503273 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499149 -title "May 14, 2019-KB4499149 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493471 -title "April 9, 2019-KB4493471 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489880 -title "March 12, 2019-KB4489880 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487023 -title "February 12, 2019-KB4487023 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480968 -title "January 8, 2019-KB4480968 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471325 -title "December 11, 2018-KB4471325 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4517134 -title "Servicing stack update for Windows Server 2008 SP2: September 10, 2019"
	CheckForHotfix -hotfixID 4572374 -title "Servicing stack update for Windows Server 2008 SP2: August 11, 2020" -Warn "Yes"
}

	CollectFiles -filesToCollect $OutputFile -fileDescription "Hotfix Rollups" -SectionDescription $sectionDescription


# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA8YAcr/9J8VncW
# H65KL8EeCrH+w6AxXueAJdVQHsY//aCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg4wCNZgol
# VZ4gkdDJa86/whlmS4YCyAPpxZoywEb11NwwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAECLy94wInqrsX2oQN0vfEqkxTnYxxFsCv52RlPYOg9sI+CU/tKrcXyF
# soCb9AQUWRui0WOtgioPhKgnHgNXSj+oSHtoj4/rUBItKx7jbNuyK6PXAKE1RHz/
# gUbUJ9joOXab/u4oG7f6is92hoAcGPwAYCtfP3WXaGN0cpeZYjr0iWE8vd1+rQdj
# A8Ee8lZ9JqjKh8F0X/mctGWYwQEhrkdBv7akKjxB/Ml+n3mbKaumq7PLIx722xhV
# 8ogv8EBsGsW0LbYZTMQy9Juty/sUuhqbU/tGS4OJx5/4pqDIjAEkCIyNcKyzXyUU
# 5QJ/NA7w/rYTE4kpPuOzzju8KzrRvYGhghL7MIIS9wYKKwYBBAGCNwMDATGCEucw
# ghLjBgkqhkiG9w0BBwKgghLUMIIS0AIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgz86QD64+svjAm16kEQ20GN55FMg/Kz7rsyElUT01rGkCBmFIuTTs
# pRgTMjAyMTEwMTMwMTE1NTUuODU5WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDkowggT5MIID4aADAgECAhMzAAABPIv9ubM/R5f9AAAAAAE8MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyM1oXDTIyMDExMjE3MjgyM1owgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MTc5RS00
# QkIwLTgyNDYxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCYECrpaQOq9jkOBpC345fQ
# 0IvOpRqK8nEe+jopJc/5XNNqzanq5hrd9wib4RdvpuPj68n5Dm/XZu2vCqnWoxhy
# 3ixrbgS/rg3CS3bqp8Ag1UQg/xAz32TueeTOY1cOelcXRahosIcjlrrkv13AacFX
# m4AbYMCgYM6BzdZKARebc6zEv+4QCy4+1AV8RHQHEOdoj42OJpbFWlHvYKzXuM1A
# H4vmjT9o/fCq2mWD7Ig2/CpaId2gHK6R+S909iK27uVkjVap2/Sb4ATOLJbaVQ+X
# 0+hYbEcCesf93g+tAQXuvA8dH63doK5I5zdZCF5U/3Dibfl7ZCFsU6ks+ph4jJrb
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQU4aFn4soS+jazYT8lGOoYvyZnPEYwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAMvcQjJTdl3luSMzFqRkxRklJ+KWRUUlB
# 3I2KJVWb4Gn6eWdJTiWdC1uxejF2oPX0b+X9QIhi8u1AaV792eEit2lQzqVgPify
# TZGLjzK2Oou4Pj/F58Pp2m6HupGfuNAehln+hSvvIE5ggEnCiv9lVkAJOMlLHF38
# DbPv7pyWs0Lzv2sjZwPHvdhtV8lBtOYsE8Nxznlbsyc80vRnReqm8JQK6Z8xAD4S
# eY8duFFXhciETG2E0bh+/N3mwGnzXJzMbSKAKkzIw6Yxqf+zHzWPFim9DGZwmchq
# +6JBKtb4EGT0EFtfqGCrOPD5O7uPwSdj1apgXqo7Hctx7hcs5qjpwjCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtQwggI9AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAHUt0elneaPLba16Ke63RR3B65OaggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAOUQN+owIhgPMjAyMTEwMTMwMDM1NTRaGA8yMDIxMTAxNDAwMzU1NFowdDA6
# BgorBgEEAYRZCgQBMSwwKjAKAgUA5RA36gIBADAHAgEAAgIETTAHAgEAAgIROzAK
# AgUA5RGJagIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAId3nYjBcSGpqxwy
# CV05eJGilxsi1HZilUyQ6eOhYbrsL8ocROJDBmhJ9ZXHIkQHiUzcBpWPjwf/NFXj
# zldt6Hs3pk0ncsF8FLNT19ntVyc+2BhPjvCnuxxWoUulSXg2VFxTV/2oXXDHB6tK
# ag7JarfPXaH4CVWJ9AM3cGaxlS64MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAE8i/25sz9Hl/0AAAAAATwwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQg0mkLNj8sqWblxpKEetI4XgJKuliNrArj5qHJ2sdrt/EwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCCgSQK6TSS/wOc6qbfUfBGv7YhsPfGYhbgVIYrh
# JuhaRjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# PIv9ubM/R5f9AAAAAAE8MCIEICrC4eM1wE3iJcLJjLi1+LyYwr41fGHo85j2EwbX
# YNwiMA0GCSqGSIb3DQEBCwUABIIBACqGt1hGXXyMXpPnHvpLRO8vWDie+ntboKnF
# kJI74hg+Q7XPM6VbcDIgeG4Kme8bT36VHcLNS2VENPUS/wnjjApMawsXsf3EgARz
# 9NbwDqDJnhbD0vklvtpqtSRhGEISwWo2FtI0SKGJrROpfH2uMdBOrdrquf64T9XO
# ZbJarfukq8Y431NtTKoJAGou8+X7Cp7pVxPL3tdbj4BPCL6ZAghCtixJ2e1dngL3
# rZPah5echyXJ8b6JTSRz2PJr7kPoG5g2mGGCC8sur8qJo58KjrQQRP8SbqH4W1eo
# nKr1gn1idGYvCHVWMtYrdYs5rde5pUtYry8JEiE8xY54urP1BGM=
# SIG # End signature block
