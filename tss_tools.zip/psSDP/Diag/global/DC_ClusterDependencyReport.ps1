﻿#************************************************
# DC_ClusterDependencyReport.ps1
# Version 1.0.1
# Date: 07-23-2009
# Author: Andre Teixeira - andret@microsoft.com
# Description: This script is used to obtain cluster resource dependency report
#************************************************

Import-LocalizedData -BindingVariable ClusterLogsStrings

if (($OSVersion.Build -ge 7600) -and (Test-Path "HKLM:\Cluster"))
{
	Write-DiagProgress -activity $ClusterLogsStrings.ID_ClusterDependencyReport -status $ClusterLogsStrings.ID_ClusterDependencyReportDesc1

	$ClusterSvc = Get-Service -Name ClusSvc

	if ($ClusterSvc.Status.value__ -eq 4) 
	{ #Service is running

		Import-Module FailoverClusters

		$ClusterGroups = Get-ClusterGroup | Where-Object {$_.IsCoreGroup -eq $false}
		
		if ($ClusterGroups -ne $null)
		{
			if ($ClusterGroups.Length -le 50)
			{
				ForEach ($ClusterGroup in $ClusterGroups) 
				{
					
					$GroupName = $ClusterGroup.Name
					$sectionDescription = "Resource Dependency Reports"
					Write-DiagProgress -activity $ClusterLogsStrings.ID_ClusterDependencyReport -status ($ClusterLogsStrings.ID_ClusterDependencyReportDesc -replace("%GroupName%", $GroupName))
					
					$fileDescription = $GroupName + " report"
					$outputfileName = $ComputerName + "_" + $GroupName + "_DependencyReport.mht.htm"
					
					Get-ClusterResourceDependencyReport -Group $GroupName | Move-Item -Destination $outputfileName
					
					CollectFiles -filesToCollect $outputfileName -fileDescription $fileDescription -sectionDescription $sectionDescription
				}
			}
			else
			{
				"A large number of cluster groups are present on this system.  Dependency reports will not be collected." | WriteTo-StdOut -ShortFormat
			}
		}
		else
		{
			"No cluster groups were identified" | WriteTo-StdOut -ShortFormat
		}
	}
}
else
{
	if (Test-Path "HKLM:\Cluster")
	{
		"Cluster dependency report not supported on this OS Version" | WriteTo-StdOut -ShortFormat
	}
	else
	{
		"Machine is not a cluster node" | WriteTo-StdOut -ShortFormat
	}
}
