﻿###########################################################################
# DC_Query_Registry
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Queries the registry and exports the services hive
###########################################################################

#$SystemRoot = $Env:SystemRoot

Import-LocalizedData -BindingVariable Reg -FileName DC_Query_Registry -UICulture en-us
Write-DiagProgress -Activity $Reg.ID_Reg  -Status $Reg.ID_RegQuery
"Start collecting registry data" | WriteTo-StdOut 

function query_registry ($key)
	{
		$CommandLineToExecute = "cmd.exe /c reg.exe query $key >> $OutputFile"
		$Header = "Querying Registry: " + $key + ":"
		$Header | Out-File $OutputFile -Append
		$Header | WriteTo-StdOut 
		RunCMD -commandToRun $CommandLineToExecute
	}


#Querying Registry: HKLM\Software\Microsoft\Windows\CurrentVersion\Policies
$OutputFile = $Computername + "_HKLM_Policies.txt"
$key = "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies /s"
query_registry $key 

#Querying Registry: HKLM\Software\Policies
$Key = "HKLM\Software\Policies /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Policies Key" -sectionDescription "Registry Data"

#########################################################################
#Querying Registry: HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer 
$OutputFile = $Computername + "_HKEY_Internet_Explorer.txt"
$Key = "`"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer`" /s"
query_registry $key 

#Querying Registry: HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer 
$Key = "`"HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer`" /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Internet Explorer Key" -sectionDescription "Internet Explorer"

#########################################################################
#Querying Registry: HKCU\Software\Policies
$OutputFile = $Computername + "_HKCU_Policies.txt"
$Key = "`"HKCU\Software\Policies`" /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "HKCU\Software\Policies Key" -sectionDescription "System Information"

#########################################################################
#Querying Registry: HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings 
$OutputFile = $Computername + "_HKEY_Internet_Settings.txt"
$Key = "`"HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings`" /s"
query_registry $key 


#Internet Settings from the Local Machine profile: Used by localSystem 
#Querying Registry: HKLM\Software\Microsoft\Windows\CurrentVersion\Internet Settings 
$Key =  "`"HKLM\Software\Microsoft\Windows\CurrentVersion\Internet Settings`" /s"
query_registry $key 

#Internet Settings from the .Default profile: Used by localSystem 
#Querying Registry: HKU\.DEFAULT\Software\Microsoft\Windows\CurrentVersion\Internet Settings 
$Key = "`"HKU\.DEFAULT\Software\Microsoft\Windows\CurrentVersion\Internet Settings`" /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Internet Settings Key" -sectionDescription "Internet Explorer"


#########################################################################
#Querying Registry: HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing 
$OutputFile = $Computername + "_HKLM_CBS.txt"
$Key = "`"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing`" /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "CBS Key" -sectionDescription "CBS Information"

#########################################################################
#Querying Registry: HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer
$OutputFile = $Computername + "_HKLM_Installer.txt"
$key = "`"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer`" /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Installer Key" -sectionDescription "Registry Data"

#########################################################################
#Querying Registry: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\MUI\UILanguages 
$OutputFile = $Computername + "_HKLM_MUILanguagePack.txt"
$key = "HKLM\SYSTEM\CurrentControlSet\Control\MUI\UILanguages /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "UI Languages Key" -sectionDescription "Registry Data"

#########################################################################
#Querying Registry: HKLM\Software\Microsoft\OLE 
$OutputFile = $Computername + "_HKLM_OLE.txt"
$Key = "HKLM\Software\Microsoft\OLE /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "OLE Key" -sectionDescription "Registry Data"

#########################################################################
#Querying Registry: HKLM\Software\Microsoft\Windows\CurrentVersion\Setup
$OutputFile = $Computername + "_HKLM_Setup.txt"
$Key = "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Setup Key" -sectionDescription "Registry Data"

#########################################################################
#Querying Registry: HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall 
$OutputFile = $Computername + "_HKLM_Uninstall.txt"
$key = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Uninstall Key" -sectionDescription "Registry Data"

#########################################################################
#Querying Registry: HKLM\SOFTWARE\Microsoft\Updates 
$OutputFile = $Computername + "_HKLM_Updates.txt"
$key = "HKLM\SOFTWARE\Microsoft\Updates /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Updates Key" -sectionDescription "Registry Data"

#########################################################################
#Querying Registry: HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon
$OutputFile = $Computername + "_HKLM_Winlogon.txt"
$key = "`"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon`" /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Winlogon Key" -sectionDescription "Registry Data"

#########################################################################
#Querying Registry: HKLM\Software\Microsoft\Windows\CurrentVersion\WindowsUpdate 
$OutputFile = $Computername + "_HKLM_WindowsUpdate_Client.txt"
$key = "HKLM\Software\Microsoft\Windows\CurrentVersion\WindowsUpdate /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Windows Updates Client Key" -sectionDescription "Windows Update Information"

#########################################################################
#Querying Registry: HKLM\SOFTWARE\Policies\Microsoft\windows\WindowsUpdate 
$OutputFile = $Computername + "_HKEY_WindowsUpdate_Policies.txt"
$Key = "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate /s"
query_registry $key 

$key = "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\WindowsUpdate /s"
query_registry $key 

$Key = "HKEY_USERS\.DEFAULT\Software\Microsoft\Windows\CurrentVersion\Policies\WindowsUpdate"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Windows Updates Policies Key" -sectionDescription "Windows Update Information"

#########################################################################
#Gathering PID and Registration information
$OutputFile = $ComputerName + "_PID.txt"
$key = "`"HKLM\SOFTWARE\Microsoft\Internet Explorer\Registration`" /s"
query_registry $key 
$key = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion /v ProductID"
query_registry $key 
$key = "`"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion`" /v ProductID"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "PID Keys" -sectionDescription "Registry Data"

#########################################################################
#Gathering WU Service Information
$OutputFile = $ComputerName + "_svcRegistration.txt"
$key = "`"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SvcHost`" /s"
query_registry $key 
$key = "HKLM\SYSTEM\CurrentControlSet\Services\BITS /s"
query_registry $key 
$key = "HKLM\SYSTEM\CurrentControlSet\Services\wuauserv /s"
CollectFiles -filesToCollect $OutputFile -fileDescription "Service Registration" -sectionDescription "Windows Update Information"

#########################################################################
#Query Registry for hotfix information
#First check for hidden files in the Windows folder
If ($OS.Version -lt 6)
{
	$OutputFile = $ComputerName + "_Hotfix.txt"
	Set-Content $OutputFile "Hidden Files in Windows Folder `n" -Encoding ascii
	Get-ChildItem $windir -force | Where-Object {$_.mode -match "h"} | Out-File $OutputFile -Append 
	$Blocks = "===[Old Hotfix regkey]============================================================ `n"
	Add-Content $OutputFile $Blocks 
	$key = "HKLM\Software\Microsoft\Hotfix /s"
	query_registry $key 
	$Blocks = "===[Hotfix regkey]================================================================ `n"
	Add-Content $OutputFile $Blocks
	$key = "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Hotfix /s"
	CollectFiles -filesToCollect $OutputFile -fileDescription "Hotfix Keys" -sectionDescription "Registry Data"
}

#########################################################################
#Collect Session Manager Key
$OutputFile = $ComputerName + "_SessionManager_Key.txt"
Set-Content $OutputFile "Querying Registry: HKLM\SYSTEM\CurrentControlSet\Control\Session Manager " -Encoding unknown
$key = "`"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager`""
query_registry $key 

add-content -Encoding unknown $OutputFile "`n`nQuerying Registry: HKLM\COMPONENTS Key "
Add-Content -Encoding unknown $OutputFile "For Pending restart issues look for existence of: `
RegValue: PendingXmlIdentifier`
RegValue: NextQueueEntryIndex`
RegValue: AdvancedInstallersNeedResolving`
RegValue: ImpactfulTransactionCommitsDisabled`
Filename: C:Windows\winsxs\pending.xml`
======================================================================== `n "
$CommandLineToExecute = "cmd.exe /c reg.exe query HKLM\COMPONENTS >> $OutputFile"
RunCMD commandToRun $CommandLineToExecute 

CollectFiles -filesToCollect $OutputFile -fileDescription "Session Manager Key" -sectionDescription "Registry Data"

#########################################################################
#Gathering CSDVersion
$OutputFile = $ComputerName + "_CSDVersion.txt"
$key = "HKLM\SYSTEM\CurrentControlSet\Control\Windows\CSDVersion"
query_registry $key 

$key = "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\CSDVersion"
query_registry $key 

$key = "`"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion`""
query_registry $key 

CollectFiles -filesToCollect $OutputFile -fileDescription "CSD Version" -sectionDescription "Registry Data"

#########################################################################
#Collect Services hive and txt

$OutputFile = $ComputerName + "_Services_Key.txt"
$key = "HKLM\SYSTEM\CurrentControlSet\Services /s"
query_registry $key 
CollectFiles -filesToCollect $OutputFile -fileDescription "Services Key" -sectionDescription "System Information"

Write-DiagProgress -Activity $Reg.ID_Reg  -Status $Reg.ID_RegHiv

$OutputFile = $ComputerName + "_Services_Key.hiv"
$CommandLineToExecute = "cmd.exe /c reg.exe save HKLM\SYSTEM\CurrentControlSet\Services $OutputFile"
RunCMD -commandToRun $CommandLineToExecute 
CollectFiles -filesToCollect $OutputFile -fileDescription "Services Hive" -sectionDescription "System Information"

"Finished collecting registry data" | WriteTo-StdOut 