﻿#************************************************ 
# DC_UserLogonInfo.ps1 
# Version 1.0 
# Date: 2/18/2014 
# Author: Tim Springston [MS] 
# Description:  This script queries for the user and computer domain
#  and returns details.
#************************************************ 
Import-LocalizedData -BindingVariable ADInfoStrings
Write-DiagProgress -Activity $AdInfoStrings.ID_ADInfo_Status -Status   $AdInfoStrings.ID_ADInfo_Wait
#| WriteTo-StdOut -shortformat

Trap [Exception]
		{
		 #Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 WriteTo-StdOut "[info]:An exception occurred." -shortformat
		 WriteTo-StdOut "[info]: Exception.Message $ExceptionMessage."
		 WriteTo-ErrorDebugReport -ErrorRecord $_
		 $Error.Clear()
		 continue
		}

#Define output file.
$FileDescription = "Text File containing details about the currently logged on user."
$SectionDescription = "Active Directory User Logon Info (TXT)"
$ExportFile = Join-Path $Pwd.Path ($ComputerName + "_UserLogonInfo.txt")
$global:FormatEnumerationLimit = -1


#Determine OS and computer role
$OS = Get-WmiObject -Class Win32_OperatingSystem
$cs =  gwmi -Namespace "root\cimv2" -class win32_computersystem
$DomainRole = $cs.domainrole
$LogonServer = $env:Logonserver
$LogonServer = $LogonServer.replace("`\","")
$ComputerName = $cs.name
if ($LogonServer -match $ComputerName)
	{$LoggedOnLocally = $true}
	else
	{$LoggedOnLocally = $false}

switch -regex ($DomainRole) {
	[0-1]{
		 #Workstation.
		$RoleString = "Client"
		if ($OS.BuildNumber -eq 3790)									
		{$OSString = "Windows XP"}
			elseif (($OS.BuildNumber -eq 6001) -or ($OS.BuildNumber -eq 6002))
				{$OSString = "Windows Vista"}
					elseif (($OS.BuildNumber -eq 7600) -or ($OS.BuildNumber -eq 7601))
							{$OSString = "Windows 7" }
						elseif  ($OS.BuildNumber -eq 9200)
							{$OSString =  "Windows 8"}
							elseif ($OS.BuildNumber -eq 9600)
								{$OSString =  "Windows 8.1"}
		}
	[2-3]{
		 #Member server.
		 $RoleString = "Member Server"
		 if ($OS.BuildNumber -eq 3790)
	 		{$OSString =  "Windows Server 2003"}
			elseif (($OS.BuildNumber -eq 6001) -or ($OS.BuildNumber -eq 6002))
				{$OSString =  "Windows Server 2008 RTM"}
				elseif (($OS.BuildNumber -eq 7600) -or ($OS.BuildNumber -eq 7601))
					{$OSString =  "Windows Server 2008 R2"}
					elseif ($OS.BuildNumber -eq 9200)
						{$OSString = "Windows Server 2012"}
								elseif ($OS.BuildNumber -eq 9600)
									{$OSString = "Windows Server 2012 R2"}
		 }
	[4-5]{
		 #Domain Controller
		 $RoleString = "Domain Controller"
		 if ($OS.BuildNumber -eq 3790)
	 		{$OSString =  "Windows Server 2003"}
			elseif (($OS.BuildNumber -eq 6001) -or ($OS.BuildNumber -eq 6002))
				{$OSString =  "Windows Server 2008 RTM"}
				elseif (($OS.BuildNumber -eq 7600) -or ($OS.BuildNumber -eq 7601))
					{$OSString =  "Windows Server 2008 R2"}
					elseif ($OS.BuildNumber -eq 9200)
						{$OSString = "Windows Server 2012"}
							elseif ($OS.BuildNumber -eq 9600)
									{$OSString = "Windows Server 2012 R2"}
		 }
	}

#Next, get useraccountcontrol value of the user object.
$user = $env:username
function GetUACAttr
{
	param ([string]$username)

	$ForestInfo = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
	$RootString = "GC://" + $ForestInfo.Name
	$Root = New-Object  System.DirectoryServices.DirectoryEntry($RootString)
	$searcher = New-Object DirectoryServices.DirectorySearcher($Root)
	$searcher.Filter="(&(samaccountname=$username))"
	$results=$searcher.findone()
	if ($results -ne $null)
		{
		$UAC = $results.properties.useraccountcontrol[0]
		return $UAC
		}
}



#Function from Fabian Muller to translate value to flags.
Function Set-UserAccountControlValueTable 
{ 
    # see http://support.microsoft.com/kb/305144/en-us 
     
    $userAccountControlHashTable = New-Object HashTable 
    $userAccountControlHashTable.Add("SCRIPT",1) 
    $userAccountControlHashTable.Add("ACCOUNTDISABLE",2) 
    $userAccountControlHashTable.Add("HOMEDIR_REQUIRED",8)  
    $userAccountControlHashTable.Add("LOCKOUT",16) 
    $userAccountControlHashTable.Add("PASSWD_NOTREQD",32) 
    $userAccountControlHashTable.Add("ENCRYPTED_TEXT_PWD_ALLOWED",128) 
    $userAccountControlHashTable.Add("TEMP_DUPLICATE_ACCOUNT",256) 
    $userAccountControlHashTable.Add("NORMAL_ACCOUNT",512) 
    $userAccountControlHashTable.Add("INTERDOMAIN_TRUST_ACCOUNT",2048) 
    $userAccountControlHashTable.Add("WORKSTATION_TRUST_ACCOUNT",4096) 
    $userAccountControlHashTable.Add("SERVER_TRUST_ACCOUNT",8192) 
    $userAccountControlHashTable.Add("DONT_EXPIRE_PASSWORD",65536)  
    $userAccountControlHashTable.Add("MNS_LOGON_ACCOUNT",131072) 
    $userAccountControlHashTable.Add("SMARTCARD_REQUIRED",262144) 
    $userAccountControlHashTable.Add("TRUSTED_FOR_DELEGATION",524288)  
    $userAccountControlHashTable.Add("NOT_DELEGATED",1048576) 
    $userAccountControlHashTable.Add("USE_DES_KEY_ONLY",2097152)  
    $userAccountControlHashTable.Add("DONT_REQ_PREAUTH",4194304)  
    $userAccountControlHashTable.Add("PASSWORD_EXPIRED",8388608)  
    $userAccountControlHashTable.Add("TRUSTED_TO_AUTH_FOR_DELEGATION",16777216)  
    $userAccountControlHashTable.Add("PARTIAL_SECRETS_ACCOUNT",67108864) 
 
    $userAccountControlHashTable = $userAccountControlHashTable.GetEnumerator() | Sort-Object -Property Value  
    return $userAccountControlHashTable 
} 
 
Function Get-UserAccountControlFlags($userInput) 
{     
        Set-UserAccountControlValueTable | foreach { 
        $binaryAnd = $_.value -band $userInput 
        if ($binaryAnd -ne "0") { write $_ } 
    } 
} 

$UACValue = GetUACAttr $user

#Translate the UAC flags into human readable form for placement into return info.
$Flags = Get-UserAccountControlFlags($UACValue)
$UACFlags = @()
ForEach ($Flag in $Flags)
	{
	$UACFlags += $Flag.Name
	}

function GetPwdLastSet 
    {
	param ([string]$username)
	Trap [Exception]
		{
		 #Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 WriteTo-StdOut "[info]:An exception occurred." -shortformat
		 WriteTo-StdOut "[info]: Exception.Message $ExceptionMessage."
		 WriteTo-ErrorDebugReport -ErrorRecord $_
		 $Error.Clear()
		 continue
		}
    $ForestInfo = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
    $RootString = "GC://" + $ForestInfo.Name
    $Root = New-Object  System.DirectoryServices.DirectoryEntry($RootString)
    $searcher = New-Object DirectoryServices.DirectorySearcher($Root)
    $searcher.Filter="(&(samaccountname=$username))"
    $results=$searcher.findone()
	if ($results -ne $null)
		{
		$LastTime = $results.properties.pwdlastset[0]
   		[datetime]$Time = [datetime]::fromfiletime($LastTime)
		return $Time
		}
    }

	
function GetUserDN 
    {
	param ([string]$username)
	$ForestInfo = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
	$RootString = "GC://" + $ForestInfo.Name
	$Root = New-Object  System.DirectoryServices.DirectoryEntry($RootString)
	$searcher = New-Object DirectoryServices.DirectorySearcher($Root)
	$searcher.Filter="(&(samaccountname=$username))"
	$results=$searcher.findone()
		if ($results -ne $null)
			{
			$DN = $results.properties.distinguishedname[0]
			return $DN
			}
	}


if ($LoggedOnLocally -eq $false)
	{
	$ForestInfo = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
	$ComputerSite = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySite]::GetComputerSite()
	$ComputerDomain= [System.DirectoryServices.ActiveDirectory.Domain]::GetComputerDomain()
	$UserDomain= [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
	$UserIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
	$UserName = $UserIdentity.Name
	$UserSID = $UserIdentity.User
	$AuthenticationType = $UserIdentity.AuthenticationType

	"User Logon Info" | Out-File $ExportFile -Append
	"***************************************" | Out-File $ExportFile -Append

	$UserDN = GetUserDN $user
	$UserPwdLastSet = GetPwdLastSet $user

	"Username is $username" | WriteTo-StdOut -shortformat
	"UserDN is $UserDN" | WriteTo-StdOut -shortformat
	"Userpwdlasstset is $UserPwdLastSet" | WriteTo-StdOut -shortformat

	#Gather the DC and GC which are responsive as well.
	$DomainDSE = New-Object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE")
	$DCName = $DomainDSE.dnsHostName
	if (($DCName -contains '{') -or ($DCName -contains '}'))
		{
		$DCName = $DCName.ToString()
		$DCName = $DCName.Replace('{','')
		$DCName = $DCName.Replace('}','')
		}

	$GCDSE = New-Object System.DirectoryServices.DirectoryEntry("GC://RootDSE")
	$GCName = $GCDSE.dnsHostName
	if (($GCName -contains '{') -or ($GCName -contains '}'))
		{
		$GCName = $GCName.ToString()
		$GCName = $GCName.Replace('{','')
		$GCName = $GCName.Replace('}','')
		}
	$UserInfoObject = New-Object PSObject
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'User Name' -Value $UserName
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'User SID' -Value $UserSID
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'User Object DN' -Value $UserDN
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'User Password Last Set' -Value $UserPwdLastSet
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'UserAccountControl Value' -Value $UACFlags
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Logon Authentication Method' -Value $AuthenticationType
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'User Domain' -Value $UserDomain
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Computer Site' -Value $ComputerSite
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Computer Role' -Value $RoleString
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Computer Operating System' -Value $OSString
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Computer Domain' -Value $ComputerDomain
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Domain Controller' -Value $DCName
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Global Catalog' -Value $GCName
	}

if ($LoggedOnLocally -eq $true)
	{
	$UserInfoObject = New-Object PSObject
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'User Name' -Value ($env:username)
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'User SID' -Value "[NONE]"
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'User Object DN' -Value "[Logged On To Local Computer]"
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'User Password Last Set' -Value "[Logged On To Local Computer]"
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'UserAccountControl Value' -Value "[Logged On To Local Computer]"
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Logon Authentication Method' -Value "[Logged On To Local Computer]"
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'User Domain' -Value $Computername
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Computer Site' -Value "[Logged On To Local Computer]"
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Computer Role' -Value $RoleString
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Computer Operating System' -Value $OSString
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Computer Domain' -Value "[Logged On To Local Computer]"
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Domain Controller' -Value "[Logged On To Local Computer]"
	Add-Member -InputObject $UserInfoObject -MemberType NoteProperty -Name 'Global Catalog' -Value "[Logged On To Local Computer]"



	}
$UserInfoObject | Out-File $ExportFile -Append

$UserInfoObject | WriteTo-StdOut -shortformat

#Add user details to the report.
$UserInfoReportObject = new-object PSObject
$TableString += "`t<tr><td></td><td></td></tr>`r`n"
$TableString = ("<table>`r`n`n" + $TableString + "</table>") 
add-member -inputobject $UserInfoReportObject -membertype noteproperty -name "User Logon Information" -value $TableString
$TableString = $null
$UserInfoReport = "__UserInfoReport"
# Write the Report
[string]$UserInputDesc = "User Logon Information"
$UserInfoObject | ConvertTo-Xml2 | update-diagreport -id $UserInfoReport -name $UserInputDesc -verbosity informational

CollectFiles -filesToCollect $ExportFile -fileDescription $FileDescription -sectionDescription $SectionDescription -renameOutput $false

# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBGOZViuoWN2H+K
# XXVAyAcKf+bFNxvUNKDhrEdWpjSzzqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgsxc6m18s
# jgP/pVLNWwzTlL2f4eoQ4bBa6/fd6XfYnVAwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAB4WkyFY2hQG3JPK3YdrOPQW+TJrawt1q2lTf0adMnpa5p/1bhgDBp7T
# kCT+YzXZc+a5uj5Dqn73aQDcCUXe4iO56CPYzVHJTkRfr0jJL/ow87/l8yeXeXna
# +UoF0GWEvFXAk/LnYHDf3n3Ki5nsEjLQnOLw09FMVrlvBvrWVGCMbrOx5djpXZ0/
# bpi422Z80htMat0Zms33tJE4S83MOta7vEGO2DKzRc/yq2fDT8sZu+3/vAKbvQbU
# i6ZpeQ0qRnWLGi/UVjj8U7H/BoC0w7K1O1a4qqUyhN1ubeAiBVyfpfCqINEKRBQ0
# 8aUaOC+ILQhCZ1V2Y8W5id1Pu2UPF3mhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQg1nkUojA5EHhDc/WyY00UkUgzgH+EbeMViJKfdkqpXUICBmCJ+m/D
# FhgTMjAyMTA1MTkyMjI0NTMuMTMxWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkM0
# QkQtRTM3Ri01RkZDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFXRAdi3G/ovioAAAAAAVcwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjEzWhcNMjIwNDExMTkwMjEzWjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkM0QkQtRTM3Ri01RkZD
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3m0Dp1Rm+efAv2pC1dzA8A2EHh7P7kJC
# t4+n9nxMfg0Gvm8B8YyjSVX+WJ0Fq0pOAcSs64ofXXFUB8F6Ecm8f1P86E5zzcIm
# z1vMOGuV3Ql3Ld4nILTIF3FV65xL7ZrZkF3nTAGD/n/ZiNDbKV8PR3Eorq1AvF04
# NO5p1Axt1rTmU8adYbBneeJKAgpVGCqoJWWEfPA21GHUAf5nFt9J7u3zPegQoB1M
# DLtKw/zKSG3eyuN2HQHKQ8V2loCCrBYIkkmYaTSACtK8cLz69e0ajcwmFZBF7km3
# N0PmR1oof25z2CdKGxfIMSEZmPHf5vxy6oQ7xse/RY9f0xER+t/G+QIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFF0xe7voOCGdT+Q9Mwp0WRH2gKnZMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBACV3eQCAbpdaJnK92JstGZavvJvpFLJyNUODy1wKK1LT
# WxNWnhPwB3ZB5h8lZ8roMwSTtBEF8qB03ugTx1e2ZBUv4lzEuPSlS7Lg0HlFyFy1
# 4Pl1GdN8qVGLy+ApRrENygUjM0RTPUQemil5qANvj+4j1SPm0i7CWKT+qu/+wcDD
# uQziAQss06B16/1n/vGjUkjB97R6hAzfDFwIUu5/xL06dy21oUBYe0QRHwi+BECA
# sn9aeW4XPrz6GsN9HJf+qpZI8gTS+gTqoXHXPxS8vAqmbrlA3I0NEyn9WYKmpFmv
# EHWjRFjs/6fiNI0a9uTZtHvSQq392iAUVEEdVW5TF/4wggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkM0QkQtRTM3Ri01
# RkZDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQARLfhJYnsN9tIb+BshDBOvOBnw8qCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9/EjAiGA8y
# MDIxMDUxOTE2MTIwMloYDzIwMjEwNTIwMTYxMjAyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT38SAgEAMAoCAQACAiZrAgH/MAcCAQACAiEYMAoCBQDkUNCSAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAhUwRQnTqtSzfIK9iRM8Pw+wqQsqu
# +h9Z3X4xCWvLbObgYtTch1bKP+WwqganmCmW8VxdEclnQeLVZULbJJpfsa7jsMWT
# 6QYsiLxGqxU3ugEH4Z/St5Dr2+VRsxn3DdsUOd1MTs5jCALYHEAZ7h8AJXWpY3AO
# VoHzDO9KqON/1y0xggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVdEB2Lcb+i+KgAAAAABVzANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCEjNiV
# S5+p+an4bHLXUMkeGqwe3WFhYjp2I9pO74XBRTCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EICxajQ1Dq/O666lSxkQxInhSxGO1DDZ0XFlaQe2pHKATMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFXRAdi3G/ovioA
# AAAAAVcwIgQgRMfqcstpA7Rx4wCfj4wNxSOqsRWlfsYIrzsVEf09p2UwDQYJKoZI
# hvcNAQELBQAEggEAihew+CG2GKWMOO+nMEw8PV4vg3WtqINMeT5NbUA6fwCwyaI4
# LUypzP6k2OTzO+HOhjiSaPzE3o1yF6nBdaUdFIpjDk/fVx4jsEnhzfEqg0RCUHid
# IgeEvKrWb2T34eSAZnqaboazgXVf2D3MIb3wXjWUsPw8dBht3DlvafMwGNWAiKHd
# WvRgPWnjuVSBcVPW2hPbsafTEpTWNPUUfXGiuJWKHId4mjA77tg4s+kZbMRxeZrs
# eT3ucM/1hA0CkFAQN68+8Cb6o97JbSb6OXr2cbLWY6YEW98etv78HbliFFrMzhc2
# 5I1ZIYXiA/YR8JmEyzw1YjXGb+UYDddboU6Dtw==
# SIG # End signature block
