#************************************************
# DC_VSSPSS
# Date: 05/18/2012
# Author: jasonf, randym
# Description:  based on VSSPSS.vbs writen By Will Effinger and Dennis Middelton
#************************************************
Import-LocalizedData -BindingVariable VSSBackupVSSPSSStrings

$VSSPSSVersion = "1.1"
$strComputer = $computername
$file = New-Item -type file "$($strComputer)_VSSPSS.txt" -force
$systeminfo = Get-CimInstance -computer $strComputer -Class Win32_ComputerSystem | Select Name, Manufacturer, Model, SystemType, Description, NumberOfProcessors, NumberOfLogicalProcessors, TotalPhysicalMemory
$OSInfo = Get-CimInstance -computer $strComputer -Class Win32_operatingSystem | select Caption,CSDVersion,OSArchitecture
$RC_DirtyBitErrorDetected = $false
$RC_DefragErrorDetected = $false
$RC_ServicesErrorDetected = $false
$RC_VSSProviderErrorDetected = $false
$RC_ClustersizeErrorDetected = $false
$RC_4kDriveCheckDetected = $false
$arrErrors = @()

add-content $file " "
add-content $file "------------------------------------"
add-content $file "System Information"
add-content $file "------------------------------------"
$SystemInformationCollected = New-Object PSobject

$name = $systeminfo.name
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Name" -Value $name
add-content $file -value "Name                    : $Name"
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Operating System" -Value $OSInfo.Caption
Add-Content $file "Operating System        : $($OSInfo.Caption)"
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Service Pack" -Value $OSInfo.CSDVersion
Add-Content $file "Service Pack            : $($OSInfo.CSDVersion)"
$Manufactor = $systeminfo.Manufacturer
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Manufacturer" -Value $Manufactor
add-content $file "Manufacturer            : $Manufactor"
$Model = $systeminfo.Model
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Model" -Value $Model
add-content $file "Model                   : $model"
$Systemtype = $systeminfo.Systemtype
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "OS Architecture" -Value $Systemtype
add-content $file "OS Architecture         : $Systemtype"
$Desciption = $systeminfo.Desciption
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Description" -Value $Desciption
add-content $file "Description             : $Desciption"
$NumberofProcessors = $systeminfo.NumberofProcessors
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Processors" -Value $NumberofProcessors
add-content $file "Processors              : $NumberofProcessors"
$NumberOfLogicalProcessors = $systeminfo.NumberOfLogicalProcessors
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Logical Processors" -Value $NumberOfLogicalProcessors
add-content $file "Logical Processors      : $NumberOfLogicalProcessors"
$TotalPhysicalMemory = formatbytes -bytes $systeminfo.TotalPhysicalMemory
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Total Physical Memory" -Value $TotalPhysicalMemory
#add-content $file ("Total Physical Memory   : " + "{0:0.00}GB" -f ($systeminfo.TotalPhysicalMemory/1gb))
add-content $file "Total Physical Memory   : $TotalPhysicalMemory"

$sectionDisplayOrder = 1
$sectionDescription = "System Information"
$SystemInformationCollected | ConvertTo-Xml2 | update-diagreport -id $sectionDisplayOrder -name $sectionDescription

function convert-FileInfoToTable ($Filename)
{
	$FileInfo = (Get-Command $Filename).FileVersionInfo
	$fileInfoVer = (Get-Item $Filename).VersionInfo | % {("FileVersion     :  {0}.{1}.{2}.{3}" -f $_.ProductMajorPart,$_.ProductMinorPart,$_.ProductBuildPart,$_.ProductPrivatePart)}
	$Table = "<table>"
	$Table += "<tr><td>File Path</td><td>" + $FileInfo.FileName + "</td></tr>"
	#$Table += "<tr><td>OriginalFileName</td><td>" + $FileInfo.OriginalFileName + "</td></tr>"
	$Table += "<tr><td>Description</td><td>" + (Replace-XMLChars $FileInfo.FileDescription) + "</td></tr>" 
	$Table += "<tr><td>Product Version</td><td>" + $fileInfoVer + "</td></tr>"
	#$Table += "<tr><td>Product Language</td><td>" + $FileInfo.Language + "</td></tr>"
	$Table += "</table>"
	return $Table
}

$VSSVC = "$env:SystemRoot\System32\VSSVC.EXE"
$VSSAPI = "$env:SystemRoot\System32\vssapi.dll"
$SWPRV = "$env:SystemRoot\System32\swprv.dll"
$VSS_PS = "$env:SystemRoot\System32\vss_ps.dll"
$NTOSKRNL = "$env:SystemRoot\System32\ntoskrnl.exe"
$ES = "$env:SystemRoot\System32\es.dll"
$EVENTCLS = "$env:SystemRoot\System32\eventcls.dll"
$PARTMGR = "$env:SystemRoot\System32\drivers\partmgr.sys"
$STORPORT = "$env:SystemRoot\System32\drivers\storport.sys"


$arrFiles = @($VSSVC, $VSSAPI, $SWPRV, $VSS_PS, $NTOSKRNL, $ES, $EVENTCLS, $PARTMGR, $STORPORT)

$FileInformationCollected = New-Object PSObject

Foreach ($_ in $arrFiles)
{
      Add-Member -InputObject $FileInformationCollected -MemberType NoteProperty -Name (Split-Path $_ -Leaf) -Value (convert-FileInfoToTable $_)
}

$sectionDisplayOrder = 2
$sectionDescription = "File Information"
$FileInformationCollected | ConvertTo-Xml2 | update-diagreport -id $sectionDisplayOrder -name $sectionDescription

add-content $file " "
add-content $file " "
add-content $file "------------------------------------"
add-content $file "File Information"
add-content $file "------------------------------------"

foreach($arrfile in $arrFiles)
{
	$fileInfo1 = ((Get-Command $arrfile).FileVersionInfo | Select-Object FileName,OriginalFilename,FileDescription,ProductName | FL | Out-String ).Trim()
	add-content $file $fileInfo1
	$fileInfo2 = (Get-Item $arrfile).VersionInfo | % {("FileVersion     :  {0}.{1}.{2}.{3}" -f $_.ProductMajorPart,$_.ProductMinorPart,$_.ProductBuildPart,$_.ProductPrivatePart)}
	add-content $file $fileInfo2
	add-content $file "------------------------------------"

}
#add-content $file (Get-Command $env:SystemRoot\System32\VSSVC.EXE).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\vssapi.dll).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\swprv.dll).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\vss_ps.dll).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\ntoskrnl.exe).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\es.dll).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\eventcls.dll).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\drivers\partmgr.sys).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\drivers\Storport.sys).FileVersionInfo

function convert-DiskInfoToTable ($Disk)
{
	$Table = "<table>"
	$Table += "<tr><td>Name</td><td>" + $Disk.name + "</td></tr>"
	$Table += "<tr><td>Model</td><td>" + $Disk.Model + "</td></tr>"
	$Table += "<tr><td>Bytes per Sector</td><td>" + $Disk.BytesPerSector + "</td></tr>" 
	$Table += "<tr><td>Signature</td><td>" + "{0:X}" -f $Disk.Signature + "</td></tr>"
	$Table += "</table>"
	return $Table
}

$DiskInformationCollected = New-Object PSObject
Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_DiskVolume -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_DiskVolumeDesc
add-content $file "------------------------------------"
add-content $file "Physical Disk Information"
add-content $file "------------------------------------"
$colItems = Get-CimInstance -computer $strComputer -Class Win32_DiskDrive | Select Name, Model, BytesPerSector, SCSILogicalUnit, Signature
foreach ($objItem in $colItems)
{
	$diskname = $objItem.name
	add-content $file "Name            : $diskname"
	$diskmodel = $objItem.Model
	add-content $file "Model           : $diskmodel"
	$BytesPerSector = $objItem.BytesPerSector
	add-content $file "Bytes/Sector    : $BytesPerSector"
	
	#4096 bytes per sector check
	If ($BytesPerSector -eq "4096")
	{
		$RC_4kDriveCheckDetected = $true
		$arrErrors += "ERROR: 4k Advanced Format Disks are not supported as backup destination. (See KB2510009)."
		$arrErrors += "------------------------------------"
		$arrErrors += ""
		#add-content $file "ERROR: 4k Advanced Format Disks are not supported as backup destination. (See KB2510009)."
		#add-content $file "------------------------------------"
		#add-content $file ""
	}
	$hexsig = "{0:X}" -f $objItem.Signature
	add-content $file "Signature       : $($hexsig)"
	add-content $file ""
	Add-Member -InputObject $DiskInformationCollected -MemberType NoteProperty -Name (Split-Path $objItem.name -leaf) -Value (convert-DiskInfoToTable $objItem)

}
$sectionDisplayOrder = 3
$sectionDescription = "Physical Disk Information"
$DiskInformationCollected | ConvertTo-Xml2 | update-diagreport -id $sectionDisplayOrder -name $sectionDescription


function convert-MountvolInfoToTable ($MountvolItem)
{
	$mountvoldirectory = Replace-XMLChars -RAWString (($MountvolItem.Directory).Substring(21))
	$mountvolvolume = Replace-XMLChars -RAWString (($MountVolItem.Volume).Substring(22))
	$Table = "<table>"
	$Table += "<tr><td>Drive Letter</td><td>" + $mountvoldirectory + "</td></tr>"
	$Table += "<tr><td>Mountvol Entry</td><td>" + $mountvolvolume + "</td></tr>"
	$Table += "</table>"
	return $Table
}
$MountvolInformationCollected = New-Object PSObject

add-content $file "------------------------------------"
add-content $file "Mountvol Information"
add-content $file "------------------------------------"
add-content $file ""

$mountvol = Get-CimInstance -computer $strComputer -Class Win32_Mountpoint | Select Directory, Volume

foreach ($objItem in $mountvol)
{
	$DirectoryRaw = $objItem.Directory
	$DirectoryTrim = $DirectoryRaw.Substring(21)
	add-content $file $DirectoryTrim

	$volumeRaw = $objItem.Volume
	$volumeTrim = $volumeRaw.Substring(22)
	add-content $file $volumeTrim
	add-content $file ""
	$mountvolitemdetected += 1
	Add-Member -InputObject $MountvolInformationCollected -MemberType NoteProperty -Name ($mountvolitemdetected) -Value (convert-MountvolInfoToTable $objItem)
}

$sectionDisplayOrder = 4
$sectionDescription = "Mountvol Information"
$MountvolInformationCollected | ConvertTo-Xml2 | update-diagreport -id $sectionDisplayOrder -name $sectionDescription


function convert-VolumeInfoToTable ($objvolume, $objdefraganalysis)
{
	$Table = "<table>"
	$Table += "<tr><td>Drive</td><td>" + $objvolume.DriveLetter + "</td></tr>"
	$Table += "<tr><td>File System</td><td>" + $objvolume.FileSystem + "</td></tr>"
	$Table += "<tr><td>Volume Size</td><td>" + "{0:0.00}GB" -f ($objdefraganalysis.VolumeSize/1GB) + "</td></tr>"
	$Table += "<tr><td>Free Space Percent</td><td>" + $objdefraganalysis.FreeSpacePercent + "</td></tr>"
	$Table += "<tr><td>Free Space Frag. Percent</td><td>" + $objdefraganalysis.FreeSpacePercentFragmentation + "</td></tr>"
	$Table += "<tr><td>Files</td><td>" + $objdefraganalysis.TotalFiles + "</td></tr>"
	$Table += "<tr><td>Fragmented Files</td><td>" + $objdefraganalysis.TotalFragmentedFiles + "</td></tr>"
	$Table += "<tr><td>File Fragmentation Percent</td><td>" + $objdefraganalysis.FilePercentFragmentation + "</td></tr>"
	$Table += "<tr><td>Folders</td><td>" + $objdefraganalysis.TotalFolders + "</td></tr>"
	$Table += "<tr><td>Fragmented Folders</td><td>" + $objdefraganalysis.FragmentedFolders + "</td></tr>"
	$Table += "<tr><td>MFT Usage Percent</td><td>" + $objdefraganalysis.MFTPercentInUse + "</td></tr>"
	$Table += "<tr><td>MFT Fragments</td><td>" + $objdefraganalysis.TotalMFTFragments + "</td></tr>"
	$Table += "<tr><td>MFT Records</td><td>" + $objdefraganalysis.MFTRecordCount + "</td></tr>"
	$Table += "<tr><td>PageFile Size</td><td>" + "{0:0.00}GB" -f ($objdefraganalysis.PageFileSize/1GB) + "</td></tr>"
	$Table += "<tr><td>PageFile Fragments</td><td>" + $objdefraganalysis.TotalPageFileFragments + "</td></tr>"
	$Table += "</table>"
	return $Table
}

$volumeInformationCollected = New-Object PSObject

add-content $file "------------------------------------"
add-content $file "Volume Information"
add-content $file "------------------------------------"
add-content $file ""

Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_Defrag -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_DefragDesc
# Defrag Info
$volumes = @(Get-CimInstance Win32_Volume -ComputerName $strComputer -Filter 'DriveType = 3')
  
foreach ($volume in $volumes) 
{
	$analysis = $volume.DefragAnalysis().DefragAnalysis
	add-content $file   "Drive               : $($volume.DriveLetter)"
	add-content $file  "File System         : $($volume.FileSystem)"
	add-content $file  ("Volume Size         : " + "{0:0.00}GB" -f ($analysis.VolumeSize/1GB))
	add-content $file  ""
	add-content $file  "Free Space          : $($analysis.FreeSpacePercent)%"
	add-content $file  ("Free Space Frag.    : " + "$($analysis.FreeSpacePercentFragmentation)%")
	add-content $file  ""
	add-content $file  "Files               : $($analysis.TotalFiles)"
	add-content $file  "Fragmented Files    : $($analysis.TotalFragmentedFiles)"
	add-content $file  "File Fragmentation  : $($analysis.FilePercentFragmentation)%"
	add-content $file  ""
	add-content $file  "Folders             : $($analysis.TotalFolders)"
	add-content $file  "Fragmented Folders  : $($analysis.FragmentedFolders)"
	add-content $file  ""
	add-content $file  "MFT Usage           : $($analysis.MFTPercentInUse)%"
	add-content $file  "MFT Fragments       : $($analysis.TotalMFTFragments)"
	add-content $file  "MFT Records         : $($analysis.MFTRecordCount)"
	add-content $file  ""
	add-content $file  ("PageFile Size       : " + "{0:0.00}GB" -f ($analysis.PageFileSize/1GB))
	add-content $file  "PageFile Fragments  : $($analysis.TotalPageFileFragments)"
	add-content $file  ""
	add-content $file  "----------------------------"
	$Driveletter = $volume.driveletter
	# checking for fragmentation
	If ($analysis.FilePercentFragmentation -gt "10")
	{
		$RC_DefragErrorDetected = $true
		$arrErrors += "ERROR: Volume $($volume.DriveLetter) needs to be defragmented for proper operation."
		$arrErrors += "------------------------------------"
		$arrErrors += ""
		#add-content $file "ERROR: Volume $($volume.DriveLetter) needs to be defragmented for proper operation."
		#add-content $file "------------------------------------"
		#add-content $file ""
	}

	$volumedetectednumber += 1

		Add-Member -InputObject $volumeInformationCollected -MemberType NoteProperty -Name $volumedetectednumber -Value (convert-VolumeInfoToTable -objvolume $volume -objDefragAnalysis $analysis)
}

$sectionDisplayOrder = 5
$sectionDescription = "Volume Information"
$volumeInformationCollected | ConvertTo-Xml2 | update-diagreport -id $sectionDisplayOrder -name $sectionDescription

# Checking cluster size vs size of volume 
 
Foreach ($volume in $volumes)
{
	if (($volume.filesystem -eq "NTFS" -and $volume.blocksize -gt 4096 -and $volume.Capacity -lt 2147483648) -or
	($volume.filesystem -eq "NTFS" -and $volume.blocksize -gt 8192 -and $volume.Capacity -lt 17592186044416) -or 
	($volume.filesystem -eq "NTFS" -and $volume.blocksize -gt 16536 -and $volume.Capacity -lt 35184372088832) -or
	($volume.filesystem -eq "NTFS" -and $volume.blocksize -gt 32768 -and $volume.Capacity -lt 70368744177664) -or
	($volume.filesystem -eq "NTFS" -and $volume.blocksize -gt 65536 -and $volume.Capacity -lt 140737488355328))
	{
		$RC_ClustersizeErrorDetected = $true
		add-content $file "VOLUME ERROR: $($volume.Driveletter) $($Volume.DriveLetter) -- The cluster size is too small for efficient VSS snapshot operation (see KB140365)."
		add-content $file  ""
		add-content $file  "----------------------------"
		$arrErrors += "VOLUME ERROR: $($volume.Driveletter) $($Volume.DriveLetter) -- The cluster size is too small for efficient VSS snapshot operation (see KB140365)."
		$arrErrors += "------------------------------------"
		$arrErrors += ""
	}
	# checking for the dirty bit being set and providing an error
	if ($volume.DirtyBitSet -eq "True")
	{
		$RC_DirtyBitErrorDetected = $true
		#add-content $file "ERROR: Run CHKDSK on volume $($volume.DriveLetter)"
		#add-content $file "------------------------------------"
		$arrErrors += "ERROR: Run CHKDSK on volume $($volume.DriveLetter)"
		$arrErrors += "------------------------------------"
		$arrErrors += ""
	}
}

Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_Provider -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_ProviderDesc

add-content $file "------------------------------------"
add-content $file "VSS Providers"
add-content $file "------------------------------------"
add-content $file ""

if((Get-CimInstance -Class Win32_OperatingSystem).ProductType -ge 2)
{
	$vssproviders = Get-CimInstance -computer $strComputer -Class Win32_ShadowProvider | Select Name, Version, CLSID

	foreach ($objItem in $vssproviders)
	{
		$ProviderName = $objItem.Name
		add-content $file "Name     : $ProviderName"

		$ProviderVersion = $objItem.Version
		add-content $file "Version  : $ProviderVersion"

		$providerCLSID = $objItem.CLSID
		add-content $file "CLSID    : $providerCLSID"
		add-content $file ""
	}
}

Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_VSSStorage  -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_VSSStorageDesc

add-content $file "------------------------------------"
add-content $file "Listing Shadow Copy Storage"
add-content $file "------------------------------------"
add-content $file ""

if((Get-CimInstance -Class Win32_OperatingSystem).ProductType -ge 2)
{
	$shadowCount = Get-CimInstance -computer $strComputer -class win32_shadowcopy
	$ShadowStorage = Get-CimInstance -computer $strComputer -Class Win32_ShadowStorage | Select Volume, AllocatedSpace, DiffVolume, MaxSpace, UsedSpace
	#Collect writer information 
	$tmpdiskshadowscriptfile = join-path $pwd.path "tmpdiskshadowscriptfile.txt"

	"list writers detailed" | out-file $tmpdiskshadowscriptfile -encoding ASCII

	Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Writers -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_WritersDesc

	$fileDescription = "DiskShadow list writers detailed output"
	$sectionDescription = "VSS Writers"
	$DiskShadowOutputFile = join-path $pwd.path ($ComputerName + "_WriterMetaData.txt")
	$CommandToExecute = "cmd.exe /c diskshadow /s `"$tmpdiskshadowscriptfile`" /l `"$DiskShadowOutputFile`""
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $DiskShadowOutputFile -fileDescription $fileDescription 
	Remove-Item $tmpdiskshadowscriptfile
	
	$fileDescription = "VSSAdmin list writers output"
	$VSSAdminOutputFile = join-path $pwd.path ($ComputerName + "_List_Writers.txt")
	$CommandToExecute = "cmd.exe /c vssadmin list writers > `"$VSSAdminOutputFile`""
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $VSSAdminOutputFile -fileDescription $fileDescription 

	foreach ($objItem in $ShadowStorage)
	{
		$ShadowVolumeRaw = $objItem.Volume
		$ShadowVolume = $ShadowVolumeRaw.Substring(22)
		add-content $file "Volume              : $shadowVolume"

		$ShadowDiff = $objItem.DiffVolume
		add-content $file "Diff Voluem          : $shadowDiff"

		$ShadowAllocated = $objItem.AllocatedSpace /1mb
		add-content $file "Space Allocated      : $ShadowAllocated /Mb"

		$ShadowMaxSpaceRaw = $objItem.MaxSpace / 1mb
		add-content $file "Max Space            : $ShadowMaxSpace /Mb"

		$ShadowUsed = $objItem.UsedSpace / 1mb
		add-content $file "Used Space           : $ShadowUsed /Mb"

		add-content $file "Snapshots on System    : $($shadowCount.count)"

		add-content $file "------------------------------------"
	}

	add-content $file ""
	add-content $file "------------------------------------"
	add-content $file "Test SnapShot Creation"
	add-content $file "------------------------------------"
	add-content $file ""

	$ShadowCompleted = @()
	$ShadowErrors = @()
	$arrCSVPartitions = @()
	if (test-path "hklm:/cluster")
	{
		import-module failoverclusters
		$arrCSVPartitions = Get-ClusterSharedVolume | %{($_.sharedvolumeinfo | select -expandproperty partition).name}
	}
		
	## Create list of volumes that are NTFS
	$Snapvolumes = Get-CimInstance -computer $strComputer -class Win32_Volume | Where-object { $_.FileSystem -match "NTFS"}

	$snapvolumesInformationCollected = New-Object PSObject
	## Create snapshot for each volume that is listed in $snapvolumes
	Foreach ($volume in $snapvolumes)
	{
		if (-not ($arrCSVPartitions -contains (($volume.Name).tostring()).trimend("\")))
		{
			$createSnapshotString = $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Create_SnapshotDesc + ": " + $volume.Name
			#Write-DiagProgress -activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Create_Snapshot -status ($VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Create_SnapshotDesc -replace ("%VolumeName%", $volume.name))
			Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Create_Snapshot -Status $createSnapshotString
			$newsnap = (Get-CimInstance -computer $strComputer -list win32_shadowcopy).Create($volume.name,"ClientAccessible")

			if ($($newsnap.ReturnValue) -eq "0")
			{
				#Write to log if success
				Add-content $file "VSS Provider Test      : SUCCESS -- Volume:  $($volume.name) SnapShot ID:  $($newsnap.ShadowID)"
			}

			if ($($newsnap.ReturnValue) -ne "0")
			{
				Add-Content $file "VSS Provider Test      : Failed -- Volume:  $($volume.name)"
				$arrErrors += "VSS Provider Test      : Failed -- Volume:  $($volume.name)"
				$RC_VSSProviderErrorDetected = $true
				Add-Member -InputObject $snapvolumeInformationCollected -MemberType NoteProperty -Name $volume.name -Value "Error - Snapshot Creation Returned $newsnap.ReturnValue"
			}

			$colItems = Get-CimInstance -computer $strComputer -class Win32_ShadowCopy

			Foreach ($objItem in $colItems)
			{
				#Match the Shadow created above to an existing snapshot on the volume and delete
				If ($objItem.ID -match $newsnap.ShadowID)
				{
					$objItem.Delete()
				}
			}
		}
		else
		{
			Add-content $file "VSS Provider Test      : CSV Detected - skipping -- Volume:  $($volume.name)"
		}
	}

	add-content $file "------------------------------------"
	add-content $file "Listing VSS Service"
	add-content $file "------------------------------------"
	add-content $file ""

	$vssService = Get-Service -computer $strComputer VSS,eventsystem,CryptSvc,SWPRV,COMSysApp,VDS |
	select Name, Status

	foreach ($service in $vssService)
	{
		Add-Content $file "Service Name: $($service.Name) Status: $($Service.Status)"
	}

	add-content $file ""
	add-content $file "------------------------------------"
	add-content $file "Errors"
	add-content $file "------------------------------------"
	add-content $file ""

	Add-Content $file $arrErrors 

	$ServicesInformationCollected = New-Object PSObject
	function ServiceStartType($servicename,$Starttype)
	{
		$StartTemp = (Get-CimInstance -computer $strComputer -class Win32_Service -filter "Name='$servicename'").StartMode
		If ($StartTemp -ne $Starttype)
		{
			Add-content $file "SERVICE ERROR: $($servicename) service start type should be $($Starttype)"
			Add-Member -
			Add-Member -InputObject $ServicesInformationCollected -MemberType NoteProperty -Name $servicename -Value $StartTemp
			return $true
		}
		else
		{
			return $false
		}
	}

	$VSSIncorrectServiceStartType = ServiceStartType VSS Manual
	$SWPRVIncorrectServiceStartType = ServiceStartType SWPRV Manual
	$EventSystemIncorrectServiceStartType = ServiceStartType EventSystem Auto
	$COMSysAppIncorrectServiceStartType = ServiceStartType COMSysApp Manual
	$CryptSvcIncorrectServiceStartType = ServiceStartType CryptSvc Auto
	$VDSIncorrectServiceStartType = ServiceStartType VDS Manual    
	
	if ($VSSIncorrectServiceStartType -or $SWPRVIncorrectServiceStartType -or $EventSystemIncorrectServiceStartType -or $COMSysAppIncorrectServiceStartType -or $CryptSvcIncorrectServiceStartType -or $VDSIncorrectServiceStartType)
	{
		$RC_ServicesErrorDetected = $true
	}

	add-content $file "VSSPSS Version: $VSSPSSVersion"
}
else
{
	Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Writers -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_WritersDesc
	$sectionDescription = "VSS Writers"
	$fileDescription = "VSSAdmin list writers output"
	$VSSAdminOutputFile = join-path $pwd.path ($ComputerName + "_List_Writers.txt")
	$CommandToExecute = "cmd.exe /c vssadmin list writers > `"$VSSAdminOutputFile`""
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $VSSAdminOutputFile -fileDescription $fileDescription 
}

CollectFiles -filesToCollect $file -fileDescription $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_resultsreportfiledesc -sectionDescription $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_resultsreportsectiondesc

#Rule to detect VSS provider error
$RootCauseName = "RC_VSSPSS_ProviderError"
$InternalContent = "http://bemis.partners.extranet.microsoft.com/2718662"
$Verbosity = "Error"
$Visibility = "3"
$SupportTopicsID = "7993"
$SolutionTitle = $VSSBackupVSSPSSStrings.ID_VSSPSS_VSSProviderErrorSD

Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSPSS_VSSProviderErrorTitle -Status $VSSBackupVSSPSSStrings.ID_VSSPSS_VSSProviderErrorDesc

if ($RC_VSSProviderErrorDetected -eq $true)
{
	# Red/ Yellow Light
	Update-DiagRootCause -id $RootCauseName -Detected $true
	Write-GenericMessage -RootCauseId $RootCauseName -InternalContentURL $InternalContent -InformationCollected $snapvolumeInformationCollected -Verbosity $Verbosity -Visibility $Visibility -SupportTopicsID $SupportTopicsID -SolutionTitle $SolutionTitle
}
else
{
	# Green Light
	Update-DiagRootCause -id $RootCauseName -Detected $false
}


# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCByZQMG+a/MiV/z
# ZjQdrwkyWYJBOwnL9yGceCzoETuQ26CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg7zgcxAlD
# IOLHumDzEontpbt7al70bsfzzKpUHUATyqIwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAJtOnH+T41C/UfvyeQCl5CK0ulH2xIjyvOEe03H6yt6wTWSnX9aPe8I6
# oCe3TzeaW4qPeGYq+jqxkEXuEe0TprqdfJ6Qe9c5QL5RzEopGLVu9f9MOQfhoa44
# 0ZBRM5jRw3TPcjTEj0KoVovX3xlgcXIHekySM+b4oLeBfh1hSwAnDnE95kLAybsv
# /6z//j/3TAYMq9t/tMwwjvihFv8TZ8/N3AVUuWfRfEGRhVk8GTM4OL6eaOMRgqRv
# EpnE4aUIpoyrVBYxfyrcVwjdkJqCAZmHZ09YFVmJz6A9ogHPdhL1LgG1c8uA4Eum
# 795ReiZzRLGqefooV+Dp9VZd7lNbtEChghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgSRzEef+FO4f93wyQH0xjYKIGhC+x50n/YgoMYeNE5lcCBmGB3Gir
# WBgTMjAyMTExMTExNjUzMzQuOTg0WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYw
# QkMtRTM4My0yNjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFaLLluRDTLbygAAAAAAVowDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE2WhcNMjIwNDExMTkwMjE2WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0yNjM1
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsL1cHFcNrScIrvQd/4aKHo3FGXWYCHMU
# l2iTxuzfGknztMzbysR4eRkBoT4pv0aL1S9OlDfOsRbJZKkhCTLG/9Z/RwiEDWYk
# 6rK7bRM3eX3pm+DNivM7+tCU+9spbv2gA7j5gWx6RAK2vMz2FChLkFgbA+H1DPro
# G5LEf1DB7LA0FCyORWiKSkHGRL4RdIjOltrZp++dExfsst7Z6vJz4+U9eZNI58fV
# Y3KRzbm73OjplfSAB3iNSkHN0wuccK0TrZsvY87TRyYAmyK2qBqi/7eUWt93Sw8A
# LBMY72LKaUmVvaxq/COpKePlHMbhHEbqtTaLt61udBOjNHvc4cwY5QIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFGRzJT/1HI+SftAGhdk5NDzA3jFnMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAAAAbex8WBtSLDiBYxXxU7GVsgb8IgxKJyIO0hmc8vzg
# 4w3iUl5Xkt4mv4dgFyjHmu5Zmbj0rb2IGYm/pWJcy0/zWlhnUQUzvfTpj7MsiH+1
# Lnvg95awe88PRA7FDgc4zYY0+8UB1S+jzPmmBX/kT6U+7rW5QIgFMMRKIc743utq
# CpvcwRM+pEo8s0Alwo8NxqUrOeYY+WfNjo/XOin/tr3RVwEdEopD+FO+f/wLxjpv
# 4y+TmRgmHrso1tVVy64FbIVIxlMcZ6cee4dWD2y8fv6Wb9X/AhtlQookk7QdCbKh
# 3JJ4P8ksLs02wNhGkU37b10tG3HR5bJmiwmZPyopsEgwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0y
# NjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQDMgAWYvcYcdZwAliLeFobCWmUaLqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5TePeDAiGA8y
# MDIxMTExMTE2NDc1MloYDzIwMjExMTEyMTY0NzUyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN494AgEAMAoCAQACAiYUAgH/MAcCAQACAhEuMAoCBQDlOOD4AgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEARgjej0SbSLQSMcUwvN12chrEC28n
# cvB5Y3XUAVhEcy1SU+s/DPBT7RaNwTGRnmi6Mq9YdOCw28LOQagQobT23OIXtlQk
# v6/VnsW+JiF8q2A2Zvn08thSlcdfEr1B4nsYLVrR78o0MGag24mYk75Z6ATsfNVT
# HmPR653hJHGQ0OcxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVosuW5ENMtvKAAAAAABWjANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCD1Hhso
# dYWwCRm8yHy9HoTRc8cimhxikYszd5/WsMRUWjCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIJP8qCZ0xLLkXTDDghqv1yZ/kizekzSFS4gicvltsX+wMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFaLLluRDTLbygA
# AAAAAVowIgQgMnaZvhznlep5/TqcHsVpqibeOA9Q6qLRQqPN0sxjsvwwDQYJKoZI
# hvcNAQELBQAEggEATlb5UHDpuHWr8sh75Uchv17zU9J/Q/YiR/7SX/ImLLRVx4Pc
# bvrouJ6hEGe5G+7kXS47UrdhvG27rXUk65TfwjEWlpSRbK/DJCRj+nF2CGf6OsNc
# H7bf1gLTfimelB9NjHYQxIzesnbGDnf1npl8Z0NjOAAkKPVQxsGeJW96/QuLQ8Qz
# 35x1Na29DZ2+G5yLFlH3MeNTo0kCLkVK4x4E6OfcFiat7f9OfLWJLY6qPH5BcSww
# Gap/pvtYr5N+3rHtyO2Fn//WZu7T6TRL0jQJgcgezTYJOkT6wu6ol9FClk53fhZe
# QAgj6+7UJtC/Kk3hJrL1QO1DhBFoEyM09T7z9A==
# SIG # End signature block
