﻿#************************************************
# DC_VSSPSS
# Date: 05/18/2012
# Author: jasonf, randym
# Description:  based on VSSPSS.vbs writen By Will Effinger and Dennis Middelton
#************************************************
Import-LocalizedData -BindingVariable VSSBackupVSSPSSStrings

$VSSPSSVersion = "1.1"
$strComputer = $computername
$file = New-Item -type file "$($strComputer)_VSSPSS.txt" -force
$systeminfo = Get-WmiObject -computer $strComputer -Class Win32_ComputerSystem | Select Name, Manufacturer, Model, SystemType, Description, NumberOfProcessors, NumberOfLogicalProcessors, TotalPhysicalMemory
$OSInfo = Get-WmiObject -computer $strComputer -Class Win32_operatingSystem | select Caption,CSDVersion,OSArchitecture
$RC_DirtyBitErrorDetected = $false
$RC_DefragErrorDetected = $false
$RC_ServicesErrorDetected = $false
$RC_VSSProviderErrorDetected = $false
$RC_ClustersizeErrorDetected = $false
$RC_4kDriveCheckDetected = $false
$arrErrors = @()

add-content $file " "
add-content $file "------------------------------------"
add-content $file "System Information"
add-content $file "------------------------------------"
$SystemInformationCollected = New-Object PSobject

$name = $systeminfo.name
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Name" -Value $name
add-content $file -value "Name                    : $Name"
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Operating System" -Value $OSInfo.Caption
Add-Content $file "Operating System        : $($OSInfo.Caption)"
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Service Pack" -Value $OSInfo.CSDVersion
Add-Content $file "Service Pack            : $($OSInfo.CSDVersion)"
$Manufactor = $systeminfo.Manufacturer
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Manufacturer" -Value $Manufactor
add-content $file "Manufacturer            : $Manufactor"
$Model = $systeminfo.Model
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Model" -Value $Model
add-content $file "Model                   : $model"
$Systemtype = $systeminfo.Systemtype
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "OS Architecture" -Value $Systemtype
add-content $file "OS Architecture         : $Systemtype"
$Desciption = $systeminfo.Desciption
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Description" -Value $Desciption
add-content $file "Description             : $Desciption"
$NumberofProcessors = $systeminfo.NumberofProcessors
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Processors" -Value $NumberofProcessors
add-content $file "Processors              : $NumberofProcessors"
$NumberOfLogicalProcessors = $systeminfo.NumberOfLogicalProcessors
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Logical Processors" -Value $NumberOfLogicalProcessors
add-content $file "Logical Processors      : $NumberOfLogicalProcessors"
$TotalPhysicalMemory = formatbytes -bytes $systeminfo.TotalPhysicalMemory
Add-Member -InputObject $SystemInformationCollected -MemberType NoteProperty -Name "Total Physical Memory" -Value $TotalPhysicalMemory
#add-content $file ("Total Physical Memory   : " + "{0:0.00}GB" -f ($systeminfo.TotalPhysicalMemory/1gb))
add-content $file "Total Physical Memory   : $TotalPhysicalMemory"

$sectionDisplayOrder = 1
$sectionDescription = "System Information"
$SystemInformationCollected | ConvertTo-Xml2 | update-diagreport -id $sectionDisplayOrder -name $sectionDescription

function convert-FileInfoToTable ($Filename)
{
	$FileInfo = (Get-Command $Filename).FileVersionInfo
	$fileInfoVer = (Get-Item $Filename).VersionInfo | % {("FileVersion     :  {0}.{1}.{2}.{3}" -f $_.ProductMajorPart,$_.ProductMinorPart,$_.ProductBuildPart,$_.ProductPrivatePart)}
	$Table = "<table>"
	$Table += "<tr><td>File Path</td><td>" + $FileInfo.FileName + "</td></tr>"
	#$Table += "<tr><td>OriginalFileName</td><td>" + $FileInfo.OriginalFileName + "</td></tr>"
	$Table += "<tr><td>Description</td><td>" + (Replace-XMLChars $FileInfo.FileDescription) + "</td></tr>" 
	$Table += "<tr><td>Product Version</td><td>" + $fileInfoVer + "</td></tr>"
	#$Table += "<tr><td>Product Language</td><td>" + $FileInfo.Language + "</td></tr>"
	$Table += "</table>"
	return $Table
}

$VSSVC = "$env:SystemRoot\System32\VSSVC.EXE"
$VSSAPI = "$env:SystemRoot\System32\vssapi.dll"
$SWPRV = "$env:SystemRoot\System32\swprv.dll"
$VSS_PS = "$env:SystemRoot\System32\vss_ps.dll"
$NTOSKRNL = "$env:SystemRoot\System32\ntoskrnl.exe"
$ES = "$env:SystemRoot\System32\es.dll"
$EVENTCLS = "$env:SystemRoot\System32\eventcls.dll"
$PARTMGR = "$env:SystemRoot\System32\drivers\partmgr.sys"
$STORPORT = "$env:SystemRoot\System32\drivers\storport.sys"


$arrFiles = @($VSSVC, $VSSAPI, $SWPRV, $VSS_PS, $NTOSKRNL, $ES, $EVENTCLS, $PARTMGR, $STORPORT)

$FileInformationCollected = New-Object PSObject

Foreach ($_ in $arrFiles)
{
      Add-Member -InputObject $FileInformationCollected -MemberType NoteProperty -Name (Split-Path $_ -Leaf) -Value (convert-FileInfoToTable $_)
}

$sectionDisplayOrder = 2
$sectionDescription = "File Information"
$FileInformationCollected | ConvertTo-Xml2 | update-diagreport -id $sectionDisplayOrder -name $sectionDescription

add-content $file " "
add-content $file " "
add-content $file "------------------------------------"
add-content $file "File Information"
add-content $file "------------------------------------"

foreach($arrfile in $arrFiles)
{
	$fileInfo1 = ((Get-Command $arrfile).FileVersionInfo | Select-Object FileName,OriginalFilename,FileDescription,ProductName | FL | Out-String ).Trim()
	add-content $file $fileInfo1
	$fileInfo2 = (Get-Item $arrfile).VersionInfo | % {("FileVersion     :  {0}.{1}.{2}.{3}" -f $_.ProductMajorPart,$_.ProductMinorPart,$_.ProductBuildPart,$_.ProductPrivatePart)}
	add-content $file $fileInfo2
	add-content $file "------------------------------------"

}
#add-content $file (Get-Command $env:SystemRoot\System32\VSSVC.EXE).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\vssapi.dll).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\swprv.dll).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\vss_ps.dll).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\ntoskrnl.exe).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\es.dll).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\eventcls.dll).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\drivers\partmgr.sys).FileVersionInfo
#add-content $file "------------------------------------"
#add-content $file (Get-Command $env:SystemRoot\System32\drivers\Storport.sys).FileVersionInfo

function convert-DiskInfoToTable ($Disk)
{
	$Table = "<table>"
	$Table += "<tr><td>Name</td><td>" + $Disk.name + "</td></tr>"
	$Table += "<tr><td>Model</td><td>" + $Disk.Model + "</td></tr>"
	$Table += "<tr><td>Bytes per Sector</td><td>" + $Disk.BytesPerSector + "</td></tr>" 
	$Table += "<tr><td>Signature</td><td>" + "{0:X}" -f $Disk.Signature + "</td></tr>"
	$Table += "</table>"
	return $Table
}

$DiskInformationCollected = New-Object PSObject
Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_DiskVolume -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_DiskVolumeDesc
add-content $file "------------------------------------"
add-content $file "Physical Disk Information"
add-content $file "------------------------------------"
$colItems = Get-WmiObject -computer $strComputer -Class Win32_DiskDrive | Select Name, Model, BytesPerSector, SCSILogicalUnit, Signature
foreach ($objItem in $colItems)
{
	$diskname = $objItem.name
	add-content $file "Name            : $diskname"
	$diskmodel = $objItem.Model
	add-content $file "Model           : $diskmodel"
	$BytesPerSector = $objItem.BytesPerSector
	add-content $file "Bytes/Sector    : $BytesPerSector"
	
	#4096 bytes per sector check
	If ($BytesPerSector -eq "4096")
	{
		$RC_4kDriveCheckDetected = $true
		$arrErrors += "ERROR: 4k Advanced Format Disks are not supported as backup destination. (See KB2510009)."
		$arrErrors += "------------------------------------"
		$arrErrors += ""
		#add-content $file "ERROR: 4k Advanced Format Disks are not supported as backup destination. (See KB2510009)."
		#add-content $file "------------------------------------"
		#add-content $file ""
	}
	$hexsig = "{0:X}" -f $objItem.Signature
	add-content $file "Signature       : $($hexsig)"
	add-content $file ""
	Add-Member -InputObject $DiskInformationCollected -MemberType NoteProperty -Name (Split-Path $objItem.name -leaf) -Value (convert-DiskInfoToTable $objItem)

}
$sectionDisplayOrder = 3
$sectionDescription = "Physical Disk Information"
$DiskInformationCollected | ConvertTo-Xml2 | update-diagreport -id $sectionDisplayOrder -name $sectionDescription


function convert-MountvolInfoToTable ($MountvolItem)
{
	$mountvoldirectory = Replace-XMLChars -RAWString (($MountvolItem.Directory).Substring(21))
	$mountvolvolume = Replace-XMLChars -RAWString (($MountVolItem.Volume).Substring(22))
	$Table = "<table>"
	$Table += "<tr><td>Drive Letter</td><td>" + $mountvoldirectory + "</td></tr>"
	$Table += "<tr><td>Mountvol Entry</td><td>" + $mountvolvolume + "</td></tr>"
	$Table += "</table>"
	return $Table
}
$MountvolInformationCollected = New-Object PSObject

add-content $file "------------------------------------"
add-content $file "Mountvol Information"
add-content $file "------------------------------------"
add-content $file ""

$mountvol = Get-WmiObject -computer $strComputer -Class Win32_Mountpoint | Select Directory, Volume

foreach ($objItem in $mountvol)
{
	$DirectoryRaw = $objItem.Directory
	$DirectoryTrim = $DirectoryRaw.Substring(21)
	add-content $file $DirectoryTrim

	$volumeRaw = $objItem.Volume
	$volumeTrim = $volumeRaw.Substring(22)
	add-content $file $volumeTrim
	add-content $file ""
	$mountvolitemdetected += 1
	Add-Member -InputObject $MountvolInformationCollected -MemberType NoteProperty -Name ($mountvolitemdetected) -Value (convert-MountvolInfoToTable $objItem)
}

$sectionDisplayOrder = 4
$sectionDescription = "Mountvol Information"
$MountvolInformationCollected | ConvertTo-Xml2 | update-diagreport -id $sectionDisplayOrder -name $sectionDescription


function convert-VolumeInfoToTable ($objvolume, $objdefraganalysis)
{
	$Table = "<table>"
	$Table += "<tr><td>Drive</td><td>" + $objvolume.DriveLetter + "</td></tr>"
	$Table += "<tr><td>File System</td><td>" + $objvolume.FileSystem + "</td></tr>"
	$Table += "<tr><td>Volume Size</td><td>" + "{0:0.00}GB" -f ($objdefraganalysis.VolumeSize/1GB) + "</td></tr>"
	$Table += "<tr><td>Free Space Percent</td><td>" + $objdefraganalysis.FreeSpacePercent + "</td></tr>"
	$Table += "<tr><td>Free Space Frag. Percent</td><td>" + $objdefraganalysis.FreeSpacePercentFragmentation + "</td></tr>"
	$Table += "<tr><td>Files</td><td>" + $objdefraganalysis.TotalFiles + "</td></tr>"
	$Table += "<tr><td>Fragmented Files</td><td>" + $objdefraganalysis.TotalFragmentedFiles + "</td></tr>"
	$Table += "<tr><td>File Fragmentation Percent</td><td>" + $objdefraganalysis.FilePercentFragmentation + "</td></tr>"
	$Table += "<tr><td>Folders</td><td>" + $objdefraganalysis.TotalFolders + "</td></tr>"
	$Table += "<tr><td>Fragmented Folders</td><td>" + $objdefraganalysis.FragmentedFolders + "</td></tr>"
	$Table += "<tr><td>MFT Usage Percent</td><td>" + $objdefraganalysis.MFTPercentInUse + "</td></tr>"
	$Table += "<tr><td>MFT Fragments</td><td>" + $objdefraganalysis.TotalMFTFragments + "</td></tr>"
	$Table += "<tr><td>MFT Records</td><td>" + $objdefraganalysis.MFTRecordCount + "</td></tr>"
	$Table += "<tr><td>PageFile Size</td><td>" + "{0:0.00}GB" -f ($objdefraganalysis.PageFileSize/1GB) + "</td></tr>"
	$Table += "<tr><td>PageFile Fragments</td><td>" + $objdefraganalysis.TotalPageFileFragments + "</td></tr>"
	$Table += "</table>"
	return $Table
}

$volumeInformationCollected = New-Object PSObject

add-content $file "------------------------------------"
add-content $file "Volume Information"
add-content $file "------------------------------------"
add-content $file ""

Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_Defrag -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_DefragDesc
# Defrag Info
$volumes = @(gwmi Win32_Volume -ComputerName $strComputer -Filter 'DriveType = 3')
  
foreach ($volume in $volumes) 
{
	$analysis = $volume.DefragAnalysis().DefragAnalysis
	add-content $file   "Drive               : $($volume.DriveLetter)"
	add-content $file  "File System         : $($volume.FileSystem)"
	add-content $file  ("Volume Size         : " + "{0:0.00}GB" -f ($analysis.VolumeSize/1GB))
	add-content $file  ""
	add-content $file  "Free Space          : $($analysis.FreeSpacePercent)%"
	add-content $file  ("Free Space Frag.    : " + "$($analysis.FreeSpacePercentFragmentation)%")
	add-content $file  ""
	add-content $file  "Files               : $($analysis.TotalFiles)"
	add-content $file  "Fragmented Files    : $($analysis.TotalFragmentedFiles)"
	add-content $file  "File Fragmentation  : $($analysis.FilePercentFragmentation)%"
	add-content $file  ""
	add-content $file  "Folders             : $($analysis.TotalFolders)"
	add-content $file  "Fragmented Folders  : $($analysis.FragmentedFolders)"
	add-content $file  ""
	add-content $file  "MFT Usage           : $($analysis.MFTPercentInUse)%"
	add-content $file  "MFT Fragments       : $($analysis.TotalMFTFragments)"
	add-content $file  "MFT Records         : $($analysis.MFTRecordCount)"
	add-content $file  ""
	add-content $file  ("PageFile Size       : " + "{0:0.00}GB" -f ($analysis.PageFileSize/1GB))
	add-content $file  "PageFile Fragments  : $($analysis.TotalPageFileFragments)"
	add-content $file  ""
	add-content $file  "----------------------------"
	$Driveletter = $volume.driveletter
	# checking for fragmentation
	If ($analysis.FilePercentFragmentation -gt "10")
	{
		$RC_DefragErrorDetected = $true
		$arrErrors += "ERROR: Volume $($volume.DriveLetter) needs to be defragmented for proper operation."
		$arrErrors += "------------------------------------"
		$arrErrors += ""
		#add-content $file "ERROR: Volume $($volume.DriveLetter) needs to be defragmented for proper operation."
		#add-content $file "------------------------------------"
		#add-content $file ""
	}

	$volumedetectednumber += 1

		Add-Member -InputObject $volumeInformationCollected -MemberType NoteProperty -Name $volumedetectednumber -Value (convert-VolumeInfoToTable -objvolume $volume -objDefragAnalysis $analysis)
}

$sectionDisplayOrder = 5
$sectionDescription = "Volume Information"
$volumeInformationCollected | ConvertTo-Xml2 | update-diagreport -id $sectionDisplayOrder -name $sectionDescription

# Checking cluster size vs size of volume 
 
Foreach ($volume in $volumes)
{
	if (($volume.filesystem -eq "NTFS" -and $volume.blocksize -gt 4096 -and $volume.Capacity -lt 2147483648) -or
	($volume.filesystem -eq "NTFS" -and $volume.blocksize -gt 8192 -and $volume.Capacity -lt 17592186044416) -or 
	($volume.filesystem -eq "NTFS" -and $volume.blocksize -gt 16536 -and $volume.Capacity -lt 35184372088832) -or
	($volume.filesystem -eq "NTFS" -and $volume.blocksize -gt 32768 -and $volume.Capacity -lt 70368744177664) -or
	($volume.filesystem -eq "NTFS" -and $volume.blocksize -gt 65536 -and $volume.Capacity -lt 140737488355328))
	{
		$RC_ClustersizeErrorDetected = $true
		add-content $file "VOLUME ERROR: $($volume.Driveletter) $($Volume.DriveLetter) -- The cluster size is too small for efficient VSS snapshot operation (see KB140365)."
		add-content $file  ""
		add-content $file  "----------------------------"
		$arrErrors += "VOLUME ERROR: $($volume.Driveletter) $($Volume.DriveLetter) -- The cluster size is too small for efficient VSS snapshot operation (see KB140365)."
		$arrErrors += "------------------------------------"
		$arrErrors += ""
	}
	# checking for the dirty bit being set and providing an error
	if ($volume.DirtyBitSet -eq "True")
	{
		$RC_DirtyBitErrorDetected = $true
		#add-content $file "ERROR: Run CHKDSK on volume $($volume.DriveLetter)"
		#add-content $file "------------------------------------"
		$arrErrors += "ERROR: Run CHKDSK on volume $($volume.DriveLetter)"
		$arrErrors += "------------------------------------"
		$arrErrors += ""
	}
}

Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_Provider -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_ProviderDesc

add-content $file "------------------------------------"
add-content $file "VSS Providers"
add-content $file "------------------------------------"
add-content $file ""

if((Get-WmiObject -Class Win32_OperatingSystem).ProductType -ge 2)
{
	$vssproviders = Get-WmiObject -computer $strComputer -Class Win32_ShadowProvider | Select Name, Version, CLSID

	foreach ($objItem in $vssproviders)
	{
		$ProviderName = $objItem.Name
		add-content $file "Name     : $ProviderName"

		$ProviderVersion = $objItem.Version
		add-content $file "Version  : $ProviderVersion"

		$providerCLSID = $objItem.CLSID
		add-content $file "CLSID    : $providerCLSID"
		add-content $file ""
	}
}

Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_VSSStorage  -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Obtaining_VSSStorageDesc

add-content $file "------------------------------------"
add-content $file "Listing Shadow Copy Storage"
add-content $file "------------------------------------"
add-content $file ""

if((Get-WmiObject -Class Win32_OperatingSystem).ProductType -ge 2)
{
	$shadowCount = Get-WmiObject -computer $strComputer -class win32_shadowcopy
	$ShadowStorage = Get-WmiObject -computer $strComputer -Class Win32_ShadowStorage | Select Volume, AllocatedSpace, DiffVolume, MaxSpace, UsedSpace
	#Collect writer information 
	$tmpdiskshadowscriptfile = join-path $pwd.path "tmpdiskshadowscriptfile.txt"

	"list writers detailed" | out-file $tmpdiskshadowscriptfile -encoding ASCII

	Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Writers -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_WritersDesc

	$fileDescription = "DiskShadow list writers detailed output"
	$sectionDescription = "VSS Writers"
	$DiskShadowOutputFile = join-path $pwd.path ($ComputerName + "_WriterMetaData.txt")
	$CommandToExecute = "cmd.exe /c diskshadow /s `"$tmpdiskshadowscriptfile`" /l `"$DiskShadowOutputFile`""
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $DiskShadowOutputFile -fileDescription $fileDescription 
	Remove-Item $tmpdiskshadowscriptfile
	
	$fileDescription = "VSSAdmin list writers output"
	$VSSAdminOutputFile = join-path $pwd.path ($ComputerName + "_List_Writers.txt")
	$CommandToExecute = "cmd.exe /c vssadmin list writers > `"$VSSAdminOutputFile`""
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $VSSAdminOutputFile -fileDescription $fileDescription 

	foreach ($objItem in $ShadowStorage)
	{
		$ShadowVolumeRaw = $objItem.Volume
		$ShadowVolume = $ShadowVolumeRaw.Substring(22)
		add-content $file "Volume              : $shadowVolume"

		$ShadowDiff = $objItem.DiffVolume
		add-content $file "Diff Voluem          : $shadowDiff"

		$ShadowAllocated = $objItem.AllocatedSpace /1mb
		add-content $file "Space Allocated      : $ShadowAllocated /Mb"

		$ShadowMaxSpaceRaw = $objItem.MaxSpace / 1mb
		add-content $file "Max Space            : $ShadowMaxSpace /Mb"

		$ShadowUsed = $objItem.UsedSpace / 1mb
		add-content $file "Used Space           : $ShadowUsed /Mb"

		add-content $file "Snapshots on System    : $($shadowCount.count)"

		add-content $file "------------------------------------"
	}

	add-content $file ""
	add-content $file "------------------------------------"
	add-content $file "Test SnapShot Creation"
	add-content $file "------------------------------------"
	add-content $file ""

	$ShadowCompleted = @()
	$ShadowErrors = @()
	$arrCSVPartitions = @()
	if (test-path "hklm:/cluster")
	{
		import-module failoverclusters
		$arrCSVPartitions = Get-ClusterSharedVolume | %{($_.sharedvolumeinfo | select -expandproperty partition).name}
	}
		
	## Create list of volumes that are NTFS
	$Snapvolumes = Get-WmiObject -computer $strComputer -class Win32_Volume | Where-object { $_.FileSystem -match "NTFS"}

	$snapvolumesInformationCollected = New-Object PSObject
	## Create snapshot for each volume that is listed in $snapvolumes
	Foreach ($volume in $snapvolumes)
	{
		if (-not ($arrCSVPartitions -contains (($volume.Name).tostring()).trimend("\")))
		{
			$createSnapshotString = $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Create_SnapshotDesc + ": " + $volume.Name
			#Write-DiagProgress -activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Create_Snapshot -status ($VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Create_SnapshotDesc -replace ("%VolumeName%", $volume.name))
			Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Create_Snapshot -Status $createSnapshotString
			$newsnap = (Get-WmiObject -computer $strComputer -list win32_shadowcopy).Create($volume.name,"ClientAccessible")

			if ($($newsnap.ReturnValue) -eq "0")
			{
				#Write to log if success
				Add-content $file "VSS Provider Test      : SUCCESS -- Volume:  $($volume.name) SnapShot ID:  $($newsnap.ShadowID)"
			}

			if ($($newsnap.ReturnValue) -ne "0")
			{
				Add-Content $file "VSS Provider Test      : Failed -- Volume:  $($volume.name)"
				$arrErrors += "VSS Provider Test      : Failed -- Volume:  $($volume.name)"
				$RC_VSSProviderErrorDetected = $true
				Add-Member -InputObject $snapvolumeInformationCollected -MemberType NoteProperty -Name $volume.name -Value "Error - Snapshot Creation Returned $newsnap.ReturnValue"
			}

			$colItems = Get-WmiObject -computer $strComputer -class Win32_ShadowCopy

			Foreach ($objItem in $colItems)
			{
				#Match the Shadow created above to an existing snapshot on the volume and delete
				If ($objItem.ID -match $newsnap.ShadowID)
				{
					$objItem.Delete()
				}
			}
		}
		else
		{
			Add-content $file "VSS Provider Test      : CSV Detected - skipping -- Volume:  $($volume.name)"
		}
	}

	add-content $file "------------------------------------"
	add-content $file "Listing VSS Service"
	add-content $file "------------------------------------"
	add-content $file ""

	$vssService = Get-Service -computer $strComputer VSS,eventsystem,CryptSvc,SWPRV,COMSysApp,VDS |
	select Name, Status

	foreach ($service in $vssService)
	{
		Add-Content $file "Service Name: $($service.Name) Status: $($Service.Status)"
	}

	add-content $file ""
	add-content $file "------------------------------------"
	add-content $file "Errors"
	add-content $file "------------------------------------"
	add-content $file ""

	Add-Content $file $arrErrors 

	$ServicesInformationCollected = New-Object PSObject
	function ServiceStartType($servicename,$Starttype)
	{
		$StartTemp = (Get-WmiObject -computer $strComputer -class Win32_Service -filter "Name='$servicename'").StartMode
		If ($StartTemp -ne $Starttype)
		{
			Add-content $file "SERVICE ERROR: $($servicename) service start type should be $($Starttype)"
			Add-Member -
			Add-Member -InputObject $ServicesInformationCollected -MemberType NoteProperty -Name $servicename -Value $StartTemp
			return $true
		}
		else
		{
			return $false
		}
	}

	$VSSIncorrectServiceStartType = ServiceStartType VSS Manual
	$SWPRVIncorrectServiceStartType = ServiceStartType SWPRV Manual
	$EventSystemIncorrectServiceStartType = ServiceStartType EventSystem Auto
	$COMSysAppIncorrectServiceStartType = ServiceStartType COMSysApp Manual
	$CryptSvcIncorrectServiceStartType = ServiceStartType CryptSvc Auto
	$VDSIncorrectServiceStartType = ServiceStartType VDS Manual    
	
	if ($VSSIncorrectServiceStartType -or $SWPRVIncorrectServiceStartType -or $EventSystemIncorrectServiceStartType -or $COMSysAppIncorrectServiceStartType -or $CryptSvcIncorrectServiceStartType -or $VDSIncorrectServiceStartType)
	{
		$RC_ServicesErrorDetected = $true
	}

	add-content $file "VSSPSS Version: $VSSPSSVersion"
}
else
{
	Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_Writers -Status $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_WritersDesc
	$sectionDescription = "VSS Writers"
	$fileDescription = "VSSAdmin list writers output"
	$VSSAdminOutputFile = join-path $pwd.path ($ComputerName + "_List_Writers.txt")
	$CommandToExecute = "cmd.exe /c vssadmin list writers > `"$VSSAdminOutputFile`""
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $VSSAdminOutputFile -fileDescription $fileDescription 
}

CollectFiles -filesToCollect $file -fileDescription $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_resultsreportfiledesc -sectionDescription $VSSBackupVSSPSSStrings.ID_VSSBackupPkg_VSSPSS_resultsreportsectiondesc

#Rule to detect VSS provider error
$RootCauseName = "RC_VSSPSS_ProviderError"
$InternalContent = "http://bemis.partners.extranet.microsoft.com/2718662"
$Verbosity = "Error"
$Visibility = "3"
$SupportTopicsID = "7993"
$SolutionTitle = $VSSBackupVSSPSSStrings.ID_VSSPSS_VSSProviderErrorSD

Write-DiagProgress -Activity $VSSBackupVSSPSSStrings.ID_VSSPSS_VSSProviderErrorTitle -Status $VSSBackupVSSPSSStrings.ID_VSSPSS_VSSProviderErrorDesc

if ($RC_VSSProviderErrorDetected -eq $true)
{
	# Red/ Yellow Light
	Update-DiagRootCause -id $RootCauseName -Detected $true
	Write-GenericMessage -RootCauseId $RootCauseName -InternalContentURL $InternalContent -InformationCollected $snapvolumeInformationCollected -Verbosity $Verbosity -Visibility $Visibility -SupportTopicsID $SupportTopicsID -SolutionTitle $SolutionTitle
}
else
{
	# Green Light
	Update-DiagRootCause -id $RootCauseName -Detected $false
}


# SIG # Begin signature block
# MIIdlQYJKoZIhvcNAQcCoIIdhjCCHYICAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQULGlpmhVdvCVlkLnaRsIPUKp0
# hdmgghhlMIIEwzCCA6ugAwIBAgITMwAAAMhHIp2jDcrAWAAAAAAAyDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODU0
# WhcNMTgwOTA3MTc1ODU0WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# Ojk4RkQtQzYxRS1FNjQxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoUNNyknhIcQy
# V4oQO4+cu9wdeLc624e9W0bwCDnHpdxJqtEGkv7f+0kYpyYk8rpfCe+H2aCuA5F0
# XoFWLSkOsajE1n/MRVAH24slLYPyZ/XO7WgMGvbSROL97ewSRZIEkFm2dCB1DRDO
# ef7ZVw6DMhrl5h8s299eDxEyhxrY4i0vQZKKwDD38xlMXdhc2UJGA0GZ16ByJMGQ
# zBqsuRyvxAGrLNS5mjCpogEtJK5CCm7C6O84ZWSVN8Oe+w6/igKbq9vEJ8i8Q4Vo
# hAcQP0VpW+Yg3qmoGMCvb4DVRSQMeJsrezoY7bNJjpicVeo962vQyf09b3STF+cq
# pj6AXzGVVwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFA/hZf3YjcOWpijw0t+ejT2q
# fV7MMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJqUDyiyB97jA9U9vp7HOq8LzCIfYVtQfJi5PUzJrpwzv6B7
# aoTC+iCr8QdiMG7Gayd8eWrC0BxmKylTO/lSrPZ0/3EZf4bzVEaUfAtChk4Ojv7i
# KCPrI0RBgZ0+tQPYGTjiqduQo2u4xm0GbN9RKRiNNb1ICadJ1hkf2uzBPj7IVLth
# V5Fqfq9KmtjWDeqey2QBCAG9MxAqMo6Epe0IDbwVUbSG2PzM+rLSJ7s8p+/rxCbP
# GLixWlAtuY2qFn01/2fXtSaxhS4vNzpFhO/z/+m5fHm/j/88yzRvQfWptlQlSRdv
# wO72Vc+Nbvr29nNNw662GxDbHDuGN3S65rjPsAkwggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TCCBhEwggP5
# oAMCAQICEzMAAACOh5GkVxpfyj4AAAAAAI4wDQYJKoZIhvcNAQELBQAwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMTAeFw0xNjExMTcyMjA5MjFaFw0xODAy
# MTcyMjA5MjFaMIGDMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24w
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDQh9RCK36d2cZ61KLD4xWS
# 0lOdlRfJUjb6VL+rEK/pyefMJlPDwnO/bdYA5QDc6WpnNDD2Fhe0AaWVfIu5pCzm
# izt59iMMeY/zUt9AARzCxgOd61nPc+nYcTmb8M4lWS3SyVsK737WMg5ddBIE7J4E
# U6ZrAmf4TVmLd+ArIeDvwKRFEs8DewPGOcPUItxVXHdC/5yy5VVnaLotdmp/ZlNH
# 1UcKzDjejXuXGX2C0Cb4pY7lofBeZBDk+esnxvLgCNAN8mfA2PIv+4naFfmuDz4A
# lwfRCz5w1HercnhBmAe4F8yisV/svfNQZ6PXlPDSi1WPU6aVk+ayZs/JN2jkY8fP
# AgMBAAGjggGAMIIBfDAfBgNVHSUEGDAWBgorBgEEAYI3TAgBBggrBgEFBQcDAzAd
# BgNVHQ4EFgQUq8jW7bIV0qqO8cztbDj3RUrQirswUgYDVR0RBEswSaRHMEUxDTAL
# BgNVBAsTBE1PUFIxNDAyBgNVBAUTKzIzMDAxMitiMDUwYzZlNy03NjQxLTQ0MWYt
# YmM0YS00MzQ4MWU0MTVkMDgwHwYDVR0jBBgwFoAUSG5k5VAF04KqFzc3IrVtqMp1
# ApUwVAYDVR0fBE0wSzBJoEegRYZDaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jcmwvTWljQ29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNybDBhBggrBgEF
# BQcBAQRVMFMwUQYIKwYBBQUHMAKGRWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2lvcHMvY2VydHMvTWljQ29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNydDAMBgNV
# HRMBAf8EAjAAMA0GCSqGSIb3DQEBCwUAA4ICAQBEiQKsaVPzxLa71IxgU+fKbKhJ
# aWa+pZpBmTrYndJXAlFq+r+bltumJn0JVujc7SV1eqVHUqgeSxZT8+4PmsMElSnB
# goSkVjH8oIqRlbW/Ws6pAR9kRqHmyvHXdHu/kghRXnwzAl5RO5vl2C5fAkwJnBpD
# 2nHt5Nnnotp0LBet5Qy1GPVUCdS+HHPNIHuk+sjb2Ns6rvqQxaO9lWWuRi1XKVjW
# kvBs2mPxjzOifjh2Xt3zNe2smjtigdBOGXxIfLALjzjMLbzVOWWplcED4pLJuavS
# Vwqq3FILLlYno+KYl1eOvKlZbiSSjoLiCXOC2TWDzJ9/0QSOiLjimoNYsNSa5jH6
# lEeOfabiTnnz2NNqMxZQcPFCu5gJ6f/MlVVbCL+SUqgIxPHo8f9A1/maNp39upCF
# 0lU+UK1GH+8lDLieOkgEY+94mKJdAw0C2Nwgq+ZWtd7vFmbD11WCHk+CeMmeVBoQ
# YLcXq0ATka6wGcGaM53uMnLNZcxPRpgtD1FgHnz7/tvoB3kH96EzOP4JmtuPe7Y6
# vYWGuMy8fQEwt3sdqV0bvcxNF/duRzPVQN9qyi5RuLW5z8ME0zvl4+kQjOunut6k
# LjNqKS8USuoewSI4NQWF78IEAA1rwdiWFEgVr35SsLhgxFK1SoK3hSoASSomgyda
# Qd691WZJvAuceHAJvDCCB3owggVioAMCAQICCmEOkNIAAAAAAAMwDQYJKoZIhvcN
# AQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAw
# BgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEx
# MB4XDTExMDcwODIwNTkwOVoXDTI2MDcwODIxMDkwOVowfjELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9zb2Z0IENvZGUg
# U2lnbmluZyBQQ0EgMjAxMTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AKvw+nIQHC6t2G6qghBNNLrytlghn0IbKmvpWlCquAY4GgRJun/DDB7dN2vGEtgL
# 8DjCmQawyDnVARQxQtOJDXlkh36UYCRsr55JnOloXtLfm1OyCizDr9mpK656Ca/X
# llnKYBoF6WZ26DJSJhIv56sIUM+zRLdd2MQuA3WraPPLbfM6XKEW9Ea64DhkrG5k
# NXimoGMPLdNAk/jj3gcN1Vx5pUkp5w2+oBN3vpQ97/vjK1oQH01WKKJ6cuASOrdJ
# Xtjt7UORg9l7snuGG9k+sYxd6IlPhBryoS9Z5JA7La4zWMW3Pv4y07MDPbGyr5I4
# ftKdgCz1TlaRITUlwzluZH9TupwPrRkjhMv0ugOGjfdf8NBSv4yUh7zAIXQlXxgo
# tswnKDglmDlKNs98sZKuHCOnqWbsYR9q4ShJnV+I4iVd0yFLPlLEtVc/JAPw0Xpb
# L9Uj43BdD1FGd7P4AOG8rAKCX9vAFbO9G9RVS+c5oQ/pI0m8GLhEfEXkwcNyeuBy
# 5yTfv0aZxe/CHFfbg43sTUkwp6uO3+xbn6/83bBm4sGXgXvt1u1L50kppxMopqd9
# Z4DmimJ4X7IvhNdXnFy/dygo8e1twyiPLI9AN0/B4YVEicQJTMXUpUMvdJX3bvh4
# IFgsE11glZo+TzOE2rCIF96eTvSWsLxGoGyY0uDWiIwLAgMBAAGjggHtMIIB6TAQ
# BgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQUSG5k5VAF04KqFzc3IrVtqMp1ApUw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAUci06AjGQQ7kUBU7h6qfHMdEjiTQwWgYDVR0f
# BFMwUTBPoE2gS4ZJaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0MjAxMV8yMDExXzAzXzIyLmNybDBeBggrBgEFBQcB
# AQRSMFAwTgYIKwYBBQUHMAKGQmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kv
# Y2VydHMvTWljUm9vQ2VyQXV0MjAxMV8yMDExXzAzXzIyLmNydDCBnwYDVR0gBIGX
# MIGUMIGRBgkrBgEEAYI3LgMwgYMwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvZG9jcy9wcmltYXJ5Y3BzLmh0bTBABggrBgEFBQcC
# AjA0HjIgHQBMAGUAZwBhAGwAXwBwAG8AbABpAGMAeQBfAHMAdABhAHQAZQBtAGUA
# bgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAZ/KGpZjgVHkaLtPYdGcimwuWEeFj
# kplCln3SeQyQwWVfLiw++MNy0W2D/r4/6ArKO79HqaPzadtjvyI1pZddZYSQfYtG
# UFXYDJJ80hpLHPM8QotS0LD9a+M+By4pm+Y9G6XUtR13lDni6WTJRD14eiPzE32m
# kHSDjfTLJgJGKsKKELukqQUMm+1o+mgulaAqPyprWEljHwlpblqYluSD9MCP80Yr
# 3vw70L01724lruWvJ+3Q3fMOr5kol5hNDj0L8giJ1h/DMhji8MUtzluetEk5CsYK
# wsatruWy2dsViFFFWDgycScaf7H0J/jeLDogaZiyWYlobm+nt3TDQAUGpgEqKD6C
# PxNNZgvAs0314Y9/HG8VfUWnduVAKmWjw11SYobDHWM2l4bf2vP48hahmifhzaWX
# 0O5dY0HjWwechz4GdwbRBrF1HxS+YWG18NzGGwS+30HHDiju3mUv7Jf2oVyW2ADW
# oUa9WfOXpQlLSBCZgB/QACnFsZulP0V3HjXG0qKin3p6IvpIlR+r+0cjgPWe+L9r
# t0uX4ut1eBrs6jeZeRhL/9azI2h15q/6/IvrC4DqaTuv/DDtBEyO3991bWORPdGd
# Vk5Pv4BXIqF4ETIheu9BCrE/+6jMpF3BoYibV3FWTkhFwELJm3ZbCoBIa/15n8G9
# bW1qyVJzEw16UM0xggSaMIIElgIBATCBlTB+MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5n
# IFBDQSAyMDExAhMzAAAAjoeRpFcaX8o+AAAAAACOMAkGBSsOAwIaBQCgga4wGQYJ
# KoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQB
# gjcCARUwIwYJKoZIhvcNAQkEMRYEFJcbQuPG73FTLz7aF+lVckF8SkN6ME4GCisG
# AQQBgjcCAQwxQDA+oCSAIgB2AHMAcwBfAEQAQwBfAFYAUwBTAFAAUwBTAC4AcABz
# ADGhFoAUaHR0cDovL21pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEAgwPI
# jzcG+WQyu2ANYRiPx5AShvmJaFqNeQK2xYGXNUiQlpAb87j775bXkutThiv3NPWS
# vUAUOtQPjVwW7wphK1X30XoZYasec9dBeAtoA31pZ1n1L2u2QBr1jpoh8/T5oPQq
# UCvv41z67kQvsh4hXg6vN7oJ+vVWEaJ4liqNdwIMn0fF2fs73rgfnGhhmyH/DCai
# Q1KCruRU1r7xlmD3puuCSQuJbwQ5BDR1G7f+B3ji3uoqnxKV6ajQcjkt+LyQsJlH
# H2+WGuN5Cb/CK69FvgZEZSXQsZdhr6D4wTFqy/VRoJbJBP+W4CZIruzxJB9xf32B
# Aoc63vBlfrRTqe6cq6GCAigwggIkBgkqhkiG9w0BCQYxggIVMIICEQIBATCBjjB3
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQDExhN
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0ECEzMAAADIRyKdow3KwFgAAAAAAMgwCQYF
# Kw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkF
# MQ8XDTE3MDUxMjE4MDU0NlowIwYJKoZIhvcNAQkEMRYEFN+Ew0uEOOeU1u5danaf
# peEAaTh8MA0GCSqGSIb3DQEBBQUABIIBAC78NI6A5o28Du+BeDAJmYpSIJoX48ck
# CkiP3LxRHClZT4AGF+AMwP/s9ClGCkk7k7l2zWKqCt/02KWEbb39+pYVf/CCJpu7
# NGJv0CKyFE2XKPA3jwJ+7pYaQiuM/x2LNqGwuWQKF3n/XUsusI9UFxrFiJI3LyLS
# Uomp0b6PoLQsqO1ypIZamNIx6Uz15wUv5MYZp6UyE4YTQJbJDqKVNGHtz5IlVg8P
# jrp1Li4y0p+oNW36rPLFDiOrRbPoLzY641WKzNf7Ketdwo6S3wjynYi/x2hC/1ks
# URSeG6G4DGTi2Z8+NCOW80bB3c4WSmSL4qzYjKFxnagfU+19qLuk+js=
# SIG # End signature block
