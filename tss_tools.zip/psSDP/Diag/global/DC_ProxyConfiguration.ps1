﻿#************************************************
# DC_ProxyConfiguration.ps1
# Version 1.0: Proxy Configuration for IE User, WinHTTP, Firewall Client, PAC Files, Network Isolation
# Version 1.1: Added Proxy Configuration for IE System
# Version 1.2 (4/28/14): Edited table of contents. 
# Create date: 12/5/2012
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects Proxy Configuration information from IE, WinHTTP and Forefront Firewall Client.
# Called from: Networking Diagnostics
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationIEUser -Status $ScriptVariable.ID_CTSProxyConfigurationIEUserDescription

$sectionDescription = "Proxy Configuration Information"
$OutputFile= $Computername + "_ProxyConfiguration.TXT"


#INTRO

	"====================================================" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"Proxy Configuration" 																| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"Overview"			 																| Out-File -FilePath $OutputFile -encoding ASCII -append
	"----------------------------------------------------" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"The Proxy Configuration script shows the proxy configuration of the following:"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  1. IE User Proxy Settings"														| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  2. IE System Proxy Settings" 													| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  3. WinHTTP Proxy Settings"														| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  4. BITS Proxy Settings" 															| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  5. TMG/ISA Firewall Client Settings" 											| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  6. Displays PAC file names and locations"										| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  7. Collects the PAC files on the system into a compressed file."					| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  8. Network Isolation settings" 													| Out-File -FilePath $OutputFile -encoding ASCII -append
	"===================================================="								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"																				| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"																				| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"																				| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"																				| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"																				| Out-File -FilePath $OutputFile -encoding ASCII -append
	

#IE
	#"[info]: Starting Proxy Configuration script" | WriteTo-StdOut
	# Check if ProxySettingsPerUser is set causing the IE settings to be read from HKLM
	if (test-path "HKLM:\Software\Policies\Windows\CurrentVersion\Internet Settings")
	{
		$ieProxyConfigProxySettingsPerUserP = (Get-ItemProperty -path "HKLM:\Software\Policies\Windows\CurrentVersion\Internet Settings").ProxySettingsPerUser
	}
	if (test-path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings")
	{
		$ieProxyConfigProxySettingsPerUserM = (Get-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxySettingsPerUser	
	}

	If ( ($ieProxyConfigProxySettingsPerUserP -eq 0) -or ($ieProxyConfigProxySettingsPerUserM -eq 0) )
	{
		#----------determine os architecture
		Function GetComputerArchitecture() 
		{ 
			if (($Env:PROCESSOR_ARCHITEW6432).Length -gt 0) #running in WOW 
			{ 
				$Env:PROCESSOR_ARCHITEW6432 
			} else { 
				$Env:PROCESSOR_ARCHITECTURE 
			} 
		}
		$OSArchitecture = GetComputerArchitecture
		# $OSArchitecture | WriteTo-StdOut

		if ($OSArchitecture -eq "AMD64")
		{
			#IE Proxy Config from HKLM
			$ieProxyConfigAutoConfigURL = (Get-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").AutoConfigURL
			$ieProxyConfigProxyEnable   = (Get-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyEnable
			$ieProxyConfigProxyServer   = (Get-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyServer
			$ieProxyConfigProxyOverride = (Get-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyOverride
			# Get list of regvalues in "HKLM\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"
			$ieConnections = (Get-Item -Path "Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections") | Select-Object -ExpandProperty Property
			$regHive = "HKLM (x64)"
		}
		if ($OSArchitecture -eq "x86")
		{
			#IE Proxy Config from HKLM
			$ieProxyConfigAutoConfigURL = (Get-ItemProperty -path "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings").AutoConfigURL
			$ieProxyConfigProxyEnable   = (Get-ItemProperty -path "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyEnable
			$ieProxyConfigProxyServer   = (Get-ItemProperty -path "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyServer
			$ieProxyConfigProxyOverride = (Get-ItemProperty -path "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyOverride
			
			# Get list of regvalues in "HKLM\Software\WOW6432Node\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"
			$ieConnections = (Get-Item -Path "Registry::HKEY_LOCAL_MACHINE\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings\Connections") | Select-Object -ExpandProperty Property
			$regHive = "HKLM (x86)"
		}
	}
	else
	{
		#IE Proxy Config from HKCU
		$ieProxyConfigAutoConfigURL = (Get-ItemProperty -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").AutoConfigURL
		$ieProxyConfigProxyEnable   = (Get-ItemProperty -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyEnable
		$ieProxyConfigProxyServer   = (Get-ItemProperty -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyServer
		$ieProxyConfigProxyOverride = (Get-ItemProperty -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyOverride

		# Get list of regvalues in "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"
		$ieConnections = (Get-Item -Path "Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections") | Select-Object -ExpandProperty Property
		$regHive = "HKCU"
	}

	#"[info]: ProxyServer array being created" | WriteTo-StdOut	
	#Find all entries in the Proxy Server Array
	if ($ieProxyConfigProxyServer -ne $null)
	{
		$ieProxyConfigProxyServerArray = ($ieProxyConfigProxyServer).Split(';')
		$ieProxyConfigProxyServerArrayLength = $ieProxyConfigProxyServerArray.length
	}
	
	#"[info]: ProxyOverride array being created" | WriteTo-StdOut	
	#Find all entries in Proxy Override Array
	if ($ieProxyConfigProxyOverride -ne $null)
	{
		[array]$ieProxyConfigProxyOverrideArray = ($ieProxyConfigProxyOverride).Split(';')
		$ieProxyConfigProxyOverrideArrayLength = $ieProxyConfigProxyOverrideArray.length
	}
	
	
	


	#"[info]: Starting Proxy Configuration: IE User Settings section" | WriteTo-StdOut
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: IE User Settings (" + $regHive + ")" 	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	
	for($i=0;$ieConnections[$i] -ne $null;$i++)
	{
		#IE Proxy Configuration Array: Detection Logic for each Connection
			[string]$ieConnection = $ieConnections[$i]

		
		# Main UI Checkboxes (3)
			$ieProxyConfigArray = (Get-ItemProperty -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections").$ieConnection
			[int]$ieProxyConfigUI = $ieProxyConfigArray[8]
			
			
		# Manual Proxy Server setting
			[int]$ieProxyConfigUIManualProxyOffset = 12
			[int]$ieProxyConfigUIManualProxyLength = $ieProxyConfigArray[$ieProxyConfigUIManualProxyOffset]
			[int]$ieProxyConfigUIManualProxyStart = $ieProxyConfigUIManualProxyOffset + 4
			[int]$ieProxyConfigUIManualProxyEnd = $ieProxyConfigUIManualProxyStart + $ieProxyConfigUIManualProxyLength
			# Convert decimal to ASCII string
			[string]$ieProxyConfigUIManualProxyValue = ""
			for ($j=$ieProxyConfigUIManualProxyStart;$j -lt $ieProxyConfigUIManualProxyEnd;$j++)
			{
				[string]$ieProxyConfigUIManualProxyValue = $ieProxyConfigUIManualProxyValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
			}
			# Split on semicolons
			$ieProxyConfigUIManualProxyValueArray = ($ieProxyConfigUIManualProxyValue).Split(';')
			$ieProxyConfigUIManualProxyValueArrayLength = $ieProxyConfigUIManualProxyValueArray.length


		# BypassProxy
			[int]$ieProxyConfigUIBypassProxyOffset = $ieProxyConfigUIManualProxyStart + $ieProxyConfigUIManualProxyLength
			[int]$ieProxyConfigUIBypassProxyLength = $ieProxyConfigArray[$ieProxyConfigUIBypassProxyOffset]
			[int]$ieProxyConfigUIBypassProxyStart  = $ieProxyConfigUIBypassProxyOffset + 4
			[int]$ieProxyConfigUIBypassProxyEnd    = $ieProxyConfigUIBypassProxyStart + $ieProxyConfigUIBypassProxyLength
			# Bypass Proxy Checkbox
			If ($ieProxyConfigUIBypassProxyLength -ne 0)
			{
				#BypassProxy Checked
				$ieProxyConfigUIBypassProxyEnabled = $true
			}
			else
			{
				#BypassProxy Unchecked
				$ieProxyConfigUIBypassProxyEnabled = $false
			}
			# Convert decimal to ASCII string
			[string]$ieProxyConfigUIBypassProxyValue = ""
			for ($j=$ieProxyConfigUIBypassProxyStart;$j -lt $ieProxyConfigUIBypassProxyEnd;$j++)
			{
				[string]$ieProxyConfigUIBypassProxyValue = $ieProxyConfigUIBypassProxyValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
			}
			# Split on semicolons
			$ieProxyConfigUIBypassProxyValueArray = ($ieProxyConfigUIBypassProxyValue).Split(';')
			$ieProxyConfigUIBypassProxyValueArrayLength = $ieProxyConfigUIBypassProxyValueArray.length
			
			
		#AutoConfig
			[int]$ieProxyConfigUIAutoConfigOffset = $ieProxyConfigUIBypassProxyStart + $ieProxyConfigUIBypassProxyLength
			[int]$ieProxyConfigUIAutoConfigLength = $ieProxyConfigArray[$ieProxyConfigUIAutoConfigOffset]
			[int]$ieProxyConfigUIAutoConfigStart  = $ieProxyConfigUIAutoConfigOffset + 4
			[int]$ieProxyConfigUIAutoConfigEnd    = $ieProxyConfigUIAutoConfigStart + $ieProxyConfigUIAutoConfigLength
			# Convert decimal to ASCII string
			[string]$ieProxyConfigUIAutoConfigValue = ""
			for ($j=$ieProxyConfigUIAutoConfigStart;$j -lt $ieProxyConfigUIAutoConfigEnd;$j++)
			{
				[string]$ieProxyConfigUIAutoConfigValue = $ieProxyConfigUIAutoConfigValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
			}
			# Split on semicolons
			$ieProxyConfigUIAutoConfigValueArray = ($ieProxyConfigUIAutoConfigValue).Split(';')
			$ieProxyConfigUIAutoConfigValueArrayLength = $ieProxyConfigUIAutoConfigValueArray.length

			

		If ($ieConnection -eq "DefaultConnectionSettings")
		{

			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"Local Area Network (LAN) Settings" 	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		}
		elseif ($ieConnection -eq "SavedLegacySettings")
		{
			# skipping SavedLegacySettings to trim output
			$i++
			[string]$ieConnection = $ieConnections[$i]
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		}
		else
		{
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		}
		

		" " + "Automatic Configuration"						| Out-File -FilePath $OutputFile -encoding ASCII -append
		# "Automatically detect settings:
			If ( ($ieProxyConfigUI -eq 9) -or ($ieProxyConfigUI -eq 11) -or ($ieProxyConfigUI -eq 13) -or ($ieProxyConfigUI -eq 15) )
			{
				"  " + "[X] Automatically detect settings:" | Out-File -FilePath $OutputFile -encoding ASCII -append
			}
			else
			{
				"  " + "[ ] Automatically detect settings:" | Out-File -FilePath $OutputFile -encoding ASCII -append
			}
		# "Use automatic configuration script:"
			If ( ($ieProxyConfigUI -eq 5) -or ($ieProxyConfigUI -eq 7) -or ($ieProxyConfigUI -eq 13) -or ($ieProxyConfigUI -eq 15) )
			{
				"  " + "[X] Use automatic configuration script:" | Out-File -FilePath $OutputFile -encoding ASCII -append
				"   " + "     " + "Address: "  | Out-File -FilePath $OutputFile -encoding ASCII -append
				# "   " + "            " + $ieProxyConfigAutoConfigURL
				
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				for ($j=0;$j -le $ieProxyConfigUIAutoConfigValueArrayLength;$j++)
				{
					"    " + "            " + $ieProxyConfigUIAutoConfigValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
				}
			}
			else
			{
				"  " + "[ ] Use automatic configuration script:" | Out-File -FilePath $OutputFile -encoding ASCII -append
				"   " + "     " + "Address: " | Out-File -FilePath $OutputFile -encoding ASCII -append
			}
		" " + "Proxy Server"								| Out-File -FilePath $OutputFile -encoding ASCII -append
		# "Use a proxy server for your LAN (These settings will not apply to dial-up or VPN connections)."
			If ( ($ieProxyConfigUI -eq 3) -or ($ieProxyConfigUI -eq 7) -or ($ieProxyConfigUI -eq 11) -or ($ieProxyConfigUI -eq 15) )
			{
				# MANUAL PROXY (from Connection)
				"  " + "[X] Use a proxy server for your LAN (These settings will not apply " | Out-File -FilePath $OutputFile -encoding ASCII -append
				If ($ieConnection -eq "DefaultConnectionSettings")
				{
					"  " + "    to dial-up or VPN connections)."		| Out-File -FilePath $OutputFile -encoding ASCII -append
				}
				else
				{
					"  " + "    to other connections)."					| Out-File -FilePath $OutputFile -encoding ASCII -append
				}
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"   " + "     Address: and Port:   " | Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				for ($j=0;$j -le $ieProxyConfigUIManualProxyValueArrayLength;$j++)
				{
					"    " + "            " + $ieProxyConfigUIManualProxyValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
				}

				# BYPASS PROXY (from Connection)
				If ($ieProxyConfigUIBypassProxyEnabled -eq $true)
				{
				"    " + "   [X] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"    " + "        Exceptions: "	| Out-File -FilePath $OutputFile -encoding ASCII -append
					"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					for ($j=0;$j -le $ieProxyConfigUIBypassProxyValueArrayLength;$j++)
					{
						"    " + "            " + $ieProxyConfigUIBypassProxyValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
					}
				}
				else
				{
				"    " + "   [ ] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"    " + "        Exceptions: "  							| Out-File -FilePath $OutputFile -encoding ASCII -append
				}
			}
			else
			{
				"  " + "[ ] Use a proxy server for your LAN (These settings will not apply to" | Out-File -FilePath $OutputFile -encoding ASCII -append
				"  " + "    dial-up or VPN connections)."					| Out-File -FilePath $OutputFile -encoding ASCII -append
				"   " + "    Address:Port "									| Out-File -FilePath $OutputFile -encoding ASCII -append
				"    " + "   [ ] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"    " + "        Exceptions: "  							| Out-File -FilePath $OutputFile -encoding ASCII -append
			}
	}





Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationIESystem -Status $ScriptVariable.ID_CTSProxyConfigurationIESystemDescription

	#----------Proxy Configuration: IE System Settings: Initialization
		#"[info]: ProxyConfiguration: IE System Settings: Initialization" | WriteTo-StdOut 	
		$regHive = "HKEY_USERS\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings"

	
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 				| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: IE System Settings (" + $regHive + ")" 		| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 				| Out-File -FilePath $OutputFile -encoding ASCII -append


	#----------
	# Verifying HKU is in the psProviderList. If not, add it
	#----------
		#
		# HKU may not be in the psProviderList, so we need to add it so we can reference it
		#
		#"[info]: Checking the PSProvider list because we need HKU" | WriteTo-StdOut
		$psProviderList = Get-PSDrive -PSProvider Registry
		$psProviderListLen = $psProviderList.length
		for ($i=0;$i -le $psProviderListLen;$i++)
		{
			if (($psProviderList[$i].Name) -eq "HKU")
			{
				$hkuExists = $true
				$i = $psProviderListLen
			}
			else
			{
				$hkuExists = $false
			}
		}
		if ($hkuExists -eq $false)
		{
			#"[info]: Creating a new PSProvider to enable access to HKU" | WriteTo-StdOut
			[void]( New-PSDrive -Name HKU -PSProvider Registry -Root Registry::HKEY_USERS)
		}

	#----------
	# Verify "\Internet Settings\Connections" exists, if not display message that IE System Context is not configured.
	#   $ieConnectionsCheck and associated code block added 10/11/2013
	#----------
	#$ieConnections = $null
	# Get list of regvalues in "HKEY_USERS\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"		
	$ieConnectionsCheck = Test-path "HKU:\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"
	
	if ($ieConnectionsCheck -eq $true)
	{
		$ieConnections = (Get-Item -Path "Registry::HKEY_USERS\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections") | Select-Object -ExpandProperty Property
		
		for($i=0;$ieConnections[$i] -ne $null;$i++)
		{
			#IE Proxy Configuration Array: Detection Logic for each Connection
				[string]$ieConnection = $ieConnections[$i]

			#"[info]: Get-ItemProperty on HKU registry location." | WriteTo-StdOut
			# Main UI Checkboxes (3)
				[array]$ieProxyConfigArray = $null
				[array]$ieProxyConfigArray = (Get-ItemProperty -path "HKU:\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections").$ieConnection
				[int]$ieProxyConfigUI = $ieProxyConfigArray[8]
				
			#"[info]: Retrieving manual proxy server setting." | WriteTo-StdOut
			# Manual Proxy Server setting
				[int]$ieProxyConfigUIManualProxyOffset = 12
				[int]$ieProxyConfigUIManualProxyLength = $ieProxyConfigArray[$ieProxyConfigUIManualProxyOffset]
				[int]$ieProxyConfigUIManualProxyStart = $ieProxyConfigUIManualProxyOffset + 4
				[int]$ieProxyConfigUIManualProxyEnd = $ieProxyConfigUIManualProxyStart + $ieProxyConfigUIManualProxyLength
				# Convert decimal to ASCII string
				[string]$ieProxyConfigUIManualProxyValue = ""
				for ($j=$ieProxyConfigUIManualProxyStart;$j -lt $ieProxyConfigUIManualProxyEnd;$j++)
				{
					[string]$ieProxyConfigUIManualProxyValue = $ieProxyConfigUIManualProxyValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
				}
				# Split on semicolons
				$ieProxyConfigUIManualProxyValueArray = ($ieProxyConfigUIManualProxyValue).Split(';')
				$ieProxyConfigUIManualProxyValueArrayLength = $ieProxyConfigUIManualProxyValueArray.length

			#"[info]: Retrieving BypassProxy setting." | WriteTo-StdOut
			# BypassProxy
				[int]$ieProxyConfigUIBypassProxyOffset = $ieProxyConfigUIManualProxyStart + $ieProxyConfigUIManualProxyLength
				[int]$ieProxyConfigUIBypassProxyLength = $ieProxyConfigArray[$ieProxyConfigUIBypassProxyOffset]
				[int]$ieProxyConfigUIBypassProxyStart  = $ieProxyConfigUIBypassProxyOffset + 4
				[int]$ieProxyConfigUIBypassProxyEnd    = $ieProxyConfigUIBypassProxyStart + $ieProxyConfigUIBypassProxyLength
				# Bypass Proxy Checkbox
				If ($ieProxyConfigUIBypassProxyLength -ne 0)
				{
					#BypassProxy Checked
					$ieProxyConfigUIBypassProxyEnabled = $true
				}
				else
				{
					#BypassProxy Unchecked
					$ieProxyConfigUIBypassProxyEnabled = $false
				}
				# Convert decimal to ASCII string
				[string]$ieProxyConfigUIBypassProxyValue = ""
				for ($j=$ieProxyConfigUIBypassProxyStart;$j -lt $ieProxyConfigUIBypassProxyEnd;$j++)
				{
					[string]$ieProxyConfigUIBypassProxyValue = $ieProxyConfigUIBypassProxyValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
				}
				# Split on semicolons
				$ieProxyConfigUIBypassProxyValueArray = ($ieProxyConfigUIBypassProxyValue).Split(';')
				$ieProxyConfigUIBypassProxyValueArrayLength = $ieProxyConfigUIBypassProxyValueArray.length
				
			#"[info]: Retrieving AutoConfig setting." | WriteTo-StdOut			
			#AutoConfig
				[int]$ieProxyConfigUIAutoConfigOffset = $ieProxyConfigUIBypassProxyStart + $ieProxyConfigUIBypassProxyLength
				[int]$ieProxyConfigUIAutoConfigLength = $ieProxyConfigArray[$ieProxyConfigUIAutoConfigOffset]
				[int]$ieProxyConfigUIAutoConfigStart  = $ieProxyConfigUIAutoConfigOffset + 4
				[int]$ieProxyConfigUIAutoConfigEnd    = $ieProxyConfigUIAutoConfigStart + $ieProxyConfigUIAutoConfigLength
				# Convert decimal to ASCII string
				[string]$ieProxyConfigUIAutoConfigValue = ""
				for ($j=$ieProxyConfigUIAutoConfigStart;$j -lt $ieProxyConfigUIAutoConfigEnd;$j++)
				{
					[string]$ieProxyConfigUIAutoConfigValue = $ieProxyConfigUIAutoConfigValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
				}
				# Split on semicolons
				$ieProxyConfigUIAutoConfigValueArray = ($ieProxyConfigUIAutoConfigValue).Split(';')
				$ieProxyConfigUIAutoConfigValueArrayLength = $ieProxyConfigUIAutoConfigValueArray.length

				

			If ($ieConnection -eq "DefaultConnectionSettings")
			{

				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"Local Area Network (LAN) Settings" 	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			}
			elseif ($ieConnection -eq "SavedLegacySettings")
			{
				# skipping SavedLegacySettings to trim output
				$i++
				[string]$ieConnection = $ieConnections[$i]
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			}
			else
			{
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			}
			

			" " + "Automatic Configuration"						| Out-File -FilePath $OutputFile -encoding ASCII -append
			# "Automatically detect settings:
				If ( ($ieProxyConfigUI -eq 9) -or ($ieProxyConfigUI -eq 11) -or ($ieProxyConfigUI -eq 13) -or ($ieProxyConfigUI -eq 15) )
				{
					"  " + "[X] Automatically detect settings:" | Out-File -FilePath $OutputFile -encoding ASCII -append
				}
				else
				{
					"  " + "[ ] Automatically detect settings:" | Out-File -FilePath $OutputFile -encoding ASCII -append
				}
			# "Use automatic configuration script:"
				If ( ($ieProxyConfigUI -eq 5) -or ($ieProxyConfigUI -eq 7) -or ($ieProxyConfigUI -eq 13) -or ($ieProxyConfigUI -eq 15) )
				{
					"  " + "[X] Use automatic configuration script:" | Out-File -FilePath $OutputFile -encoding ASCII -append
					"   " + "     " + "Address: "  | Out-File -FilePath $OutputFile -encoding ASCII -append
					# "   " + "            " + $ieProxyConfigAutoConfigURL
					
					"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					for ($j=0;$j -le $ieProxyConfigUIAutoConfigValueArrayLength;$j++)
					{
						"    " + "            " + $ieProxyConfigUIAutoConfigValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
					}
				}
				else
				{
					"  " + "[ ] Use automatic configuration script:" | Out-File -FilePath $OutputFile -encoding ASCII -append
					"   " + "     " + "Address: " | Out-File -FilePath $OutputFile -encoding ASCII -append
				}
			" " + "Proxy Server"								| Out-File -FilePath $OutputFile -encoding ASCII -append
			# "Use a proxy server for your LAN (These settings will not apply to dial-up or VPN connections)."
				If ( ($ieProxyConfigUI -eq 3) -or ($ieProxyConfigUI -eq 7) -or ($ieProxyConfigUI -eq 11) -or ($ieProxyConfigUI -eq 15) )
				{
					# MANUAL PROXY (from Connection)
					"  " + "[X] Use a proxy server for your LAN (These settings will not apply " | Out-File -FilePath $OutputFile -encoding ASCII -append
					If ($ieConnection -eq "DefaultConnectionSettings")
					{
						"  " + "    to dial-up or VPN connections)."		| Out-File -FilePath $OutputFile -encoding ASCII -append
					}
					else
					{
						"  " + "    to other connections)."					| Out-File -FilePath $OutputFile -encoding ASCII -append
					}
					"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					"   " + "     Address: and Port:   " | Out-File -FilePath $OutputFile -encoding ASCII -append
					"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					for ($j=0;$j -le $ieProxyConfigUIManualProxyValueArrayLength;$j++)
					{
						"    " + "            " + $ieProxyConfigUIManualProxyValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
					}

					# BYPASS PROXY (from Connection)
					If ($ieProxyConfigUIBypassProxyEnabled -eq $true)
					{
					"    " + "   [X] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					"    " + "        Exceptions: "	| Out-File -FilePath $OutputFile -encoding ASCII -append
						"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
						for ($j=0;$j -le $ieProxyConfigUIBypassProxyValueArrayLength;$j++)
						{
							"    " + "            " + $ieProxyConfigUIBypassProxyValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
						}
					}
					else
					{
					"    " + "   [ ] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					"    " + "        Exceptions: "  | Out-File -FilePath $OutputFile -encoding ASCII -append
					}
				}
				else
				{
					"  " + "[ ] Use a proxy server for your LAN (These settings will not apply to" | Out-File -FilePath $OutputFile -encoding ASCII -append
					"  " + "    dial-up or VPN connections)."					| Out-File -FilePath $OutputFile -encoding ASCII -append
					"   " + "    Address:Port "									| Out-File -FilePath $OutputFile -encoding ASCII -append
					"    " + "   [ ] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					"    " + "        Exceptions: "  | Out-File -FilePath $OutputFile -encoding ASCII -append
				}
		}
	}
	

	Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationWinHTTP -Status $ScriptVariable.ID_CTSProxyConfigurationWinHTTPDescription
	#"[info]: ProxyConfiguration: WinHTTP" | WriteTo-StdOut 	
#WinHTTP
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: WinHTTP" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	
	
	Function RunNetSH ([string]$NetSHCommandToExecute="")
	{
		$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
		"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"netsh $NetSHCommandToExecute"		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + "| Out-File -FilePath $OutputFile -encoding ASCII -append"
		RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	}
	RunNetSH -NetSHCommandToExecute "winhttp show proxy"





#BITS
	# update for BITS proxy: Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationWinHTTP -Status $ScriptVariable.ID_CTSProxyConfigurationWinHTTPDescription
	#"[info]: ProxyConfiguration: BITS" | WriteTo-StdOut 	

	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: BITS" 									| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append

	function RunBitsAdmin ([string]$BitsAdminCommandToExecute="")
	{
		$BitsAdminCommandToExecuteLength = $BitsAdminCommandToExecute.Length + 6
		"-" * ($BitsAdminCommandToExecuteLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"bitsadmin $BitsAdminCommandToExecute"		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"-" * ($BitsAdminCommandToExecuteLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		$CommandToExecute = "cmd.exe /c bitsadmin.exe " + $BitsAdminCommandToExecute + "| Out-File -FilePath $OutputFile -encoding ASCII -append"
		RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	}
	RunBitsAdmin -BitsAdminCommandToExecute " /util /getieproxy localsystem"
	RunBitsAdmin -BitsAdminCommandToExecute " /util /getieproxy networkservice"
	RunBitsAdmin -BitsAdminCommandToExecute " /util /getieproxy localservice"




	

#Firewall Client
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationFirewallClient -Status $ScriptVariable.ID_CTSProxyConfigurationFirewallClientDescription
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: Firewall Client" 						| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append

	#----- Is the Firewall Client installed?
	$processActive = Get-Process fwcagent -ErrorAction SilentlyContinue
	if ($processActive -ne $null)
	{
		"The Firewall Client appears to be installed. Gathering output."	| Out-File -FilePath $OutputFile -encoding ASCII -append
		" "	| Out-File -FilePath $OutputFile -encoding ASCII -append
		" "	| Out-File -FilePath $OutputFile -encoding ASCII -append
		$firewallClientProcessPath = (get-process fwcagent).path
		$firewallClientProcess = $firewallClientProcessPath.substring(0,$firewallClientProcessPath.Length-12) + "fwctool.exe"
		$firewallClientProcess
		$firewallClientArgs  = " printconfig"
		$firewallClientCmd = "`"" + $firewallClientProcess + "`"" + $firewallClientArgs
		$firewallClientCmdLength = $firewallClientCmd.length
		# Output header and command that will be run
		"`n" + "-" * ($firewallClientCmdLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n" + "`"" + $firewallClientProcess + " " + $firewallClientArgs + "`""		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n" + "-" * ($firewallClientCmdLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		# Run the command
		$CommandToExecute = "cmd.exe /c " + $firewallClientCmd + " | Out-File -FilePath $OutputFile -encoding ASCII -append"
		RunCmD -commandToRun $CommandToExecute -CollectFiles $false
	}
	else
	{
		"The Firewall Client is not installed."	| Out-File -FilePath $OutputFile -encoding ASCII -append
	}


	
	
	

#PAC files	
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationPACFiles -Status $ScriptVariable.ID_CTSProxyConfigurationPACFilesDescription

	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: PAC Files" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append

	# Where are PAC files referenced?
	# HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad

	#-----PAC files
	#  Outside of SDP    = Inside SDP
	#  "c:\users\bbenson = $env:USERPROFILE + "
	#  "c:\windows       = $env:windir + "
	#
	#-----array*.script and wpad*.dat files in User Profile
	$pacUserProfPath = $env:USERPROFILE + "\AppData\Local\Microsoft\Windows\Temporary Internet Files\*"
	# Added Sort-Object to sort the array on creation
	#   | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
	if (Test-Path $pacUserProfPath)
	{
		[array]$pacUserProf = Get-ChildItem $pacUserProfPath  -include array*.script,wpad*.dat -force -recurse | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
		$pacUserProfLen = $pacUserProf.length
		if ($pacUserProfLen -eq $null)  
		{
			$pacUserProfLen = 0
		}
		else
		{
			if ($pacUserProfLen -ne 0)
			{
				[array]$pacArray = [array]$pacUserProf
				$pacArrayLen = $pacArray.length
			}
		}
	}
	#-----array*.script and wpad*.dat files in Windir Sys32
	$pacWindirSys32Path = $env:windir + "\System32\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\*"
	# Added Sort-Object to sort the array on creation
	#   | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
	if (Test-Path $pacWindirSys32Path)
	{
		[array]$pacWindirSys32 = Get-ChildItem $pacWindirSys32Path -include array*.script,wpad*.dat -force -recurse | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
		$pacWindirSys32Len = $pacWindirSys32.length
		if ($pacWindirSys32Len -eq $null)
		{
			$pacWindirSys32Len = 0
		}
		else
		{
			if ($pacWindirSys32Len -ne 0)
			{
				[array]$pacArray = [array]$pacArray + [array]$pacWindirSys32
				$pacArrayLen = $pacArray.length
			}
		}
	}
	#-----array*.script and wpad*.dat files in Windir Syswow64
	$pacWindirSysWow64Path = $env:windir + "\SysWOW64\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\*"
	# Added Sort-Object to sort the array on creation
	#   | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
	if  (Test-Path $pacWindirSysWow64Path)
	{
		[array]$pacWindirSysWow64 = Get-ChildItem $pacWindirSysWow64Path -include array*.script,wpad*.dat -force –recurse  | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
		$pacWindirSysWow64Len = $pacWindirSysWow64.length
		if ($pacWindirSysWow64Len -eq $null)
		{
			$pacWindirSysWow64Len = 0
		}
		else
		{
			if ($pacWindirSysWow64Len -ne 0)
			{
				[array]$pacArray = [array]$pacArray + [array]$pacWindirSysWow64
				$pacArrayLen = $pacArray.length
			}
		}
	}
	#-----Engineer message indicating where the script searched for the files.
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"Searching for PAC files named wpad*.dat or array*.script in the following locations: " | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"  %userprofile%\AppData\Local\Microsoft\Windows\Temporary Internet Files\*" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"  %windir%\System32\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\*" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"  %windir%\SysWOW64\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\*" | Out-File -FilePath $OutputFile -encoding ASCII -append
		
		# dir "%userprofile%\AppData\Local\Microsoft\Windows\Temporary Internet Files\wpad*.dat" /s
		# dir "%userprofile%\AppData\Local\Microsoft\Windows\Temporary Internet Files\array*.script" /s
		# dir "%windir%\System32\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\wpad*.dat" /s
		# dir "%windir%\System32\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\array*.script" /s
		# dir "%windir%\SysWOW64\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\wpad*.dat" /s
		# dir "%windir%\SysWOW64\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\array*.script" /s


	if ($pacArrayLen -eq $null)
	{
		$pacArrayLen = 0
	}
	#-----Display the array
	if ($pacArrayLen -eq 0)
	{
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"Found " + $pacArrayLen + " PAC files." | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"There are " + $pacArrayLen + " PAC files named wpad*.dat or array*.script located within `"Temporary Internet Files`" for the user and/or the system." | Out-File -FilePath $OutputFile -encoding ASCII -append
	}
	elseif ($pacArrayLen -eq 1)
	{
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"Found " + $pacArrayLen + " PAC file." | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		
		#-----Show FullName, LastWriteTime and LastAccessTime
		for($i=0;$i -lt $pacArrayLen;$i++)
		{
			" " | Out-File -FilePath $OutputFile -encoding ASCII -append
			"[#" + ($i+1) + "]" | Out-File -FilePath $OutputFile -encoding ASCII -append
			"FullName        : " + ($pacArray[$i]).FullName | Out-File -FilePath $OutputFile -encoding ASCII -append
			# "LastWriteTime   : " + ($pacArray[$i]).LastWriteTime | Out-File -FilePath $OutputFile -encoding ASCII -append
			"LastAccessTime  : " + ($pacArray[$i]).LastAccessTime | Out-File -FilePath $OutputFile -encoding ASCII -append
			" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		}
	}
	elseif ($pacArrayLen -gt 1)
	{
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"Found " + $pacArrayLen + " PAC files (in descending showing the most recent LastAccessTime first)" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		
		#-----Show FullName, LastWriteTime and LastAccessTime
		for($i=0;$i -lt $pacArrayLen;$i++)
		{
			# Sort the array by LastAccessTime
			$pacArray | sort LastAccessTime -Descending
			
			# Text Output with no sorting
			" " | Out-File -FilePath $OutputFile -encoding ASCII -append
			"[#" + ($i+1) + "]" | Out-File -FilePath $OutputFile -encoding ASCII -append
			"FullName        : " + ($pacArray[$i]).FullName | Out-File -FilePath $OutputFile -encoding ASCII -append
			#"LastWriteTime   : " + ($pacArray[$i]).LastWriteTime | Out-File -FilePath $OutputFile -encoding ASCII -append
			"LastAccessTime  : " + ($pacArray[$i]).LastAccessTime | Out-File -FilePath $OutputFile -encoding ASCII -append
			" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		}
	}

	If ($pacArrayLen -gt 0)
	{
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		"------------------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"Collecting PAC files" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"------------------------" | Out-File -FilePath $OutputFile -encoding ASCII -append

		# Initialize array for PAC files with FullName
		for ($i=0;$i -lt $pacArrayLen;$i++)  { $pacFilesArray += @($i) }
		
		# Create array of PAC Files with FullName
		for ($i=0;$i -lt $pacArrayLen;$i++)
		{
			$pacFilesArray[$i] = "`"" + ($pacArray[$i]).FullName + "`""
			$pacFilesArray[$i]	| Out-File -FilePath $OutputFile -encoding ASCII -append
			#copy to temp dir
			$CommandToExecute = "cmd.exe /c copy " + $pacFilesArray[$i] + " " + $PWD
			RunCmD -commandToRun $CommandToExecute -CollectFiles $false
		}
		# This function fails because of file not found, but I know the file exists. Probably because of [] in name.
		# CollectFiles -filesToCollect $pacFilesArray[$i]
		
		#Collect PAC files
		$destFileName = $env:COMPUTERNAME + "_Proxy-PACFiles.zip"
		# CollectFiles -filesToCollect $pacFilesArray
		$pacFilesWpadDat = join-path $PWD "wpad*.dat"
		$pacFilesArrScript = join-path $PWD "array*.script"
		CompressCollectFiles -filestocollect $pacFilesWpadDat -DestinationFileName $destFileName
		CompressCollectFiles -filestocollect $pacFilesArrScript -DestinationFileName $destFileName
	}





#Network Isolation Policies
	"`n`n`n`n`n`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"Network Isolation Policy Configuration (W8/WS2012+)" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	
	
	if (test-path HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation)
	{
		$netIsolationDomainLocalProxies 	= (Get-ItemProperty -path "HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation").DomainLocalProxies
		$netIsolationDomainProxies 			= (Get-ItemProperty -path "HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation").DomainProxies
		$netIsolationDomainSubnets 			= (Get-ItemProperty -path "HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation").DomainSubnets	
		$netIsolationDProxiesAuthoritive 	= (Get-ItemProperty -path "HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation").DProxiesAuthoritive
		$netIsolationDSubnetsAuthoritive 	= (Get-ItemProperty -path "HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation").DSubnetsAuthoritive
		
		"RegKey  : HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegValue: DomainLocalProxies" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegData : " + $netIsolationDomainLocalProxies 		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegValue: DomainProxies" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegData : " + $netIsolationDomainProxies | Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegValue: DomainSubnets" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegData : " + $netIsolationDomainSubnets 				| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegValue: DProxiesAuthoritive" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegData : " + $netIsolationDProxiesAuthoritive 		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegValue: DSubnetsAuthoritive" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegData : " + $netIsolationDSubnetsAuthoritive 		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	}
	else
	{
		"Network Isolation policies are not configured.  This location does not exist: HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation" | Out-File -FilePath $OutputFile -encoding ASCII -append
	}

CollectFiles -filesToCollect $OutputFile -fileDescription "Proxy Configuration Information" -SectionDescription $sectionDescription

# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDn4ZtMWr9CYWar
# 3Qr+S9SOu9yM1QQrNtYROyvLuxKjYKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgqcVX7HWR
# 1wVwm12dIsmDb/1kBkiF3U3N8EWmifgObcswOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAC3JZMQKoDf5IUaYh8ry1o0r16sR7uL2OrgYsR0EovaK64FtecTQJrAH
# 0eekSwfRbB2JTQJf4rRJq0I7EPQ4piNNHqufG9ZNDNxDTwUxPYyAX0Qk1GBsu3j9
# +chqpDubegsEXcJgRjs0hDw9PxXdrnMqBbsbhFt+e8XhXJXKPPQo8OnhpUaqXfPc
# 4ba3IuJuE2NPs6ySeyyjy5wPNUXDcAhKcIpTilwPiV7oumsRt1A/bHwUjWynUv5e
# o0qJUgqNdZcUCdKfoDUSYoHnA2LMzG/+zfqbJmYDEpia83hqii0Yfo9J5B9U7kmt
# GnF4IcmNe6CMx/11oclXkkQMQsAS+gWhghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgYmD1S3oFNBHQt2BVycqxA9aV99Xj851RDgSBSHlslycCBmCKzjK5
# kRgTMjAyMTA1MTkyMjIyNTMuOTYxWjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjowODQyLTRCRTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABOczo6EOL8DThAAAAAAE5MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyMVoXDTIyMDExMjE3MjgyMVowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MDg0Mi00
# QkU2LUMyOUExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDaE/mM4yWTJaGOsyoG/KJ4
# +FofmDdPf1DB27oeoCdZwuXP39kqgL9AXPjmBvRp3Xgi+oVoWbYnqj6+GFt/ihAk
# 4cNNyNlcEpBNtBP/DosJa90JecVCXZrycR3jYSYTuvFFWYq6ZsegQpX5DBh0ZzvS
# rk7wzZiSon9K1ysWEW2aEXFy9Vn6CDhrPO8Tzv6ygjNhXrOozYpY79NLL1l6iLlf
# hChtXoAq7AkfTzJJnaVAFfOd3yvAPPLr4FioleKb5v5X7sTfvjVvpxD1+Y40Ckcu
# GQaqjTv8HXg2Qaqo73vyECNe1WhCkqMq7rLFfOyylCePSuV+xX8fJJb+X6LPHspP
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQUmZ6bhnJUwpnakoqxn0b2UC0GDOkwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAWFwoavP/NxqFzcFa7UOCiL8QDbEm+7r2
# EYiToW0g8ddYyK5Wa1FAd/ynJD1qyc/Zxx9HP90yqXKT+rz4g1wIsQSWlKCb3XG4
# IVhsWECEsm2ijN/fxofmtjZnFY31u4MSScl+IaIrpD7ySQI1aZtaPYPFHAQXwh8H
# CMXsQ+FgOB2KUrPjzq7CGCiyivUa4NaKViMagw2reWvAMiRj/zcpSkmGiuWmIF2Q
# g0SxWQJ/PIQuZ70Le1qZm0xJfGtRnBfpat/d1JgQCrLfo8lkmuLBPCG/OMh6oPx4
# rNRSHe58Tb8SMQBtpsGEKjb61SjKdPpMAm2N2K9riDs/vf9VCtJwxzCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjowODQyLTRCRTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUADU2U/hveloSNdD8d7koExrNljAeggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAORPqfUwIhgPMjAyMTA1MTkyMzE1MDFaGA8yMDIxMDUyMDIzMTUwMVowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5E+p9QIBADAKAgEAAgIkDwIB/zAHAgEAAgIR
# vDAKAgUA5FD7dQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAEX5vNFqxbZd
# 1WiwOPX6h0I2ezlQuxbPvJoXAvB4W0Smc1FMwAjcn6wDrqc9eZt8lgPlmwlA3jZB
# Fq5T0yWasXtzbo1thcbL4xZljida7U9S4klgJD6k+NK3WHfPd1+aXcAm2ElhDBqS
# xn5V8OzpoAfhRAJj8Rn3AOa9GBmVRcUAMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAE5zOjoQ4vwNOEAAAAAATkwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgs37kehSjE88zwOy+qvJh9rHcI+VyerryRyhBuosRExkwgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCA8oY7kOKPXJHsxQrHigQWufGpVJ/Oaep8m
# ptSgBw/8nzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABOczo6EOL8DThAAAAAAE5MCIEIL7mUdaYZOaaXs0cWGWfYHG3xpF60MpWkkrm
# h9X+E6BZMA0GCSqGSIb3DQEBCwUABIIBAD4eZMNv2+9X8yPxSVuEdpcjKhAznsEF
# sjPk3S/2M7brTMPOW/63Ynk0QIVyOkA80Sev7sRv4DEZKaVBozG3wiJiA/lsIKLl
# UU4/UGbhyR7bbYRLX5okDKSY6zmz67/AhF+EE6YodDN6Aa2XTDS0EmiF4wwQUVux
# rw3IiAC6L/AOOogfAhjy9fXkwyr0/E1pcLsU1UBxkJeCugakLaPeNdQiexkHpJud
# h5tnmZEAQbCpiJUUUVRRCcJgXP2LFwjX0uJI/cOL8tSC3sJSmAQgHvFk9Uq6jzZS
# gSXrq48mqlkxNSuqsrkH19G3aoxCqkoZOD4XCso1FV9faRo+umMpsDU=
# SIG # End signature block
