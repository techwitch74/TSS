﻿#************************************************
# DC_ProxyConfiguration.ps1
# Version 1.0: Proxy Configuration for IE User, WinHTTP, Firewall Client, PAC Files, Network Isolation
# Version 1.1: Added Proxy Configuration for IE System
# Version 1.2 (4/28/14): Edited table of contents. 
# Create date: 12/5/2012
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects Proxy Configuration information from IE, WinHTTP and Forefront Firewall Client.
# Called from: Networking Diagnostics
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationIEUser -Status $ScriptVariable.ID_CTSProxyConfigurationIEUserDescription

$sectionDescription = "Proxy Configuration Information"
$OutputFile= $Computername + "_ProxyConfiguration.TXT"


#INTRO

	"====================================================" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"Proxy Configuration" 																| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"Overview"			 																| Out-File -FilePath $OutputFile -encoding ASCII -append
	"----------------------------------------------------" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"The Proxy Configuration script shows the proxy configuration of the following:"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  1. IE User Proxy Settings"														| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  2. IE System Proxy Settings" 													| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  3. WinHTTP Proxy Settings"														| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  4. BITS Proxy Settings" 															| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  5. TMG/ISA Firewall Client Settings" 											| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  6. Displays PAC file names and locations"										| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  7. Collects the PAC files on the system into a compressed file."					| Out-File -FilePath $OutputFile -encoding ASCII -append
	"  8. Network Isolation settings" 													| Out-File -FilePath $OutputFile -encoding ASCII -append
	"===================================================="								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"																				| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"																				| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"																				| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"																				| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"																				| Out-File -FilePath $OutputFile -encoding ASCII -append
	

#IE
	#"[info]: Starting Proxy Configuration script" | WriteTo-StdOut
	# Check if ProxySettingsPerUser is set causing the IE settings to be read from HKLM
	if (test-path "HKLM:\Software\Policies\Windows\CurrentVersion\Internet Settings")
	{
		$ieProxyConfigProxySettingsPerUserP = (Get-ItemProperty -path "HKLM:\Software\Policies\Windows\CurrentVersion\Internet Settings").ProxySettingsPerUser
	}
	if (test-path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings")
	{
		$ieProxyConfigProxySettingsPerUserM = (Get-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxySettingsPerUser	
	}

	If ( ($ieProxyConfigProxySettingsPerUserP -eq 0) -or ($ieProxyConfigProxySettingsPerUserM -eq 0) )
	{
		#----------determine os architecture
		Function GetComputerArchitecture() 
		{ 
			if (($Env:PROCESSOR_ARCHITEW6432).Length -gt 0) #running in WOW 
			{ 
				$Env:PROCESSOR_ARCHITEW6432 
			} else { 
				$Env:PROCESSOR_ARCHITECTURE 
			} 
		}
		$OSArchitecture = GetComputerArchitecture
		# $OSArchitecture | WriteTo-StdOut

		if ($OSArchitecture -eq "AMD64")
		{
			#IE Proxy Config from HKLM
			$ieProxyConfigAutoConfigURL = (Get-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").AutoConfigURL
			$ieProxyConfigProxyEnable   = (Get-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyEnable
			$ieProxyConfigProxyServer   = (Get-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyServer
			$ieProxyConfigProxyOverride = (Get-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyOverride
			# Get list of regvalues in "HKLM\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"
			$ieConnections = (Get-Item -Path "Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections") | Select-Object -ExpandProperty Property
			$regHive = "HKLM (x64)"
		}
		if ($OSArchitecture -eq "x86")
		{
			#IE Proxy Config from HKLM
			$ieProxyConfigAutoConfigURL = (Get-ItemProperty -path "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings").AutoConfigURL
			$ieProxyConfigProxyEnable   = (Get-ItemProperty -path "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyEnable
			$ieProxyConfigProxyServer   = (Get-ItemProperty -path "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyServer
			$ieProxyConfigProxyOverride = (Get-ItemProperty -path "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyOverride
			
			# Get list of regvalues in "HKLM\Software\WOW6432Node\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"
			$ieConnections = (Get-Item -Path "Registry::HKEY_LOCAL_MACHINE\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Internet Settings\Connections") | Select-Object -ExpandProperty Property
			$regHive = "HKLM (x86)"
		}
	}
	else
	{
		#IE Proxy Config from HKCU
		$ieProxyConfigAutoConfigURL = (Get-ItemProperty -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").AutoConfigURL
		$ieProxyConfigProxyEnable   = (Get-ItemProperty -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyEnable
		$ieProxyConfigProxyServer   = (Get-ItemProperty -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyServer
		$ieProxyConfigProxyOverride = (Get-ItemProperty -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings").ProxyOverride

		# Get list of regvalues in "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"
		$ieConnections = (Get-Item -Path "Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections") | Select-Object -ExpandProperty Property
		$regHive = "HKCU"
	}

	#"[info]: ProxyServer array being created" | WriteTo-StdOut	
	#Find all entries in the Proxy Server Array
	if ($ieProxyConfigProxyServer -ne $null)
	{
		$ieProxyConfigProxyServerArray = ($ieProxyConfigProxyServer).Split(';')
		$ieProxyConfigProxyServerArrayLength = $ieProxyConfigProxyServerArray.length
	}
	
	#"[info]: ProxyOverride array being created" | WriteTo-StdOut	
	#Find all entries in Proxy Override Array
	if ($ieProxyConfigProxyOverride -ne $null)
	{
		[array]$ieProxyConfigProxyOverrideArray = ($ieProxyConfigProxyOverride).Split(';')
		$ieProxyConfigProxyOverrideArrayLength = $ieProxyConfigProxyOverrideArray.length
	}
	
	
	


	#"[info]: Starting Proxy Configuration: IE User Settings section" | WriteTo-StdOut
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: IE User Settings (" + $regHive + ")" 	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	
	for($i=0;$ieConnections[$i] -ne $null;$i++)
	{
		#IE Proxy Configuration Array: Detection Logic for each Connection
			[string]$ieConnection = $ieConnections[$i]

		
		# Main UI Checkboxes (3)
			$ieProxyConfigArray = (Get-ItemProperty -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections").$ieConnection
			[int]$ieProxyConfigUI = $ieProxyConfigArray[8]
			
			
		# Manual Proxy Server setting
			[int]$ieProxyConfigUIManualProxyOffset = 12
			[int]$ieProxyConfigUIManualProxyLength = $ieProxyConfigArray[$ieProxyConfigUIManualProxyOffset]
			[int]$ieProxyConfigUIManualProxyStart = $ieProxyConfigUIManualProxyOffset + 4
			[int]$ieProxyConfigUIManualProxyEnd = $ieProxyConfigUIManualProxyStart + $ieProxyConfigUIManualProxyLength
			# Convert decimal to ASCII string
			[string]$ieProxyConfigUIManualProxyValue = ""
			for ($j=$ieProxyConfigUIManualProxyStart;$j -lt $ieProxyConfigUIManualProxyEnd;$j++)
			{
				[string]$ieProxyConfigUIManualProxyValue = $ieProxyConfigUIManualProxyValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
			}
			# Split on semicolons
			$ieProxyConfigUIManualProxyValueArray = ($ieProxyConfigUIManualProxyValue).Split(';')
			$ieProxyConfigUIManualProxyValueArrayLength = $ieProxyConfigUIManualProxyValueArray.length


		# BypassProxy
			[int]$ieProxyConfigUIBypassProxyOffset = $ieProxyConfigUIManualProxyStart + $ieProxyConfigUIManualProxyLength
			[int]$ieProxyConfigUIBypassProxyLength = $ieProxyConfigArray[$ieProxyConfigUIBypassProxyOffset]
			[int]$ieProxyConfigUIBypassProxyStart  = $ieProxyConfigUIBypassProxyOffset + 4
			[int]$ieProxyConfigUIBypassProxyEnd    = $ieProxyConfigUIBypassProxyStart + $ieProxyConfigUIBypassProxyLength
			# Bypass Proxy Checkbox
			If ($ieProxyConfigUIBypassProxyLength -ne 0)
			{
				#BypassProxy Checked
				$ieProxyConfigUIBypassProxyEnabled = $true
			}
			else
			{
				#BypassProxy Unchecked
				$ieProxyConfigUIBypassProxyEnabled = $false
			}
			# Convert decimal to ASCII string
			[string]$ieProxyConfigUIBypassProxyValue = ""
			for ($j=$ieProxyConfigUIBypassProxyStart;$j -lt $ieProxyConfigUIBypassProxyEnd;$j++)
			{
				[string]$ieProxyConfigUIBypassProxyValue = $ieProxyConfigUIBypassProxyValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
			}
			# Split on semicolons
			$ieProxyConfigUIBypassProxyValueArray = ($ieProxyConfigUIBypassProxyValue).Split(';')
			$ieProxyConfigUIBypassProxyValueArrayLength = $ieProxyConfigUIBypassProxyValueArray.length
			
			
		#AutoConfig
			[int]$ieProxyConfigUIAutoConfigOffset = $ieProxyConfigUIBypassProxyStart + $ieProxyConfigUIBypassProxyLength
			[int]$ieProxyConfigUIAutoConfigLength = $ieProxyConfigArray[$ieProxyConfigUIAutoConfigOffset]
			[int]$ieProxyConfigUIAutoConfigStart  = $ieProxyConfigUIAutoConfigOffset + 4
			[int]$ieProxyConfigUIAutoConfigEnd    = $ieProxyConfigUIAutoConfigStart + $ieProxyConfigUIAutoConfigLength
			# Convert decimal to ASCII string
			[string]$ieProxyConfigUIAutoConfigValue = ""
			for ($j=$ieProxyConfigUIAutoConfigStart;$j -lt $ieProxyConfigUIAutoConfigEnd;$j++)
			{
				[string]$ieProxyConfigUIAutoConfigValue = $ieProxyConfigUIAutoConfigValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
			}
			# Split on semicolons
			$ieProxyConfigUIAutoConfigValueArray = ($ieProxyConfigUIAutoConfigValue).Split(';')
			$ieProxyConfigUIAutoConfigValueArrayLength = $ieProxyConfigUIAutoConfigValueArray.length

			

		If ($ieConnection -eq "DefaultConnectionSettings")
		{

			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"Local Area Network (LAN) Settings" 	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		}
		elseif ($ieConnection -eq "SavedLegacySettings")
		{
			# skipping SavedLegacySettings to trim output
			$i++
			[string]$ieConnection = $ieConnections[$i]
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		}
		else
		{
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
			"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		}
		

		" " + "Automatic Configuration"						| Out-File -FilePath $OutputFile -encoding ASCII -append
		# "Automatically detect settings:
			If ( ($ieProxyConfigUI -eq 9) -or ($ieProxyConfigUI -eq 11) -or ($ieProxyConfigUI -eq 13) -or ($ieProxyConfigUI -eq 15) )
			{
				"  " + "[X] Automatically detect settings:" | Out-File -FilePath $OutputFile -encoding ASCII -append
			}
			else
			{
				"  " + "[ ] Automatically detect settings:" | Out-File -FilePath $OutputFile -encoding ASCII -append
			}
		# "Use automatic configuration script:"
			If ( ($ieProxyConfigUI -eq 5) -or ($ieProxyConfigUI -eq 7) -or ($ieProxyConfigUI -eq 13) -or ($ieProxyConfigUI -eq 15) )
			{
				"  " + "[X] Use automatic configuration script:" | Out-File -FilePath $OutputFile -encoding ASCII -append
				"   " + "     " + "Address: "  | Out-File -FilePath $OutputFile -encoding ASCII -append
				# "   " + "            " + $ieProxyConfigAutoConfigURL
				
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				for ($j=0;$j -le $ieProxyConfigUIAutoConfigValueArrayLength;$j++)
				{
					"    " + "            " + $ieProxyConfigUIAutoConfigValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
				}
			}
			else
			{
				"  " + "[ ] Use automatic configuration script:" | Out-File -FilePath $OutputFile -encoding ASCII -append
				"   " + "     " + "Address: " | Out-File -FilePath $OutputFile -encoding ASCII -append
			}
		" " + "Proxy Server"								| Out-File -FilePath $OutputFile -encoding ASCII -append
		# "Use a proxy server for your LAN (These settings will not apply to dial-up or VPN connections)."
			If ( ($ieProxyConfigUI -eq 3) -or ($ieProxyConfigUI -eq 7) -or ($ieProxyConfigUI -eq 11) -or ($ieProxyConfigUI -eq 15) )
			{
				# MANUAL PROXY (from Connection)
				"  " + "[X] Use a proxy server for your LAN (These settings will not apply " | Out-File -FilePath $OutputFile -encoding ASCII -append
				If ($ieConnection -eq "DefaultConnectionSettings")
				{
					"  " + "    to dial-up or VPN connections)."		| Out-File -FilePath $OutputFile -encoding ASCII -append
				}
				else
				{
					"  " + "    to other connections)."					| Out-File -FilePath $OutputFile -encoding ASCII -append
				}
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"   " + "     Address: and Port:   " | Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				for ($j=0;$j -le $ieProxyConfigUIManualProxyValueArrayLength;$j++)
				{
					"    " + "            " + $ieProxyConfigUIManualProxyValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
				}

				# BYPASS PROXY (from Connection)
				If ($ieProxyConfigUIBypassProxyEnabled -eq $true)
				{
				"    " + "   [X] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"    " + "        Exceptions: "	| Out-File -FilePath $OutputFile -encoding ASCII -append
					"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					for ($j=0;$j -le $ieProxyConfigUIBypassProxyValueArrayLength;$j++)
					{
						"    " + "            " + $ieProxyConfigUIBypassProxyValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
					}
				}
				else
				{
				"    " + "   [ ] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"    " + "        Exceptions: "  							| Out-File -FilePath $OutputFile -encoding ASCII -append
				}
			}
			else
			{
				"  " + "[ ] Use a proxy server for your LAN (These settings will not apply to" | Out-File -FilePath $OutputFile -encoding ASCII -append
				"  " + "    dial-up or VPN connections)."					| Out-File -FilePath $OutputFile -encoding ASCII -append
				"   " + "    Address:Port "									| Out-File -FilePath $OutputFile -encoding ASCII -append
				"    " + "   [ ] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"    " + "        Exceptions: "  							| Out-File -FilePath $OutputFile -encoding ASCII -append
			}
	}





Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationIESystem -Status $ScriptVariable.ID_CTSProxyConfigurationIESystemDescription

	#----------Proxy Configuration: IE System Settings: Initialization
		#"[info]: ProxyConfiguration: IE System Settings: Initialization" | WriteTo-StdOut 	
		$regHive = "HKEY_USERS\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings"

	
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 				| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: IE System Settings (" + $regHive + ")" 		| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 				| Out-File -FilePath $OutputFile -encoding ASCII -append


	#----------
	# Verifying HKU is in the psProviderList. If not, add it
	#----------
		#
		# HKU may not be in the psProviderList, so we need to add it so we can reference it
		#
		#"[info]: Checking the PSProvider list because we need HKU" | WriteTo-StdOut
		$psProviderList = Get-PSDrive -PSProvider Registry
		$psProviderListLen = $psProviderList.length
		for ($i=0;$i -le $psProviderListLen;$i++)
		{
			if (($psProviderList[$i].Name) -eq "HKU")
			{
				$hkuExists = $true
				$i = $psProviderListLen
			}
			else
			{
				$hkuExists = $false
			}
		}
		if ($hkuExists -eq $false)
		{
			#"[info]: Creating a new PSProvider to enable access to HKU" | WriteTo-StdOut
			[void]( New-PSDrive -Name HKU -PSProvider Registry -Root Registry::HKEY_USERS)
		}

	#----------
	# Verify "\Internet Settings\Connections" exists, if not display message that IE System Context is not configured.
	#   $ieConnectionsCheck and associated code block added 10/11/2013
	#----------
	#$ieConnections = $null
	# Get list of regvalues in "HKEY_USERS\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"		
	$ieConnectionsCheck = Test-path "HKU:\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"
	
	if ($ieConnectionsCheck -eq $true)
	{
		$ieConnections = (Get-Item -Path "Registry::HKEY_USERS\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections") | Select-Object -ExpandProperty Property
		
		for($i=0;$ieConnections[$i] -ne $null;$i++)
		{
			#IE Proxy Configuration Array: Detection Logic for each Connection
				[string]$ieConnection = $ieConnections[$i]

			#"[info]: Get-ItemProperty on HKU registry location." | WriteTo-StdOut
			# Main UI Checkboxes (3)
				[array]$ieProxyConfigArray = $null
				[array]$ieProxyConfigArray = (Get-ItemProperty -path "HKU:\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections").$ieConnection
				[int]$ieProxyConfigUI = $ieProxyConfigArray[8]
				
			#"[info]: Retrieving manual proxy server setting." | WriteTo-StdOut
			# Manual Proxy Server setting
				[int]$ieProxyConfigUIManualProxyOffset = 12
				[int]$ieProxyConfigUIManualProxyLength = $ieProxyConfigArray[$ieProxyConfigUIManualProxyOffset]
				[int]$ieProxyConfigUIManualProxyStart = $ieProxyConfigUIManualProxyOffset + 4
				[int]$ieProxyConfigUIManualProxyEnd = $ieProxyConfigUIManualProxyStart + $ieProxyConfigUIManualProxyLength
				# Convert decimal to ASCII string
				[string]$ieProxyConfigUIManualProxyValue = ""
				for ($j=$ieProxyConfigUIManualProxyStart;$j -lt $ieProxyConfigUIManualProxyEnd;$j++)
				{
					[string]$ieProxyConfigUIManualProxyValue = $ieProxyConfigUIManualProxyValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
				}
				# Split on semicolons
				$ieProxyConfigUIManualProxyValueArray = ($ieProxyConfigUIManualProxyValue).Split(';')
				$ieProxyConfigUIManualProxyValueArrayLength = $ieProxyConfigUIManualProxyValueArray.length

			#"[info]: Retrieving BypassProxy setting." | WriteTo-StdOut
			# BypassProxy
				[int]$ieProxyConfigUIBypassProxyOffset = $ieProxyConfigUIManualProxyStart + $ieProxyConfigUIManualProxyLength
				[int]$ieProxyConfigUIBypassProxyLength = $ieProxyConfigArray[$ieProxyConfigUIBypassProxyOffset]
				[int]$ieProxyConfigUIBypassProxyStart  = $ieProxyConfigUIBypassProxyOffset + 4
				[int]$ieProxyConfigUIBypassProxyEnd    = $ieProxyConfigUIBypassProxyStart + $ieProxyConfigUIBypassProxyLength
				# Bypass Proxy Checkbox
				If ($ieProxyConfigUIBypassProxyLength -ne 0)
				{
					#BypassProxy Checked
					$ieProxyConfigUIBypassProxyEnabled = $true
				}
				else
				{
					#BypassProxy Unchecked
					$ieProxyConfigUIBypassProxyEnabled = $false
				}
				# Convert decimal to ASCII string
				[string]$ieProxyConfigUIBypassProxyValue = ""
				for ($j=$ieProxyConfigUIBypassProxyStart;$j -lt $ieProxyConfigUIBypassProxyEnd;$j++)
				{
					[string]$ieProxyConfigUIBypassProxyValue = $ieProxyConfigUIBypassProxyValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
				}
				# Split on semicolons
				$ieProxyConfigUIBypassProxyValueArray = ($ieProxyConfigUIBypassProxyValue).Split(';')
				$ieProxyConfigUIBypassProxyValueArrayLength = $ieProxyConfigUIBypassProxyValueArray.length
				
			#"[info]: Retrieving AutoConfig setting." | WriteTo-StdOut			
			#AutoConfig
				[int]$ieProxyConfigUIAutoConfigOffset = $ieProxyConfigUIBypassProxyStart + $ieProxyConfigUIBypassProxyLength
				[int]$ieProxyConfigUIAutoConfigLength = $ieProxyConfigArray[$ieProxyConfigUIAutoConfigOffset]
				[int]$ieProxyConfigUIAutoConfigStart  = $ieProxyConfigUIAutoConfigOffset + 4
				[int]$ieProxyConfigUIAutoConfigEnd    = $ieProxyConfigUIAutoConfigStart + $ieProxyConfigUIAutoConfigLength
				# Convert decimal to ASCII string
				[string]$ieProxyConfigUIAutoConfigValue = ""
				for ($j=$ieProxyConfigUIAutoConfigStart;$j -lt $ieProxyConfigUIAutoConfigEnd;$j++)
				{
					[string]$ieProxyConfigUIAutoConfigValue = $ieProxyConfigUIAutoConfigValue + [CHAR][BYTE]$ieProxyConfigArray[$j]
				}
				# Split on semicolons
				$ieProxyConfigUIAutoConfigValueArray = ($ieProxyConfigUIAutoConfigValue).Split(';')
				$ieProxyConfigUIAutoConfigValueArrayLength = $ieProxyConfigUIAutoConfigValueArray.length

				

			If ($ieConnection -eq "DefaultConnectionSettings")
			{

				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"Local Area Network (LAN) Settings" 	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			}
			elseif ($ieConnection -eq "SavedLegacySettings")
			{
				# skipping SavedLegacySettings to trim output
				$i++
				[string]$ieConnection = $ieConnections[$i]
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			}
			else
			{
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
				"-----Connection:  " + $ieConnection + "-----"		| Out-File -FilePath $OutputFile -encoding ASCII -append
				"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
			}
			

			" " + "Automatic Configuration"						| Out-File -FilePath $OutputFile -encoding ASCII -append
			# "Automatically detect settings:
				If ( ($ieProxyConfigUI -eq 9) -or ($ieProxyConfigUI -eq 11) -or ($ieProxyConfigUI -eq 13) -or ($ieProxyConfigUI -eq 15) )
				{
					"  " + "[X] Automatically detect settings:" | Out-File -FilePath $OutputFile -encoding ASCII -append
				}
				else
				{
					"  " + "[ ] Automatically detect settings:" | Out-File -FilePath $OutputFile -encoding ASCII -append
				}
			# "Use automatic configuration script:"
				If ( ($ieProxyConfigUI -eq 5) -or ($ieProxyConfigUI -eq 7) -or ($ieProxyConfigUI -eq 13) -or ($ieProxyConfigUI -eq 15) )
				{
					"  " + "[X] Use automatic configuration script:" | Out-File -FilePath $OutputFile -encoding ASCII -append
					"   " + "     " + "Address: "  | Out-File -FilePath $OutputFile -encoding ASCII -append
					# "   " + "            " + $ieProxyConfigAutoConfigURL
					
					"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					for ($j=0;$j -le $ieProxyConfigUIAutoConfigValueArrayLength;$j++)
					{
						"    " + "            " + $ieProxyConfigUIAutoConfigValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
					}
				}
				else
				{
					"  " + "[ ] Use automatic configuration script:" | Out-File -FilePath $OutputFile -encoding ASCII -append
					"   " + "     " + "Address: " | Out-File -FilePath $OutputFile -encoding ASCII -append
				}
			" " + "Proxy Server"								| Out-File -FilePath $OutputFile -encoding ASCII -append
			# "Use a proxy server for your LAN (These settings will not apply to dial-up or VPN connections)."
				If ( ($ieProxyConfigUI -eq 3) -or ($ieProxyConfigUI -eq 7) -or ($ieProxyConfigUI -eq 11) -or ($ieProxyConfigUI -eq 15) )
				{
					# MANUAL PROXY (from Connection)
					"  " + "[X] Use a proxy server for your LAN (These settings will not apply " | Out-File -FilePath $OutputFile -encoding ASCII -append
					If ($ieConnection -eq "DefaultConnectionSettings")
					{
						"  " + "    to dial-up or VPN connections)."		| Out-File -FilePath $OutputFile -encoding ASCII -append
					}
					else
					{
						"  " + "    to other connections)."					| Out-File -FilePath $OutputFile -encoding ASCII -append
					}
					"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					"   " + "     Address: and Port:   " | Out-File -FilePath $OutputFile -encoding ASCII -append
					"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					for ($j=0;$j -le $ieProxyConfigUIManualProxyValueArrayLength;$j++)
					{
						"    " + "            " + $ieProxyConfigUIManualProxyValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
					}

					# BYPASS PROXY (from Connection)
					If ($ieProxyConfigUIBypassProxyEnabled -eq $true)
					{
					"    " + "   [X] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					"    " + "        Exceptions: "	| Out-File -FilePath $OutputFile -encoding ASCII -append
						"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
						for ($j=0;$j -le $ieProxyConfigUIBypassProxyValueArrayLength;$j++)
						{
							"    " + "            " + $ieProxyConfigUIBypassProxyValueArray[$j]	| Out-File -FilePath $OutputFile -encoding ASCII -append
						}
					}
					else
					{
					"    " + "   [ ] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					"    " + "        Exceptions: "  | Out-File -FilePath $OutputFile -encoding ASCII -append
					}
				}
				else
				{
					"  " + "[ ] Use a proxy server for your LAN (These settings will not apply to" | Out-File -FilePath $OutputFile -encoding ASCII -append
					"  " + "    dial-up or VPN connections)."					| Out-File -FilePath $OutputFile -encoding ASCII -append
					"   " + "    Address:Port "									| Out-File -FilePath $OutputFile -encoding ASCII -append
					"    " + "   [ ] Bypass proxy server for local addresses"	| Out-File -FilePath $OutputFile -encoding ASCII -append
					"    " + "        Exceptions: "  | Out-File -FilePath $OutputFile -encoding ASCII -append
				}
		}
	}
	

	Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationWinHTTP -Status $ScriptVariable.ID_CTSProxyConfigurationWinHTTPDescription
	#"[info]: ProxyConfiguration: WinHTTP" | WriteTo-StdOut 	
#WinHTTP
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: WinHTTP" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	
	
	Function RunNetSH ([string]$NetSHCommandToExecute="")
	{
		$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
		"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"netsh $NetSHCommandToExecute"		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + "| Out-File -FilePath $OutputFile -encoding ASCII -append"
		RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	}
	RunNetSH -NetSHCommandToExecute "winhttp show proxy"





#BITS
	# update for BITS proxy: Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationWinHTTP -Status $ScriptVariable.ID_CTSProxyConfigurationWinHTTPDescription
	#"[info]: ProxyConfiguration: BITS" | WriteTo-StdOut 	

	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: BITS" 									| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append

	function RunBitsAdmin ([string]$BitsAdminCommandToExecute="")
	{
		$BitsAdminCommandToExecuteLength = $BitsAdminCommandToExecute.Length + 6
		"-" * ($BitsAdminCommandToExecuteLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"bitsadmin $BitsAdminCommandToExecute"		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"-" * ($BitsAdminCommandToExecuteLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		$CommandToExecute = "cmd.exe /c bitsadmin.exe " + $BitsAdminCommandToExecute + "| Out-File -FilePath $OutputFile -encoding ASCII -append"
		RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	}
	RunBitsAdmin -BitsAdminCommandToExecute " /util /getieproxy localsystem"
	RunBitsAdmin -BitsAdminCommandToExecute " /util /getieproxy networkservice"
	RunBitsAdmin -BitsAdminCommandToExecute " /util /getieproxy localservice"




	

#Firewall Client
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationFirewallClient -Status $ScriptVariable.ID_CTSProxyConfigurationFirewallClientDescription
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: Firewall Client" 						| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append

	#----- Is the Firewall Client installed?
	$processActive = Get-Process fwcagent -ErrorAction SilentlyContinue
	if ($processActive -ne $null)
	{
		"The Firewall Client appears to be installed. Gathering output."	| Out-File -FilePath $OutputFile -encoding ASCII -append
		" "	| Out-File -FilePath $OutputFile -encoding ASCII -append
		" "	| Out-File -FilePath $OutputFile -encoding ASCII -append
		$firewallClientProcessPath = (get-process fwcagent).path
		$firewallClientProcess = $firewallClientProcessPath.substring(0,$firewallClientProcessPath.Length-12) + "fwctool.exe"
		$firewallClientProcess
		$firewallClientArgs  = " printconfig"
		$firewallClientCmd = "`"" + $firewallClientProcess + "`"" + $firewallClientArgs
		$firewallClientCmdLength = $firewallClientCmd.length
		# Output header and command that will be run
		"`n" + "-" * ($firewallClientCmdLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n" + "`"" + $firewallClientProcess + " " + $firewallClientArgs + "`""		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n" + "-" * ($firewallClientCmdLength)	| Out-File -FilePath $OutputFile -encoding ASCII -append
		# Run the command
		$CommandToExecute = "cmd.exe /c " + $firewallClientCmd + " | Out-File -FilePath $OutputFile -encoding ASCII -append"
		RunCmD -commandToRun $CommandToExecute -CollectFiles $false
	}
	else
	{
		"The Firewall Client is not installed."	| Out-File -FilePath $OutputFile -encoding ASCII -append
	}


	
	
	

#PAC files	
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSProxyConfigurationPACFiles -Status $ScriptVariable.ID_CTSProxyConfigurationPACFilesDescription

	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	" Proxy Configuration: PAC Files" 								| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append

	# Where are PAC files referenced?
	# HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad

	#-----PAC files
	#  Outside of SDP    = Inside SDP
	#  "c:\users\bbenson = $env:USERPROFILE + "
	#  "c:\windows       = $env:windir + "
	#
	#-----array*.script and wpad*.dat files in User Profile
	$pacUserProfPath = $env:USERPROFILE + "\AppData\Local\Microsoft\Windows\Temporary Internet Files\*"
	# Added Sort-Object to sort the array on creation
	#   | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
	if (Test-Path $pacUserProfPath)
	{
		[array]$pacUserProf = Get-ChildItem $pacUserProfPath  -include array*.script,wpad*.dat -force -recurse | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
		$pacUserProfLen = $pacUserProf.length
		if ($pacUserProfLen -eq $null)  
		{
			$pacUserProfLen = 0
		}
		else
		{
			if ($pacUserProfLen -ne 0)
			{
				[array]$pacArray = [array]$pacUserProf
				$pacArrayLen = $pacArray.length
			}
		}
	}
	#-----array*.script and wpad*.dat files in Windir Sys32
	$pacWindirSys32Path = $env:windir + "\System32\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\*"
	# Added Sort-Object to sort the array on creation
	#   | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
	if (Test-Path $pacWindirSys32Path)
	{
		[array]$pacWindirSys32 = Get-ChildItem $pacWindirSys32Path -include array*.script,wpad*.dat -force -recurse | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
		$pacWindirSys32Len = $pacWindirSys32.length
		if ($pacWindirSys32Len -eq $null)
		{
			$pacWindirSys32Len = 0
		}
		else
		{
			if ($pacWindirSys32Len -ne 0)
			{
				[array]$pacArray = [array]$pacArray + [array]$pacWindirSys32
				$pacArrayLen = $pacArray.length
			}
		}
	}
	#-----array*.script and wpad*.dat files in Windir Syswow64
	$pacWindirSysWow64Path = $env:windir + "\SysWOW64\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\*"
	# Added Sort-Object to sort the array on creation
	#   | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
	if  (Test-Path $pacWindirSysWow64Path)
	{
		[array]$pacWindirSysWow64 = Get-ChildItem $pacWindirSysWow64Path -include array*.script,wpad*.dat -force –recurse  | sort-object -property @{Expression={$_.LastAccessTime}; Ascending=$false}
		$pacWindirSysWow64Len = $pacWindirSysWow64.length
		if ($pacWindirSysWow64Len -eq $null)
		{
			$pacWindirSysWow64Len = 0
		}
		else
		{
			if ($pacWindirSysWow64Len -ne 0)
			{
				[array]$pacArray = [array]$pacArray + [array]$pacWindirSysWow64
				$pacArrayLen = $pacArray.length
			}
		}
	}
	#-----Engineer message indicating where the script searched for the files.
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"Searching for PAC files named wpad*.dat or array*.script in the following locations: " | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"  %userprofile%\AppData\Local\Microsoft\Windows\Temporary Internet Files\*" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"  %windir%\System32\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\*" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"  %windir%\SysWOW64\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\*" | Out-File -FilePath $OutputFile -encoding ASCII -append
		
		# dir "%userprofile%\AppData\Local\Microsoft\Windows\Temporary Internet Files\wpad*.dat" /s
		# dir "%userprofile%\AppData\Local\Microsoft\Windows\Temporary Internet Files\array*.script" /s
		# dir "%windir%\System32\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\wpad*.dat" /s
		# dir "%windir%\System32\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\array*.script" /s
		# dir "%windir%\SysWOW64\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\wpad*.dat" /s
		# dir "%windir%\SysWOW64\config\systemprofile\AppData\Local\Microsoft\Windows\Temporary Internet Files\array*.script" /s


	if ($pacArrayLen -eq $null)
	{
		$pacArrayLen = 0
	}
	#-----Display the array
	if ($pacArrayLen -eq 0)
	{
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"Found " + $pacArrayLen + " PAC files." | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"There are " + $pacArrayLen + " PAC files named wpad*.dat or array*.script located within `"Temporary Internet Files`" for the user and/or the system." | Out-File -FilePath $OutputFile -encoding ASCII -append
	}
	elseif ($pacArrayLen -eq 1)
	{
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"Found " + $pacArrayLen + " PAC file." | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		
		#-----Show FullName, LastWriteTime and LastAccessTime
		for($i=0;$i -lt $pacArrayLen;$i++)
		{
			" " | Out-File -FilePath $OutputFile -encoding ASCII -append
			"[#" + ($i+1) + "]" | Out-File -FilePath $OutputFile -encoding ASCII -append
			"FullName        : " + ($pacArray[$i]).FullName | Out-File -FilePath $OutputFile -encoding ASCII -append
			# "LastWriteTime   : " + ($pacArray[$i]).LastWriteTime | Out-File -FilePath $OutputFile -encoding ASCII -append
			"LastAccessTime  : " + ($pacArray[$i]).LastAccessTime | Out-File -FilePath $OutputFile -encoding ASCII -append
			" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		}
	}
	elseif ($pacArrayLen -gt 1)
	{
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"Found " + $pacArrayLen + " PAC files (in descending showing the most recent LastAccessTime first)" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"--------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		
		#-----Show FullName, LastWriteTime and LastAccessTime
		for($i=0;$i -lt $pacArrayLen;$i++)
		{
			# Sort the array by LastAccessTime
			$pacArray | sort LastAccessTime -Descending
			
			# Text Output with no sorting
			" " | Out-File -FilePath $OutputFile -encoding ASCII -append
			"[#" + ($i+1) + "]" | Out-File -FilePath $OutputFile -encoding ASCII -append
			"FullName        : " + ($pacArray[$i]).FullName | Out-File -FilePath $OutputFile -encoding ASCII -append
			#"LastWriteTime   : " + ($pacArray[$i]).LastWriteTime | Out-File -FilePath $OutputFile -encoding ASCII -append
			"LastAccessTime  : " + ($pacArray[$i]).LastAccessTime | Out-File -FilePath $OutputFile -encoding ASCII -append
			" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		}
	}

	If ($pacArrayLen -gt 0)
	{
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		" " | Out-File -FilePath $OutputFile -encoding ASCII -append
		"------------------------" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"Collecting PAC files" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"------------------------" | Out-File -FilePath $OutputFile -encoding ASCII -append

		# Initialize array for PAC files with FullName
		for ($i=0;$i -lt $pacArrayLen;$i++)  { $pacFilesArray += @($i) }
		
		# Create array of PAC Files with FullName
		for ($i=0;$i -lt $pacArrayLen;$i++)
		{
			$pacFilesArray[$i] = "`"" + ($pacArray[$i]).FullName + "`""
			$pacFilesArray[$i]	| Out-File -FilePath $OutputFile -encoding ASCII -append
			#copy to temp dir
			$CommandToExecute = "cmd.exe /c copy " + $pacFilesArray[$i] + " " + $PWD
			RunCmD -commandToRun $CommandToExecute -CollectFiles $false
		}
		# This function fails because of file not found, but I know the file exists. Probably because of [] in name.
		# CollectFiles -filesToCollect $pacFilesArray[$i]
		
		#Collect PAC files
		$destFileName = $env:COMPUTERNAME + "_Proxy-PACFiles.zip"
		# CollectFiles -filesToCollect $pacFilesArray
		$pacFilesWpadDat = join-path $PWD "wpad*.dat"
		$pacFilesArrScript = join-path $PWD "array*.script"
		CompressCollectFiles -filestocollect $pacFilesWpadDat -DestinationFileName $destFileName
		CompressCollectFiles -filestocollect $pacFilesArrScript -DestinationFileName $destFileName
	}





#Network Isolation Policies
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"Network Isolation Policy Configuration (W8/WS2012)" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"====================================================" 			| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	
	
	if (test-path HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation)
	{
		$netIsolationDomainLocalProxies 	= (Get-ItemProperty -path "HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation").DomainLocalProxies
		$netIsolationDomainProxies 			= (Get-ItemProperty -path "HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation").DomainProxies
		$netIsolationDomainSubnets 			= (Get-ItemProperty -path "HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation").DomainSubnets	
		$netIsolationDProxiesAuthoritive 	= (Get-ItemProperty -path "HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation").DProxiesAuthoritive
		$netIsolationDSubnetsAuthoritive 	= (Get-ItemProperty -path "HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation").DSubnetsAuthoritive
		
		"RegKey  : HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegValue: DomainLocalProxies" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegData : " + $netIsolationDomainLocalProxies 		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegValue: DomainProxies" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegData : " + $netIsolationDomainProxies | Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegValue: DomainSubnets" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegData : " + $netIsolationDomainSubnets 				| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegValue: DProxiesAuthoritive" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegData : " + $netIsolationDProxiesAuthoritive 		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegValue: DSubnetsAuthoritive" | Out-File -FilePath $OutputFile -encoding ASCII -append
		"RegData : " + $netIsolationDSubnetsAuthoritive 		| Out-File -FilePath $OutputFile -encoding ASCII -append
		"`n"	| Out-File -FilePath $OutputFile -encoding ASCII -append
	}
	else
	{
		"Network Isolation policies are not configured.  This location does not exist: HKLM:\Software\Policies\Microsoft\Windows\NetworkIsolation" | Out-File -FilePath $OutputFile -encoding ASCII -append
	}

CollectFiles -filesToCollect $OutputFile -fileDescription "Proxy Configuration Information" -SectionDescription $sectionDescription
