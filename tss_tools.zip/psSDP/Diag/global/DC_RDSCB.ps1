﻿#************************************************
# DC_RDSCB.ps1
# Version 1.0.1
# Date: 21-01-2012
# Author: Daniel Grund - dgrund@microsoft.com
# Description: 
#	This script gets the RDSCB config and
#   checks vital signs to inform user.
# 1.0.0 Beta release
#************************************************
PARAM(
	$TargetHost = "localhost",
   	$RDSobject,
	$OutputFileName,
	$OS,
	$bIsRDSCB
)
# globals and function definitions for RDS
$OutputFolder =$PWD.Path
Import-LocalizedData -BindingVariable RDSSDPStrings 
Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSCB
$RDSSDPStrings.ID_RDSCB | WriteTo-StdOut

$workspace = FilterWMIObject (get-WmiObject -Class Win32_Workspace -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$OutputFileName = SaveAsXml $workspace  ($TargetHost +"_Workspace.xml") $OutputFileName
$PublishedFarm = FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedFarm -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$OutputFileName = SaveAsXml $PublishedFarm  ($TargetHost +"_PublishedFarm.xml") $OutputFileName
$PublishedDeploymentSettings = FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedDeploymentSettings -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$OutputFileName = SaveAsXml $PublishedDeploymentSettings  ($TargetHost +"_PublishedDeploymentSettings.xml") $OutputFileName
$PublishedFileAssociation  = FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedFileAssociation -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$OutputFileName = SaveAsXml $PublishedFileAssociation  ($TargetHost +"_PublishedFileAssociation.xml") $OutputFileName
$PersonalDesktopAssignment = FilterWMIObject (get-WmiObject -Class Win32_RDPersonalDesktopAssignment -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$OutputFileName = SaveAsXml $PersonalDesktopAssignment  ($TargetHost +"_PersonalDesktopAssignment.xml") $OutputFileName
#rule 5833
UpdateAndMessage  -Id "RC_RDSCB902" -RootCause $RDSSDPStrings.ID_RDSCBEvent902 -Solution $RDSSDPStrings.ID_RDSCBEvent902Solution -Detected (IsEventLogged -EventLog Microsoft-Windows-TerminalServices-SessionBroker/Admin -EventId 902)

$RDSCBCluster = get-WmiObject -Class Win32_SessionDirectoryCluster -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
$Deployment = get-WmiObject -Namespace ROOT\cimv2\rdms -Class Win32_RDMSDeploymentSettings -List -ComputerName $TargetHost  -Authentication PacketPrivacy -Impersonation Impersonate
if ($Deployment -ne $NULL)
{
	$HighAvailabilityBrokersList = $Deployment.GetStringProperty('HighAvailabilityBrokersList').Value
	
	if( (([int]$OS.Version[0] -48) -eq 6 ) -and (([int]$OS.Version[2]- 48) -ge 2) )
	{  
		# Check for HighAvailabilityBrokersList to long for session brokers
		UpdateAndMessage -Id "RC_RDCB_CBSTRING" -Detected ($HighAvailabilityBrokersList.Length -ge 128) 
		# Check for more than 2 CB, not supported
		UpdateAndMessage -Id "RC_RDCB_CBCOUNT" -Detected ($HighAvailabilityBrokersList.IndexOf(';',2) -gt 0)
	}
	[array]$CBLog += "High Available Connection Brokers: "+ $Deployment.GetStringProperty('HighAvailabilityBrokersList').Value +" broker Alias:  "+ $Deployment.GetStringProperty('DeploymentRedirectorServer').Value
	[array]$CBLog += "	Deployment Gateway Name: " + $Deployment.GetStringProperty('DeploymentGatewayName').Value
	[array]$CBLog += ""
	[array]$CBLog += ""
}

[array]$CBLog += "ConnectionBroker Farm Information:"
[array]$CBLog +=""

if($RDSCBCluster -ne $NULL)
{
	[array]$CBLog += "ClusterName= " + $RDSCBCluster.ClusterName
	[array]$CBLog += "NumberOfServers= " + $RDSCBCluster.NumberOfServers
	[array]$CBLog += "SingleSessionMode= " + $RDSCBCluster.SingleSessionMode
}
foreach( $Cluster in $RDSCBCluster)
{
	$Query = "Select * from Win32_SessionDirectoryServer where ClusterName='" + $Cluster.ClusterName + "'" 
	$RDSCBClusterEnum = get-WmiObject -Query $Query -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
	if ($RDSCBClusterEnum -ne $null) 
	{
		[array]$CBLog +=""
		[array]$CBLog +="Nodes in "+ $Cluster.ClusterName + ":"

		ForEach($RDSCBClusterNode in $RDSCBClusterEnum)
		{
			[array]$CBLog +=""
			[array]$CBLog +="	ServerName:            " + $RDSCBClusterNode.ServerName
			[array]$CBLog +="	ServerIPAddress:       " + $RDSCBClusterNode.ServerIPAddress
			[array]$CBLog +="	SingleSessionMode:     " + $RDSCBClusterNode.SingleSessionMode
			[array]$CBLog +="	Number of Sessions:    " + $RDSCBClusterNode.NumberOfSessions
			[array]$CBLog +="	ServerWeight:          " + $RDSCBClusterNode.ServerWeight
			[array]$CBLog +="	Number of PendingConn: " + $RDSCBClusterNode.NumPendRedir
			[array]$CBLog +="	LoadIndicator:         " + $RDSCBClusterNode.LoadIndicator
		
			$Query = "Select * from Win32_SessionDirectorySession where ServerName='" + $RDSCBClusterNode.ServerName + "'" 
			$RDSCBSessionEnum = get-WmiObject -Query $Query -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
			if ($RDSCBSessionEnum -ne $null) 
			{
				[array]$CBLog +=""
				[array]$CBLog +="	Sessions on FarmMember: " + $RDSCBSessionEnum.Count
		
				ForEach($RDSCBSession in $RDSCBSessionEnum)
				{
					[array]$CBLog +=""
					[array]$CBLog +="		UserName:         " + $RDSCBSession.DomainName + "\" + $RDSCBSession.UserName
					[array]$CBLog +="		ServerName:       " + $RDSCBSesion.ServerName
					[array]$CBLog +="		ServerIPAddress:  " + $RDSCBSesion.ServerIPAddress
					[array]$CBLog +="		TSProtocol:       " + (TSProtocol $RDSCBSession.TSProtocol)
					[array]$CBLog +="		SessionID:        " + $RDSCBSesion.SessionID
					[array]$CBLog +="		SessionState:     " + (SessionState $RDSCBSession.SessionState)
					[array]$CBLog +="		Initial Program:  " + $RDSCBSession.ApplicationType
					[array]$CBLog +="		CreateTime:       " + $RDSCBSession.ConvertToDateTime($RDSCBSession.CreateTime)
					[array]$CBLog +="		DisconnectTime:   " + $RDSCBSession.ConvertToDateTime($RDSCBSession.DisconnectTime)
					[array]$CBLog +="		ResolutionWidth:  " + $RDSCBSession.ResolutionWidth
					[array]$CBLog +="		ResolutionHeight: " + $RDSCBSession.ResolutionHeight
					[array]$CBLog +="		ColorDepth:       " + $RDSCBSession.ColorDepth
				}
			}
		}
	}
}
# get the Personal Desktop Pool
$Query = "Select * from  Win32_SessionBrokerFarm  where PluginName = 'VMResource'"
$RDSCBVMPDFarms = get-WmiObject -Query $Query -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
if ($RDSCBVMPDFarms -ne $null)
{
	[array]$CBLog +=""
	[array]$CBLog +="Number of Farms: " + $RDSCBVMPDFarms.Count

	ForEach($RDSCBVMPDFarm in $RDSCBVMPDFarms)
	{
		[array]$CBLog +=""
		[array]$CBLog +="	Farm (VM): " + $RDSCBVMPDFarm.FarmName
		$Query = "Select * from  Win32_SessionBrokerTarget where PluginName = 'VMResource'  and FarmName  = '" + $RDSCBVMPDFarm.FarmName + "'"
		$RDSCBVMPDTarget = get-WmiObject -Query $Query -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
		if ( $RDSCBVMPDTarget -ne $null)
		{
			[array]$CBLog +=""
			[array]$CBLog +="		Number of VMs in Pool: " + $RDSCBVMPDTarget.Count
		
			ForEach($RDSCBVMPDPool in $RDSCBVMPDTarget)
			{

				[array]$CBLog +=""
				[array]$CBLog +="			Target (VM) name:   " + $RDSCBVMPDPool.TargetName
				[array]$CBLog +="			Pool name:          " + $RDSCBVMPDPool.FarmName
				[array]$CBLog +="			Target (VM) guid:   " + $RDSCBVMPDPool.Guid
				[array]$CBLog +="			Target (VM) host:   " + $RDSCBVMPDPool.Environment

			}
		}
	}
}


$savepath = $OutputFolder + "\"+ $TargetHost + "_ConnectionBroker_Database.txt"
[array]$OutputFileName += $savepath
$CBLog | Out-File $savepath

#rule 5550
$VMProv = get-childitem $Env:windir\system32\tssesdir\*.xml|foreach-object{$_.Name}
if ($VMProv.count -ge 1)
{
 $VMProv|foreach-object{[array]$OutputFileName += "$Env:windir\system32\tssesdir\$_"}
}
# SIG # Begin signature block
# MIIazwYJKoZIhvcNAQcCoIIawDCCGrwCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUzVOkpjU0Kyn6z7FlwEnAFVIH
# 8s+gghWCMIIEwzCCA6ugAwIBAgITMwAAAHGzLoprgqofTgAAAAAAcTANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTUwMzIwMTczMjAz
# WhcNMTYwNjIwMTczMjAzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkI4RUMtMzBBNC03MTQ0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA6pG9soj9FG8h
# NigDZjM6Zgj7W0ukq6AoNEpDMgjAhuXJPdUlvHs+YofWfe8PdFOj8ZFjiHR/6CTN
# A1DF8coAFnulObAGHDxEfvnrxLKBvBcjuv1lOBmFf8qgKf32OsALL2j04DROfW8X
# wG6Zqvp/YSXRJnDSdH3fYXNczlQqOVEDMwn4UK14x4kIttSFKj/X2B9R6u/8aF61
# wecHaDKNL3JR/gMxR1HF0utyB68glfjaavh3Z+RgmnBMq0XLfgiv5YHUV886zBN1
# nSbNoKJpULw6iJTfsFQ43ok5zYYypZAPfr/tzJQlpkGGYSbH3Td+XA3oF8o3f+gk
# tk60+Bsj6wIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFPj9I4cFlIBWzTOlQcJszAg2
# yLKiMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAC0EtMopC1n8Luqgr0xOaAT4ku0pwmbMa3DJh+i+h/xd9N1P
# pRpveJetawU4UUFynTnkGhvDbXH8cLbTzLaQWAQoP9Ye74OzFBgMlQv3pRETmMaF
# Vl7uM7QMN7WA6vUSaNkue4YIcjsUe9TZ0BZPwC8LHy3K5RvQrumEsI8LXXO4FoFA
# I1gs6mGq/r1/041acPx5zWaWZWO1BRJ24io7K+2CrJrsJ0Gnlw4jFp9ByE5tUxFA
# BMxgmdqY7Cuul/vgffW6iwD0JRd/Ynq7UVfB8PDNnBthc62VjCt2IqircDi0ASh9
# ZkJT3p/0B3xaMA6CA1n2hIa5FSVisAvSz/HblkUwggTsMIID1KADAgECAhMzAAAA
# ymzVMhI1xOFVAAEAAADKMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE0MDQyMjE3MzkwMFoXDTE1MDcyMjE3MzkwMFowgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJZxXe0GRvqEy51bt0bHsOG0ETkDrbEVc2Cc66e2bho8
# P/9l4zTxpqUhXlaZbFjkkqEKXMLT3FIvDGWaIGFAUzGcbI8hfbr5/hNQUmCVOlu5
# WKV0YUGplOCtJk5MoZdwSSdefGfKTx5xhEa8HUu24g/FxifJB+Z6CqUXABlMcEU4
# LYG0UKrFZ9H6ebzFzKFym/QlNJj4VN8SOTgSL6RrpZp+x2LR3M/tPTT4ud81MLrs
# eTKp4amsVU1Mf0xWwxMLdvEH+cxHrPuI1VKlHij6PS3Pz4SYhnFlEc+FyQlEhuFv
# 57H8rEBEpamLIz+CSZ3VlllQE1kYc/9DDK0r1H8wQGcCAwEAAaOCAWAwggFcMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBQfXuJdUI1Whr5KPM8E6KeHtcu/
# gzBRBgNVHREESjBIpEYwRDENMAsGA1UECxMETU9QUjEzMDEGA1UEBRMqMzE1OTUr
# YjQyMThmMTMtNmZjYS00OTBmLTljNDctM2ZjNTU3ZGZjNDQwMB8GA1UdIwQYMBaA
# FMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY0NvZFNpZ1BDQV8w
# OC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljQ29kU2lnUENBXzA4LTMx
# LTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQB3XOvXkT3NvXuD2YWpsEOdc3wX
# yQ/tNtvHtSwbXvtUBTqDcUCBCaK3cSZe1n22bDvJql9dAxgqHSd+B+nFZR+1zw23
# VMcoOFqI53vBGbZWMrrizMuT269uD11E9dSw7xvVTsGvDu8gm/Lh/idd6MX/YfYZ
# 0igKIp3fzXCCnhhy2CPMeixD7v/qwODmHaqelzMAUm8HuNOIbN6kBjWnwlOGZRF3
# CY81WbnYhqgA/vgxfSz0jAWdwMHVd3Js6U1ZJoPxwrKIV5M1AHxQK7xZ/P4cKTiC
# 095Sl0UpGE6WW526Xxuj8SdQ6geV6G00DThX3DcoNZU6OJzU7WqFXQ4iEV57MIIF
# vDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZIm
# iZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQD
# EyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMTAwODMx
# MjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJyWVwZMGS/HZpgICBC
# mXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay7P/ewkJOI9VyANs1VwqJyq4gSfTw
# aKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB2/O98jakyVxF3K+tPeAoaJcap6Vy
# c1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpnUo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ
# +NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049oDI9kM2hOAaFXE5WgigqBTK3S9dP
# Y+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJGzzc8OJ60d1ylF56NyxGPVjzBrAlf
# A9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFMsR6MrS
# tBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIBhjASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGYYDuoMW+mPLzYLTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAWgBQOrIJgQFYnl+UlE/wq4QpTlVnk
# pDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEE
# SDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDANBgkqhkiG9w0BAQUFAAOCAgEAWTk+
# fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddDrQv+y+ktMaMjzHxQmIAhXaw9L0y6
# oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6WcIC36C1DEVs0t40rSvHDnqA2iA6VW
# 4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqkghyT4pQHHfLiTviMocroE6WRTsgb
# 0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5Y1ZEolHN+emjWFbdmwJFRC9f9Nqu
# 1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6EiYJZTiU8XofSrvR4Vbo0HiWGFzJ
# NRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjHCe6FDoxPbQ4TTj18KUicctHzbMrB
# 7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI5nI3EvRvsTxngvlSso0zFmUeDord
# EN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMnQK3k+eGpf0a7B2BHZWBATrBC7E7t
# s3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9QFi58vwUheuKVQSdpw5OPlcmN2Jsh
# rg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMkuYjPaqhHMS+a3ONxPdcAfmJH0c6I
# ybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjWwz0wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TGCBLcwggSz
# AgEBMIGQMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAh
# BgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBAhMzAAAAymzVMhI1xOFV
# AAEAAADKMAkGBSsOAwIaBQCggdAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFABO
# G54+QlOqcu//u0CKLjH2yp5qMHAGCisGAQQBgjcCAQwxYjBgoEaARABEAEkAQQBH
# AF8AUgBEAFMAUwBlAHIAdgBlAHIAXwBnAGwAbwBiAGEAbABfAEQAQwBfAFIARABT
# AEMAQgAuAHAAcwAxoRaAFGh0dHA6Ly9taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEB
# AQUABIIBAE6Vhh9z3ql3Ztbi4c6itrFseGNFGmZrLYOL+A7kxnRIzIpBNU1tWL/u
# tTqBpAf1veYoZqgJj6Cuxe7ROQXl8ZyVzOMcIFqX8EmJXiCebJltDHTNky4UZatl
# FYzOrNMCdpSkbCL6uuqm7aFk8TYHCBCWhku5nABgdVWPkWh7vvLPV3E6m9xDJ+8a
# E7j5HIiG9jgVlVAKkdogIpn77d1ipunTW1qAePrvewr3x/5EnCJ7mWtrr93KoCdQ
# ltTz5gYq8lh18sP2PbkAjTFJTMsgq6zQi2l9/T8k/3B1RirwAkOCE//Liu93gr/E
# hsX8NTaVh/SyU5xpuLQ9kYzLyb60wYmhggIoMIICJAYJKoZIhvcNAQkGMYICFTCC
# AhECAQEwgY4wdzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEh
# MB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBAhMzAAAAcbMuimuCqh9O
# AAAAAABxMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwG
# CSqGSIb3DQEJBTEPFw0xNTA1MTIxNjQzMzRaMCMGCSqGSIb3DQEJBDEWBBS2SNsB
# PBo4dFdCz+42319bBsEgEzANBgkqhkiG9w0BAQUFAASCAQDErgeqOsXx7dUbSqjf
# HZia3NP3ZLTxb5AP+pFXzIl9WagzZo7q+K8nFJ2GmlIYfeXfKB0pgf75Ew9CoYPg
# bGhyZNk1Ci4bS0Q+LjW7yIP+PdzR/j/yOKcbeKAuxHtCrWdntVyO1d58JiyIHbTk
# AJS+f/jEGhDh7DZ9KWDtf6hl+HIsbZWdI/DGDRFmW3pceVyb5wN0hT9UJmyfYmdN
# 4xLxUpW1Y//d4Qcp7pHm6TKp8ojj2mBgjEBMHZ9hhTK2I5Frm/yONiyLyezrXHQ5
# hlXTa/lhniCfiicc0IsD+4ei3zVCcise/RbPrAgeKkK3dR+OOUbZKjFoWQbZ0GNi
# UUpP
# SIG # End signature block
