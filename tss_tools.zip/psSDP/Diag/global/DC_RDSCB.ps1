﻿#************************************************
# DC_RDSCB.ps1
# Version 1.0.1
# Date: 21-01-2012
# Author: Daniel Grund - dgrund@microsoft.com
# Description: 
#	This script gets the RDSCB config and
#   checks vital signs to inform user.
# 1.0.0 Beta release
#************************************************
PARAM(
	$TargetHost = "localhost",
   	$RDSobject,
	$OutputFileName,
	$OS,
	$bIsRDSCB
)
# globals and function definitions for RDS
$OutputFolder =$PWD.Path
Import-LocalizedData -BindingVariable RDSSDPStrings 
Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSCB
$RDSSDPStrings.ID_RDSCB | WriteTo-StdOut

$workspace = FilterWMIObject (get-WmiObject -Class Win32_Workspace -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$OutputFileName = SaveAsXml $workspace  ($TargetHost +"_Workspace.xml") $OutputFileName
$PublishedFarm = FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedFarm -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$OutputFileName = SaveAsXml $PublishedFarm  ($TargetHost +"_PublishedFarm.xml") $OutputFileName
$PublishedDeploymentSettings = FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedDeploymentSettings -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$OutputFileName = SaveAsXml $PublishedDeploymentSettings  ($TargetHost +"_PublishedDeploymentSettings.xml") $OutputFileName
$PublishedFileAssociation  = FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedFileAssociation -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$OutputFileName = SaveAsXml $PublishedFileAssociation  ($TargetHost +"_PublishedFileAssociation.xml") $OutputFileName
$PersonalDesktopAssignment = FilterWMIObject (get-WmiObject -Class Win32_RDPersonalDesktopAssignment -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$OutputFileName = SaveAsXml $PersonalDesktopAssignment  ($TargetHost +"_PersonalDesktopAssignment.xml") $OutputFileName
#rule 5833
UpdateAndMessage  -Id "RC_RDSCB902" -RootCause $RDSSDPStrings.ID_RDSCBEvent902 -Solution $RDSSDPStrings.ID_RDSCBEvent902Solution -Detected (IsEventLogged -EventLog Microsoft-Windows-TerminalServices-SessionBroker/Admin -EventId 902)

$RDSCBCluster = get-WmiObject -Class Win32_SessionDirectoryCluster -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
$Deployment = get-WmiObject -Namespace ROOT\cimv2\rdms -Class Win32_RDMSDeploymentSettings -List -ComputerName $TargetHost  -Authentication PacketPrivacy -Impersonation Impersonate
if ($Deployment -ne $NULL)
{
	$HighAvailabilityBrokersList = $Deployment.GetStringProperty('HighAvailabilityBrokersList').Value
	
	if( (([int]$OS.Version[0] -48) -eq 6 ) -and (([int]$OS.Version[2]- 48) -ge 2) )
	{  
		# Check for HighAvailabilityBrokersList to long for session brokers
		UpdateAndMessage -Id "RC_RDCB_CBSTRING" -Detected ($HighAvailabilityBrokersList.Length -ge 128) 
		# Check for more than 2 CB, not supported
		UpdateAndMessage -Id "RC_RDCB_CBCOUNT" -Detected ($HighAvailabilityBrokersList.IndexOf(';',2) -gt 0)
	}
	[array]$CBLog += "High Available Connection Brokers: "+ $Deployment.GetStringProperty('HighAvailabilityBrokersList').Value +" broker Alias:  "+ $Deployment.GetStringProperty('DeploymentRedirectorServer').Value
	[array]$CBLog += "	Deployment Gateway Name: " + $Deployment.GetStringProperty('DeploymentGatewayName').Value
	[array]$CBLog += ""
	[array]$CBLog += ""
}

[array]$CBLog += "ConnectionBroker Farm Information:"
[array]$CBLog +=""

if($RDSCBCluster -ne $NULL)
{
	[array]$CBLog += "ClusterName= " + $RDSCBCluster.ClusterName
	[array]$CBLog += "NumberOfServers= " + $RDSCBCluster.NumberOfServers
	[array]$CBLog += "SingleSessionMode= " + $RDSCBCluster.SingleSessionMode
}
foreach( $Cluster in $RDSCBCluster)
{
	$Query = "Select * from Win32_SessionDirectoryServer where ClusterName='" + $Cluster.ClusterName + "'" 
	$RDSCBClusterEnum = get-WmiObject -Query $Query -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
	if ($RDSCBClusterEnum -ne $null) 
	{
		[array]$CBLog +=""
		[array]$CBLog +="Nodes in "+ $Cluster.ClusterName + ":"

		ForEach($RDSCBClusterNode in $RDSCBClusterEnum)
		{
			[array]$CBLog +=""
			[array]$CBLog +="	ServerName:            " + $RDSCBClusterNode.ServerName
			[array]$CBLog +="	ServerIPAddress:       " + $RDSCBClusterNode.ServerIPAddress
			[array]$CBLog +="	SingleSessionMode:     " + $RDSCBClusterNode.SingleSessionMode
			[array]$CBLog +="	Number of Sessions:    " + $RDSCBClusterNode.NumberOfSessions
			[array]$CBLog +="	ServerWeight:          " + $RDSCBClusterNode.ServerWeight
			[array]$CBLog +="	Number of PendingConn: " + $RDSCBClusterNode.NumPendRedir
			[array]$CBLog +="	LoadIndicator:         " + $RDSCBClusterNode.LoadIndicator
		
			$Query = "Select * from Win32_SessionDirectorySession where ServerName='" + $RDSCBClusterNode.ServerName + "'" 
			$RDSCBSessionEnum = get-WmiObject -Query $Query -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
			if ($RDSCBSessionEnum -ne $null) 
			{
				[array]$CBLog +=""
				[array]$CBLog +="	Sessions on FarmMember: " + $RDSCBSessionEnum.Count
		
				ForEach($RDSCBSession in $RDSCBSessionEnum)
				{
					[array]$CBLog +=""
					[array]$CBLog +="		UserName:         " + $RDSCBSession.DomainName + "\" + $RDSCBSession.UserName
					[array]$CBLog +="		ServerName:       " + $RDSCBSesion.ServerName
					[array]$CBLog +="		ServerIPAddress:  " + $RDSCBSesion.ServerIPAddress
					[array]$CBLog +="		TSProtocol:       " + (TSProtocol $RDSCBSession.TSProtocol)
					[array]$CBLog +="		SessionID:        " + $RDSCBSesion.SessionID
					[array]$CBLog +="		SessionState:     " + (SessionState $RDSCBSession.SessionState)
					[array]$CBLog +="		Initial Program:  " + $RDSCBSession.ApplicationType
					[array]$CBLog +="		CreateTime:       " + $RDSCBSession.ConvertToDateTime($RDSCBSession.CreateTime)
					[array]$CBLog +="		DisconnectTime:   " + $RDSCBSession.ConvertToDateTime($RDSCBSession.DisconnectTime)
					[array]$CBLog +="		ResolutionWidth:  " + $RDSCBSession.ResolutionWidth
					[array]$CBLog +="		ResolutionHeight: " + $RDSCBSession.ResolutionHeight
					[array]$CBLog +="		ColorDepth:       " + $RDSCBSession.ColorDepth
				}
			}
		}
	}
}
# get the Personal Desktop Pool
$Query = "Select * from  Win32_SessionBrokerFarm  where PluginName = 'VMResource'"
$RDSCBVMPDFarms = get-WmiObject -Query $Query -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
if ($RDSCBVMPDFarms -ne $null)
{
	[array]$CBLog +=""
	[array]$CBLog +="Number of Farms: " + $RDSCBVMPDFarms.Count

	ForEach($RDSCBVMPDFarm in $RDSCBVMPDFarms)
	{
		[array]$CBLog +=""
		[array]$CBLog +="	Farm (VM): " + $RDSCBVMPDFarm.FarmName
		$Query = "Select * from  Win32_SessionBrokerTarget where PluginName = 'VMResource'  and FarmName  = '" + $RDSCBVMPDFarm.FarmName + "'"
		$RDSCBVMPDTarget = get-WmiObject -Query $Query -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
		if ( $RDSCBVMPDTarget -ne $null)
		{
			[array]$CBLog +=""
			[array]$CBLog +="		Number of VMs in Pool: " + $RDSCBVMPDTarget.Count
		
			ForEach($RDSCBVMPDPool in $RDSCBVMPDTarget)
			{

				[array]$CBLog +=""
				[array]$CBLog +="			Target (VM) name:   " + $RDSCBVMPDPool.TargetName
				[array]$CBLog +="			Pool name:          " + $RDSCBVMPDPool.FarmName
				[array]$CBLog +="			Target (VM) guid:   " + $RDSCBVMPDPool.Guid
				[array]$CBLog +="			Target (VM) host:   " + $RDSCBVMPDPool.Environment

			}
		}
	}
}


$savepath = $OutputFolder + "\"+ $TargetHost + "_ConnectionBroker_Database.txt"
[array]$OutputFileName += $savepath
$CBLog | Out-File $savepath

#rule 5550
$VMProv = get-childitem $Env:windir\system32\tssesdir\*.xml|foreach-object{$_.Name}
if ($VMProv.count -ge 1)
{
 $VMProv|foreach-object{[array]$OutputFileName += "$Env:windir\system32\tssesdir\$_"}
}
# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDgRUcjyLzEyPIx
# fN6uZb4CRtLb0Fw8uoJdTxg/iqSSMaCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQghE7myNrt
# em6fBLI86r8hFM4oN9pzBhwFmGNFp70a5oEwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBACHxBMlsLP0Gi3qnW8Jec5zWLapGqBOTPQ0Vpg/Rrwcb8wfJLTdDcYti
# 8OSivOu7S9sYfcY3H+AFFoaLWAQ6fbME2ffwPrTak5Z4ZWwnAc/g8kZ+9wGZu6bq
# dbzKrK3+dRyivjkLSnkZuAicemMf+WWjGFcdPkVdG1Ecj6eoXSFboQN1hsAIL2ZQ
# vzdmwyviFyj3WZ+ne91X6CUIVeQBGgYaiklvFxQ3OjU4TX5gGfw95rKfIdQdlmLq
# mObnOkYkB9Q6j8XFTFtTAzHonNqfCM+lN5eTPYZaElcwEko4rCJDXxRPz2z/6MNp
# K9va310ZXBKA+TzG8f5K6rrGtfX2roqhghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgpcyoVb+Z9Q4IHzTDLda/8ytvKTGR/7ualny1eh69aBYCBmCKzjBg
# mhgTMjAyMTA1MTkyMjIyNTUuNzM1WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjozQkQ0LTRCODAtNjlDMzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABOxIbkiNSAlqlAAAAAAE7MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyMloXDTIyMDExMjE3MjgyMlowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046M0JENC00
# QjgwLTY5QzMxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDjNtaV0NblMBgHAVLzwvdV
# AK2xT9nIXeeq0LD5VErh4bGY1d1AhSFt9wKsmyXt26R6vDy5KKWWn4AfmED2A5Fz
# cgAkL43seVlZdf/mgCQ22tsxpkyFhYOEw8HhOUrDwp3A6nNlkXjGcOBpZZm5uX5C
# dYHaq3a58tlLrioL7ewaMDbwQ6LWftTOVqQf68XqWgIvljoh+re/kJOrsJ7j1kHZ
# kJbBimQfjtxid69EzKbcQCz03T5C8JpeI6iwsjFuGWq+MoArm/0kUJKMRN2lRopK
# BNJWVsNT5Hv3BLO92xaA99NOTQ1uaJuvcDElRTv6AV924jQCjfqbImQlCDXQIUQx
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQUx8+PzeLoV6CKVmQJQUW6vu/miJEwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAQbDxtOa5Na9VB/sxLUyv3O6QNUQx9acB
# b95j85X95W1tTYddgDCivyJ4Nn6+ZabNLj2zf1Vgb5AEC++jWxVomc1rZmQY1Cj2
# yfsIn6V9qntvzNCNwRXZjXRlk93XLYU+dd0jtpJtV28YiuTwF7DmJZqvphJBnHkr
# jKgkPWqXHn88Xub8oZ6Rym0x+PmH/7gdx4UT0yqdWJGckiNWKeYnObqpc1T5VBGq
# 5rJGGLngD45nShij72GyRix5kWyGUJjofVUMUgMTqAEjf0wPsUbOdSyCpJy4rp5Q
# IcS59fwVoQuPgluwmynqrRyleKRLxcqfnJvS6eZQVBdV7j2u08siFzCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjozQkQ0LTRCODAtNjlDMzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAKDPC77kp1J1G63s+RXUk5YJcfeSggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAORPqfAwIhgPMjAyMTA1MTkyMzE0NTZaGA8yMDIxMDUyMDIzMTQ1NlowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5E+p8AIBADAKAgEAAgIgcwIB/zAHAgEAAgIR
# ODAKAgUA5FD7cAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBABtVnWN1u52S
# 3kVhmono3Nh6OwQ1qouDk2WmLiL5qRMbEh0hE40Fdpl1+7rC8MU4h3kLuzUUXp7U
# W2DB0jBZnEZOChsDjOiHid3CdK+Bq0m/p9n6MONNwz7+qM9cW4nv09WhDnz3Ktzp
# eABhwpsNawa2tz1vfPDonojGzLBDVeqkMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAE7EhuSI1ICWqUAAAAAATswDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQg15PDwkDFONrjSz9lLvYT18vwdDlxyxblMKV+odk+nwowgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAcNuc3ecUm2AJt2Z/vQsVVt1FrWO0AxlG9
# Fjtk4cRAHDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABOxIbkiNSAlqlAAAAAAE7MCIEIO2Py1yVZQgqJuzfMitYHL/UOHpOwq41csFl
# eItyrj9UMA0GCSqGSIb3DQEBCwUABIIBAM8GHuNeq4LePlOrGg0Q2ulvNFBzB5kO
# 6rB/+aD3HNu4lrL4KKo2v7lZ+fy2TODqiK7X/Kz7cUCfeaFHBFN8ZpP/atSI9Zcq
# Z3uhdUr7d+TH3JGytqKMXUNBvT3hZH9Z/sW5tXn5lql97C+lSHm4D7RRneiJHuks
# M7ZKGTdbyOy8bhnxRrY2FblknfeTo28uBaNEAM6Dg2ASamd7xuLbx21WJToIjmou
# HHIoMVN94uVFPn2bPXCH0741sj+YL6dl3+d05aWaeVjTPxUmS6s8UAvgdfYTDU7L
# rJfpcrKKIbM+9pdoelJKRdlhRTRGenmuqRQV9BAQ/SwEs3K9UPkN6es=
# SIG # End signature block
