﻿#************************************************
# DC_HyperVNetworking.ps1
# Version 1.0.04.22.14: Created script.
# Version 1.1.04.26.14: Corrected formatting issues with PowerShell output using format-table
# Version 1.2.05.23.14: Added Get-SCIPAddress; Added Hyper-V registry output (and placed at the top of the script)
# Version 1.3.07.31.14: Moved the "Hyper-V Network Virtualization NAT Configuration" section into its own code block for WS2012R2+. 
# Date: 2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: PS cmdlets
# Called from: Networking Diags
#*******************************************************


Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}	
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}



$sectionDescription = "Hyper-V Networking Settings"

#----------Registry
$outputFile = $Computername + "_HyperVNetworking_reg_.TXT"
#grouped registry values together:
#  RegKeys: vmms;
#  RegKeys: vmsmp, smsp, vmsvsf, vmsvsp
#  RegKeys: vmbus, vmbushid, vmbusr
#  RegKeys: vmbusr, vmicguestinterface, vmicheartbeat, vmickvpexchange, vmicrdv, vmicshutdown, vmictimesync, vmicvss

$CurrentVersionKeys = 	"HKLM\SYSTEM\CurrentControlSet\services\vmms",
						"HKLM\SYSTEM\CurrentControlSet\services\vmsmp",
						"HKLM\SYSTEM\CurrentControlSet\services\VMSP",
						"HKLM\SYSTEM\CurrentControlSet\services\VMSVSF",
						"HKLM\SYSTEM\CurrentControlSet\services\VMSVSP",
						"HKLM\SYSTEM\CurrentControlSet\services\vmbus",
						"HKLM\SYSTEM\CurrentControlSet\services\VMBusHID",
						"HKLM\SYSTEM\CurrentControlSet\services\vmbusr",
						"HKLM\SYSTEM\CurrentControlSet\services\vmicguestinterface",
						"HKLM\SYSTEM\CurrentControlSet\services\vmicheartbeat",
						"HKLM\SYSTEM\CurrentControlSet\services\vmickvpexchange",
						"HKLM\SYSTEM\CurrentControlSet\services\vmicrdv",
						"HKLM\SYSTEM\CurrentControlSet\services\vmicshutdown",
						"HKLM\SYSTEM\CurrentControlSet\services\vmictimesync",
						"HKLM\SYSTEM\CurrentControlSet\services\vmicvss"
RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $outputFile -fileDescription "Hyper-V Registry Keys" -SectionDescription $sectionDescription



# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$outputFile = $Computername + "_HyperVNetworking_info_pscmdlets.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"Hyper-V Networking Settings Powershell Cmdlets"		| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Server Configuration"							| Out-File -FilePath $OutputFile -append
"  1. Get-VMHost"										| Out-File -FilePath $OutputFile -append
"  2. Get-VMHostNumaNode"								| Out-File -FilePath $OutputFile -append
"  3. Get-VMHostNumaNodeStatus"							| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Switch Configuration"							| Out-File -FilePath $OutputFile -append
"  1. Get-VMSwitch *"									| Out-File -FilePath $OutputFile -append
"  2. Get-VMSwitch * | fl"								| Out-File -FilePath $OutputFile -append
#_#"  3. Get-VMSwitchTeam -SwitchName ""vSwitch"" | fl -Property * " | Out-File -FilePath $OutputFile -append
"  3. Get-VMSwitchTeam -EA SilentlyContinue | fl -Property *" | Out-File -FilePath $OutputFile -append
#_#"  4. Get-VMSwitch -Name ""vSwitch"" | Get-VMSwitchExtension | fl -Property * " | Out-File -FilePath $OutputFile -append
"  4. Get-VMSwitch | Get-VMSwitchExtension | fl -Property *" | Out-File -FilePath $OutputFile -append
"  5. Get-VMSystemSwitchExtension | fl -Property * "	| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Adapter Configuration"					| Out-File -FilePath $OutputFile -append
"  1. Get-VMNetworkAdapter -ManagementOS"				| Out-File -FilePath $OutputFile -append
"  2. Get-VMNetworkAdapter -All"						| Out-File -FilePath $OutputFile -append
"  3. Get-VMNetworkAdapter *"							| Out-File -FilePath $OutputFile -append
"  4. Get-VMNetworkAdapter * | fl"						| Out-File -FilePath $OutputFile -append
"  5. Get-VMNetworkAdapter -ManagementOS | fl -Property *"		| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Virtualization Configuration"			| Out-File -FilePath $OutputFile -append
"  1. Get-NetVirtualizationCustomerRoute"				| Out-File -FilePath $OutputFile -append
"  2. Get-NetVirtualizationProviderAddress"				| Out-File -FilePath $OutputFile -append
"  3. Get-NetVirtualizationProviderRoute"				| Out-File -FilePath $OutputFile -append
"  4. Get-NetVirtualizationLookupRecord"				| Out-File -FilePath $OutputFile -append
"  4. Get-NetVirtualizationGlobal"						| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Virtualization SCVMM Configuration"	| Out-File -FilePath $OutputFile -append
"  1. Get-SCIPAddress"									| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Virtualization NAT Configuration [HNV Gateway]" | Out-File -FilePath $OutputFile -append
"  1. Get-NetNat"										| Out-File -FilePath $OutputFile -append
"  2. Get-NetNatGlobal"									| Out-File -FilePath $OutputFile -append
"  3. Get-NetNatSession"								| Out-File -FilePath $OutputFile -append
"  4. Get-NetNatStaticMapping"							| Out-File -FilePath $OutputFile -append
"  5. Get-NetNatExternalAddress"						| Out-File -FilePath $OutputFile -append	
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append


$vmmsCheck = Test-path "HKLM:\SYSTEM\CurrentControlSet\Services\vmms"
if ($vmmsCheck)
{
	if ((Get-Service "vmms").Status -eq 'Running')
	{
		if ($bn -gt 9000) 
		{
			"[info] Hyper-V Server Configuration section."  | WriteTo-StdOut	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Hyper-V Server Configuration"							| Out-File -FilePath $OutputFile -append	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			# Hyper-V: Get-VMHost
			runPS "Get-VMHost"		-ft # W8/WS2012, W8.1/WS2012R2	# ft	
			$vmhost = get-vmhost
			runPS "Get-VMHostNumaNode"		-ft # W8/WS2012, W8.1/WS2012R2	# ft
			if ($vmhost.NumaSpanningEnabled -eq $false)
			{
				"NUMA Spanning has been disabled within Hyper-V Settings, running the `"Get-VMHostNumaNodeStatus`" ps cmdlet."		| Out-File -FilePath $OutputFile -append
				"`n"	| Out-File -FilePath $OutputFile -append				
				runPS "Get-VMHostNumaNodeStatus"			# W8/WS2012, W8.1/WS2012R2	# ft	
			}
			else
			{
				"------------------------"	| Out-File -FilePath $OutputFile -append
				"Get-VMHostNumaNodeStatus"	| Out-File -FilePath $OutputFile -append
				"------------------------"	| Out-File -FilePath $OutputFile -append
				"NUMA Spanning is NOT enabled. Not running the `"Get-VMHostNumaNodeStatus`" ps cmdlet."	| Out-File -FilePath $OutputFile -append
				"`n"	| Out-File -FilePath $OutputFile -append
				"`n"	| Out-File -FilePath $OutputFile -append
				"`n"	| Out-File -FilePath $OutputFile -append
			}

			
			"[info] Hyper-V Switch Configuration section."  | WriteTo-StdOut	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Hyper-V Switch Configuration"							| Out-File -FilePath $OutputFile -append	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			# Hyper-V: Get-VMSwitch
			runPS "Get-VMSwitch *"	-ft 							# W8/WS2012, W8.1/WS2012R2	# ft	
			runPS "Get-VMSwitch * | fl"	-ft 						# W8/WS2012, W8.1/WS2012R2	# ft
			#_#runPS "Get-VMSwitchTeam -SwitchName ""vSwitch"" | fl -Property *" #-ft # W8/WS2012, W8.1/WS2012R2
			runPS "Get-VMSwitchTeam -EA SilentlyContinue | fl -Property *"
			#_#runPS "Get-VMSwitch -Name ""vSwitch"" | Get-VMSwitchExtension | fl -Property *"	#-ft # W8/WS2012, W8.1/WS2012R2
			runPS "Get-VMSwitch | Get-VMSwitchExtension | fl -Property *"
			runPS "Get-VMSystemSwitchExtension | fl -Property *" #-ft # W8/WS2012, W8.1/WS2012R2


			"[info] Hyper-V Network Adapter Configuration section."  | WriteTo-StdOut
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Hyper-V Network Adapter Configuration"					| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			# Hyper-V: Get-VMNetworkAdapter
			runPS "Get-VMNetworkAdapter -ManagementOS"		-ft # W8/WS2012, W8.1/WS2012R2	# ft
			runPS "Get-VMNetworkAdapter -All"				-ft # W8/WS2012, W8.1/WS2012R2	# ft				
			runPS "Get-VMNetworkAdapter *"					-ft # W8/WS2012, W8.1/WS2012R2	# ft	
			runPS "Get-VMNetworkAdapter * | fl"					# W8/WS2012, W8.1/WS2012R2	# fl
			runPS "Get-VMNetworkAdapter -ManagementOS | fl -Property *"	# W8/WS2012, W8.1/WS2012R2	# fl	


			"[info] Hyper-V Network Virtualization Configuration section."  | WriteTo-StdOut	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Hyper-V Network Virtualization Configuration"			| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append		
			"`n"	| Out-File -FilePath $OutputFile -append
			# Hyper-V: Get-NetVirtualization
			runPS "Get-NetVirtualizationCustomerRoute"			# W8/WS2012, W8.1/WS2012R2	# fl
			runPS "Get-NetVirtualizationProviderAddress"		# W8/WS2012, W8.1/WS2012R2	# fl	
			runPS "Get-NetVirtualizationProviderRoute"			# W8/WS2012, W8.1/WS2012R2	# unknown
			runPS "Get-NetVirtualizationLookupRecord"			# W8/WS2012, W8.1/WS2012R2	# fl
			runPS "Get-NetVirtualizationGlobal"					# W8/WS2012, W8.1/WS2012R2	# fl		#Added 4/26/14


			"[info] Hyper-V Network Virtualization Configuration section."  | WriteTo-StdOut	
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"Hyper-V Network Virtualization SCVMM Configuration"	| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append		
			"`n"	| Out-File -FilePath $OutputFile -append

			If (Test-path “HKLM:\SYSTEM\CurrentControlSet\Services\SCVMMService”)
			{
				if ($bn -ge 9600) 
				{
					runPS "Get-SCIPAddress"						# W8.1/WS2012R2	# fl
				}
				else
				{
					"This server is not running WS2012 R2. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
				}
			}
			else
			{
				"SCVMM is not installed."					| Out-File -FilePath $OutputFile -append
				"Not running the Get-SCIPAddress pscmdlet."	| Out-File -FilePath $OutputFile -append			
			}			
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
		}
		else
		{
			"This server is not running WS2012 or WS2012 R2. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"The `"Hyper-V Virtual Machine Management`" service is not running. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Hyper-V Virtual Machine Management`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}


"[info] Hyper-V Network Virtualization Configuration section."  | WriteTo-StdOut	
"===================================================="	| Out-File -FilePath $OutputFile -append
"Hyper-V Network Virtualization NAT Configuration"		| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append	
"`n"	| Out-File -FilePath $OutputFile -append
#_#if ($bn -ge 9600)
		#Get role, OSVer, hotfix data. #_#
		$cs =  gwmi -Namespace "root\cimv2" -class win32_computersystem -ComputerName $ComputerName #_#
		$DomainRole = $cs.domainrole #_#
if (($bn -ge 9600) -and ($cs.DomainRole -ge 2)) #_# not on Win8+,Win10 client
{
	# Hyper-V: Get-NetVirtualization
	runPS "Get-NetNat"						# W8.1/WS2012R2	# unknown		# Added 4/26/14
	runPS "Get-NetNatGlobal"				# W8.1/WS2012R2	# unknown		# Added 4/26/14
	"---------------------------"			| Out-File -FilePath $OutputFile -append
	"Get-NetNatSession"						| Out-File -FilePath $OutputFile -append
	"---------------------------"			| Out-File -FilePath $OutputFile -append
	"Not running Get-NetNatSession currently because of exception."			| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	#runPS "Get-NetNatSession"				# W8.1/WS2012R2	# unknown		# Added 4/26/14 -> commented out because of exception... Need a check in place.
	runPS "Get-NetNatStaticMapping"			# W8.1/WS2012R2	# unknown		# Added 4/26/14
	runPS "Get-NetNatExternalAddress"		# W8.1/WS2012R2	# unknown		# Added 4/26/14
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}
else
{
	"The Get-NetNat* powershell cmdlets only run on Server WS2012 R2+. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}
CollectFiles -filesToCollect $outputFile -fileDescription "Hyper-V Networking Settings" -SectionDescription $sectionDescription

# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCfjjr25lob8Inl
# rQG1cmj8e9Tsl2vavcnwnlHsP9tMy6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgd6fdpiDq
# /7j7fXN2mFWW4S5AakssMw00hOuOyVxJQcgwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAFqbhy3JRP6zkiIEJLlyTW6k/onUeWcS4mKm5OyBvFd7L24+G1Ug7MDL
# eJghdriQ4xuEwzOx4mWz8v5WzbPQvGwSMzybCwZCGIKyF68dYG7nprCskFJfoW+M
# +reWaEC8KWRx2l10Ey59kYQEHuQ0Jaa0YjDPb8LeaOrC+vLcsqAHNPyg9qFCFbTc
# sYYq0lyHSl+SM34h2gOg4YWjvIbqx4+1PFs1V3pSBQBSKRZ4mVxfz+oESX/dS5tE
# nwKZAt+SwgIW2KptvMhI43dQ0ezhKuBCZi8iMo088UMakLNmYV6Rx8CIoRMfo+s+
# 5CVJl8NePqzoOOMjijvxzxgfpv6O6cuhghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgWrsorVYCqImsvlOs/pXYWGfWwsU1xhwI378LEA0QerwCBmCKzptS
# sxgTMjAyMTA1MTkyMjIyNTUuNjM0WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABPIv9ubM/R5f9AAAAAAE8MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyM1oXDTIyMDExMjE3MjgyM1owgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MTc5RS00
# QkIwLTgyNDYxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCYECrpaQOq9jkOBpC345fQ
# 0IvOpRqK8nEe+jopJc/5XNNqzanq5hrd9wib4RdvpuPj68n5Dm/XZu2vCqnWoxhy
# 3ixrbgS/rg3CS3bqp8Ag1UQg/xAz32TueeTOY1cOelcXRahosIcjlrrkv13AacFX
# m4AbYMCgYM6BzdZKARebc6zEv+4QCy4+1AV8RHQHEOdoj42OJpbFWlHvYKzXuM1A
# H4vmjT9o/fCq2mWD7Ig2/CpaId2gHK6R+S909iK27uVkjVap2/Sb4ATOLJbaVQ+X
# 0+hYbEcCesf93g+tAQXuvA8dH63doK5I5zdZCF5U/3Dibfl7ZCFsU6ks+ph4jJrb
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQU4aFn4soS+jazYT8lGOoYvyZnPEYwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAMvcQjJTdl3luSMzFqRkxRklJ+KWRUUlB
# 3I2KJVWb4Gn6eWdJTiWdC1uxejF2oPX0b+X9QIhi8u1AaV792eEit2lQzqVgPify
# TZGLjzK2Oou4Pj/F58Pp2m6HupGfuNAehln+hSvvIE5ggEnCiv9lVkAJOMlLHF38
# DbPv7pyWs0Lzv2sjZwPHvdhtV8lBtOYsE8Nxznlbsyc80vRnReqm8JQK6Z8xAD4S
# eY8duFFXhciETG2E0bh+/N3mwGnzXJzMbSKAKkzIw6Yxqf+zHzWPFim9DGZwmchq
# +6JBKtb4EGT0EFtfqGCrOPD5O7uPwSdj1apgXqo7Hctx7hcs5qjpwjCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAHUt0elneaPLba16Ke63RR3B65OaggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAORPqk8wIhgPMjAyMTA1MTkyMzE2MzFaGA8yMDIxMDUyMDIzMTYzMVowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5E+qTwIBADAKAgEAAgIYqAIB/zAHAgEAAgIR
# MzAKAgUA5FD7zwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAI+E73p4h9kk
# SYCzO+rXLK7RK5Ia4XU7rSWLex0xaCG/tD8TBNoGZmVMrG4m9+o4FLmoY6aEzPou
# xTR4PEZU7Qh1EwiNCZblZFkfz+rofE0LgYHWkXw/kJuAVExDxVWBlamtk6kY7p1/
# XyFZKWFBMQMEU6Iu1idtHDCvZZNdvLOxMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAE8i/25sz9Hl/0AAAAAATwwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgt3TcRqvnBUH7CiE/WKGBK3scm4Y0JjYfzxbZ5PJr8XIwgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCgSQK6TSS/wOc6qbfUfBGv7YhsPfGYhbgV
# IYrhJuhaRjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABPIv9ubM/R5f9AAAAAAE8MCIEIB+co0f6Uly9BxK096y0E+Z8u4RNWInNiBJi
# 2xgL13agMA0GCSqGSIb3DQEBCwUABIIBAG/8OXzkWizw8P6bKubck/WLv1k4CWHE
# hD3H5OJyWogKdn2iLJC1uiiTS8s2fIpy9ABRNyV9S5oj8JxFiXHNoqCMgGFveViL
# Jvs9+QQgVv4R5Gd4MY2GR22up8ZbQZRkQ5rVDLNMfCdVsRjKOB1DXfHzu2gidaF8
# QN72JOt3WC2FcaobrD7MoCB50xX+AHytvQxGHV35vEYcRJWcdhZTbZRz/CuVu/+N
# YZ1jLhCePs/dGzcA3u4gUSoG2vOptWjtbQkREnDq6cohSEFiI51ulas902xSYGzH
# VVmmX1ZVgsLnpqwIy4l4zFHu8qyvjXql9qb0Dg10jsgjzJKBprt4Rpo=
# SIG # End signature block
