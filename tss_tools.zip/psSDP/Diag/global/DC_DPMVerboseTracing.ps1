﻿#************************************************
# DC_DPMVerboseTracing.ps1
# Version 1.0.1
# Date: 12/3/2012
# Author: v-maam
# Description:  [Idea ID 6196] [System Center Data Protection Manager] SDP Request - Verbose logging option (tracing) for DPM
# Rule number:  6196
# Rule URL:  http://sharepoint/sites/rules/Rule Submissions/Forms/DispForm.aspx?ID=6196
#************************************************

$StartTime  = [DateTime]::Now

Import-LocalizedData -BindingVariable ScriptStrings

$Script:DPMRegisoryKeyPath = "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager"
$Script:DPMFolderDir = GetDPMInstallFolder  # GetDPMInstallFolder function from Functions.ps1
 trap [Exception] 
 {
  WriteTo-ErrorDebugReport -ErrorRecord $_ 
  $Error.Clear()
  continue
 }

Function Press_s_key
		Write-Host "`n$(Get-Date -Format "HH:mm:ss") === Press the 's' key to stop verbose tracing. ===`n" -ForegroundColor Green
		do {
			$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
		} until ($x.Character -ieq 's')
}
####################################################################################
# Check to be sure the DPM 2010 or 2012 installed on the DPM server
####################################################################################
#Function CheckTheAvailableDPMVersion
#{
#	if(IsDPMInstalled) # IsDPMInstalled function from Functions.ps1
#	{		
#		$DPMVersion = DPMVersion ($Script:DPMFolderDir) 
#		if(($DPMVersion -eq 3) -or ($DPMVersion -eq 4))  # DPM 2010 and DPM 2012
#		{
#			return $true
#		}
#		else
#		{
#			"The current DPM version is " + $DPMVersion + " - rule does not apply." | WriteTo-StdOut 
#		}
#	}
#	return $false
#}

####################################################################################
# Check to be sure the DPM 2010 Agent or 2012 Agent installed on the server
####################################################################################
Function CheckTheAvailableDPMRAVersion
{
	if(IsDPMInstalled)
	{
		$DPMRAVersion = DPMRAVersion ($Script:DPMFolderDir)
		if(($DPMRAVersion -eq 3) -or ($DPMRAVersion -eq 4))  # DPM 2010 agent and DPM 2012 agent
		{
			return $true
		}
		else
		{
			"The current DPM agent version is " + $DPMRAVersion + " - rule does not apply." | WriteTo-StdOut 
		}
	}
	return $false
}

####################################################################################
# Add the TraceLogLevel property to the DPM registory key and restart the dpm related services
####################################################################################
Function AddTheTraceLogLevelRegistryKeyAndRestartServices
{
	if(Test-Path $Script:DPMRegisoryKeyPath)
	{
		$TraceLogLevel = (Get-ItemProperty $Script:DPMRegisoryKeyPath).TraceLogLevel
		if($TraceLogLevel -eq $null)
		{
			New-ItemProperty $Script:DPMRegisoryKeyPath -Name "TraceLogLevel" -Value 0x43e -PropertyType "DWord" 
			"Add the RegitoryKey: HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\TraceLogLevel on " + $ComputerName | WriteTo-StdOut
		}
		else
		{
			Set-ItemProperty $Script:DPMRegisoryKeyPath -Name "TraceLogLevel" -Value 0x43e
			"Set the RegitoryKey: HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\TraceLogLevel value to 0x43e on " + $ComputerName | WriteTo-StdOut
		}
	}

	"Restart the DPM, DPM Access Manager and DPMRA services on " + $ComputerName | WriteTo-StdOut
	if(IsDPMServer)
	{
		Restart-Service "DPM"
		Restart-Service "DPM AccessManager Service"
	}
	else
	{
		"DPM, DPM Access Manager services is not available on " + $ComputerName | WriteTo-StdOut
	}
	Restart-Service "DPMRA"
}

####################################################################################
# Remove the TraceLogLevel property from the DPM registory key and restart the dpm related services
####################################################################################
Function RemoveTheTraceLogLevelRegistryKeyAndRestartServices
{
	if(Test-Path $Script:DPMRegisoryKeyPath)
	{
		$TraceLogLevel = (Get-ItemProperty $Script:DPMRegisoryKeyPath).TraceLogLevel
		if($TraceLogLevel -ne $null)
		{
			Remove-ItemProperty $Script:DPMRegisoryKeyPath -Name "TraceLogLevel"
			"Removed the RegitoryKey: HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\TraceLogLevel on " + $ComputerName | WriteTo-StdOut
		}
	}

	"Restart the DPM, DPM Access Manager and DPMRA services on " + $ComputerName | WriteTo-StdOut
	if(IsDPMServer)
	{
		Restart-Service "DPM"
		Restart-Service "DPM AccessManager Service"
	}
	else
	{
		"DPM, DPM Access Manager services is not available on " + $ComputerName | WriteTo-StdOut
	}
	Restart-Service "DPMRA"
}

####################################################################################
# Record the load dpm console and enumerate the protect server time
####################################################################################
Function RecordScriptRunningTime($StartTime)
{
	$CompletionTime = [DateTime]::Now
	[void][System.Reflection.Assembly]::LoadWithPartialName('System.Core')
	$TimeZone = [System.TimeZoneInfo]::Local | Select-Object -ExpandProperty Id

	$InformationCollected = new-object PSObject
	Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Time Zone" -Value $TimeZone
	Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Start Time" -Value $StartTime
	Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Completion Time" -Value $CompletionTime
	Add-Member -InputObject $InformationCollected -MemberType NoteProperty -Name "Runing Total Seconds" -Value ([timespan]($CompletionTime - $StartTime)).TotalSeconds
	$InformationCollected | ConvertTo-Xml2 | update-diagreport -id "EnumerateServerTimeFor$ComputerName" -name ($ComputerName + " - Execution time information")	
}

####################################################################################
# For Remote server side verbose logging Phase 1 and 2, will create the txt file.
####################################################################################
Function RemoteServerSideVerboseLoggingPhase($Phase)
{
	"Start verbose logging Phase: " + $Phase + " on remote server: " + $ComputerName | WriteTo-StdOut
	$File = "VerbosePhase" + $Phase + ".txt"
	"For verbose logging Phase" + $Phase | Out-File $File -Encoding "utf8"
	$timeout = 15*60
	do
	{
		$VerbosePhaseFileExist = $true
		if(Test-Path (Join-Path $Pwd.Path $File))
		{
			Start-Sleep -Seconds 3
			$timeout = $timeout - 3

			if($timeout -le 0) # time out occurred, and log the information.
			{
				"[Error] A timeout has occurred. The verbose logging phase ("+ $Phase +") file: " + $File + " is still exist on the " + $ComputerName +", this phase will ended." | WriteTo-StdOut
			}
		}
		else
		{
			$VerbosePhaseFileExist = $false
		}
	} while ($VerbosePhaseFileExist -and ($timeout -gt 0))

	"End verbose logging Phase: " + $Phase + " on remote server: " + $ComputerName | WriteTo-StdOut
}

####################################################################################
# For Local server side verbose logging Phase 1 and 2, will delete the txt file.
####################################################################################
Function LocalServerSideVerboseLoggingPhase($ProtectedServerList, $Phase)
{
	"Start verbose logging Phase: " + $Phase + " on Local Server: " + $ComputerName | WriteTo-StdOut
	$FileName = "VerbosePhase" + $Phase + ".txt"
	$DiagnosticsFolderName = [System.IO.Path]::GetFileName($PWD.Path)
	$FoundPhaseFileMachineList = @("$ComputerName")
	$timeout = 15*60
	$timeoutOccurred = $false
	do 
	{
		$VerbosePhaseFileFound = $true	# assume all machine found the VerbosePhase.txt file
		foreach($machine in $ProtectedServerList)
		{			
			if(-not($FoundPhaseFileMachineList -Contains $machine))
			{
				trap [Exception] 
				{
					$ErrorStd = "[LocalServerSideVerboseLoggingPhase] The following error ocurred when checking if the VerbosePhasePhase"+$Phase+".txt file exists" 
					WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText $ErrorStd
					$error.Clear()
					continue
				}

				$Status = (($ScriptStrings.ID_DPM_Activity_VerboseLogs_Syncronizingexecution_Status) -Replace("%machine%", $machine) -Replace("%Phase%",$Phase))
				Write-DiagProgress -Activity $ScriptStrings.ID_DPM_Activity_VerboseLogs -Status $Status

				$FileFullPath = Join-Path -Path "\\$machine\admin$\temp\diagnostics\$DiagnosticsFolderName" -ChildPath $FileName
				"Checking for " + $FileFullPath + " (Phase " + $Phase + " ) on Server: " + $machine | WriteTo-StdOut

				if (-not(Test-Path $FileFullPath)) #Check all machines, once found a machine didnot have the file, always set the flag to false.
				{
					$VerbosePhaseFileFound = $false  
					if($timeoutOccurred  -eq $true) #if time out occurred, add the unable communicate machine to list string.
					{
						$UnableCommunicateMachinesString += " " + $machine + ","
					}
				}
				else # if machine has the file, add the machine to list, and next time will not check this machine.
				{
					$FoundPhaseFileMachineList += $machine 
				}
			}
		}
			
		if(($timeoutOccurred -eq $true) -and ($UnableCommunicateMachinesString -ne $null)) #if time out occurred, log the unable communicate machines.
		{
			"[Error] A timeout has occurred. Unable to communicate to the following machine(s):[" + $UnableCommunicateMachinesString + "]" | WriteTo-StdOut
		}	
				
		if($VerbosePhaseFileFound -eq $false)
		{
			Start-Sleep -Seconds 3
			$timeout = $timeout - 3

			if(($timeout -le 0) -and ($timeoutOccurred -eq $false)) #if time out occurred, add 3 seconds to $timeout, make sure loop one more time to log the unable communicated machines. 
			{
				$timeoutOccurred = $true
				$timeout = $timeout + 3
			}
		}
	} while (($VerbosePhaseFileFound -eq $false) -and ($timeout -gt 0))

	if($Phase -eq 2)
	{
		"Create the sub-key TraceLogLevel in HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft Data Protection Manager on Local Server: " + $ComputerName | WriteTo-StdOut 
		AddTheTraceLogLevelRegistryKeyAndRestartServices

		#-# Get-DiagInput -Id ID_WaitingForReproduceIssue
		Press_s_key
	}

	foreach($machine in $ProtectedServerList)
	{
		if($machine -ne $ComputerName)
		{
			"Remove "+$FileName+" on server: " + $machine | WriteTo-StdOut
			Remove-Item (Join-Path -Path "\\$machine\admin$\temp\diagnostics\$DiagnosticsFolderName" -ChildPath $FileName)
		}
	}

	"End verbose logging Phase: " + $Phase + " on Local Server: " + $ComputerName | WriteTo-StdOut
}

####################################################################################
# Main Logic for collect the VerboseTracing Data
####################################################################################

Write-DiagProgress -Activity $ScriptStrings.ID_DPM_Activity_VerboseLogs -Status $ScriptStrings.ID_DPM_Activity_VerboseLogs_Status

"here" | out-file C:\temp\function.txt -append

if(CheckTheAvailableDPMRAVersion)
{
	$RuningEnv = Get-TSRemote
	"TS Remote Level: " + $RuningEnv + " on " + $ComputerName | WriteTo-StdOut
	if($RuningEnv -eq 1) #Under TS_Remote environment, but running on the local machine
	{
		$SelectedMachinesPath = Join-Path $Pwd.Path "SelectedMachines.txt"
		if(Test-Path $SelectedMachinesPath)
		{
			$AllProtectedMachines = Get-Content $SelectedMachinesPath

			LocalServerSideVerboseLoggingPhase -ProtectedServerList $AllProtectedMachines -Phase 1

			LocalServerSideVerboseLoggingPhase -ProtectedServerList $AllProtectedMachines -Phase 2
		}
		else
		{
			"Did not found the SelectedMachines.txt" | WriteTo-StdOut
		}

	}
	elseif($RuningEnv -eq 2) #Under TS_Remote environment and running on a remote machine
	{
		RemoteServerSideVerboseLoggingPhase -Phase 1

		"Create the sub-key TraceLogLevel in HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft Data Protection Manager on " + $ComputerName | WriteTo-StdOut 
		AddTheTraceLogLevelRegistryKeyAndRestartServices

		RemoteServerSideVerboseLoggingPhase -Phase 2
	}
	else  #No TS_Remote environment, local machine runing only.
	{
		"Create the sub-key TraceLogLevel in HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft Data Protection Manager on " + $ComputerName | WriteTo-StdOut 
		AddTheTraceLogLevelRegistryKeyAndRestartServices

		#_# Get-DiagInput -Id ID_WaitingForReproduceIssue
		Press_s_key
	}
	
	Write-DiagProgress -Activity $ScriptStrings.ID_DPM_Activity_VerboseLogs -Status $ScriptStrings.ID_DPM_VerboseLogging_Desc

	"Collect the files from " + $Script:DPMFolderDir + "\Temp on " + $ComputerName | WriteTo-StdOut
	$OutputBase= "$ComputerName" + "_DPM_Verbose_Logs"
	CompressCollectFiles -filesToCollect (Join-Path $DPMFolderDir "Temp\*.*") -fileDescription "DPM Verbose Tracing file" -sectionDescription "Verbose Logging Information" -DestinationFileName ($OutputBase + ".zip") -renameoutput $false

	"Removed the sub-key TraceLogLevel on " + $ComputerName | WriteTo-StdOut
	RemoveTheTraceLogLevelRegistryKeyAndRestartServices

	RecordScriptRunningTime -StartTime $StartTime
}
else
{
	"This is not a DPM server or a protect server" | WriteTo-StdOut
}

# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAk5nLaiWVgc1Nf
# vvlwRhaBT15lU8NULhi5eMoZHY+oiKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgFYXuAsPs
# q7AT43pueoIesMfXo4+p2i6FoWak6tMwF7swOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAJHBDj+lTJtdAPv6YenBVyVt5nNK9J62iDR7X2/rgaiPqrR6aSClQgZg
# Je2duVglOrwGVPP27SZG/NEnL7LllEs5L2wRJ+RMymAiSLG79IohQy5QuNkE+3ra
# 8d91JzNu0y03uU6AuxnqjH2Ry1bg49JkFvBN0ken88NsTmmFYxMAg/bgXIJVKe0R
# O12OG3Do/h8RnQ/iH3dzGl26PdnH45/ecxpbKo+ShjKuGUKvnBZtLe6xP03pVmP/
# 3b6IrN6EjJRsJBCH4d/h4ND9LhX/gUbpqZ28thsRP/9E4BQJ8lfEc195rIbZ2W8B
# ocWa92do91pIAGKcFPHPzTI0gpqsYx2hghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgZhdtXwm1SaPMBobFdFMmQtSPNvAMlr+eze+FPsk3oncCBmGB3Gir
# VhgTMjAyMTExMTExNjUzMzQuNzE0WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYw
# QkMtRTM4My0yNjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFaLLluRDTLbygAAAAAAVowDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE2WhcNMjIwNDExMTkwMjE2WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0yNjM1
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsL1cHFcNrScIrvQd/4aKHo3FGXWYCHMU
# l2iTxuzfGknztMzbysR4eRkBoT4pv0aL1S9OlDfOsRbJZKkhCTLG/9Z/RwiEDWYk
# 6rK7bRM3eX3pm+DNivM7+tCU+9spbv2gA7j5gWx6RAK2vMz2FChLkFgbA+H1DPro
# G5LEf1DB7LA0FCyORWiKSkHGRL4RdIjOltrZp++dExfsst7Z6vJz4+U9eZNI58fV
# Y3KRzbm73OjplfSAB3iNSkHN0wuccK0TrZsvY87TRyYAmyK2qBqi/7eUWt93Sw8A
# LBMY72LKaUmVvaxq/COpKePlHMbhHEbqtTaLt61udBOjNHvc4cwY5QIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFGRzJT/1HI+SftAGhdk5NDzA3jFnMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAAAAbex8WBtSLDiBYxXxU7GVsgb8IgxKJyIO0hmc8vzg
# 4w3iUl5Xkt4mv4dgFyjHmu5Zmbj0rb2IGYm/pWJcy0/zWlhnUQUzvfTpj7MsiH+1
# Lnvg95awe88PRA7FDgc4zYY0+8UB1S+jzPmmBX/kT6U+7rW5QIgFMMRKIc743utq
# CpvcwRM+pEo8s0Alwo8NxqUrOeYY+WfNjo/XOin/tr3RVwEdEopD+FO+f/wLxjpv
# 4y+TmRgmHrso1tVVy64FbIVIxlMcZ6cee4dWD2y8fv6Wb9X/AhtlQookk7QdCbKh
# 3JJ4P8ksLs02wNhGkU37b10tG3HR5bJmiwmZPyopsEgwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0y
# NjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQDMgAWYvcYcdZwAliLeFobCWmUaLqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5TePeDAiGA8y
# MDIxMTExMTE2NDc1MloYDzIwMjExMTEyMTY0NzUyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN494AgEAMAoCAQACAiYUAgH/MAcCAQACAhEuMAoCBQDlOOD4AgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEARgjej0SbSLQSMcUwvN12chrEC28n
# cvB5Y3XUAVhEcy1SU+s/DPBT7RaNwTGRnmi6Mq9YdOCw28LOQagQobT23OIXtlQk
# v6/VnsW+JiF8q2A2Zvn08thSlcdfEr1B4nsYLVrR78o0MGag24mYk75Z6ATsfNVT
# HmPR653hJHGQ0OcxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVosuW5ENMtvKAAAAAABWjANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCBAhk6S
# Lg4ekF06aDAkDMdDrdZEbsJyMSSLCwKv3llB+DCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIJP8qCZ0xLLkXTDDghqv1yZ/kizekzSFS4gicvltsX+wMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFaLLluRDTLbygA
# AAAAAVowIgQgMnaZvhznlep5/TqcHsVpqibeOA9Q6qLRQqPN0sxjsvwwDQYJKoZI
# hvcNAQELBQAEggEAo76RPnrF8Ly2tLe/E+DT4rLGCTAkavfeYYZqDRWBOrDY6B7l
# kXiEX0Dc1jHcIZZ0tCSO70OanH3Vp43t7duWF8zKFAqpVsuGDLlDY78LdnU1EEDZ
# cnk52qQprm+W84jWIhsZDIJ+D4/kZrwAklMED/9r47jxuJvFiIWEUkeWQKPRpPIG
# nunmUN3bxOtqa5mvPgawKTsZgg2FCoEdcqshhmYYf2Y5Z9ybvroYrlEBVRKp7KWM
# FDfR7927lzWNwzLv9zZ6qMRBmC3l//rpornne4vXBvhI9qbbyjHg7zc+5WifeLrV
# YLkAr0oh/sWCplWwZwcZDsgVKnJ+XyrB6lfu7g==
# SIG # End signature block
