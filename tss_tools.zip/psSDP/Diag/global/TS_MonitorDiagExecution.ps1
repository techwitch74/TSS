PARAM (
	$ProcessToTerminate = $null,
	$ScriptBlockToExecute = $null,
	[string] $SessionName = "Session0",
	[switch] $EndMonitoring,
	[switch] $AllSessions
)
# 2019-03-17 WalterE added Trap #_#
Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 WriteTo-ErrorDebugReport -ErrorRecord $_
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Function Get-DiagMonitoringSessionRegistryKey
{
	$DiagMonitoringRegistryKey = "Registry::HKCU\Software\Microsoft\CSSDiagnosticsMonitoring"
	if(-not (Test-Path $DiagMonitoringRegistryKey))
	{
		New-Item -Path $DiagMonitoringRegistryKey | Out-Null
	}
	return (Get-Item $DiagMonitoringRegistryKey)
}
Function Remove-DiagMonitoringSession($SessionName,[switch]$AllSessions)
{
	$MonitoringKey = Get-DiagMonitoringSessionRegistryKey
	if(-not [string]::IsNullOrEmpty($SessionName))
	{
		Remove-ItemProperty -LiteralPath $MonitoringKey.PSPath -Name $SessionName -ErrorAction SilentlyContinue | Out-Null
	}
	if($AllSessions.IsPresent -or ($MonitoringKey.GetValueNames().Length -eq 0))
	{
		Remove-Item -LiteralPath $MonitoringKey.PSPath -Recurse -ErrorAction SilentlyContinue | Out-Null
	}
}
Function Add-DiagMonitoringSession($SessionName,$Process)
{
	$MonitoringKey = Get-DiagMonitoringSessionRegistryKey
	New-ItemProperty -LiteralPath $MonitoringKey.PSPath -Name $SessionName -Value ("{0}|{1}" -f $Process.ID,$Process.StartTime.ToString()) | Out-Null
}

Function Get-DiagMonitoringExistingSessions
{
	param([switch]$Name)
	$MonitoringKey = Get-DiagMonitoringSessionRegistryKey
	$sessionNames = $MonitoringKey.GetValueNames()

	
	return $sessionNames | %{
		$sessionData = $MonitoringKey.GetValue($_).ToString().Split("|")
		$sessionPID = $sessionData[0]
		$sessionStartTime = $sessionData[1]
		
		# test if there's an active processes matching the session - else delete it.
		# matching processes will have the same PID and have been started at the same
		# time with a 5-second margin of error
		
		if($null -eq 
			(Get-Process -id $sessionPID -ErrorAction SilentlyContinue | ? {
				[Math]::Abs(
					[DateTime]::Parse($sessionStartTime).Subtract($_.StartTime).TotalSeconds) -lt 5
			})
		)
		{
			Remove-DiagMonitoringSession -SessionName $_
			return
		}
		
		if($Name.IsPresent)
		{
			return $_
		}
		else
		{
			$sessionObject = New-Object PSObject
			$sessionObject | Add-Member -MemberType NoteProperty -Name "Name" -Value $_
			$sessionObject | Add-Member -MemberType NoteProperty -Name "PID" -Value $sessionPID
			$sessionObject | Add-Member -MemberType NoteProperty -Name "StartTime" -Value $sessionStartTime
			$sessionObject
		}
	}
}

Function CreateSessionMonitorPS1 ($RunDiagMonitorPS1Path, $ConfigXMLPath)
{
	'$ConfigXMLPath = ' + "'" + $ConfigXMLPath + "'"
	$SigFound = $false
	Get-Content $RunDiagMonitorPS1Path -Encoding UTF8 | ForEach-Object -Process {
		if ($_.StartsWith("# SIG #"))
		{
			$SigFound = $true
			return ''
		}
		elseif (-not $SigFound)
		{
			$_
		}
	}
}

Function StartMonitoring ([array] $ExternalProcessesToMonitor, [string] $ScriptBlockToExecute,[string] $SessionName)
{
	[xml] $XMLMonitoring = "<Root />"
	$RootNode = $XMLMonitoring.get_DocumentElement()
	$RootNode.SetAttribute("ParentProcessID",$PID) | Out-Null
	$RootNode.SetAttribute("DiagnosticPath",$PWD.Path) | Out-Null
	$RootNode.SetAttribute("SessionName",$SessionName) | Out-Null
	
	if ($ExternalProcessesToMonitor.Count -gt 0)
	{
		$ProcessesToMonitorNode = [System.Xml.XmlElement]$RootNode.AppendChild($XMLMonitoring.CreateElement("ProcessesToMonitor"))
		Foreach ($ExternalProcesseToMonitor in $ExternalProcessesToMonitor)
		{
			#If Process to Monitor is an int, then it is a PID
			if ($ExternalProcessesToMonitor -as [int])
			{
				$ProcessInfo = Get-Process | Where-Object {$_.ID -eq $ProcessesToMonitorString}
				if ($ProcessInfo -ne $null)
				{
					$ProcessesToMonitorNode.AppendChild($XMLMonitoring.CreateElement("PID")).set_InnerText($ExternalProcessesToMonitor)
					"    Configuring to monitor process with PID $ExternalProcessesToMonitor" | WriteTo-StdOut -ShortFormat
				}
				else
				{
					"    Process with PID $ExternalProcessesToMonitor is not currently runnning and will not be monitored. It was probably terminated." | WriteTo-StdOut  -ShortFormat
				}
			}
			else
			{
				if (Test-Path $ExternalProcessesToMonitor)
				{
					$ExternalProcessesToMonitorProcessPath = [System.IO.Path]::GetFullPath($ExternalProcessesToMonitor)
					$ProcessesToMonitorNode.AppendChild($XMLMonitoring.CreateElement("ProcessPath")).set_InnerText($ExternalProcessesToMonitorProcessPath)
				}
				else
				{
					$ExternalProcessesToMonitorProcessName = [system.IO.Path]::GetFileNameWithoutExtension($ExternalProcessesToMonitor)
					$ProcessesToMonitorNode.AppendChild($XMLMonitoring.CreateElement("ProcessName")).set_InnerText($ExternalProcessesToMonitorProcessName)
				}
			}
		}
	}

	if (-not [string]::IsNullOrEmpty($ScriptBlockToExecute))
	{
		$ScriptBlockToRunNode = $XMLMonitoring.CreateElement('ScriptBlock')
		$ScriptBlockToRunNode.set_InnerText($ScriptBlockToExecute)
		$X = $RootNode.AppendChild($ScriptBlockToRunNode)
	}
	
	$ConfigXMLPath = [System.IO.Path]::GetTempFileName()
	
	$XMLMonitoring.Save($ConfigXMLPath)
	
	$PS1FilePath = ([System.IO.Path]::GetTempFileName() + ".ps1")
	
	$MonitoringPS1Content = CreateSessionMonitorPS1 $Script:MonitoringPS1FilePath $ConfigXMLPath
	$MonitoringPS1Content | Set-Content -Path $PS1FilePath -Encoding UTF8

	$FileFlagStop = Join-Path $PWD.Path "..\StopMonitoring_$($SessionName)."
	if (Test-Path $FileFlagStop)
	{
		[System.IO.File]::Delete($FileFlagStop)
	}

	#$monitoringProcess = Run-ExternalPSScript -BackgroundExecution -BackgroundExecutionTimeOut 0 -ScriptPath $PS1FilePath -BackgroundExecutionSkipMaxParallelDiagCheck
	$monitoringProcess = Run-ExternalPSScript -BackgroundExecution -BackgroundExecutionTimeOut 0 -ScriptPath $PS1FilePath -BackgroundExecutionSkipMaxParallelDiagCheck  -BackgroundExecutionSessionName "MonitorDiagExecution"
	Add-DiagMonitoringSession -SessionName $SessionName -Process $monitoringProcess

	$StartedFlagFileName = Join-Path $PWD.Path "..\MonitorStarted_$($SessionName)."
	$MAX_WAIT_ITERATIONS = 30
	$waitIterations = 0
	[Diagnostics.Debug]::Assert($waitIterations -le $MAX_WAIT_ITERATIONS)
	while ((-not (Test-Path $StartedFlagFileName)) -and ($waitIterations -lt $MAX_WAIT_ITERATIONS)){
		if(($waitIterations % 6) -eq 0) {(Split-Path $StartedFlagFileName -Leaf) + " has not yet been created. Waiting..." | WriteTo-StdOut -ShortFormat}
		sleep -Milliseconds 600
		$waitIterations++
	} 

	if(Test-Path $StartedFlagFileName)
	{
		trap [Exception] 
		{
			WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText ("Removing Session Monitoring Files for $($SessionName)")
			continue
		}
		
		"Deleting $StartedFlagFileName" | WriteTo-StdOut -ShortFormat
		
		$waitIterations = 1
		[Diagnostics.Debug]::Assert($waitIterations -le $MAX_WAIT_ITERATIONS)
		while ((Test-Path $StartedFlagFileName) -and ($waitIterations -lt $MAX_WAIT_ITERATIONS))
		{
			trap [Exception] 
			{
				WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText ("Deleting " + (Split-Path $StartedFlagFileName -Leaf))
				continue
			}
			
			[IO.File]::Delete($StartedFlagFileName)
			if(($waitIterations % 6) -eq 0) {(Split-Path $StartedFlagFileName -Leaf) + " - Trying to Delete." | WriteTo-StdOut -ShortFormat}
			sleep -Milliseconds 600
			$waitIterations++
		} 
		
		if(Test-Path $ConfigXMLPath)
		{
			"Deleting Config XML: $ConfigXMLPath" | WriteTo-StdOut -ShortFormat
			[IO.File]::Delete($ConfigXMLPath)
		}
		
		if(Test-Path $PS1FilePath)
		{
			"Deleting Session Monitor PS1 $PS1FilePath" | WriteTo-StdOut -ShortFormat
			[IO.File]::Delete($PS1FilePath)
		}
	}
}

#********************
# Script Starts Here
#********************

# Default session name to Session0 for back compat and for scenarios when 
# only one monitor is designed to be used.
if([string]::IsNullOrEmpty($SessionName)) 
{
	$SessionName = "Session0"
}

# Remove invalid path characters from session name since we're using the name in the path of a file.
[System.IO.Path]::GetInvalidPathChars() | %{ $SessionName = $SessionName.Replace($_,"_")}

if((-not ($EndMonitoring.IsPresent)) -and ((Get-DiagMonitoringExistingSessions -Name) -contains $SessionName))
{
	"[MonitorDiagExecution] ERROR: Duplicate `$SessionName=`"$SessionName`" provided. Monitoring cannot continue. Provide an alternate name." | WriteTo-StdOut -IsError
	return
}
elseif($EndMonitoring.IsPresent -and (-not $AllSessions.IsPresent) -and ((Get-DiagMonitoringExistingSessions -Name) -notcontains $SessionName))
{
	"[MonitorDiagExecution] ERROR: `$SessionName=`"$SessionName`" does not exist. Unable to stop monitoring process. Current Session names = $(Get-DiagMonitoringExistingSessions -Name | Out-String)" | WriteTo-StdOut -IsError
	return
}

$Script:MonitoringPS1FilePath = (Join-Path $PWD.Path 'TS_RunDiagMonitor.ps1')

if (Test-Path $Script:MonitoringPS1FilePath)
{
	if (-not ($EndMonitoring.IsPresent))
	{
		if (($ProcessToTerminate -ne $null) -or ($ScriptBlockToExecute -ne $null))
		{
			if ($ProcessToTerminate -isnot [array])
			{
				if (($ProcessToTerminate -isnot [string]) -or ($ProcessToTerminate -isnot [int]))
				{
					$ProcessToTerminate = [array] $ProcessToTerminate 
				}
				else
				{
					"ERROR: ExternalProcessToMonitor argument needs to contain array, string or integer, but its current type is " + $ProcessToTerminate.GetType().FullName + ". No external process will monitored" | WriteTo-StdOut -IsError
					$ProcessToTerminate = $null
				}
			}
			
			if (($ScriptBlockToExecute -ne $null) -and ($ScriptBlockToExecute -is [scriptblock]))
			{
				$ScriptBlockToExecute = $ScriptBlockToExecute.ToString()
			}
			
			$StatusMSG = "    [MonitorDiagnosticExecution] Sending Command To Start Monitoring. [Session: $SessionName]"
			
			if ($ProcessToTerminate.Count -gt 0) 
			{
				$StatusMSG += "`r`n         [Process(es) To Terminate: "+ [string]::Join(", ", $ProcessToTerminate) + " ]"
			}
			if ([string]::IsNullOrEmpty($ScriptBlockToExecute) -eq $false)
			{
				if ($ScriptBlockToExecute.Length -lt 100)
				{
					$StatusMSG += "`r`n         [Script Block To Execute:]`r`n"+ $ScriptBlockToExecute.replace("`n", "`n             ")
				}
				else
				{
					$StatusMSG += "`r`n         [Script Block To Execute (first 100 chars):]`r`n         " + $ScriptBlockToExecute.Remove(100).replace("`n", "`n            ") + "..."
				}
			}
			
			$StatusMSG | WriteTo-StdOut
			
			StartMonitoring -ExternalProcessesToMonitor $ProcessToTerminate -ScriptBlockToExecute $ScriptBlockToExecute -SessionName $SessionName
		}
		else
		{
			'ERROR: You have to use one of the arguments: ExternalProcessToMonitor ScriptBlockToExecute or EndMonitoring. Ending script' | WriteTo-StdOut -IsError
		}
	}
	else
	{
	
		#sleep several seconds for the package will not end immediately if the user click Close button
		"Before forwarding command to stop monitoring session $SessionName, waiting 2 seconds..." | WriteTo-StdOut -ShortFormat -Color ([System.ConsoleColor]::Cyan)
		sleep 2 
		"Forwarding command to stop monitoring [Session: $SessionName]" | WriteTo-StdOut -ShortFormat -Color ([System.ConsoleColor]::Cyan)
		if($AllSessions.IsPresent)
		{
			Get-DiagMonitoringExistingSessions -Name | %{
				$FileFlagStop = Join-Path $PWD.Path "..\StopMonitoring_$($_)."
				(Get-Date).ToString() | Out-File $FileFlagStop
			}
		}
		else
		{
			$FileFlagStop = Join-Path $PWD.Path "..\StopMonitoring_$($SessionName)."
			(Get-Date).ToString() | Out-File $FileFlagStop
		}
		Remove-DiagMonitoringSession -SessionName $SessionName -AllSessions:$AllSessions
	}
}
else
{
	"ERROR: $($Script:MonitoringPS1FilePath) cannot be found. Ending script" | WriteTo-StdOut -IsError
}
