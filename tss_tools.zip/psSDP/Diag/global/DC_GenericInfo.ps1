trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

TraceOut "Started"
$sectionDescription = "System Information"

Import-LocalizedData -BindingVariable ScriptStrings

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status $ScriptStrings.ID_SCCM_GenericInfo_OSInfo

# Header for Client Summary File
$OSInfoFile = Join-Path $Pwd.Path ($ComputerName + "__OS_Summary.txt")
"=====================================" | Out-File $OSInfoFile
"Operating System Information Summary:" | Out-File $OSInfoFile -Append
"=====================================" | Out-File $OSInfoFile -Append

# PSObject to store Client information
$OSInfo = New-Object PSObject

TraceOut "    Getting OS information..."

# -------------
# Computer Name
# -------------
Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Computer Name" -Value $ComputerName

# ----------------------
# OS information:
# ----------------------
$Temp = Get-CimInstance -Namespace root\cimv2 -Class Win32_OperatingSystem -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Operating System" -Value $Temp.Caption
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Service Pack" -Value $Temp.CSDVersion
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Version" -Value $Temp.Version
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Architecture" -Value $OSArchitecture
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Last Boot Up Time" -Value ($Temp.ConvertToDateTime($Temp.LastBootUpTime))
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Current Time" -Value ($Temp.ConvertToDateTime($Temp.LocalDateTime))
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Total Physical Memory" -Value  ([string]([math]::round($($Temp.TotalVisibleMemorySize/1MB), 2)) + " GB")
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Free Physical Memory" -Value  ([string]([math]::round($($Temp.FreePhysicalMemory/1MB), 2)) + " GB")
}
else {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "OS Details" -Value "Error obtaining data from Win32_OperatingSystem WMI Class" }

# ----------------------
# Computer System Information:
# ----------------------
$Temp = Get-CimInstance -Namespace root\cimv2 -Class Win32_TimeZone -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Time Zone" -Value $Temp.Description }
else {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Time Zone" -Value "Error obtaining value from Win32_TimeZone WMI Class" }

$Temp = Get-CimInstance -Namespace root\cimv2 -Class Win32_ComputerSystem -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Daylight In Effect" -Value $Temp.DaylightInEffect
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Domain" -Value $Temp.Domain
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Model" -Value $Temp.Model
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Number of Processors" -Value $Temp.NumberOfProcessors
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Number of Logical Processors" -Value $Temp.NumberOfLogicalProcessors
}
else {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Computer System Details" -Value "Error obtaining value from Win32_ComputerSystem WMI Class" }

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status $ScriptStrings.ID_SCCM_GenericInfo_SysInfo

# --------------------------
# Get SystemInfo.exe output
# --------------------------
$TempFileName = $ComputerName + "_OS_SysInfo.txt"
$SysInfoFile = Join-Path $Pwd.Path $TempFileName
$CmdToRun = "cmd.exe /c SystemInfo.exe /S $ComputerName > $SysInfoFile"
RunCmd -commandToRun $CmdToRun -filesToCollect $SysInfoFile -fileDescription "SysInfo Output"  -sectionDescription $sectionDescription -BackgroundExecution -noFileExtensionsOnDescription
Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "SysInfo Output" -Value "Review $TempFileName"

TraceOut "    Getting Processes and Services..."

# -----------------------
# Get Running Tasks List
# -----------------------
$TempFileName = $ComputerName + "_OS_TaskList.txt"
$TaskListFile = Join-Path $Pwd.Path $TempFileName
$CmdToRun = "cmd.exe /c TaskList.exe /v /FO TABLE /S $ComputerName > $TaskListFile"
RunCmd -commandToRun $CmdToRun -filesToCollect $TaskListFile -fileDescription "Running Tasks List"  -sectionDescription $sectionDescription -noFileExtensionsOnDescription
Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Running Tasks List" -Value "Review $TempFileName"

# ----------------
# Services Status
#-----------------
$TempFileName = $ComputerName + "_OS_Services.txt"
$ServicesFile = Join-Path $Pwd.Path $TempFileName
$Temp = Get-CimInstance Win32_Service -ErrorVariable WMIError -ErrorAction SilentlyContinue  | Select DisplayName, Name, State, @{name="Log on As";expression={$_.StartName}}, StartMode | `
			Sort-Object DisplayName | `
			Format-Table -AutoSize
If ($WMIError.Count -eq 0) {
	$Temp | Out-File $ServicesFile -Width 1000
	CollectFiles -filesToCollect $ServicesFile -fileDescription "Services Status" -sectionDescription $sectionDescription -noFileExtensionsOnDescription
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Services Status" -Value "Review $TempFileName"
}
Else {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Services Status" -Value "Error obtaining Services Status: $WMIError[0].Exception.Message"
	$WMIError.Clear()
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status $ScriptStrings.ID_SCCM_GenericInfo_MSInfo

# ------------------
# Get MSInfo output
# ------------------
$TempFileName = $ComputerName + "_OS_MSInfo.NFO"
$MSInfoFile = Join-Path $Pwd.Path $TempFileName
$CmdToRun = "cmd.exe /c start /wait MSInfo32.exe /nfo $MSInfoFile /computer $ComputerName"
RunCmd -commandToRun $CmdToRun -filesToCollect $MSInfoFile -fileDescription "MSInfo Output"  -sectionDescription $sectionDescription -BackgroundExecution
Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "MSInfo Output" -Value "Review $TempFileName"

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status $ScriptStrings.ID_SCCM_GenericInfo_RSoP

# --------------------
# Get GPResult Output
# --------------------
TraceOut "    Getting GPResult..."
$CommandToExecute = "$Env:windir\system32\cmd.exe"

$OutputFileZ = $ComputerName + "_OS_GPResult.txt"
$Arg =  "/c $Env:windir\system32\gpresult.exe /Z > `"" + $PWD.Path + "\$OutputFileZ`""
Runcmd -fileDescription "GPResult /Z output" -commandToRun ($CommandToExecute + " " + $Arg) -filesToCollect $OutputFileZ -sectionDescription $sectionDescription -noFileExtensionsOnDescription
Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "GPResult /Z Output" -Value "Review $OutputFileZ"

If ($OSVersion.Major -ge 6) {
	$OutputFileH = $ComputerName + "_OS_GPResult.htm"
	$Arg =  "/c $Env:windir\system32\gpresult.exe /H `"" + $PWD.Path + "\$OutputFileH`" /F"
	Runcmd -fileDescription "GPResult /H output" -commandToRun ($CommandToExecute + " " + $Arg) -filesToCollect $OutputFileH -sectionDescription $sectionDescription -noFileExtensionsOnDescription
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "GPResult /H Output" -Value "Review $OutputFileH"
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status $ScriptStrings.ID_SCCM_GenericInfo_EnvVar

# ----------------------
# Environment Variables
# ----------------------
TraceOut "    Getting environment variables..."
$TempFileName = $ComputerName + "_OS_EnvironmentVariables.txt"
$OutputFile = join-path $pwd.path $TempFileName
"-----------------" | Out-File $OutputFile
"SYSTEM VARIABLES" | Out-File $OutputFile -Append
"-----------------" | Out-File $OutputFile -Append
 [environment]::GetEnvironmentVariables("Machine") | Out-File $OutputFile -Append -Width 250
"" | Out-File $OutputFile -Append
"-----------------" | Out-File $OutputFile -Append
"USER VARIABLES" | Out-File $OutputFile -Append
"-----------------" | Out-File $OutputFile -Append
 [environment]::GetEnvironmentVariables("User") | Out-File $OutputFile -Append -Width 250
 CollectFiles -filesToCollect $OutputFile -fileDescription "Environment Variables"  -sectionDescription $sectionDescription -noFileExtensionsOnDescription
 Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Environment Variables" -Value "Review $TempFileName"

# ----------------------
# Pending Reboot
# ----------------------
TraceOut "    Determining if reboot is pending..."
$TempFileName = $ComputerName + "_OS_RebootPending.txt"
$OutputFile = join-path $pwd.path $TempFileName
Get-PendingReboot -ComputerName $ComputerName | Out-File $OutputFile
CollectFiles -filesToCollect $OutputFile -fileDescription "Reboot Pending"  -sectionDescription $sectionDescription -noFileExtensionsOnDescription
Add-Member -InputObject $OSInfoFile -MemberType NoteProperty -Name "Reboot Pending" -Value "Review $TempFileName"

# ---------------------------------
# Get event logs
# ---------------------------------
TraceOut "    Getting Event Logs..."
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status ($ScriptStrings.ID_SCCM_GenericInfo_EventLog)

$ZipName = $ComputerName + "_OS_EventLogs.zip"
$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_OS_EventLogs")
$fileDescription = "Event Logs"

If (Test-Path $Destination) {
	Remove-Item -Path $Destination -Recurse -Force
}
New-Item -ItemType "Directory" $Destination

# Copy files directly, it's much much faster this way. User can convert to TXT or CSV offline, as needed.
$TempLogPath = Join-Path $Env:windir "system32\winevt\logs"
Copy-Files -Source $TempLogPath -Destination $Destination -Filter Application.evtx
Copy-Files -Source $TempLogPath -Destination $Destination -Filter System.evtx
Copy-Files -Source $TempLogPath -Destination $Destination -Filter Security.evtx
Copy-Files -Source $TempLogPath -Destination $Destination -Filter Setup.evtx

compressCollectFiles -DestinationFileName $ZipName -filesToCollect ($Destination + "\*.*") -sectionDescription $sectionDescription -fileDescription $fileDescription -Recursive -ForegroundProcess -noFileExtensionsOnDescription
Remove-Item -Path $Destination -Recurse -Force

# --------------------------------
# Get WMI Provider Configuration
# --------------------------------
TraceOut "    Getting WMI Configuration..."
$TempFileName = $ComputerName + "_OS_WMIProviderConfig.txt"
$OutputFile = join-path $pwd.path $TempFileName
$Temp1 = Get-CimInstance -Namespace root -Class __ProviderHostQuotaConfiguration -ErrorAction SilentlyContinue
If ($Temp1 -is [WMI]) {
	TraceOut "      Connected to __ProviderHostQuotaConfiguration..."
	"------------------------" | Out-File $OutputFile
	"WMI Quota Configuration " | Out-File $OutputFile -Append
	"------------------------" | Out-File $OutputFile -Append
	$Temp1 | Select MemoryPerHost, MemoryAllHosts, ThreadsPerHost, HandlesPerHost, ProcessLimitAllHosts | Out-File $OutputFile -Append
}

$Temp2 = Get-CimInstance -Namespace root\cimv2 -Class MSFT_Providers -ErrorAction SilentlyContinue
if (($Temp2 | Measure-Object).Count -gt 0) {
	TraceOut "      Connected to MSFT_Providers..."
	"------------------------" | Out-File $OutputFile -Append
	"WMI Providers " | Out-File $OutputFile -Append
	"------------------------`r`n" | Out-File $OutputFile -Append
	foreach($provider in $Temp2) {
		"Process ID $($provider.HostProcessIdentifier)" | Out-File $OutputFile -Append
		"  - Used by Provider $($provider.provider)" | Out-File $OutputFile -Append
		"  - Associated with Namespace $($provider.Namespace)" | Out-File $OutputFile -Append

		if (-not [string]::IsNullOrEmpty($provider.User)) {
			"  - By User $($provider.User)" | Out-File $OutputFile -Append
		}

		if (-not [string]::IsNullOrEmpty($provider.HostingGroup)) {
			"  - Under Hosting Group $($provider.HostingGroup)" | Out-File $OutputFile -Append
		}

		"" | Out-File $OutputFile -Append
	}
}

if ($Temp1 -is [wmi] -or $Temp2 -is [wmi]) {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "WMI Provider Config" -Value "Review $TempFileName"
	CollectFiles -filesToCollect $OutputFile -fileDescription "WMI Provider Config" -sectionDescription $sectiondescription -noFileExtensionsOnDescription }
else {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "WMI Provider Config" -Value "Error obtaining data from WMI" }

# --------------------------------
# Collect Certificate Information
# --------------------------------
TraceOut "    Getting Certificates..."
$TempFileName = ($ComputerName + "_OS_Certificates.txt")
$OutputFile = join-path $pwd.path $TempFileName

"##############" | Out-File $OutputFile
"## COMPUTER ##" | Out-File $OutputFile -Append
"##############`r`n`r`n" | Out-File $OutputFile -Append

"MY" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\LocalMachine\My | Out-File $OutputFile -Append

"SMS" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\LocalMachine\SMS | Out-File $OutputFile -Append

"Trusted People" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\LocalMachine\TrustedPeople | Out-File $OutputFile -Append

"Trusted Publishers" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\LocalMachine\TrustedPublisher | Out-File $OutputFile -Append

"Trusted Root CA's" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\LocalMachine\Root | Out-File $OutputFile -Append

"##############" | Out-File $OutputFile -Append
"##   USER   ##" | Out-File $OutputFile -Append
"##############`r`n`r`n" | Out-File $OutputFile -Append

"MY" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\CurrentUser\My | Out-File $OutputFile -Append

"Trusted People" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\CurrentUser\TrustedPeople | Out-File $OutputFile -Append

"Trusted Publishers" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\CurrentUser\TrustedPublisher | Out-File $OutputFile -Append

"Trusted Root CA's" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\CurrentUser\Root | Out-File $OutputFile -Append

Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Certificates" -Value "Review $TempFileName"
CollectFiles -filesToCollect $OutputFile -fileDescription "Certificates" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ---------------------------
# Collect OS Information
# ---------------------------
$OSInfo | Out-File $OSInfoFile -Append -Width 500
CollectFiles -filesToCollect $OSInfoFile -fileDescription "OS Summary"  -sectionDescription $global:SummarySectionDescription -noFileExtensionsOnDescription

TraceOut "Completed"
# SIG # Begin signature block
# MIIjhwYJKoZIhvcNAQcCoIIjeDCCI3QCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBWP5DE6hib1Dfe
# GSAWYF0q+ZKrXDOl+Yyc4vXHhxKVlKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXDCCFVgCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgLUaUbv9Q
# dxorb8jVgBGnqzagZAkKfYZEap7T4RSW64cwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAF3LQRdWA9sPz88x+N39slesfpx19FonmCyKNEpVvnRD08gNM7cZ6KW2
# wvOQVWVuh0fFDemg1BjrKSbzRLZS3HLxTLH/e4c+6eCigEYuh6gUt8qL9y+/VCzH
# VmQyQ3bT8W0VfUqLUkjtkCmHsa53rxubhDONX9Cl+yaKooTnxl50kLbWKviagWlw
# gyptVttT5pJDadpQepCzZ047mvyejdH3QFl2orZws/LYEvwfR5eRa39ZQui1wETt
# O8g2I8XmR8jgFrFgNUCasJzmUZRfdJ2jZnZXBpd80m9/osqhOmXx3c6cUBVKDRgS
# 9ZoJRijq30tkIgSLrGcvumrQ65n80XWhghLwMIIS7AYKKwYBBAGCNwMDATGCEtww
# ghLYBgkqhkiG9w0BBwKgghLJMIISxQIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVAYL
# KoZIhvcNAQkQAQSgggFDBIIBPzCCATsCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgMgIXqQbS+F+ALQYHxVP/sFk3gQE+lJAQQFJbxr1HrjcCBmGB56/O
# jRgSMjAyMTExMTExNjUzMzQuMzJaMASAAgH0oIHUpIHRMIHOMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3Bl
# cmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046Nzg4
# MC1FMzkwLTgwMTQxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZp
# Y2Wggg5EMIIE9TCCA92gAwIBAgITMwAAAVyG0uPsOfaLOAAAAAABXDANBgkqhkiG
# 9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMTAxMTQx
# OTAyMTdaFw0yMjA0MTExOTAyMTdaMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVy
# dG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046Nzg4MC1FMzkwLTgwMTQx
# JTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQDQKis+ryofYkCyaBLyXAlMHeX52rcEF5iG
# TJSfOL+J7DLn53yWxutt3/1PDgbtbMjlzme1cxzngv/qyGa83CUGkPK+ZQkI5/X4
# ht45Pqaj0hUZd8PWBhY6LsvxcbkgOrPzL+29BktG2h05SRYEbgygYAbE2oBkeEkZ
# h5xXa0oU97ZNU91gEi0xiEnhhseItA8g7s/M0FZqaS/PgVMoj4q9Fv12TrLgOhRM
# Y94E78ky34g1YZjXMMz7+S0JayFYq9Jtvu1A02PIp8x5f9gpR+DeNrqm1pPR9iOK
# 6QgnFFkgcNZvA3uIU7ExkBE+6okfhXyOz0JSUPvXn+wDQH5T0jYbAgMBAAGjggEb
# MIIBFzAdBgNVHQ4EFgQUX/MUrDkocoCQBX+4mnstYxjBuj4wHwYDVR0jBBgwFoAU
# 1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0w
# Ny0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkq
# hkiG9w0BAQsFAAOCAQEAeHlM9td+IHMOHCP1Mtnto5Du7XqSu0+Vl7e+mvwM/6XT
# QjegdQ+kGEURy/dCZhpWTHVLcBvwOhPUajag7/Wh0PP9hSxXK6zTk4A0NHI2f/TM
# fLLaNe5OK1ttkL02DkAQdeKLjQLA5aGfWqnP0LZovCRR3ejHO7xOaA4HlRpt8vHq
# +1IC5+IJEyGJ/JXkz2PR9srqC3120PF65dFlhQW5mZurdwxBvq+q2iJjSez6wUB5
# 6XV8Qo4xeVjTzGDXihFgPkZMgORQ+WANLil7ZTXeR4L8HFqPwAhsrj5bscGAXAwm
# UBRWraL9LjYzrEMRDEYAM6QOb6hDjsf01BGBZHEQSTCCBnEwggRZoAMCAQICCmEJ
# gSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18
# aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdN
# uDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NM
# ksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2K
# Qk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZ
# zTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQ
# BgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0f
# BE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4w
# TDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCB
# jwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAd
# AEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAd
# MA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F
# 4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbM
# QEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mB
# ZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7ti
# X5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S
# 4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3ai
# caoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf
# 5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsb
# iSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJ
# zxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB
# 0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/e
# dIhJEqGCAtIwggI7AgEBMIH8oYHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQ
# dWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046Nzg4MC1FMzkwLTgw
# MTQxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAH
# BgUrDgMCGgMVAJ7ipaPGnyhHlZx+Xesj+J5OafBMoIGDMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDlN5qzMCIYDzIw
# MjExMTExMTczNTQ3WhgPMjAyMTExMTIxNzM1NDdaMHcwPQYKKwYBBAGEWQoEATEv
# MC0wCgIFAOU3mrMCAQAwCgIBAAICIV8CAf8wBwIBAAICEgowCgIFAOU47DMCAQAw
# NgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgC
# AQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQBVcB0qf+Uxb+Cew7YkRSwXqYH6NWCm
# jJD+EQ7/bx7UC79TkfgWae2dZAirgPW/E+BJsG6k4jKrZC8usFa4chIobj/R3JMX
# GTe3jAE7ctNFsTeFuqK2RQvFjEDHPNvia9kL7d9bL4/YW011dInBDvq5Xdhj145a
# NwXvuKvHaG/7dTGCAw0wggMJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAABXIbS4+w59os4AAAAAAFcMA0GCWCGSAFlAwQCAQUAoIIBSjAa
# BgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEILF0vJOc
# tKfxcBwRmB3vKQZCAjwSbIZnU7u8PYy5h17yMIH6BgsqhkiG9w0BCRACLzGB6jCB
# 5zCB5DCBvQQgTy1kV8IgT2wAMEnMpCArUD30LiCIRm8V77RcjwwZ5rUwgZgwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAVyG0uPsOfaLOAAA
# AAABXDAiBCCpK/gRC+kHNYXrOhyCUE2rKr9XSTrweuoWoz8O9w/stjANBgkqhkiG
# 9w0BAQsFAASCAQCdwco3LmZox6PM1P/WSHA6yHhM75hv/J3jfp+jIQEtC5nwlML/
# 4J4N3y7KheJS400Pm7gYufVnt/uoC6yIw2aWy1Uptvezab1ePa0N1jPAs+eWQ8K5
# 0Y/1yrGaY5uYqXkAsvXOMlqhxaUvYGBB4LwwIWFvrC/lVxa2Kdlgdjn7Cp7zNt5E
# 27a/rbPA6OHb6/y8O4sq0wKI+tMdGQ5/7qxzKTXJAlSbe658p+F/vR3IbFud6byr
# 3V1kfFTSVPwPUrRIX1qccKRDIduTFBCH8liUzY7aksQHmfGRn/Z0fsIV4qYq2+5E
# iRRkA3AXEuLJOwyy6eqh99ts4EoomLk5rFrn
# SIG # End signature block
