﻿###########################################################################
# DC_ClassRegistration
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Queries registry for WU Class Registrations
###########################################################################

Import-LocalizedData -BindingVariable ClassReg -FileName DC_ClassRegistration -UICulture en-us
Write-DiagProgress -Activity $ClassReg.ID_ClassReg -Status $ClassReg.ID_ClassDesc

$OutputFile = $ComputerName + "_ClassRegistration.txt"
"Start creating " + $OutputFile | WriteTo-StdOut 

New-PSDrive -PSProvider registry -Name HKCR -Root HKEY_CLASSES_ROOT
Set-Content $OutputFile "Determining if critical dlls are registered: `n"

function test-registration($reg)
{
	if (Test-Path $reg)
	{
		Add-Content $OutputFile $Class
	}
	else 
	{ 
		Add-Content $OutputFile $NotRegistered
	}
	
}


$reg = "HKCR:\CLSID\{BFE18E9C-6D87-4450-B37C-E02F0B373803}"
$Class = "AutomaticUpdates Class Registered"
$NotRegistered = "AutomaticUpdates Class NOT Registered"
test-registration $reg

$reg = "HKCR:\CLSID\{4CB43D7F-7EEE-4906-8698-60DA1C38F2FE}"
$Class = "UpdateSession Class Registered"
$NotRegistered = "UpdateSession Class NOT Registered"
test-registration $reg

$reg = "HKCR:\CLSID\{72C97D74-7C3B-40AE-B77D-ABDB22EBA6FB}"
$Class = "StringCollection Class Registered"
$NotRegistered = "StringCollection Class NOT Registered"
test-registration $reg

$reg = "HKCR:\CLSID\{C01B9BA0-BEA7-41BA-B604-D0A36F469133}"
$Class = "SystemInformation Class Registered"
$NotRegistered = "SystemInformation Class NOT Registered"
test-registration $reg

$reg = "HKCR:\CLSID\{13639463-00DB-4646-803D-528026140D88}"
$Class = "UpdateCollection Class Registered"
$NotRegistered = "UpdateCollection Class NOT Registered"
test-registration $reg

$reg = "HKCR:\CLSID\{5BAF654A-5A07-4264-A255-9FF54C7151E7}"
$Class = "UpdateDownloader Class Registered"
$NotRegistered = "UpdateDownloader Class NOT Registered"
test-registration $reg

$reg = "HKCR:\CLSID\{20710225-D696-4DA8-B6AE-757E68CDA80C}"
$Class = "UpdateIdentity Class Registered"
$NotRegistered = "UpdateIdentity Class NOT Registered"
test-registration $reg

$reg = "HKCR:\CLSID\{5241D37D-6B9E-43A3-838E-992FE4BB9C51}"
$Class = "UpdateIdentityCollection Class Registered"
$NotRegistered = "UpdateIdentityCollection Class NOT Registered"
test-registration $reg

$reg = "HKCR:\CLSID\{D2E0FE7F-D23E-48E1-93C0-6FA8CC346474}"
$Class = "UpdateInstaller Class Registered"
$NotRegistered = "UpdateInstaller Class NOT Registered"
test-registration $reg

$reg = "HKCR:\CLSID\{B699E5E8-67FF-4177-88B0-3684A3388BFB}"
$Class = "UpdateSearcher Class Registered"
$NotRegistered = "UpdateSearcher Class NOT Registered"
test-registration $reg

$reg = "HKCR:\CLSID\{650503CF-9108-4DDC-A2CE-6C2341E1C582}"
$Class = "WebProxy Class Registered"
$NotRegistered = "WebProxy Class NOT Registered"
test-registration $reg

CollectFiles -filesToCollect $OutputFile -fileDescription "Class Registration" -sectionDescription "System Information"

"Finished creating " + $OutputFile | WriteTo-StdOut 
