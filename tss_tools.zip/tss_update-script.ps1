# Name: tss_update-script.ps1

<# 
.SYNOPSIS
	Script to auto-update tss to latest version or download latest zip from GitHub.

.DESCRIPTION
	Script will search on "https://api.github.com/repos/CSS-Windows/WindowsDiag/releases" for latest tss version
	If local version does not match the remote Github version, it will download and replace tss with latest version
	Script gets the current version by running "tss version".

.PARAMETER tss_action
	choose action from allowed values: "Download" or "Update" or "Version"
		Download	= download latest GitHub version
		Update		= update current local version
		Version		= decide based on local version, try AutoUpdate if local version is lower than GitHub version
	Ex: -tss_action "Download"
	
.PARAMETER tss_file
	Specify filename from allowed values: "tss_tools.zip" or "tss_tools_ttt.zip" or "tss_tools_diff.zip"
	Ex: -tss_file "tss_tools.zip"
	
.PARAMETER tss_path
	Specify the local path where tss.cmd is located.
	Ex: -tss_path "C:\Tss_tools"
.PARAMETER Folderpath
	Specify the local path where tss.cmd is located.
.PARAMETER UpdMode
	Specify the mode: 
		Full  = complete package (tss_tools.zip), 
		Quick =	differential package only (tss_diff.zip): replace only tss.cmd and tss_extra_*.* tss_config.* tss_stop_*.* files
		Force =	run a Full update, regardless of current installed version
.PARAMETER LKGVer
	Last-Known-Good tss version
.PARAMETER tss_arch
	Specify the System Architecture.
	Allowed values:
		x64 - For 64-bit systems
		x86 - For 32-bit systems
	Ex: -tss_arch "x64"

.EXAMPLE
	.\tss_update-script.ps1 -tss_action "Update" -tss_path "C:\Tss_tools" -tss_file "tss_tools.zip"
	Example 1: Update tss in folder C:\Tss_tools
	
.LINK
	https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/TSS - deprecated
	https://api.github.com/repos/CSS-Windows/WindowsDiag/releases - deprecated
#>


param(
	[ValidateSet("download","update","version")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose from: download|update|version')]
	[string]$tss_action 	= "download"
	,
	[string]$tss_path 		= (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[string]$Folderpath 	= (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[ValidateSet("Full","Quick","Force")]
	[string]$UpdMode 		= "Full"
	,
	$LKGVer,
	[ValidateSet("tss_tools.zip","tss_tools_ttt.zip","tss_tools_diff.zip")]
	[string]$tss_file 		= "tss_tools.zip"
	,
	[ValidateSet("x64","x86")]
	[string]$tss_arch 		= "x64",
	[string]$CentralStore	= "",								# updating from Central Enterprise Store
	[switch]$AutoUpd		= $False,							# 
	[switch]$UseExitCode 	= $true								# This will cause the script to bail out after the error is logged if an error occurs.
)

#region  ::::: [Variables] -----------------------------------------------------------#
$ScriptVersion		= "1.11"	#2021-03-15
#$tss_release_url 	= "https://api.github.com/repos/CSS-Windows/WindowsDiag/releases"
$tss_release_url 	= "https://api.github.com/repos/walter-1/TSS/releases"
$UpdLogfile 		= $Folderpath + "\_tss_Update-Log.txt"
$script:ChkFailed	= $FALSE

$invocation 		= (Get-Variable MyInvocation).Value
$scriptName 		= $invocation.MyCommand.Name
$ScriptBeginTimeStamp = Get-Date
#endregion  ::::: [Variables] --------------------------------------------------------#
	
# Check if last "\" was provided in $tss_path, if it was not, add it
if (-not $tss_path.EndsWith("\")){
	$tss_path = $tss_path+"\"
}

#region  ::::: [Functions] -----------------------------------------------------------#
function ExitWithCode ($Ecode) {
	# set ErrorLevel to be picked up by invoking CMD script
	if ( $UseExitCode ) {
		Write-Verbose "[Update] Return Code: $Ecode"
		#error.clear()	# clear script errors
		exit $Ecode
		} #end UseExitCode
}

function get_local_tss_version ($type="current"){
	<#
	.SYNOPSIS
		Function returns current or LKG tss version locally from "$tss_Cmd_file version" command.
	#>
	#param($type = "current")
	switch ($type) {
        "current"  	{ $tss_Cmd_file = "tss.cmd" }
        "LKG" 		{ $tss_Cmd_file = "tss-LKG.cmd" }
        }
	# Regex for version number
	[regex]$regex = '\d+\.\d+\.\d+.\d+'
	
	# Build tss command and run it
	$command = "$tss_path" + "$tss_Cmd_file"
	$version = &$command version | Write-Output

	# Match and return versions
	[string]$version -match $regex > $null
	write-verbose "[Info] $type local version: $version"
	return $Matches[0]
}

function get_GitHub_latest_tss_version() {
	<#
	.SYNOPSIS
		Function will get latest version number from Github Release page
	.LINK
		https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/TSS
	#>

	# Get web content and convert from JSON
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	try { $web_content = Invoke-WebRequest -Uri $tss_release_url -UseBasicParsing | ConvertFrom-Json } catch { "`n*** Failure during TSS update. Exception Message:`n $($_.Exception.Message)" | Out-File $UpdLogfile -Append }
		if ($web_content.tag_name) {
			[version]$expected_latest_tss_version = $web_content.tag_name.replace("v","")
			write-verbose "GitHub Version of '$tss_release_url': --> $expected_latest_tss_version"
			return $expected_latest_tss_version
		}
		else { Write-Host -foreground Red "[ERROR] cannot securely access $tss_release_url. Please download https://aka.ms/getTSS"
			"`n $ScriptBeginTimeStamp [ERROR] cannot securely access $tss_release_url. Please download https://aka.ms/getTSS" | Out-File $UpdLogfile -Append
			$script:ChkFailed=$TRUE
			return 2020.0.0.0}
}

function DownloadFileFromGitHubRelease {
	param($action = "download", $file, $installedTSSver)
	# Download latest CSS-Windows/WindowsDiag release from github
	#$repo = "CSS-Windows/WindowsDiag" "https://api.github.com/repos/CSS-Windows/WindowsDiag/releases"
	$repo = "walter-1/TSS"
	$releases = "https://api.github.com/repos/$repo/releases"
	#Determining latest release , Set TLS to 1.2
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	$tag = (Invoke-WebRequest $releases | ConvertFrom-Json)[0].tag_name
	$download = "https://github.com/$repo/releases/download/$tag/$file"
	Write-Verbose "download: https://github.com/$repo/releases/download/$tag/$file"
	$name = $file.Split(".")[0]
	$zip = "$name-$tag.zip"
	$TmpDir = "$name-$tag"
	Write-Verbose "Name: $name - Zip: $zip - Dir: $TmpDir - Tag/version: $tag"
	
	#_# faster Start-BitsTransfer $download -Destination $zip # is not allowed for GitHub
	Write-Host ".. Secure download of latest release: $download"
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	Invoke-WebRequest $download -OutFile $zip

	if ($action -match "download") {
		Write-Host -foreground Green "[Info] Downloaded version to folder: $tss_path$tss_file"
		}
	if ($action -match "update") {
		$orig_tss_path = (Split-Path $tss_path -Parent)
		if ($orig_tss_path -match "tss_tools") {Write-Host "[downlevel update]: $orig_tss_path matches tss_tools"
			$tss_path = $orig_tss_path
			}
		Write-Host "... saving a copy of installed tss.cmd to $($tss_path + "tss.cmd_v" + $installedTSSver)"
		Copy-Item ($tss_path + "tss.cmd") ($tss_path + "tss.cmd_v" + $installedTSSver) -Force -ErrorAction SilentlyContinue
		Write-Host "... saving a copy of current tss_config.cfg to $($tss_path + "tss_config.cfg_backup")"
		Copy-Item ($tss_path + "tss_config.cfg") ($tss_path + "tss_config.cfg_backup") -Force -ErrorAction SilentlyContinue
		Write-Host "[Expand-Archive] Extracting release files from $zip"
		Write-Verbose ".. Extracting release files from $zip to $ENV:temp\$TmpDir"
		Expand-Archive  -Path $zip -DestinationPath $ENV:temp\$TmpDir -Force
		Write-Host ".. Cleaning up .."
		Write-Verbose "Cleaning up target dir: Remove-Item $name -Recurse"
		Write-Verbose "Copying from temp dir: $ENV:temp\$TmpDir to target dir: $tss_path"
		Copy-Item $ENV:temp\$TmpDir\* -Destination $tss_path -Recurse -Force
		Write-Verbose "Removing temp file: $zip and folder $TmpDir"
		Remove-Item $zip -Force
		Write-Verbose "Remove-Item $ENV:temp\$TmpDir -Recurse"
		Remove-Item $ENV:temp\$TmpDir -Recurse -Force -ErrorAction SilentlyContinue
		if ($orig_tss_path -match "tss_tools") {
			Write-Host "[downlevel update]: copy tss.cmd and tss_update-script.ps1 to $tss_path"
			Copy-Item $ENV:temp\$TmpDir\tss.cmd -Destination $tss_path -Force
			Copy-Item $ENV:temp\$TmpDir\tss_update-script.ps1 -Destination $tss_path -Force
			Write-Host -foreground Green "[Info] New TSS version $expectedVersion is in folder: $tss_path"
			Remove-Item $ENV:temp\$TmpDir -Recurse -Force -ErrorAction SilentlyContinue
		}
	}
}

function TestGithubConn {
	if ($bn -gt 9600) { $checkConn = Test-NetConnection -ComputerName api.Github.com -CommonTCPPort HTTP -InformationLevel Quiet; return $checkConn}
	if ($bn -gt 7600) { $checkConn = Test-Connection -ComputerName api.Github.com -Quiet -Count 1; return $checkConn}
}
#endregion  ::::: [Functions] --------------------------------------------------------#


#region  ::::: [MAIN] ----------------------------------------------------------------#
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$installedTSSver = New-Object System.Version(get_local_tss_version current)
$fileLKGVersion  = New-Object System.Version(get_local_tss_version LKG)
	
# Check if Quick update is allowed / Full update needed: installedTSSver -gt fileLKGVersion 
if ($($installedTSSver.CompareTo($fileLKGVersion)) -lt 0) { # if $installedTSSver is lower than $fileLKGVersion => use Full update
	$UpdMode = "Full"
}

## :: Criteria to use Quick vs. Full update: Quick = current version is higher then LKGVer; Full = if updates in xray or psSDP are needed, ...
# Choose download file based on $UpdMode (and current installed TSS build)
switch ($UpdMode) {
        "Full"  { $tss_file = "tss_tools.zip" }
        "Quick" { $tss_file = "tss_tools_diff.zip" }
		"Force" { $tss_file = "tss_tools.zip" }	# always perform a Full update
        default { $tss_file = "tss_tools.zip"}
        }
		
# Check for Internet connectivity // Test-NetConnection does not work for Win7
$checkConn = TestGithubConn
if ( $checkConn -eq "True") {
	# Determine which edition we need, ? based on existence of .\x64\TTTracer.exe
	$expectedVersion = New-Object System.Version(get_GitHub_latest_tss_version)
	if ("$($expectedVersion)" -eq "0.0") { Write-Verbose "Bail out: $expectedVersion"; ExitWithCode 20}
	# Check if tss exists in $tss_path
	if (-not (Test-Path ($tss_path + "tss.cmd"))){
		Write-Host -foreground red "[Warning] tss.cmd could not be located in $tss_path"
		Write-Host
		DownloadFileFromGitHubRelease "update" $tss_file $installedTSSver
	}

	if (Test-Path ($tss_path + "tss.cmd")){
		if ($UpdMode -eq "Force") {	# update regardless of current local version
		Write-Host -foreground Cyan "[Forced update:] to latest version $expectedVersion from GitHub`n"
		 if (Test-Path ($tss_path + "x64\TTTracer.exe")) { Write-Host -foreground Yellow "[note:] This procedure will not refresh iDNA part"}
									DownloadFileFromGitHubRelease "update" $tss_file $installedTSSver
		} else {
			Write-Host "[Info] check current version $installedTSSver in $tss_path against latest released GitHub version $expectedVersion."
			if ($($installedTSSver.CompareTo($expectedVersion)) -eq 0) { 		# If versions match, display message
				"`n [Info] Latest Tss version $expectedVersion is installed. " | Out-File $UpdLogfile -Append
				Write-Host -foreground Cyan "[Info] Latest Tss version $expectedVersion is installed.`n"}
			elseif ($($installedTSSver.CompareTo($expectedVersion)) -lt 0) {	# if installed current version is lower than latest GitHub Release version
				"`n [Action: $tss_action -[Warning] Actually installed Tss version $installedTSSver is outdated] " | Out-File $UpdLogfile -Append
				Write-Host -foreground red "[Warning] Actually installed Tss version $installedTSSver is outdated"
				Write-Host "[Info] Expected latest tss version on GitHub: $expectedVersion"
				Write-Host -foreground yellow "[Warning] ** Update will overwrite customized configuration, last tss_config.cfg is preserved in tss_config.cfg_backup. ** "
				switch($tss_action)
					{
					"download"		{ 	Write-Host "[download:] latest $tss_file"
										DownloadFileFromGitHubRelease "download" $tss_file $installedTSSver
									}
					"update"		{ 	Write-Host "[update:] to latest version $expectedVersion from GitHub " 
										 if (Test-Path ($tss_path + "x64\TTTracer.exe")) { Write-Host -foreground Yellow "[note:] This procedure will not refresh iDNA part"}
										DownloadFileFromGitHubRelease "update" $tss_file $installedTSSver
									}
					"version"		{ 	Write-Host -background darkRed "[version:] installed TSS version is outdated, please run 'TSS Update', trying AutoUpate" # or answer next question with 'Yes'"
										Write-Host -foreground Cyan "[Info] running AutoUpdate now... (to avoid updates, append TSS switch 'noUpdate')"
										DownloadFileFromGitHubRelease "update" $tss_file $installedTSSver
									}
					}
					"`n [Action: $tss_action - update OK] " | Out-File $UpdLogfile -Append
			}
			else {	# if installed current version is greater than latest GitHub Release version
				if ($script:ChkFailed) {Write-Host -foreground Gray "[Info] Version check failed! Expected version on Github: $expectedVersion. Please download https://aka.ms/getTSS `n"}
				Write-Verbose "Match: Current installed tss version:  $installedTSSver"
				Write-Verbose "Expected latest tss version on GitHub: $expectedVersion"
			}
		}
	}
} else {
	Write-Host -foreground Red "[failed update] Missing secure internet connection to api.GitHub.com. Please download https://aka.ms/getTSS `n"
							"`n [failed update] Missing secure internet connection to api.GitHub.com. Please download https://aka.ms/getTSS `n" | Out-File $UpdLogfile -Append
	}

$ScriptEndTimeStamp = Get-Date
$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)

Write-Host -foreground Black -background gray "[Info] Script $scriptName v$ScriptVersion execution finished. Duration: $Duration"
if ($AutoUpd) { Write-Host -foreground Yellow  "[AutoUpdate done] .. Please repeat your TSS command now."}
# Write-Host -foreground Black -background gray "       .. you can safely IGNORE any Tss update errors after this line - Please repeat your TSS command now."
#}
#endregion  ::::: [MAIN] -------------------------------------------------------------#

#region  ::::: [ToDo] ----------------------------------------------------------------#
<# 
 ToDo: 
 - save any CX changed file like tss_config.cfg into a [backup_v...] subfolder with prev. version, --> easy restoration, if there is no schema change
	see "...saving a copy of installed tss.cmd  ..."
 - allow TSS to update from CX Central Enterprise store \\server\share\tss defined in tss_config.cfg ,if update from GitHub fails
 
- Implement a scheduled task for periodic update check
Example one-line command: schtasks.exe /Create /SC DAILY /MO 1 /TN "tss Updater" /TR "powershell \path\to\script\get-latest-tss.ps1 -tss_path 'path\to\where\tss\is' -tss_arch 'x64'" /ST 12:00 /F
	[/SC DAILY]: Run daily
	[/MO 1]: Every Day
	[/TN "tss Updater"]: Task Name
	[/TR "powershell \path\to\script\get-latest-tss.ps1 -tss_path 'path\to\where\tss\is' -tss_arch 'x64'"]: Command to run
	[/ST 12:00]: Run at 12 PM
	[/F]: Force update
#>
#endregion  ::::: [ToDo] -------------------------------------------------------------#
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDtSv6su3e1uw49
# d8Y/fsUrKyXrVQgpJ+MJHHaOa/Q4KaCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgzEkdxKs2
# 7Wy9bOavzCSCWxzfTjKzC0v4H4msdLv8+BcwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAGzKGSQw39322eYLSDjzam4MQ7mw/qGIyZ1V1Zjl7eMWQSYhEDZTDLhi
# 5v1rn2D5THqH3GnCG/d1kZFoqM72/0SpIqO0BhYuB9VDEpi/wl6RSuX6e8W4reHY
# OrsgHql0w6EylAMLuYsO0fkOK9rAq7hSrLxhDoloUnxEA4ytes+bl7Py2JtIOMzc
# lEvMTe79yycJ9GZPiWMtFVU7IFYxIisWoBwYEs8mqaNgzA7gFe1dTW10dqaBtV8I
# 5qPD6pAzPx6y8xE8NPk+3vAvsF9kO1/wOk25h+7FTaDGH/GTLQwEhO2o0rNyROfB
# 39c+3sKBSzAwmjI2FS6pY1+AOR8NH36hghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQguxU5WaEUdI133oQpCdX7wIOqVz4cM9Uem20X95N1JpcCBmCJ+dKY
# sBgTMjAyMTA1MTkyMjIxNTQuNzc0WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ2
# MkYtRTMxOS0zRjIwMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFYcFoi976W5gMAAAAAAVgwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE0WhcNMjIwNDExMTkwMjE0WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ2MkYtRTMxOS0zRjIw
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoR8Ll2D1q7DQoAUbC/XvIwUbxJ+qBRQU
# LwPPBryaumzR7KFFDY2/0rv+zP99UTWj/V9mnirhIaK1yyM8a06eNbHjlUgVMg1C
# l2g6Gaw92cXLeAFekwa1N9eouedQTj5WYoLa8CE5nTpTq+3kJzRwmioQm3M5ZHAR
# rPwGhfacJfVEFeQfc+IC7u1Ym/dXzOFFI8sWZ6In4IjBrLTgBSCavBcRAe8keBvo
# +IsLGATZUAEIM1PkJXKJ41qlxmIrHXpBsOV7so7CSMwQgqRzFH7fZ0My3MK2khQO
# CsrGaPH4ab3iMeJ6iE4dS6GXe7eGUBh+/ZID/zpPVQ0CIFCDda73GwIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFEtw2Rt9nRwYH+7nfqB7kyfTovlYMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBADnfKANai9CuHx+6WI1dbQJQFPN8DhKXiH4g8SHmU12u
# EMXLpPgwD2O6nXPOUWSlitRzSxN9AIA6cCOa6c+CeZpLltJ/ZUfwyDfhTaqA8sic
# wCQZoGz8HNpsnrlgp7U/kgpk3taPZtF8IrTcRLyRLuDphAfruLEwJAIsOt5YMoli
# w2zRyE2kk4DPIl4Z/JFR75NRRsXCOwL/XwqZg4NWClFJhnHRbuOsaqUlUR6G7ClI
# iwY5gIEyckM10qc/7XcKDrxxW0I1fqQl29QUfRmK48yUFgPsasI+oBGVKf6/F98y
# K+7YMwkkuR7LDFJ8PnawNX40F/kieK4oVwT3LSb2baMwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ2MkYtRTMxOS0z
# RjIwMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQCpyStzGufRCyGm6jOOn6X4NJ80v6CBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9+azAiGA8y
# MDIxMDUxOTE2MDkxNVoYDzIwMjEwNTIwMTYwOTE1WjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT35rAgEAMAoCAQACAgyqAgH/MAcCAQACAhEVMAoCBQDkUM/rAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAPYKNTrA4Z5n2byC1KZ6daaqIwTbC
# 5ysce8Ylar2oI9Qto6sYab7Ziz7B+TgUhJudvxk2LE6IzItvn2PfhPlxTIBrgZdU
# Y93JcRqtOi/EYmEhywm9pylQS7RSbNZ3Mc7TB9vQ93nYX+YyOtZBVQACGqWI/DZA
# qCMQ0nbH2FJNKxUxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVhwWiL3vpbmAwAAAAABWDANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDJR+WZ
# QW/XS5ja82WUe8NzG4/RGPhxpe3x21cQ0ra6PjCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIPJKM41shjWXbMpPhtriwIjhaQELqwh9H25JU1XHcNMHMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFYcFoi976W5gMA
# AAAAAVgwIgQg7DjdbVbb8vJnVqJWHDriLRBz7rRjLeDflmDsHToIV/gwDQYJKoZI
# hvcNAQELBQAEggEAmVjCSxT9c1+bU5Fncr0iG3FHG6uSQeoT9aN/P5dzf4OvGT2M
# sgv5HfvuCLVTilsIRk9jWCHHwhjEDngCfRl8Hj1T5lyFXGMcmPkoiOC+mUGO4w0w
# IbHIov0CNOXQsRMBo9OeccbIS4uYLm8fxZ2XCjJFnJIVHAwGtjigpTKdsGHAu1kf
# dDC0tGRsPvhl7ovgxg0lyZAg6RCwuRSxqTdm8TeMgRO/5UyJyl4ES4Wz/GLxCFvP
# YOeLIZvXX6oNMQeW4hAnV8iiKDl43fNjanBf0bDk7kwUbOASgGqEnr/1HR9CYEee
# sn4Pu9DOrL4arYTbVi3v2xXzeohhl3Tl8HQ4dg==
# SIG # End signature block
