# File: tss_ADFS-tracing.ps1
# https://github.com/CSS-Identity/ADFS-Diag
############################################################################################################
# ADFS troubleshooting - Data Collection
# Supported versions: Windows Server 2012, Windows Server 2012 R2, Windows Server 2016 and Server 2019
# Supported role: ADFS server, ADFS proxy server (2012) and Web Application Proxy (2012 R2 and 2016 and 2019)
# Version:Rel2021_02
############################################################################################################

param (
    [Parameter(Mandatory=$false)]
    [string] $Path,

    [Parameter(Mandatory=$false)]
    [bool]$TraceEnabled,

    [Parameter(Mandatory=$false)]
    [bool]$NetTraceEnabled,

    [Parameter(Mandatory=$false)]
    [bool]$PerfCounter,
	
	[Parameter(Mandatory=$false)]
	[switch]$TSSrun  = $false 		#This tells this script if it was called by TSS
)

##########################################################################
#region Parameters
[Version]$WinVer = (Get-WmiObject win32_operatingsystem).version
try {$wmiOperatingSystem = Get-WmiObject -ComputerName $Env:ComputerName -Class Win32_OperatingSystem | Where {$_.Primary -eq $true}
	} catch {}
if ($wmiOperatingSystem) { $ProductType = ($wmiOperatingSystem.ProductType) }
if ($ProductType -gt 1) {$IsProxy = ((Get-WindowsFeature -name ADFS-Proxy).Installed -or (Get-WindowsFeature -name Web-Application-Proxy).Installed)}
$isdomainjoined = (Get-WmiObject -Class Win32_ComputerSystem).PartOfDomain


				
# Event logs
$ADFSDebugEvents = "Microsoft-Windows-CAPI2/Operational","AD FS Tracing/Debug","Device Registration Service Tracing/Debug"
$WAPDebugEvents  = "Microsoft-Windows-CAPI2/Operational","AD FS Tracing/Debug","Microsoft-Windows-WebApplicationProxy/Session"

$ADFSExportEvents = 'System','Application','Security','AD FS Tracing/Debug','AD FS/Admin','Microsoft-Windows-CAPI2/Operational','Device Registration Service Tracing/Debug','DRS/Admin'
$WAPExportEvents  = 'System','Application','Security','AD FS Tracing/Debug','AD FS/Admin','Microsoft-Windows-CAPI2/Operational','Microsoft-Windows-WebApplicationProxy/Admin','Microsoft-Windows-WebApplicationProxy/Session'
$DbgLvl = 5

#Kerberos EncryptionTypes Bitmask for common
$EncTypes = @{
        "DES-CBC-CRC"             = 1
        "DES-CBC-MD5"             = 2
        "RC4-HMAC"                = 4
        "AES128-CTS-HMAC-SHA1-96" = 8
        "AES256-CTS-HMAC-SHA1-96" = 16
}


#Definition Netlogon Debug Logging
$setDBFlag = 'DBFlag'
$setvaltype = [Microsoft.Win32.RegistryValueKind]::String
$setvalue = "0x2fffffff"

# Netlogon increase size to 100MB = 102400000Bytes = 0x61A8000)
$setNLMaxLogSize = 'MaximumLogFileSize'
$setvaltype2 = [Microsoft.Win32.RegistryValueKind]::DWord
$setvalue2 = 0x061A8000

# Store the original values to revert the config after collection
$orgdbflag = (get-itemproperty -PATH "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters").$setDBFlag
$orgNLMaxLogSize = (get-itemproperty -PATH "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters").$setNLMaxLogSize

#ETW Trace providers
$LogmanOn = 'logman.exe create trace "schannel" -ow -o .\schannel.etl -p {37D2C3CD-C5D4-4587-8531-4696C44244C8} 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 2048 -ets',`
'logman create trace "kerbntlm" -ow -o .\kerbntlm.etl -p {6B510852-3583-4E2D-AFFE-A67F9F223438} 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 2048 -ets',`
'logman update trace "kerbntlm" -p {5BBB6C18-AA45-49B1-A15F-085F7ED0AA90} 0xffffffffffffffff 0xff -ets',`
'logman create trace "dcloc" -ow -o .\dcloc.etl -p "Microsoft-Windows-DCLocator" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 2048 -ets',`
'logman update trace "dcloc" -p {6B510852-3583-4E2D-AFFE-A67F9F223438} 0xffffffffffffffff 0xff -ets',`
'logman update trace "dcloc" -p {5BBB6C18-AA45-49B1-A15F-085F7ED0AA90} 0xffffffffffffffff 0xff -ets'

#NetworkCapture
#changed report generation to NO. speeding up the data collection at the end; #_# for OS >9200 report=disabled, else report=no
$EnableNetworkTracer = 'netsh trace start scenario=internetServer capture=yes report=disabled overwrite=yes maxsize=800 tracefile=.\%COMPUTERNAME%-HTTP-network.etl provider="{DD5EF90A-6398-47A4-AD34-4DCECDEF795F}" keywords=0xffffffffffffffff level=0xff provider="Microsoft-Windows-HttpService" keywords=0xffffffffffffffff level=0xff provider="Microsoft-Windows-HttpEvent" keywords=0xffffffffffffffff level=0xff provider="Microsoft-Windows-Http-SQM-Provider" keywords=0xffffffffffffffff level=0xff provider="{B3A7698A-0C45-44DA-B73D-E181C9B5C8E6}" keywords=0xffffffffffffffff level=0xff'
$DisableNetworkTracer = 'netsh trace stop'

#Performance Counter
$CreatePerfCountProxy = 'Logman.exe create counter ADFSProxy -o ".\ADFSProxy-perf.blg" -f bincirc -max 1024 -v mmddhhmm -c "\AD FS Proxy\*" "\LogicalDisk(*)\*" "\Memory\*" "\PhysicalDisk(*)\*" "\Process(*)\*" "\Processor(*)\*" "\TCPv4\*" -si 0:00:05'
$EnablePerfCountProxy = 'Logman.exe start ADFSProxy'

$DisablePerfCountProxy = 'Logman.exe stop ADFSProxy'
$RemovePerfCountProxy = 'Logman.exe delete ADFSProxy'

$CreatePerfCountADFS = 'Logman.exe create counter ADFSBackEnd -o ".\%COMPUTERNAME%-ADFSBackEnd-perf.blg" -f bincirc -max 1024 -v mmddhhmm -c "\AD FS\*" "\LogicalDisk(*)\*" "\Memory\*" "\PhysicalDisk(*)\*" "\Process(*)\*" "\Processor(*)\*" "\Netlogon(*)\*" "\TCPv4\*" "Netlogon(*)\*" -si 00:00:05'
$EnablePerfCountADFS = 'Logman.exe start ADFSBackEnd'

$DisablePerfCountADFS = 'Logman.exe stop ADFSBackEnd'
$RemovePerfCountADFS = 'Logman.exe delete ADFSBackEnd'

$LogmanOff = 'logman stop "schannel" -ets',`
'logman stop "kerbntlm" -ets',`
'logman stop "dcloc" -ets'

$others = 'nltest /dsgetdc:%USERDNSDOMAIN% > %COMPUTERNAME%-nltest-dsgetdc-USERDNSDOMAIN-BEFORE.txt',`
'certutil -verifystore AdfsTrustedDevices > %COMPUTERNAME%-certutil-verifystore-AdfsTrustedDevices-BEFORE.txt',`
'certutil -v -store AdfsTrustedDevices > %COMPUTERNAME%-certutil-v-store-AdfsTrustedDevices-BEFORE.txt',`
'ipconfig /flushdns > %COMPUTERNAME%-ipconfig-flushdns-BEFORE.txt'

#Collection for Additional Files
$Filescollector = 'copy /y %windir%\debug\netlogon.*  ',`
'ipconfig /all > %COMPUTERNAME%-ipconfig-all-AFTER.txt',`
'netstat -nao > %COMPUTERNAME%-netstat-nao-AFTER.txt',`
'copy %WINDIR%\system32\drivers\etc\hosts %COMPUTERNAME%-hosts.txt',`
'netsh dnsclient show state > %COMPUTERNAME%-netsh-dnsclient-show-state-AFTER.txt',`
'set > %COMPUTERNAME%-environment-variables-AFTER.txt',`
'route print > %COMPUTERNAME%-route-print-AFTER.txt',`
'netsh advfirewall show global > %COMPUTERNAME%-netsh-int-advf-show-global.txt',`
'net start > %COMPUTERNAME%-services-running-AFTER.txt',`
'sc query  > %COMPUTERNAME%-services-config-AFTER.txt',`
'tasklist > %COMPUTERNAME%-tasklist-AFTER.txt',`
'if defined USERDNSDOMAIN (nslookup %USERDNSDOMAIN% > %COMPUTERNAME%-nslookup-USERDNSDOMAIN-AFTER.txt)',`
'nltest /dsgetdc:%USERDNSDOMAIN% > %COMPUTERNAME%-nltest-dsgetdc-USERDNSDOMAIN-AFTER.txt',`
'certutil -verifystore my > %COMPUTERNAME%-certutil-verifystore-my.txt',`
'certutil -verifystore ca > %COMPUTERNAME%-certutil-verifystore-ca.txt',`
'certutil -verifystore root > %COMPUTERNAME%-certutil-verifystore-root.txt',`
'certutil -verifystore AdfsTrustedDevices > %COMPUTERNAME%-certutil-verifystore-AdfsTrustedDevices-AFTER.txt',`
'certutil -v -store my > %COMPUTERNAME%-certutil-v-store-my.txt',`
'certutil -v -store ca > %COMPUTERNAME%-certutil-v-store-ca.txt',`
'certutil -v -store root > %COMPUTERNAME%-certutil-v-store-root.txt',`
'certutil -v -store AdfsTrustedDevices > %COMPUTERNAME%-certutil-v-store-AdfsTrustedDevices-AFTER.txt',`
'certutil –urlcache > %COMPUTERNAME%-cerutil-urlcache.txt',`
'certutil –v –store –enterprise ntauth > %COMPUTERNAME%-cerutil-v-store-enterprise-ntauth.txt',`
'netsh int ipv4 show dynamicport tcp > %COMPUTERNAME%-netsh-int-ipv4-show-dynamicport-tcp.txt',`
'netsh int ipv4 show dynamicport udp > %COMPUTERNAME%-netsh-int-ipv4-show-dynamicport-udp.txt',`
'netsh int ipv6 show dynamicport tcp > %COMPUTERNAME%-netsh-int-ipv6-show-dynamicport-tcp.txt',`
'netsh int ipv6 show dynamicport udp > %COMPUTERNAME%-netsh-int-ipv6-show-dynamicport-udp.txt',`
'netsh http show cacheparam > %COMPUTERNAME%-netsh-http-show-cacheparam.txt',`
'netsh http show cachestate > %COMPUTERNAME%-netsh-http-show-cachestate.txt',`
'netsh http show sslcert > %COMPUTERNAME%-netsh-http-show-sslcert.txt',`
'netsh http show iplisten > %COMPUTERNAME%-netsh-http-show-iplisten.txt',`
'netsh http show servicestate > %COMPUTERNAME%-netsh-http-show-servicestate.txt',`
'netsh http show timeout > %COMPUTERNAME%-netsh-http-show-timeout.txt',`
'netsh http show urlacl > %COMPUTERNAME%-netsh-http-show-urlacl.txt',`
'netsh winhttp show proxy > %COMPUTERNAME%-netsh-winhttp-proxy.txt',`
'wmic qfe list full /format:htable > %COMPUTERNAME%-WindowsPatches.htm',`
'GPResult /f /h %COMPUTERNAME%-GPReport.html',`
'regedit /e %COMPUTERNAME%-reg-RPC-ports-and-general-config.txt HKEY_LOCAL_MACHINE\Software\Microsoft\Rpc',`
'regedit /e %COMPUTERNAME%-reg-NTDS-port-and-other-params.txt HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NTDS\parameters',`
'regedit /e %COMPUTERNAME%-reg-NETLOGON-port-and-other-params.txt HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Netlogon\parameters',`
'regedit /e %COMPUTERNAME%-reg-schannel.txt HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\SecurityProviders\SCHANNEL',`
'regedit /e %COMPUTERNAME%-reg-Cryptography_registry.txt HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Cryptography',`
'regedit /e %COMPUTERNAME%-reg-schannel_NET_strong_crypto.txt HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\.NETFramework',`
'regedit /e %COMPUTERNAME%-reg-schannel_NET_WOW_strong_crypto.txt HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\.NETFramework',`
'regedit /e %COMPUTERNAME%-reg-ciphers_policy_registry.txt HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL'
#endregion Parameters
##########################################################################
#region UI
Function RunDialog {
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$Form                            = New-Object system.Windows.Forms.Form
$Form.ClientSize                 = '800,600'
$Form.text                       = "ADFS Trace Collector"
$Form.TopMost                    = $false
$Form.StartPosition              = 'CenterScreen'
$Form.MaximizeBox                = $false
$Form.MinimizeBox                = $false
$Form.FormBorderStyle            = [System.Windows.Forms.FormBorderStyle]::Fixed3D
# Text field
$Description                     = New-Object system.Windows.Forms.RichTextBox
$Description.multiline           = $true
$Description.text                = "Before running this script consider running the ADFS Diagnostic Analyzer to detect possible existing configuration problems
You can obtain the ADFS Diagnostic Analyzer from the following webpage: https://adfshelp.microsoft.com/DiagnosticsAnalyzer/Analyze

This ADFS Tracing script is intended to collect various details about the ADFS configuration and related Windows Settings.

It also provides the capability to collect various debug logs at runtime for issues that needs to be actively reproduced or are otherwise not detectable
via the ADFS Diagnostic Analyzer and the resulting data can be provided to a Microsoft support technician for analysis.

When running a Debug/Runtime Trace you can choose to add Network Traces and/or Performance Counter to the collection if it is required to troubleshoot
a particular issue.

The script will prepare itself to start capturing data and will prompt the Administrator once the data collection script is ready.
When you have the script in this prompt on all the servers, just hit any key to start collecting data in all of them.
It will then display another message to inform you that it's collecting data and will wait for another key to be pressed to stop the capture.

Note: The script will capture multiple traces in circular buffers. It will use a temporary folder under the path you provide (Example: C:\tracing\temporary).
The temporary folder will be compressed and .zip file left in the path file you selected.
In worst case it will require 10-12 GB depending on the workload and the time we keep it running, but usually it's below 4GB.
Consider capturing the data in a period of time with low workload in your ADFS environment.
"
$Description.width               = 780
$Description.height              = 360
$Description.location            = New-Object System.Drawing.Point(15,0)
$Description.Font                = 'Arial,10'
$Description.ScrollBars          = 'Vertical'
$Description.ReadOnly            = $true
$Description.DetectUrls          = $true

#Configuration only Button
$cfgonly                         = New-Object system.Windows.Forms.CheckBox
$cfgonly.text                    = "Configuration only"
$cfgonly.AutoSize                = $false
$cfgonly.width                   = 220
$cfgonly.height                  = 20
$cfgonly.location                = New-Object System.Drawing.Point(15,380)
$cfgonly.Font                    = 'Arial,10'

#Checkbox for Debug Tracing
$TracingMode                     = New-Object system.Windows.Forms.CheckBox
$TracingMode.text                = "Runtime Tracing"
$TracingMode.AutoSize            = $false
$TracingMode.width               = 220
$TracingMode.height              = 20
$TracingMode.location            = New-Object System.Drawing.Point(15,415)
$TracingMode.Font                = 'Arial,10'
#Checkbox to invlude Network Tracing
$NetTrace                        = New-Object system.Windows.Forms.CheckBox
$NetTrace.text                   = "include Network Traces"
$NetTrace.AutoSize               = $false
$NetTrace.Enabled                = $false
$NetTrace.width                  = 220
$NetTrace.height                 = 20
$NetTrace.location               = New-Object System.Drawing.Point(15,450)
$NetTrace.Font                   = 'Arial,10'

#include Performance Counters
$perfc                           = New-Object system.Windows.Forms.CheckBox
$perfc.text                      = "include Performance Counter"
$perfc.AutoSize                  = $false
$perfc.Enabled                   = $false
$perfc.width                     = 260
$perfc.height                    = 20
$perfc.location                  = New-Object System.Drawing.Point(340,450)
$perfc.Font                      = 'Arial,10'

#Text Field for the Export Path to store the results
$label                           = New-Object System.Windows.Forms.Label
$label.Location                  = New-Object System.Drawing.Point(15,480)
$label.Size                      = New-Object System.Drawing.Size(518,20)
$label.Text                      = 'Type a path to the Destination Folder or Click "Browse..." to select the Folder'
$label.Font                      = 'Arial,8'

$TargetFolder                    = New-Object system.Windows.Forms.TextBox
$TargetFolder.text               = ""
$TargetFolder.width              = 470
$TargetFolder.height             = 80
$TargetFolder.location           = New-Object System.Drawing.Point(15,501)
$TargetFolder.Font               = 'Arial,13'

#Browser Folder button
$SelFolder                       = New-Object system.Windows.Forms.Button
$SelFolder.text                  = "Browse..."
$SelFolder.width                 = 90
$SelFolder.height                = 29
$SelFolder.location              = New-Object System.Drawing.Point(490,500)
$SelFolder.Font                  = 'Arial,10'

$Okbtn                           = New-Object system.Windows.Forms.Button
$Okbtn.text                      = "OK"
$Okbtn.width                     = 70
$Okbtn.height                    = 30
$Okbtn.location                  = New-Object System.Drawing.Point(600,540)
$Okbtn.Font                      = 'Arial,10'
$Okbtn.DialogResult              = [System.Windows.Forms.DialogResult]::OK
$Okbtn.Enabled                   = $false

$cnlbtn                          = New-Object system.Windows.Forms.Button
$cnlbtn.text                     = "Cancel"
$cnlbtn.width                    = 70
$cnlbtn.height                   = 30
$cnlbtn.location                 = New-Object System.Drawing.Point(700,540)
$cnlbtn.Font                     = 'Arial,10'
$cnlbtn.DialogResult              = [System.Windows.Forms.DialogResult]::Cancel


$Form.controls.AddRange(@($Description,$TracingMode,$NetTrace,$TargetFolder,$SelFolder,$Okbtn,$cnlbtn,$cfgonly,$perfc,$label))

$cfgonly.Add_CheckStateChanged({ if ($cfgonly.checked)
                                {$TracingMode.Enabled = $false; $NetTrace.Enabled = $false; $perfc.Enabled = $false}
                                else
                                {$TracingMode.Enabled = $true; $NetTrace.Enabled = $false}
                              })

$TracingMode.Add_CheckStateChanged({ if ($TracingMode.checked)
                                {$cfgonly.Enabled = $false; $NetTrace.Enabled = $true;$NetTrace.Checked = $true; $perfc.Enabled = $true}
                                else
                                {$cfgonly.Enabled = $true; $NetTrace.Checked = $false; $NetTrace.Enabled = $false;$perfc.Checked = $false; $perfc.Enabled = $false }
                              })

#For future Versions we may add addional dependencies to the Network Trace.
#$NetTrace.Add_CheckedChanged({ })
$Description.add_LinkClicked({ Start-Process -FilePath $_.LinkText })

$SelFolder.Add_Click({
                                #Add-Type -AssemblyName System.Windows.Forms
                                $FolderDialog = New-Object windows.forms.FolderBrowserDialog
                                $FolderDialog.RootFolder = "Desktop"
                                $FolderDialog.ShowDialog()
                                $TargetFolder.text  = $FolderDialog.SelectedPath
 })


$TargetFolder.Add_TextChanged({ ($Okbtn.Enabled = $true) })

$FormsCOmpleted = $Form.ShowDialog()

if ($FormsCOmpleted -eq [System.Windows.Forms.DialogResult]::OK)
    {
        New-Object psobject -Property @{
            Path    = $TargetFolder.text
            TraceEnabled = $TracingMode.Checked
            NetTraceEnabled = $NetTrace.Checked
            ConfigOnly = $cfgonly.Checked
            PerfCounter =$perfc.Checked
        }
    }
elseif($FormsCOmpleted -eq [System.Windows.Forms.DialogResult]::Cancel)
    {
    Write-host "Script was canceled by User" -ForegroundColor Red
    exit
    }
}

Function Pause { param([String]$Message,[String]$MessageTitle,[String]$MessageC)

   # "ReadKey" not supported in PowerShell ISE.
   If ($psISE) {
      # Show MessageBox UI instead
      $Shell = New-Object -ComObject "WScript.Shell"
      $Button = $Shell.Popup($Message, 0, $MessageTitle, 0)
      Return
   }
   #If not ISE we prompt for key stroke
   Write-Host -NoNewline $MessageC -ForegroundColor Yellow
   While ($KeyInfo.VirtualKeyCode -Eq $Null -Or $Ignore -Contains $KeyInfo.VirtualKeyCode) {
      $KeyInfo = $Host.UI.RawUI.ReadKey("NoEcho, IncludeKeyDown")
   }
}

##########################################################################
#region Functions
Function IsAdminAccount
{
([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

function LDAPQuery
{
  param(
	[string]$filter,
	[string[]]$att,
    [string]$conn,
    [string]$basedn
  )
[System.Reflection.Assembly]::LoadWithPartialName("System.DirectoryServices.Protocols") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("System.Net")| Out-Null

$c = New-Object System.DirectoryServices.Protocols.LdapConnection ($conn)

$c.SessionOptions.SecureSocketLayer = $false;
$c.SessionOptions.Sealing = $true
$c.AuthType = [System.DirectoryServices.Protocols.AuthType]::Kerberos
$c.Bind();
$basedn = (New-Object System.DirectoryServices.DirectoryEntry("LDAP://$conn/RootDSE")).DefaultNamingContext
$scope = [System.DirectoryServices.Protocols.SearchScope]::Subtree
$r = New-Object System.DirectoryServices.Protocols.SearchRequest -ArgumentList $basedn,$filter,$scope,$att
$re = $c.SendRequest($r)
$c.Dispose()
return $re
}

Function EnableDebugEvents ($events)
{
    if($TraceEnabled)
    {
        	ForEach ($evt in $events)
        	{
	        	$TraceLog = New-Object System.Diagnostics.Eventing.Reader.EventlogConfiguration $evt
        		$TraceLog.IsEnabled = $false
        		$TraceLog.SaveChanges()

	        	if ($TraceLog.LogName -like "*Tracing/Debug*")
	        	{
	        		$TraceLog.ProviderLevel = 5
        			$TraceLog.IsEnabled = $true
	        		$TraceLog.SaveChanges()
        		}
        		elseif($TraceLog.IsEnabled -eq $false)
	        	{
        			$tracelog.MaximumSizeInBytes = '50000000'
	        		$TraceLog.IsEnabled = $true
	        		$TraceLog.SaveChanges()
	           	}
	        }
    }
    else
    { Write-Host "Debug Event Logging skipped due to selected scenario" -ForegroundColor DarkCyan }
}

Function LogManStart
{
    if($TraceEnabled)
    {
	        ForEach ($ets in $LogmanOn)
	        {
		    Push-Location $TraceDir
		    cmd /c $ets |Out-Null
		    Pop-Location
	        }
    }
    else
    { Write-Host "ETW Tracing skipped due to selected scenario" -ForegroundColor DarkCyan }
}

Function EnableNetlogonDebug
{
    if($TraceEnabled)
    {
        $key = (get-item -PATH "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon")
        $subkey = $key.OpenSubKey("Parameters",$true)
        Write-host "Enabling Netlogon Debug Logging" -ForegroundColor DarkCyan

        $subkey.SetValue($setDBFlag,$setvalue,$setvaltype)

        Write-host "Increasing Netlogon Debug Size to 100 MB" -ForegroundColor DarkCyan
        $subkey.SetValue($setNLMaxLogSize,$setvalue2,$setvaltype2)

        #cleanup and close the write  handle
        $key.Close()
    }
    else
    { Write-Host "Netlogon Logging skipped due to scenario" -ForegroundColor DarkCyan }
}


Function AllOtherLogs
{
	ForEach ($o in $others)
	{
		Push-Location $TraceDir
		cmd.exe /c $o |Out-Null
		Pop-Location
	}
}

Function LogManStop
{
    if($TraceEnabled)
    {
        ForEach ($log in $LogmanOff)
        {
	    	Push-Location $TraceDir
	    	cmd.exe /c $log |Out-Null
	    	Pop-Location
        }
    }
    else
    { Write-host "ETW Tracing was not enabled" -ForegroundColor DarkCyan }
}

Function DisableNetlogonDebug
{
    if($TraceEnabled)
    {
        $key = (get-item -PATH "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon")
        $subkey = $key.OpenSubKey("Parameters",$true)

        # Configure Keys based on initial configuration; if the keys did not exist we are also removing the keys again. else we set the old value
        if ([string]::IsNullOrEmpty($orgdbflag))
	    { $subkey.deleteValue($setDBFlag) }
        else
	    { $subkey.SetValue($setDBFlag,$orgdbflag,$setvaltype) }

        if ([string]::IsNullOrEmpty($orgNLMaxLogSize))
	    { $subkey.deleteValue($setNLMaxLogSize) }
        else
	    { $subkey.SetValue($setNLMaxLogSize,$orgNLMaxLogSize,$setvaltype2) }
        $key.Close()
    }
    else
    { Write-host "Net Logging logging was not enabled" -ForegroundColor DarkCyan }
}

Function DisableDebugEvents ($events)
{
    if($TraceEnabled)
    {
        ForEach ($evt in $events)
        {
		    $TraceLog = New-Object System.Diagnostics.Eventing.Reader.EventlogConfiguration $evt
		    if ($TraceLog.IsEnabled -eq $true)
            {
			    $TraceLog.IsEnabled = $false
			    $TraceLog.SaveChanges()
            }
        }

    }
    else
    { Write-host "Debug Tracing Eventlogs where not enabled" -ForegroundColor DarkCyan }
}

Function ExportEventLogs {
Param(
		[parameter(Position=0)]
		$events,
		[parameter(Position=1)]
		$RuntimeInMsec
		)
    ForEach ($evts in $events)
    {
        $expfilter= '*' #default filter
        #Sec events can be very large; in tracing mode we only  care about the events whilst the trace ran
        #query filter for export is  timebased and calculated on the time the trace collection started and ended + an offset of 5 minutes
        if ($evts -eq 'Security')
            {
            if($TraceEnabled)
                {
                #"create export filter with : "+$RuntimeInMsec
                $expfilter= '<QueryList>' + '<Query Id="'+0+'" Path="'+$evts+'"><Select Path="'+$evts+'">'+"*[System[TimeCreated[timediff(@SystemTime) &lt;= $RuntimeInMsec]]]"+'</Select></Query></QueryList>'
                }
            else #only export the last 60 minutes;
                {
                $expfilter= '<QueryList>' + '<Query Id="'+0+'" Path="'+$evts+'"><Select Path="'+$evts+'">'+"*[System[TimeCreated[timediff(@SystemTime) &lt;= 3600000]]]"+'</Select></Query></QueryList>'
                }
        }

		Push-Location $TraceDir
		# Replace slashes in the event filename before building the export paths
		$evtx = [regex]::Replace($evts,"/","-")
		$evttarget = $TraceDir +"\"+ $evtx+".evtx"
		$EventSession = New-Object System.Diagnostics.Eventing.Reader.EventLogSession
        #"Exporting Eventlog : "+ $evts + " using filter :" + $expfilter
		$EventSession.ExportLogAndMessages($evts,'Logname',$expfilter,$evttarget)
		Pop-Location
    }
}

Function GatherTheRest
{
    ForEach ($logfile in $Filescollector)
    {
		Push-Location $TraceDir
		cmd.exe /c $logfile | out-null
		Pop-Location
    }
}
Function GatherMsinfo32
{
	Push-Location $TraceDir
	cmd.exe /c'Msinfo32 /nfo %COMPUTERNAME%-msinfo32-AFTER.nfo' | out-null
	Pop-Location
}

Function EnablePerfCounter
{
    if ($TraceEnabled -and $PerfCounter)
        {
            if ($IsProxy)
            {
            Write-host "Enabling PerfCounter" -ForegroundColor DarkCyan
            Push-Location $TraceDir
            cmd /c $CreatePerfCountProxy |Out-Null
		    cmd /c $EnablePerfCountProxy |Out-Null
		    Pop-Location

            }
            else
            {
            Push-Location $TraceDir
            Write-host "Configuring PerfCounter" -ForegroundColor DarkCyan
            cmd /c $CreatePerfCountADFS |Out-Null
		    cmd /c $EnablePerfCountADFS |Out-Null
            Pop-Location
            }
    }
    else
    { Write-Host "Performance Monitoring will not be sampled due to selected scenario" -ForegroundColor DarkCyan }
}

Function DisablePerfCounter
{
    if ($TraceEnabled -and $PerfCounter)
        { Write-Host "Stopping Performance Monitoring" -ForegroundColor DarkCyan
            if ($IsProxy)
            {
		    cmd /c $DisablePerfCountProxy |Out-Null
            #we need to remove the counter created during enablement
            cmd /c $RemovePerfCountProxy |Out-Null
            }
            else
            {
		    cmd /c $DisablePerfCountADFS |Out-Null
            #we need to remove the counter created during enablement
            cmd /c $RemovePerfCountADFS |Out-Null
            }
    }
    else
    { Write-Host "Performance Monitoring was not sampled due to selected scenario" -ForegroundColor DarkCyan }
}

Function EnableNetworkTrace
{
    if ($TraceEnabled -and $NetTraceEnabled)
    {
            Write-host "Starting Network Trace" -ForegroundColor DarkCyan
            Push-Location $TraceDir
		    cmd /c $EnableNetworkTracer |Out-Null
		    Pop-Location
    }
}

Function DisableNetworkTrace
{
    if ($TraceEnabled -and $NetTraceEnabled)
    {
        Write-host "Stopping Network Trace. It may take some time for the data to be flushed to disk. Please be patient`n" -ForegroundColor Yellow
        cmd /c $DisableNetworkTracer |Out-Null
    }
}

function getServiceAccountDetails
{
if (!$IsProxy)
{
$SVCACC = ((get-wmiobject win32_service -Filter "Name='adfssrv'").startname) #currently fails if a upn is used//mostly if logonname of service got set manually
if ($SVCACC.contains('@'))
{
    $filter ="(userprincipalname="+$SVCACC.Split('@')[0]+")"
    $domain = $SVCACC.Split('@')[1]
}
if ($SVCACC.contains('\'))
{
    $filter ="(samaccountname="+$SVCACC.Split('\')[1]+")"
    $domain = $SVCACC.Split('\')[0]
}

$conn= (New-Object System.DirectoryServices.DirectoryEntry("LDAP://$domain/RootDSE")).dnshostname
[string]$att = "*"

"Performing LDAP Lookup of ADFS Service Account: " + $SVCACC | out-file Get-ServicePrincipalNames.txt -Append

$re= LDAPQuery -filter $filter -att $att -conn $conn
$gmsa =$false
$gmsa = [Bool]($re.Entries.Attributes.objectclass.GetValues('string') -eq 'msDS-GroupManagedServiceAccount')
"Service Account is GMSA: " + $gmsa | out-file Get-ServicePrincipalNames.txt -Append

    if($gmsa -eq $true)
    {
    $adl = new-object System.DirectoryServices.ActiveDirectorySecurity
    $adl.SetSecurityDescriptorBinaryForm($re.Entries[0].Attributes.'msds-groupmsamembership'[0])
    "`nGMSA allowed Hosts: `n" + $adl.AccessToString |ft |out-file Get-ServicePrincipalNames.txt -Append
    }
    else {"`nService Account used is a generic User"| out-file Get-ServicePrincipalNames.txt -Append}

    "`nServicePrincipalNames registered: " |out-file Get-ServicePrincipalNames.txt -Append
    $re.Entries.Attributes.serviceprincipalname.GetValues('string') |out-file Get-ServicePrincipalNames.txt -Append

    $EncType=$null
    Try { $EncType= [int]::Parse($re.Entries[0].Attributes.'msds-supportedencryptiontypes'.GetValues('string')) }
    Catch { "We handled an exception when reading msds-supportedencryptiontypes, which implies the attribute is not configured. This is not a critical error"; }

    $KRBflags = [System.Collections.ArrayList]::new()
    if(![string]::IsNullOrEmpty($EncType))
    {
    foreach ($etype in ($EncTypes.GetEnumerator() | Sort-Object -Property Value ))
        { if (($EncType -band $etype.Value) -ne 0) { $KRBflags.Add($etype.Key.ToString()) |out-null } }
    }
    else
        { $KRBflags.Add("`n`tmsds-supportedencryptiontypes is not configured on the service account, Service tickets would be RC4 only!`n`tFor AES Support configure the msds-supportedencryptiontypes on the ADFS Service Account with a value of either:`n`t24(decimal) == AES only `n`t or `n`t28(decimal) == AES & RC4") }

    "`nKerberos Encryption Types supported by Service Account: " + ($KRBflags -join ' | ') |Out-File Get-ServicePrincipalNames.txt -Append
    "`nChecking for Duplicate SPNs( current ServiceAccount will be included in this check):`n" |out-file Get-ServicePrincipalNames.txt -Append

    $conn= (New-Object System.DirectoryServices.DirectoryEntry("GC://$domain/RootDSE")).dnshostname
    $filter= "(serviceprincipalname="+('*/'+(get-adfsproperties).hostname)+")"
    [string]$att = "*"
    $re= LDAPQuery -filter $filter -att $att -conn $conn
    $re.Entries |foreach {$_.distinguishedName |out-file Get-ServicePrincipalNames.txt -Append ;$_.Attributes.'serviceprincipalname'.GetValues('string')|out-file Get-ServicePrincipalNames.txt -Append}
}
}

Function GetADFSConfig
{
    Push-Location $TraceDir
    if ($IsProxy)
    {
	    if ($WinVer -eq [Version]"6.2.9200") # ADFS proxy 2012
	    {
		    Get-AdfsProxyProperties | format-list * | Out-file "Get-AdfsProxyProperties.txt"
	    }
	    else # ADFS 2012 R2 or ADFS 2016 or 2019
	    {
		    Get-WebApplicationProxyApplication | format-list * | Out-file "Get-WebApplicationProxyApplication.txt"
		    Get-WebApplicationProxyAvailableADFSRelyingParty | format-list * | Out-file "Get-WebApplicationProxyAvailableADFSRelyingParty.txt"
		    Get-WebApplicationProxyConfiguration | format-list * | Out-file "Get-WebApplicationProxyConfiguration.txt"
		    Get-WebApplicationProxyHealth | format-list * | Out-file "Get-WebApplicationProxyHealth.txt"
		    Get-WebApplicationProxySslCertificate | format-list * | Out-file "Get-WebApplicationProxySslCertificate.txt"
		    $proxcfg = 'copy %WINDIR%\ADFS\Config\Microsoft.IdentityServer.ProxyService.exe.config %COMPUTERNAME%-Microsoft.IdentityServer.ProxyService.exe.config'
            cmd.exe /c $proxcfg |Out-Null
	    }
    }
    else # Is ADFS server
 {
	    # Common ADFS commands to all versions
	    Get-AdfsAttributeStore | format-list * | Out-file "Get-AdfsAttributeStore.txt"
	    Get-AdfsCertificate | format-list * | Out-file "Get-AdfsCertificate.txt"
	    Get-AdfsClaimDescription | format-list * | Out-file "Get-AdfsClaimDescription.txt"
	    Get-AdfsClaimsProviderTrust | format-list * | Out-file "Get-AdfsClaimsProviderTrust.txt"
	    Get-AdfsEndpoint | format-list * | Out-file "Get-AdfsEndpoint.txt"
	    Get-AdfsProperties | format-list * | Out-file "Get-AdfsProperties.txt"
	    Get-AdfsRelyingPartyTrust | format-list * | Out-file "Get-AdfsRelyingPartyTrust.txt"
	    Get-AdfsSyncProperties | format-list * | Out-file "Get-AdfsSyncProperties.txt"
	    Get-AdfsSslCertificate | format-list * | Out-file "Get-AdfsSslCertificate.txt"
        getServiceAccountDetails


	if ($WinVer -ge [Version]"10.0.14393") # ADFS commands specific to ADFS 2016 and common in 2019
	    {
        (Get-AdfsProperties).WiasupportedUseragents | Out-file -Append "Get-AdfsProperties.txt"
		Get-AdfsAccessControlPolicy | format-list * | Out-file "Get-AdfsAccessControlPolicy.txt"
		Get-AdfsApplicationGroup | format-list * | Out-file "Get-AdfsApplicationGroup.txt"
		Get-AdfsApplicationPermission | format-list * | Out-file "Get-AdfsApplicationPermission.txt"
		Get-AdfsCertificateAuthority | format-list * | Out-file "Get-AdfsCertificateAuthority.txt"
		Get-AdfsClaimsProviderTrustsGroup | format-list * | Out-file "Get-AdfsClaimsProviderTrustsGroup.txt"
		Get-AdfsFarmInformation | format-list * | Out-file "Get-AdfsFarmInformation.txt"
		Get-AdfsLocalClaimsProviderTrust | format-list * | Out-file "Get-AdfsLocalClaimsProviderTrust.txt"
		Get-AdfsNativeClientApplication | format-list * | Out-file "Get-AdfsNativeClientApplication.txt"
		Get-AdfsRegistrationHosts | format-list * | Out-file "Get-AdfsRegistrationHosts.txt"
		Get-AdfsRelyingPartyTrustsGroup | format-list * | Out-file "Get-AdfsRelyingPartyTrustsGroup.txt"
		Get-AdfsRelyingPartyWebTheme | format-list * | Out-file "Get-AdfsRelyingPartyWebTheme.txt"
		Get-AdfsScopeDescription | format-list * | Out-file "Get-AdfsScopeDescription.txt"
		Get-AdfsServerApplication | format-list * | Out-file "Get-AdfsServerApplication.txt"
		Get-AdfsTrustedFederationPartner | format-list * | Out-file "Get-AdfsTrustedFederationPartner.txt"
		Get-AdfsWebApiApplication | format-list * | Out-file "Get-AdfsWebApiApplication.txt"
		Get-AdfsAdditionalAuthenticationRule | format-list * | Out-file "Get-AdfsAdditionalAuthenticationRule.txt"
		Get-AdfsAuthenticationProvider | format-list * | Out-file "Get-AdfsAuthenticationProvider.txt"
		Get-AdfsAuthenticationProviderWebContent | format-list * | Out-file "Get-AdfsAuthenticationProviderWebContent.txt"
		Get-AdfsClient | format-list * | Out-file "Get-AdfsClient.txt"
		Get-AdfsGlobalAuthenticationPolicy | format-list * | Out-file "Get-AdfsGlobalAuthenticationPolicy.txt"
		Get-AdfsGlobalWebContent | format-list * | Out-file "Get-AdfsGlobalWebContent.txt"
		Get-AdfsNonClaimsAwareRelyingPartyTrust | format-list * | Out-file "Get-AdfsNonClaimsAwareRelyingPartyTrust.txt"
		Get-AdfsRelyingPartyWebContent | format-list * | Out-file "Get-AdfsRelyingPartyWebContent.txt"
		Get-AdfsSslCertificate | format-list * | Out-file "Get-AdfsSslCertificate.txt"
		Get-AdfsWebApplicationProxyRelyingPartyTrust | format-list * | Out-file "Get-AdfsWebApplicationProxyRelyingPartyTrust.txt"
		Get-AdfsWebConfig | format-list * | Out-file "Get-AdfsWebConfig.txt"
		Get-AdfsWebTheme | format-list * | Out-file "Get-AdfsWebTheme.txt"

		$svccfg = 'copy %WINDIR%\ADFS\Microsoft.IdentityServer.ServiceHost.Exe.Config %COMPUTERNAME%-Microsoft.IdentityServer.ServiceHost.Exe.Config'
        cmd.exe /c $svccfg |Out-Null

        if (Get-AdfsAzureMfaConfigured)
        { Export-AdfsAuthenticationProviderConfigurationData -name AzureMfaAuthentication -FilePath Get-ADFSAzureMfaAdapterconfig.txt }
        ##comming soon: WHFB Cert Trust Informations
        if ($WinVer -ge [Version]"10.0.17763") #ADFS command specific to ADFS 2019+
        {
        Get-AdfsDirectoryProperties | format-list * | Out-file "Get-AdfsDirectoryProperties.txt"
        }

		}
	    if ($WinVer -eq [Version]"6.3.9600") # ADFS commands specific to ADFS 2012 R2/consolidate this in next release
	    {
         (Get-AdfsProperties).WiasupportedUseragents | Out-file -Append "Get-AdfsProperties.txt"
         Get-AdfsAdditionalAuthenticationRule | format-list * | Out-file "Get-AdfsAdditionalAuthenticationRule.txt"
		 Get-AdfsAuthenticationProvider | format-list * | Out-file "Get-AdfsAuthenticationProvider.txt"
		 Get-AdfsAuthenticationProviderWebContent | format-list * | Out-file "Get-AdfsAuthenticationProviderWebContent.txt"
		 Get-AdfsClient | format-list * | Out-file "Get-AdfsClient.txt"
		 Get-AdfsGlobalAuthenticationPolicy | format-list * | Out-file "Get-AdfsGlobalAuthenticationPolicy.txt"
		 Get-AdfsGlobalWebContent | format-list * | Out-file "Get-AdfsGlobalWebContent.txt"
		 Get-AdfsNonClaimsAwareRelyingPartyTrust | format-list * | Out-file "Get-AdfsNonClaimsAwareRelyingPartyTrust.txt"
		 Get-AdfsRelyingPartyWebContent | format-list * | Out-file "Get-AdfsRelyingPartyWebContent.txt"
		 Get-AdfsWebApplicationProxyRelyingPartyTrust | format-list * | Out-file "Get-AdfsWebApplicationProxyRelyingPartyTrust.txt"
		 Get-AdfsWebConfig | format-list * | Out-file "Get-AdfsWebConfig.txt"
		 Get-AdfsWebTheme | format-list * | Out-file "Get-AdfsWebTheme.txt"
		 $svccfg = 'copy %WINDIR%\ADFS\Microsoft.IdentityServer.ServiceHost.Exe.Config %COMPUTERNAME%-Microsoft.IdentityServer.ServiceHost.Exe.Config'
         cmd.exe /c $svccfg |Out-Null
	    }
	    elseif ($WinVer -eq [Version]"6.2.9200")
	    {
		    # No specific cmdlets for this version
	    }
    }
    Pop-Location
}

Function EndOfCollection
{
    $date = get-date -Format yyyy-dd-MM_hh-mm
    $computername = (Get-Childitem env:computername).value
    $zip = $computername + "_ADFS_traces_"+$date
    $datafile = "$(Join-Path -Path $path -ChildPath $zip).zip"
    Stop-Transcript |Out-Null
		Write-host "Creating Archive File" -ForegroundColor Gray
		Add-Type -Assembly "System.IO.Compression.FileSystem" ;
		[System.IO.Compression.ZipFile]::CreateFromDirectory($TraceDir, $datafile)

		Write-host "Archive File created in $datafile" -ForegroundColor Green

		# Cleanup the Temporary Folder (if error retain the temp files)
		if(Test-Path -Path $Path)
		{
			Write-host "Removing Temporary Files" -ForegroundColor Gray
			Remove-Item -Path $TraceDir -Force -Recurse | Out-Null
		}
		else
		{
			Write-host "The Archive could not be created. Keeping Temporary Folder $TraceDir" -ForegroundColor Yellow
			New-Item -ItemType directory -Path $Path -Force | Out-Null
		}
}

Function GetDRSConfig
{

    if ((-Not $IsProxy) -And ($WinVer -gt [Version]"6.2.9200"))
	{
		Push-Location $TraceDir
		Get-AdfsDeviceRegistrationUpnSuffix | format-list * | Out-file "Get-AdfsDeviceRegistrationUpnSuffix.txt"
		Try { Get-AdfsDeviceRegistration | format-list * | Out-file "Get-AdfsDeviceRegistration.txt" }  Catch { $_.Exception.Message | Out-file "Get-AdfsDeviceRegistration.txt" }
		Try
		{
			$rootdse = New-Object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE")
			$dirEntry = "LDAP://" +$rootdse.dnshostname+"/CN=DeviceRegistrationService,CN=Device Registration Services,CN=Device Registration Configuration,CN=Services," +$rootdse.configurationNamingContext
			$searcher = new-object System.DirectoryServices.DirectorySearcher
			$searcher.SearchRoot = $dirEntry
			$searcher.SearchScope = "Subtree"
			$DScloudissuerpubliccert = new-object System.Security.Cryptography.X509Certificates.X509Certificate2
			$DScloudissuerpubliccert.Import(($searcher.FindAll()).GetDirectoryEntry().Properties.'msds-cloudissuerpubliccertificates'.Value)
			$DSissuerpubliccert = new-object System.Security.Cryptography.X509Certificates.X509Certificate2
			$DSissuerpubliccert.Import(($searcher.FindAll()).GetDirectoryEntry().Properties.'msDS-IssuerPublicCertificates'.Value)
			"==========================CloudDRSIssuerCertificatePublicKey======================================" | Out-File Get-AdfsDeviceRegistration.txt -Append
			$DScloudissuerpubliccert |fl * | Out-File Get-AdfsDeviceRegistration.txt -Append
			"=============================DRSIssuerCertificatePublicKey========================================" | Out-File Get-AdfsDeviceRegistration.txt -Append
			$DSissuerpubliccert |fl * | Out-File Get-AdfsDeviceRegistration.txt -Append
		}
		catch
		{
			"The function DRSConfig ran into the following Error when querying the AD DRS Object: " + ($_) | Out-File DiagnosticsDebug.txt -Append
		}
		pop-location
	}
}
#endregion Functions
##########################################################################
#region Execution

if (IsAdminAccount){
Write-host "Script is executed as Administrator. Resuming execution" -ForegroundColor Green

if ([string]::IsNullOrEmpty($Path))
{
$RunProp = RunDialog
$Path = $RunProp.Path.ToString()
$TraceEnabled = $RunProp.TraceEnabled
$NetTraceEnabled = $RunProp.NetTraceEnabled
$ConfigOnly = $RunProp.ConfigOnly
$PerfCounter = $RunProp.PerfCounter
}
elseif (![string]::IsNullOrEmpty($Path))
{
    if ($TraceEnabled -eq $false)
    {
        Write-host "Please Specify what data to capture"
        $Mode = Read-Host 'For "Configuration Only" press "C" . For a "Debug Tracing" press "T"'
        Switch ($Mode)
                 {
                    C {Write-host "You selected Configuration Only, skipping Debug logging"; $TraceEnabled=$false; $ConfigOnly=$true}
                    T {Write-Host "You selected Tracing Mode, enabling additional logging"; $TraceEnabled=$true; ; $ConfigOnly=$false}
                    Default {Write-Host "You did not selected an operationsmode. We will only collect the Configuration"; $TraceEnabled=$false; $ConfigOnly=$true}
                 }
    }
    else
    {
        $ConfigOnly=$false
    }
	
	if (-not $TSSrun) {
		If (($TraceEnabled -and ($NetTraceEnabled -eq $false))  )
		{
				$NMode = Read-Host 'Collect a Network Trace (Y/N). If you do not provide a value network tracing is enabled by default'
				Switch ($NMode)
				   {
					 Y {Write-host "Enabling Network Tracing"; $NetTraceEnabled=$true; $ConfigOnly=$false}
					 N {Write-Host "Skipping Network Tracing"; $NetTraceEnabled=$false; $ConfigOnly=$false}
					 Default {Write-Host "You provided an incorrect or no value. Enabling Network Tracing"; $NetTraceEnabled=$true; $ConfigOnly=$false}
				   }
		}
	}

    if (($TraceEnabled -and ($PerfCounter -eq $false)))

    {
            $PMode = Read-Host 'Collect Performance Counters (Y/N). You you do not provide a value network tracing is enabled by default'
            Switch ($PMode)
              {
                   Y {Write-host "Collecting Performance Counter"; $PerfCounter=$true; $ConfigOnly=$false}
                   N {Write-Host "Skipping Performance Counters"; $PerfCounter=$false; $ConfigOnly=$false}
                   Default {Write-Host "You provided an incorrect or no value. Skipping Performance Counters"; $PerfCounter=$false; $ConfigOnly=$false}
              }
    }

}

if(Test-Path -Path $Path)
{
   Write-host "Your folder: $Path already exists. Starting Data Collection..." -ForegroundColor DarkCyan
}
else
{
Write-host "Your Logfolder: $Path does not exist. Creating Folder" -ForegroundColor DarkCyan
New-Item -ItemType directory -Path $Path -Force | Out-Null
}

$TraceDir = $Path +"\temporary"
# Save execution output to file
Write-host "Creating Temporary Folder in $path" -ForegroundColor DarkCyan
New-Item -ItemType directory -Path $TraceDir -Force | Out-Null

Start-Transcript -Path "$TraceDir\transscript_output.txt" -Append -IncludeInvocationHeader |out-null
Write-Host "Debug logs will be saved in: " $Path -ForegroundColor DarkCyan
Write-Host "Options selected:  TracingEnabled:"$TraceEnabled "NetworkTrace:" $NetTraceEnabled " ConfigOnly:" $ConfigOnly " PerfCounter:" $PerfCounter -ForegroundColor DarkCyan
Write-Progress -Activity "Preparation" -Status 'Setup Data Directory' -percentcomplete 5

if ($TraceEnabled)
	{
	$MessageTitle = "Initialization completed`n"
	$MessageIse = "Data Collection is ready to start.`nPrepare other computers to start collecting data.`n`nWhen ready, Click OK to start the collection...`n"
	$MessageC = "`nData Collection is ready to start.`nPrepare other computers to start collecting data.`n`nWhen ready, press any key to start the collection...`n"
	Pause $MessageIse $MessageTitle $MessageC
	}

Write-Progress -Activity "Gathering Configuration Data" -Status 'Getting ADFS Configuration' -percentcomplete 7
if ($ProductType -gt 1) { 
	GetADFSConfig
	GetDRSConfig
 }
Write-Progress -Activity "Gathering Configuration Data" -Status 'Gathering Logfiles' -percentcomplete 10
AllOtherLogs

Write-Progress -Activity "Enable Logging" -Status 'Eventlogs' -percentcomplete 15
$starttime = (get-date)
Write-host "Configuring Event Logging" -ForegroundColor DarkCyan
if ($IsProxy) 	{ EnableDebugEvents $WAPDebugEvents  }
else 			{ EnableDebugEvents $ADFSDebugEvents }

Write-Progress -Activity "Enable Logging" -Status 'Netlogon Debug Logging' -percentcomplete 30
EnableNetlogonDebug

Write-Progress -Activity "Enable Logging" -Status 'Additional ETL Logging' -percentcomplete 40
LogManStart
if (-not $TSSrun) { EnableNetworkTrace }
EnableNetworkTrace
EnablePerfCounter

if($TraceEnabled)
	{
	Write-Progress -Activity "Ready for Repro" -Status 'Waiting for Repro' -percentcomplete 50
	$MessageTitle = "Data Collection Running"
	$MessageIse = "Data Collection is currently running`nProceed  reproducing the problem now or`n`nPress OK to stop the collection...`n"
	$MessageC = "Data Collection is currently running`nProceed  reproducing the problem now or `n`nPress any key to stop the collection...`n"
	Pause $MessageIse $MessageTitle $MessageC
	}

Write-Progress -Activity "Collecting" -Status 'Stop Event logging' -percentcomplete 55
if ($IsProxy) 	{ DisableDebugEvents $WAPDebugEvents }
else 			{ DisableDebugEvents $ADFSDebugEvents }

Write-Progress -Activity "Collecting" -Status 'Stop additional logs' -percentcomplete 65
    LogManStop
    if (-not $TSSrun) { DisableNetworkTrace }
	DisableNetworkTrace
    DisablePerfCounter
    DisableNetlogonDebug

Write-Progress -Activity "Collecting" -Status 'Getting ' -percentcomplete 70
GatherTheRest
if (-not $TSSrun) { GatherMsinfo32 }

Write-Progress -Activity "Collecting" -Status 'Exporting Eventlogs' -percentcomplete 85
[int]$endtimeinmsec= (New-TimeSpan -start $starttime -end (get-date).AddMinutes(5)).TotalMilliseconds

if ($IsProxy) 	{ ExportEventLogs $WAPExportEvents $endtimeinmsec }
else 			{ ExportEventLogs $ADFSExportEvents $endtimeinmsec }

Write-Progress -Activity "Saving" -Status 'Compressing Files - This may take some moments to complete' -percentcomplete 95
Write-host "Almost done. We are compressing all Files. Please wait" -ForegroundColor Green
EndOfCollection
Write-host "tss_ADFS-tracing completed" -ForegroundColor DarkCyan
}
else
	{
	Write-Host "You do not have Administrator rights!`nPlease re-run this script as an Administrator!" -ForegroundColor Red
	Break
	}
#endregion Execution
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBqRsBM31ViRUv/
# IRKhSeM3pwvjl7EUyTjKkApODpOxiKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgHTjv+sX7
# tY8D65JeJ7JbVVXuM2eA/YFBqIQI7zJrnDUwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAJY1YXdAoqL63z2LkByHQLdkpHXkj5w1uLKKQxmFYLSXVvc0bceXkMd0
# q6mNETOpU5CyYA8XDJOJ75bNxOExvcJASg90yknghsm5ciIGV2AUW0SB36NNEC7h
# Kgl8/3Bc9223Vd0N6BbyLzcWXDw9onL8CbdGgBtEoGihArTTzgepIeBo4LBCZ+/P
# xbrYatrlgn9YYU63a4ODtOWQyWi4YooswUwL4x7USXZc+Bcayh/r9qfv/95odABU
# lfbnkOsLbiW21ya1hjHj/fmm4I7GaICZlXLsSyi5y8S+Qw6H0fLVjnMV+tToWR9E
# JMkdmc9MlUmEksDd/sHZ+comnBpyIGmhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQg2hofPFbxfVsjXKdNfZS3J40a8Zxl+dc+K4qK5jYyVvsCBmCJ+m/A
# 7hgTMjAyMTA1MTkyMjIxNTUuODI3WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkM0
# QkQtRTM3Ri01RkZDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFXRAdi3G/ovioAAAAAAVcwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjEzWhcNMjIwNDExMTkwMjEzWjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkM0QkQtRTM3Ri01RkZD
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3m0Dp1Rm+efAv2pC1dzA8A2EHh7P7kJC
# t4+n9nxMfg0Gvm8B8YyjSVX+WJ0Fq0pOAcSs64ofXXFUB8F6Ecm8f1P86E5zzcIm
# z1vMOGuV3Ql3Ld4nILTIF3FV65xL7ZrZkF3nTAGD/n/ZiNDbKV8PR3Eorq1AvF04
# NO5p1Axt1rTmU8adYbBneeJKAgpVGCqoJWWEfPA21GHUAf5nFt9J7u3zPegQoB1M
# DLtKw/zKSG3eyuN2HQHKQ8V2loCCrBYIkkmYaTSACtK8cLz69e0ajcwmFZBF7km3
# N0PmR1oof25z2CdKGxfIMSEZmPHf5vxy6oQ7xse/RY9f0xER+t/G+QIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFF0xe7voOCGdT+Q9Mwp0WRH2gKnZMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBACV3eQCAbpdaJnK92JstGZavvJvpFLJyNUODy1wKK1LT
# WxNWnhPwB3ZB5h8lZ8roMwSTtBEF8qB03ugTx1e2ZBUv4lzEuPSlS7Lg0HlFyFy1
# 4Pl1GdN8qVGLy+ApRrENygUjM0RTPUQemil5qANvj+4j1SPm0i7CWKT+qu/+wcDD
# uQziAQss06B16/1n/vGjUkjB97R6hAzfDFwIUu5/xL06dy21oUBYe0QRHwi+BECA
# sn9aeW4XPrz6GsN9HJf+qpZI8gTS+gTqoXHXPxS8vAqmbrlA3I0NEyn9WYKmpFmv
# EHWjRFjs/6fiNI0a9uTZtHvSQq392iAUVEEdVW5TF/4wggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkM0QkQtRTM3Ri01
# RkZDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQARLfhJYnsN9tIb+BshDBOvOBnw8qCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9/EjAiGA8y
# MDIxMDUxOTE2MTIwMloYDzIwMjEwNTIwMTYxMjAyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT38SAgEAMAoCAQACAiZrAgH/MAcCAQACAiEYMAoCBQDkUNCSAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAhUwRQnTqtSzfIK9iRM8Pw+wqQsqu
# +h9Z3X4xCWvLbObgYtTch1bKP+WwqganmCmW8VxdEclnQeLVZULbJJpfsa7jsMWT
# 6QYsiLxGqxU3ugEH4Z/St5Dr2+VRsxn3DdsUOd1MTs5jCALYHEAZ7h8AJXWpY3AO
# VoHzDO9KqON/1y0xggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVdEB2Lcb+i+KgAAAAABVzANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCnyF1X
# R3pHIhKl433gU67cyth8bIfRpdf0n9dJ2A2aHzCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EICxajQ1Dq/O666lSxkQxInhSxGO1DDZ0XFlaQe2pHKATMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFXRAdi3G/ovioA
# AAAAAVcwIgQgRMfqcstpA7Rx4wCfj4wNxSOqsRWlfsYIrzsVEf09p2UwDQYJKoZI
# hvcNAQELBQAEggEAs8Ksqg0+MirrVIPt6LjaEiuY5A74B5PFcuxxH36IwAK2iYZy
# 4UqnlmRPc25QlprSu9HzmUuhEt/8nrfZ3cFwgJ8X93EY9/tDr0SyjchKEWHKRfg1
# htmnHPi4OFPEX7JGKxEhvC/3if8Ys8C+MKuI5RjisLrYhZyuMvyGauWoLG2HApO1
# okwt8nSaPm63MRWMuNU7RLd6OxzZwXZEMtcSv1qZpF6yIi1KOVRm9Vq0f7Szko3H
# h6qYJMtTCmaEKTybTjK5XchNsY73roc5jIxFbqM1ILlAqbYekcvn8kAXT3ZyqrQe
# 6L6s3fi/BLx7SU3o5SsuIhfcnp14c5ct6GB7kw==
# SIG # End signature block
