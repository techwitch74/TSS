﻿<#
.SYNOPSIS
    The Script used to collect SDN Envrionment Logs for Windows Server SDN Deployment
.DESCRIPTION
    Script to be executed from a Jumpbox that have access to NC Rest URI and the PowerShell Remoting needed to collect logs on NC, MUX, Gateway and SDN Host
.EXAMPLE
    Scenario 1: Collect Infra Logs not include Hosts
    PS C:\> SDNLogCollect.ps1 -NCVM <NCVMName>
    The most common usage. Specify one of the NC VM and collect Logs from NC, MUX and Gateway VMs. 

    Scenario 2: Include SDN Hosts Logs
    Step 1: Define the SDN Hosts array that include all Hosts need data collection
    PS C:\> $SDNHosts = $("host1","host2")
    Step 2: Start the Hosts trace, 
    PS C:\> SDNLogCollect.ps1 -StartSDNHostTrace -SDNHosts $SDNHosts
    If you want to include VFP Logs and Network Traces on Hosts, use -InccludeVfp switch
    PS C:\> SDNLogCollect.ps1 -StartSDNHostTrace -SDNHosts $SDNHosts -IncludeVfp
    Step 3: Stop the Hosts trace after issue reproduced, specificy one of the NC VM Name also to collect infra logs together.
    PS C:\> SDNLogCollect.ps1 -StopSDNHostTrace -SDNHosts $SDNHosts -NCVMName <One of the NC VM Name>
.PARAMETER NCVMName 
    [REQUIRED]
    Specify one of the NC VM name in NC Cluster

.PARAMETER OutputPath
    [REQUIRED]
    Specify the path you want to save the logs to. Defaults to current folder

.PARAMETER StartSDNHostTrace
    [OPTIONAL]
    Used to start the SDN Host trace. $SDNHosts is required.

.PARAMETER StopSDNHostTrace
    [OPTIONAL]
    Used to stop the SDN Host trace. $SDNHosts is required.
       
    
.PARAMETER IncludeVfp
    [OPTIONAL]
    Used together with StartSDNHostTrace. No need to specify when StopSDNHostTrace. 
    When specified, this script will collect Network Traces include VFP ETL on Hosts. The log collection time will take longer.
       
.PARAMETER SDNHosts
    [OPTIONAL]
    Used to specificy the SDN Hosts Array that you want Start/Stop logs. Required when StartSDNHostTrace/StopSDNHostTrace specified.
    
.NOTES
    Author: Luyao Feng (luyaof@microsoft.com)
#>

Param(
    [int]$LastInNum,
    [int]$LastInMin,
    [switch]$All,
    [String]$NCVMName,
    [String]$OutputPath,
    [switch]$StartSDNHostTrace,
    [switch]$StopSDNHostTrace,
    [switch]$IncludeVfp,
    [String[]]$SDNHosts

)

function Write-Log(
    [String]$Message,
    [ValidateSet("Info","Warning","Error")]
    [String]$Type = "Info")
{
    $FormattedDate = date -Format "yyyyMMdd-HH:mm:ss"
    $FormattedMessage = "[$FormattedDate] [$Type] $Message"
    $messageColor = "Green"
    Switch($Type)
    {
        "Info"{ $messageColor = "Green"}
        "Warning"{$messageColor = "Yellow"}
        "Error"{$messageColor = "Red"}
    }
    Write-Host -ForegroundColor $messageColor $FormattedMessage

    $formattedMessage | out-file "$OutputPath\SDNLogCollectLog.txt" -Append
}

function Get-SdnResources([String]$NcUri, [String]$OutputFolder, [pscredential]$Cred) 
{
    $OutputFolder = "$OutputFolder\SDNResources"
    # Gather Network Controller resources
    Write-Log -Message "Gathering SDN configuration details. Results saved to $OutputFolder" 
    New-Item -Path "$OutputFolder" -ItemType Directory -Force | Out-Null
    [array]$SDNResources="AccessControlLists","Credentials","GatewayPools","Gateways","LoadBalancerMuxes","LoadBalancers","LogicalNetworks","MacPools","NetworkInterfaces","PublicIPAddresses","Servers","RouteTables","VirtualGateways","VirtualNetworks","VirtualServers","iDNSServer/configuration","LoadBalancerManager/config","virtualNetworkManager/configuration","serviceInsertions"
    foreach ($resource in $SDNResources){
        Try {
            Invoke-RestMethod -Uri "$NcUri/networking/v1/$resource" -Method Get -UseDefaultCredentials | ConvertTo-Json -Depth 100 | Out-File "$OutputFolder\$resource.json".Replace("/","_")
        }
        Catch {
            if($_.Exception.Response.StatusCode.Value__ -ne 404)
            {
                Write-Log -Message "$($_.Exception) 
                at $($_.Exception.Response.ResponseUri.AbsoluteUri)" -Type "Error"
            }else
            {
                Write-Log "$resource not found" -Type "Warning"
            }
        }
    }
}

Function Start-NCImosDump([String]$NCUri)
{
	Import-Module NetworkController
	
	Write-Log "Triggering IMOS Dump"
	$state=New-Object Microsoft.Windows.NetworkController.NetworkControllerStateProperties
	$ncStateResult = Invoke-NetworkControllerState -ConnectionUri $NCUri -Properties $state -Force
	
    $ncState = Invoke-RestMethod -Uri "$($NCUri)/networking/v1/diagnostics/networkcontrollerstate" -UseDefaultCredentials
    $timeout = 300
    Write-Log "Waiting for IMOS Dump finish"
	while($timeout -gt 0)
	{
		$ncState = Invoke-RestMethod -Uri "$($NCUri)/networking/v1/diagnostics/networkcontrollerstate" -UseDefaultCredentials
		if($ncState.properties.provisioningState -ne "Updating")
		{
			break
		}
		Start-Sleep -s 10
		$timeout = $timeout - 10
	}
	Write-Log "IMOS Dump finished status: $($ncState.properties.provisioningState)"
}

Function Get-NCImosDump([String]$NCVMName, [String]$OutputPath)
{
    Write-Log "Getting IMOS Dump via NCURI: $($NcUri)"
    $NCVMs = Get-NetworkControllerNode -ComputerName $NCVMName
    # Cleanup the existing IMOS Dump folder to generate a new one

    Invoke-Command -ComputerName $NCVMs.Server -ScriptBlock{
        Write-Host "[$(HostName)]Cleaning IMOS DB folder"
        Get-ChildItem -Path "C:\Windows\tracing\SDNDiagnostics\NetworkControllerState" | Remove-Item -Force
    }

    Start-NCImosDump -NCUri $NcUri
    
    foreach($NCVM in $NCVMs)
    {
        Write-Log "Getting IMOS dump from $($NCVM.Server)"
        $RemotePathToCopy = "\\$($NCVM.Server)\c$\Windows\Tracing\SDNDiagnostics\NetworkControllerState\*"
        New-Item "$OutputPath\NetworkControllerState" -ItemType Directory -Force | Out-Null
       	Copy-Item -Path $RemotePathToCopy -Destination "$OutputPath\NetworkControllerState" -Recurse
    }
}

Function Get-NCLogInMin([int]$LastInMin, [String]$NCVMName, [String]$OutputPath)
{
    $LatestTime = (Get-Date).AddMinutes(-$latestTimeInMins)
    $LatestTime = $LatestTime.ToUniversalTime()

    $NCVMs = Get-NetworkControllerNode -ComputerName $NCVMName
    foreach($NCVM in $NCVMs)
    {
        Write-Log "Getting NC ETL logs from $($NCVM.Server)"

        $ToCopy = Invoke-Command -ComputerName $($NCVM.Server) -ArgumentList $LatestTime -ScriptBlock{
        Param(
            [DateTime]$LatestTime
        )
            $logs = Get-ChildItem -Path "C:\Windows\Tracing\*.log"
            $etls = Get-ChildItem -Path "C:\Windows\Tracing\SDNDiagnostics\Logs" | sort LastWriteTime -Descending
            $EtlToCopy = @()
            foreach($etl in $etls)
            {
                $EtlToCopy += $etl.Name
                if($etl.LastWriteTimeUtc -le $LatestTime)
                {
                    return $EtlToCopy
                }
           
            }
        }

        Write-Log "Invoke-Command done for $($NCVM.Server)"
        $RemotePathToCopy = "\\$($NCVM.Server)\c$\Windows\Tracing\SDNDiagnostics\Logs\"


        $NCVMFolder = New-Item -ItemType Directory  -Path "$OutputPath\$($NCVM.Server)\ETL"
        foreach($Etl in $ToCopy)
        {
            Copy-Item -Path $RemotePathToCopy\$Etl -Destination "$($NCVMFolder.FullName)\$Etl"
        }
    }
}


Function Get-NCLogInNumber([int]$LastInNum, [String]$NCVMName, [String]$OutputPath)
{
   
    $NCVMs = Get-NetworkControllerNode -ComputerName $NCVMName
    foreach($NCVM in $NCVMs)
    {
        Write-Log "Getting logs from $($NCVM.Server)"

        $ToCopy = Invoke-Command -ComputerName $($NCVM.Server) -ArgumentList $LastInNum -ScriptBlock{
        Param(
            [int]$LastInNum
        )
            $logs = Get-ChildItem -Path "C:\Windows\Tracing\*.log"
            $etls = Get-ChildItem -Path "C:\Windows\Tracing\SDNDiagnostics\Logs" -Filter "*ETL*" | sort LastWriteTime -Descending
            $EtlToCopy = @()
            foreach($etl in $etls)
            {
                $EtlToCopy += $etl.Name
                if($LastInNum -gt 0){
                    $LastInNum --
                }
                if($LastInNum -eq 0)
                {
                    return $EtlToCopy
                }
           
            }

            return $EtlToCopy
        }

        Write-Log "Invoke-Command done for $($NCVM.Server)"
        $RemotePathToCopy = "\\$($NCVM.Server)\c$\Windows\Tracing\SDNDiagnostics\Logs\"


        $NCVMFolder = New-Item -ItemType Directory  -Path "$OutputPath\$($NCVM.Server)\ETL"
        foreach($Etl in $ToCopy)
        {
            Copy-Item -Path $RemotePathToCopy\$Etl -Destination "$($NCVMFolder.FullName)\$Etl"
        }
    }
}

Function Get-NCClusterInfo([String]$NCVMName, [String]$OutputPath)
{
    Write-Log "Getting NC Cluster Info"
    New-Item -Path "$OutputPath\NCClusterInfo" -ItemType Directory -Force | Out-Null
    $OutputPath = "$OutputPath\NCClusterInfo"
    $ncPSSession = New-PSSession -ComputerName $NCVMName
    Invoke-Command -Session $ncPSSession -ScriptBlock{
        Get-NetworkControllerReplica
    }| Out-File -FilePath "$OutputPath\GetNetworkControllerReplica.txt" 

    Invoke-Command -Session $ncPSSession -ScriptBlock{
        Get-NetworkController
    } | Out-File -FilePath "$OutputPath\GetNetworkController.txt" 

    Invoke-Command -Session $ncPSSession -ScriptBlock{
        Get-NetworkControllerNode
    } | Out-File -FilePath "$OutputPath\GetNetworkControllerNode.txt" 

    
    $sfClusterInfo = Invoke-Command -Session $ncPSSession -ScriptBlock{
        Connect-ServiceFabricCluster | Out-Null
        Get-ServiceFabricClusterHealth | Select-Object AggregatedHealthState, NodeHealthStates, ApplicationHealthStates | ft -AutoSize
        Get-ServiceFabricNode | Format-Table NodeName, IpAddressOrFQDN, NodeStatus, NodeUpTime, HealthState, ConfigVersion, CodeVersiom, FaultDomain, UpgradeDomain -AutoSize | Out-String -Width 4096
        Get-ServiceFabricApplication -ApplicationName fabric:/NetworkController | ft ApplicationName, ApplicationStatus, HealthState -AutoSize
        Get-ServiceFabricService -ApplicationName fabric:/NetworkController | ft ServiceName, ServiceStatus, HealthState -AutoSize
        Get-ServiceFabricService -ApplicationName fabric:/System | ft ServiceName, ServiceStatus, HealthState -AutoSize
    }

    $sfClusterInfo | Out-File -FilePath "$OutputPath\ServiceFabricHealth.txt" 

}
Function Start-SDNHostLogs([String[]]$SDNHosts, [bool]$IncludeVfp)
{
    if($SDNHosts.Count -gt 0){
        Invoke-Command -ComputerName $SDNHosts -ScriptBlock{
            Param(
                [bool]$IncludeVfp
            )

            New-item -Path c:\SDNHostTrace -ItemType Directory -Force

            logman create trace "ncha" -ow -o c:\SDNHostTrace\ncha.etl -p "{28F7FB0F-EAB3-4960-9693-9289CA768DEA}" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
            logman update trace "ncha" -p "{A6527853-5B2B-46E5-9D77-A4486E012E73}" 0xffffffffffffffff 0xff -ets
            logman update trace "ncha" -p "{dbc217a8-018f-4d8e-a849-acea31bc93f9}" 0xffffffffffffffff 0xff -ets
            logman update trace "ncha" -p "{41DC7652-AAF6-4428-BBBB-CFBDA322F9F3}" 0xffffffffffffffff 0xff -ets
            logman update trace "ncha" -p "{F2605199-8A9B-4EBD-B593-72F32DEEC058}" 0xffffffffffffffff 0xff -ets
            
            logman create trace "vm_dv" -ow -o c:\SDNHostTrace\vm_dv.etl -p "{1F387CBC-6818-4530-9DB6-5F1058CD7E86}" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
            logman update trace "vm_dv" -p "{6C28C7E5-331B-4437-9C69-5352A2F7F296}" 0xffffffffffffffff 0xff -ets

            logman create trace "slbha" -ow -o c:\SDNHostTrace\slbha.etl -p "{2380c5ee-ab89-4d14-b2e6-142200cb703c}" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets

            
            if($IncludeVfp){
                #Start the VFP related trace
                
                logman create trace "vfp" -ow -o c:\SDNHostTrace\vfpext.etl -p "{9F2660EA-CFE7-428F-9850-AECA612619B0}" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
                logman update trace "vfp" -p "Microsoft-Windows-Hyper-V-Vmswitch" 0xffffffffffffffff 0xff -ets
                logman update trace "vfp" -p "Microsoft-Windows-NDIS-PacketCapture" 0xffffffffffffffff 0xff -ets

                netsh trace start capture=yes overwrite=yes maxsize=2048 tracefile=c:\SDNHostTrace\host.etl scenario=virtualization capturetype=both  
            }
            Write-Host "Started SDN Host Trace at $(HostName)"
        } -ArgumentList $IncludeVfp
    }else {
        Write-Error "No SDN Hosts Specified"
        return
    }
}

Function Stop-SDNHostLogs([String[]]$SDNHosts, [String]$OutputPath, [bool]$IncludeVfp)
{
    if($SDNHosts.Count -gt 0){
        Invoke-Command -ComputerName $SDNHosts -ScriptBlock{
            param(
                [bool]$IncludeVfp
            )
            Write-Host "Stopping SDN Host Trace at $(HostName)"
            logman stop "ncha" -ets
            logman stop "vm_dv" -ets
            logman stop "slbha" -ets

            if($IncludeVfp){
                #Stop VFP related trace
                logman stop "vfp" -ets
                netsh trace stop
            }
        } -ArgumentList $IncludeVfp
    }else
    {
        Write-Error "No SDN Hosts Specified"
        return
    }
}

# Function to collect logs from Infra Nodes. This used to collect static logs only
Function Get-SdnInfraNodeLogs(
    [Parameter(Mandatory = $true)]
    [String[]] $InfraNodes,
    [Parameter(Mandatory = $true)]
    [ValidateSet("NC","MUX","GW")]
    [String]$Role,
    [Parameter(Mandatory = $true)]
    [String]$OutputFolder
)
{
    $DataCollectionDir = "C:\Temp\CSS_SDN"
    $InfraNodeSessions = @()
    $FromDate = (Get-Date).AddHours(-4)
    $FromDateSf = (Get-Date).AddHours(-1)
    $FromDateNc = (Get-Date).AddHours(-8)
    Write-Log -Message "Creating remote sessions to Infra Nodes: $InfraNodes"
    foreach ($InfraNode in $InfraNodes){
        Try {
            $InfraNodeSessions += New-PSSession -ComputerName $InfraNode -ErrorAction Stop
        }
        Catch {
            Write-Log -Message "$_" -Type Error
            continue
        }
    }

    # Gather data from data nodes
    Write-Log -Message "Gathering $Role Logs from $($InfraNodeSessions.ComputerName)"
    $InvokeRemoteJob = Invoke-Command -Session $InfraNodeSessions -ScriptBlock {
        Param(
            [String] $Role,
            [String] $DataCollectionDir
        )
        function Write-Log(
            [String]$Message,
            [ValidateSet("Info","Warning","Error")]
            [String]$Type = "Info")
        {
            $FormattedDate = date -Format "yyyyMMdd-HH:mm:ss"
            $FormattedMessage = "[$FormattedDate] [$Type] [$(HostName)] $Message"
            $messageColor = "Green"
            Switch($Type)
            {
                "Info"{ $messageColor = "Green"}
                "Warning"{$messageColor = "Yellow"}
                "Error"{$messageColor = "Red"}
            }
            Write-Host -ForegroundColor $messageColor $FormattedMessage
        
            $formattedMessage | out-file "$DataCollectionDir\SDNLogCollectLog.txt" -Append
        }
        New-Item -Path "$DataCollectionDir\SDNLogCollectLog.txt" -Force
        # Remove the temp local directory if existed to cleanup old 
        if(Test-Path $DataCollectionDir){
            Write-Host "[$(HostName)] Log path $DataCollectionDir existed, remove the old logs and recreate"
            Remove-Item -Path $DataCollectionDir -Recurse -Force
        }
        
        Write-Host "[$(HostName)] Creating Folder $DataCollectionDir"
        # Create local directory now
        New-Item -Path "$DataCollectionDir" -ItemType Directory | Out-Null
        New-Item -Path "$DataCollectionDir\SDNLogCollectLog.txt" -Force
        
        Write-Log "Started Data Collection"

        # Collect general logs for any role
        $folders = Get-ChildItem -Path "C:\Windows\Tracing" -Recurse -Directory | Where-Object {$_.Name -ne "NetworkControllerState" -and $_.Name -ne "CrashDumps" -and $_.name -ne "AutoBackups"}
        $folders += Get-Item -Path "C:\Windows\Tracing"

        # Gather trace files that generated in last 4 hours from defined folders 
        foreach ($folder in $folders){
            $logfiles = Get-ChildItem -Path $folder.FullName | Where-Object {$_.LastWriteTime -gt $using:FromDate -and $_.Attributes -ne "Directory"}
            foreach ($file in $logfiles){
                if(!(Test-Path -Path "$DataCollectionDir\$($folder.Name)" -PathType Container)){
                    New-Item -Path "$DataCollectionDir\$($folder.Name)" -ItemType Directory
                }
                if($file.LastWriteTime -gt $using:FromDateNc -and $file.Parent -ne "CrashDumps"){
                    Copy-Item $file.FullName -Destination "$DataCollectionDir\$($folder.Name)"
                }
            }
        }

        $EventLogs = @()
        $EventLogs += Get-WinEvent -ListLog Application
        $EventLogs += Get-WinEvent -ListLog System

        if($role -eq "NC")
        {
            # Collect Logs for network controller role
            New-Item -Path "$DataCollectionDir\ServiceFabric" -ItemType Directory | Out-Null
            $SFLogs = Get-ChildItem -Path "C:\ProgramData\Microsoft\Service Fabric\log\Traces" | Where-Object {$_.LastWriteTime -gt $using:FromDateSf}
            foreach($SFLog in $SFLogs)
            {
                Copy-Item $SFLog.FullName -Destination "$DataCollectionDir\ServiceFabric"
            }

            $EventLogs += Get-WinEvent -ListLog *NetworkController* | Where-Object {$_.RecordCount}
            $EventLogs += Get-WinEvent -ListLog *ServiceFabric* | Where-Object {$_.RecordCount}      

            ### Get IMOS DB Info
            #Collect SF Cluster IMOS DB File info
            $sfClusterConnection = Connect-ServiceFabricCluster
            if($sfClusterConnection)
            {
                Write-Log "Collecting Network Controller IMOS Store Info"
                $ncServices = Get-ServiceFabricService -ApplicationName "fabric:/NetworkController"
                # service fabric base folder
                $svcFabricPath = "C:\ProgramData\Microsoft\Service Fabric\$(HostName)\Fabric\work\Applications\NetworkController_App0\work"
                $imosInfo = @()
                foreach($ncService in $ncServices)
                {
                    #Get partition ID
                    $partitionId = (Get-ServiceFabricPartition -ServiceName $ncService.ServiceName).PartitionId
                    $imosPath = Join-Path -Path $svcFabricPath -ChildPath "P_$partitionId"
                    #Get replica ID
                    $replicaId = (Get-ServiceFabricReplica -PartitionId $partitionId | Where-Object NodeName -EQ $(HostName)).ReplicaId
                    $path = Join-Path -Path $imosPath -ChildPath "R_$replicaId\ImosStore"
                    if(Test-Path $path)
                    {
                        #Write-Host "[$(HostName)] $($ncService.ServiceName) IMOS Size: $((Get-Item $path).length)"
                        $imosFile = Get-Item $path
                        $imosInfo += [PSCustomObject]@{
                        NC = $(HostName)
                        ServiceName = $ncService.ServiceName
                        ServicePartitionId = $partitionId
                        ImosSizeinKB = ($imosFile.length)/1KB
                        LastWriteTime = $imosFile.LastWriteTime
                        }
                    }
                    
                }
                $imosInfo | ft | Out-File -FilePath "$DataCollectionDir\IMOSDBInfo.txt"

                Write-Log "Collecting Network Controller Status"
                New-Item -Path "$DataCollectionDir\NetworkControllerStatus" -ItemType Directory | Out-Null
                $client = [System.Fabric.FabricClient]::new()
                $task = $client.PropertyManager.EnumeratePropertiesAsync("fabric:/NetworkController/GlobalConfiguration", $true, $null)
                $task.Result | ForEach-Object {$name=$_.Metadata.PropertyName; $value=[System.Fabric.NamedProperty].getmethod("GetValue").MakeGenericMethod([string]).Invoke($_, $null); "Name:"+$name +", "+ "Value:"+$value} >> "$DataCollectionDir\NetworkControllerStatus\GlobalConfiguration.txt"
    
                $NCUri = "fabric:/NetworkController"
                Get-ServiceFabricClusterManifest | Out-File -FilePath "$using:DataCollectionDir\NetworkControllerStatus\ClusterManifest.xml"
                Get-ServiceFabricClusterHealth | Out-File -FilePath "$using:DataCollectionDir\NetworkControllerStatus\ClusterHealth.txt"

                $NCApp = Get-ServiceFabricApplication -ApplicationName $NCUri 
                $NCApp | Out-File -FilePath "$using:DataCollectionDir\NetworkControllerStatus\NCApp.txt"
                Get-ServiceFabricApplicationManifest -ApplicationTypeName $NCApp.ApplicationTypeName -ApplicationTypeVersion $NCApp.ApplicationTypeVersion | Out-File -FilePath "$using:DataCollectionDir\NetworkControllerStatus\NCAppManifest.txt"
                Get-ServiceFabricApplicationHealth -ApplicationName $NCUri | Out-File -FilePath "$using:DataCollectionDir\NetworkControllerStatus\NCAppHealth.txt"

                $NCServices = Get-ServiceFabricService -ApplicationName $NCUri
                $NCServices | Out-File -FilePath "$using:DataCollectionDir\NetworkControllerStatus\NCServices.txt"
                foreach ($service in $NCServices){
                    $serviceTypeName=$service.ServiceTypeName
                    Get-ServiceFabricServiceHealth -ServiceName $service.ServiceName.AbsoluteUri | Out-File -FilePath "$using:DataCollectionDir\NetworkControllerStatus\$serviceTypeName.txt"

                    $partition = Get-ServiceFabricPartition -ServiceName $service.ServiceName.AbsoluteUri 
                    $replicas = Get-ServiceFabricReplica -PartitionId $partition.PartitionId
                    $replicas | Out-File -FilePath "$using:DataCollectionDir\NetworkControllerStatus\$serviceTypeName.txt" 
                    foreach($replica in $replicas){
                        if($replica.ReplicaId){
                            Get-ServiceFabricReplicaHealth -PartitionId $partition.PartitionId -ReplicaOrInstanceId $replica.ReplicaId >> "$using:DataCollectionDir\NetworkControllerStatus\$serviceTypeName.txt"
                        }
                        else {
                            Get-ServiceFabricReplicaHealth -PartitionId $partition.PartitionId -ReplicaOrInstanceId $replica.InstanceId >> "$using:DataCollectionDir\NetworkControllerStatus\$serviceTypeName.txt"
                        }
                    }
                }
                
            }else
            {
                Write-Log "Failed to connect to Service Fabric Cluster" -Type "Error"
            }
           

        }elseif($role -eq "MUX")
        {
            Write-Log "Collecting MUX Logs"
            # Collect Logs for MUX role
            $EventLogs += Get-WinEvent -ListLog *SLBMux* | Where-Object {$_.RecordCount}

            # MUX Driver Control Console Output
            MuxDriverControlConsole.exe /GetMuxState | Out-File "$DataCollectionDir\MuxState.txt"
            MuxDriverControlConsole.exe /GetMuxConfig | Out-File "$DataCollectionDir\MuxConfig.txt"
            MuxDriverControlConsole.exe /GetMuxStats | Out-File "$DataCollectionDir\MuxStats.txt"
            MuxDriverControlConsole.exe /GetMuxVipList | Out-File "$DataCollectionDir\MuxVipList.txt"
            MuxDriverControlConsole.exe /GetMuxVip | Out-File "$DataCollectionDir\MuxVips.txt"
            MuxDriverControlConsole.exe /GetMuxDripList | Out-File "$DataCollectionDir\MuxDripList.txt"
            MuxDriverControlConsole.exe /GetStatelessVip | Out-File "$DataCollectionDir\StatelessVip.txt"
            MuxDriverControlConsole.exe /GetStatefulVip | Out-File "$DataCollectionDir\StatefulVip.txt"
        }
        elseif($role -eq "GW")
        {
            Write-Log "Collecting Gateway Logs"
            # Collect Logs for GW
            $EventLogs += Get-WinEvent -ListLog *RemoteAccess* | Where-Object {$_.RecordCount}
            $EventLogs += Get-WinEvent -ListLog *VPN* | Where-Object {$_.RecordCount}
            $EventLogs += Get-WinEvent -ListLog *IKE* | Where-Object {$_.RecordCount}       
            
            Get-RemoteAccess | Out-File "$DataCollectionDir\Get-RemoteAccess.txt"
            Get-VpnServerConfiguration | Out-File "$DataCollectionDir\Get-VpnServerConfiguration.txt"
            Get-VpnS2SInterface | Format-List * | Out-File "$DataCollectionDir\Get-VpnS2SInterface.txt"
            Get-GatewayTunnel | Format-List * | Out-File "$DataCollectionDir\Get-GatewayTunnel.txt"
            Get-RemoteaccessRoutingDomain | Format-List * | Out-File "$DataCollectionDir\Get-RemoteAccessRoutingDomain.txt"  
            foreach ($routingDomain in Get-RemoteAccessRoutingDomain){
                New-Item -Path "$DataCollectionDir\$($routingDomain.RoutingDomainID)" -ItemType Directory | Out-Null
                Get-BgpRouter -RoutingDomain $routingDomain.RoutingDomain | Format-List * | Out-File "$DataCollectionDir\$($routingDomain.RoutingDomainID)\Get-BgpRouter.txt"
                Get-BgpPeer -RoutingDomain $routingDomain.RoutingDomain | Format-List * | Out-File "$DataCollectionDir\$($routingDomain.RoutingDomainID)\Get-BgpPeer.txt"
                Get-BgprouteInformation -RoutingDomain $routingDomain.RoutingDomain | Format-List * | Out-File "$DataCollectionDir\$($routingDomain.RoutingDomainID)\Get-BgpRouteInformation.txt"
                Get-BgpCustomRoute -RoutingDomain $routingDomain.RoutingDomain | Format-List * | Out-File "$DataCollectionDir\$($routingDomain.RoutingDomainID)\Get-BgpCustomRoute.txt"
            } 
            Set-Content -Path "$DataCollectionDir\README.txt" -Value "ETL files to be decoded using InsightClient"
            # Ensure we cleanup RAS logs from tracing
            # Remove-Item -Path "C:\Windows\Tracing\*.log"
            # Remove-Item -Path "C:\Windows\Tracing\*.etl"
        }elseif($role -eq "HyperV")
        {
            Write-Log "Collecting Hyper-V Logs"
            $EventLogs += Get-WinEvent -ListLog *Hyper-V* | Where-Object {$_.RecordCount} 
             # Gather VFP port configuration details
            New-Item -Path "$DataCollectionDir\VFP" -ItemType Directory -Force | Out-Null
            $vmAdapters = Get-VMNetworkAdapter *
            $VMAdapterPortInfos = @()
            $PortProfileFeatureId = "9940cd46-8b06-43bb-b9d5-93d50381fd56"
            foreach($vmAdapter in $vmAdapters){
                Write-Host "Getting VM Adapter Port Info for $vmAdapter"
                $PortSettings = $vmAdapter | Get-VMSwitchExtensionPortFeature -FeatureId $PortProfileFeatureId
                $portDatas = Get-VMSwitchExtensionPortData -VMNetworkAdapter $vmAdapter
                if($portDatas.Count -gt 0)
                {
                    $portid = $portDatas[0].data.deviceid
                }else
                {
                    continue
                }
                foreach($PortSetting in $PortSettings){
                    $VMAdapterPortInfo = [PSCustomObject]@{
                            VMName = $vmAdapter.VMName
                            VMAdapterName= $vmAdapter.Name;
                            PortId = $portid
                            PortProfileId = $PortSetting.SettingData.ProfileId
                            PortProfileName = $PortSetting.SettingData.ProfileName
                        
                        }
                    $VMAdapterPortInfos += $VMAdapterPortInfo
                }
            }
         
            $mgmtVmAdapters = Get-VMNetworkAdapter -ManagementOS
            foreach($mgmtVmAdapter in $mgmtVmAdapters)
            {
                Write-Host "Getting VM Adapter Port Info for $mgmtVmAdapter"
                $portid = (Get-VMSwitchExtensionPortData -ManagementOS -VMNetworkAdapterName $mgmtVmAdapter.Name)[0].data.deviceid
                $VMAdapterPortInfo = [PSCustomObject]@{
                    VMName = "ManagementOS"
                    VMAdapterName= $mgmtVmAdapter.Name
                    PortId = $portid
                    PortProfileId = $null
                    PortProfileName = $null
                }
                $VMAdapterPortInfos += $VMAdapterPortInfo
                
            } 
            
            $VMAdapterPortInfos | Out-File "$DataCollectionDir\VMNetworkAdapterPort.txt"

            foreach($vmAdapterPort in $VMAdapterPortInfos)
            {
            vfpctrl.exe /list-rule /port:$($vmAdapterPort.PortId) | Out-File "$DataCollectionDir\VFP\$($vmAdapterPort.VMName)_$($vmAdapterPort.PortId)_RuleInfo.txt"
            vfpctrl.exe /list-nat-range /port $($vmAdapterPort.PortId) | Out-File "$DataCollectionDir\VFP\$($vmAdapterPort.VMName)_$($vmAdapterPort.PortId)_NatInfo.txt"
            vfpctrl.exe /list-mapping /port $($vmAdapterPort.PortId) | Out-File "$DataCollectionDir\VFP\$($vmAdapterPort.VMName)_$($vmAdapterPort.PortId)_ListMapping.txt"
            }
             # Gather OVSDB databases
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_vtep | Out-File "$DataCollectionDir\ovsdb_vtep.txt"
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_firewall | Out-File "$DataCollectionDir\ovsdb_firewall.txt"
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_service_insertion | Out-File "$DataCollectionDir\ovsdb_serviceinsertion.txt"
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_vtep -f json -pretty| Out-File "$DataCollectionDir\ovsdb_vtep.json"
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_firewall -f json -pretty | Out-File "$DataCollectionDir\ovsdb_firewall.json"
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_service_insertion | Out-File "$DataCollectionDir\ovsdb_serviceinsertion.json"
            vfpctrl /list-vmswitch-port | Out-File "$DataCollectionDir\vfpctrl_list-vmswitch-port.txt"

            # Gather Hyper-V network details
            Get-PACAMapping | Sort-Object PSComputerName | Format-Table -AutoSize | Out-String -Width 4096 | Out-File "$DataCollectionDir\Get-PACAMapping.txt"
            Get-ProviderAddress | Sort-Object PSComputerName | Format-Table -AutoSize | Out-String -Width 4096 | Out-File "$DataCollectionDir\Get-ProviderAddress.txt"
            Get-CustomerRoute | Sort-Object PSComputerName | Format-Table -AutoSize | Out-String -Width 4096 | Out-File "$DataCollectionDir\Get-CustomerRoute.txt"
            Get-NetAdapterVPort | Out-File "$DataCollectionDir\Get-NetAdapterVPort.txt"
            Get-NetAdapterVmqQueue | Out-File "$DataCollectionDir\Get-NetAdapterVMQQueue.txt"
            Get-VMSwitch | Format-List * | Out-String -Width 4096 | Out-File "$DataCollectionDir\Get-VMSwitch.txt"
            Get-VMSwitchTeam | Format-List * | Out-String -Width 4096 | Out-File "$DataCollectionDir\Get-VMSwitchTeam.txt"

            # Gather registry key properties for nchostagent and other nc services
            $RegKeyDirectories = @()
            $RegKeyDirectories += Get-ChildItem HKLM:\SYSTEM\CurrentControlSet\Services\NcHostAgent
            $RegKeyDirectories += Get-ChildItem HKLM:\SYSTEM\CurrentControlSet\Services\NcHostAgent -Recurse
            $RegKeyDirectories += Get-ChildItem HKLM:\SYSTEM\CurrentControlSet\Services\DnsProxy
            $RegKeyDirectories += Get-ChildItem HKLM:\SYSTEM\CurrentControlSet\Services\DnsProxy -Recurse
            $RegKeyDirectories = $RegKeyDirectories | Sort-Object -Unique

            foreach($obj in $RegKeyDirectories){
                if($obj.PSPath -like "*NCHostAgent*"){
                    Get-ItemProperty -Path $obj.PSPath | Out-File -Encoding ascii "$DataCollectionDir\Registry_NCHostAgent.txt" -Append
                }
                if($obj.PSPath -like "*DnsProxy*"){
                    Get-ItemProperty -Path $obj.PSPath | Out-File -Encoding ascii "$DataCollectionDir\Registry_DnsProxy.txt" -Append
                }
            }

            # [RS5] Gather nvspinfo.exe results
            if([System.Environment]::OSVersion.Version.Build -eq '17763'){
                nvspinfo.exe -e | Out-File -FilePath "$DataCollectionDir\NVSPInfo.txt"
            }
        }

        Write-Log "Procesing Event Logs"
        $EventLogFolder = "$DataCollectionDir\EventLogs"
        if(!(Test-Path -Path $EventLogFolder -PathType Container)){
            New-Item -Path $EventLogFolder -ItemType Directory -Force | Out-Null
        }
        foreach ($EventLog in $EventLogs){
            #Get-WinEvent -LogName $EventLog.LogName | Where-Object {$_.TimeCreated -gt $using:FromDate} | Select-Object TimeCreated, LevelDisplayName, Id, ProviderName, ProviderID, TaskDisplayName, OpCodeDisplayName, Message | Export-Csv -Path "$EventLogFolder\$($EventLog.LogName).csv".Replace("/","_") -NoTypeInformation
            wevtutil epl $EventLog.LogName "$EventLogFolder\$($EventLog.LogName).evtx".Replace("/","_")
        }        
    
        # Gather general configuration details from all nodes
        Get-ComputerInfo | Out-File "$DataCollectionDir\Get-ComputerInfo.txt"
        Get-Hotfix | Out-File "$DataCollectionDir\Get-Hotfix.txt"
        Get-NetAdapter | Format-Table -AutoSize | Out-String -Width 4096 | Out-File "$DataCollectionDir\Get-NetAdapter.txt"
        foreach($NetAdapter in Get-NetAdapter){
            Get-NetAdapter -Name $NetAdapter.Name | Format-List * | Out-File "$DataCollectionDir\Get-NetAdapter_$($NetAdapter.Name).txt"
            Get-NetAdapterAdvancedProperty -Name $NetAdapter.Name | Format-List * | Out-File "$DataCollectionDir\Get-NetAdapterAdvancedProperty_$($NetAdapter.Name).txt"    
        }
        
        Get-Service | Format-Table -AutoSize | Out-String -Width 4096 | Out-File "$DataCollectionDir\Get-Service.txt"
        Get-Process | Format-Table -AutoSize | Out-String -Width 4096 | Out-File "$DataCollectionDir\Get-Process.txt"
        ipconfig /allcompartments /all | Out-File "$DataCollectionDir\ipconfig_allcompartments.txt"
        Get-NetIPInterface | Format-Table -AutoSize | Out-String -Width 4096 | Out-File "$DataCollectionDir\Get-NetIPInterface.txt"
        Get-NetNeighbor | Format-Table -AutoSize | Out-String -Width 4096 | Out-File "$DataCollectionDir\Get-NetNeighbor.txt"
        Get-NetRoute -AddressFamily IPv4 -IncludeAllCompartments | Out-File "$DataCollectionDir\Get-NetRoute.txt"
        Get-NetTCPConnection | Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, State, OwningProcess, @{n="ProcessName";e={(Get-Process -Id $_.OwningProcess).ProcessName}} | Export-Csv -Path "$DataCollectionDir\Get-NetTCPConnection.csv" -NoTypeInformation

        Write-Log "Collecting Certificates Information"
        # Gather certificates from all nodes
        $CertLocationPaths = @(
        'Cert:\LocalMachine\My'
        'Cert:\LocalMachine\Root'
        )
        foreach ($CertLocation in $CertLocationPaths){
            $Certificates = @()
            $CertificateList = Get-ChildItem -Path $CertLocation -Recurse | Where-Object {$_.PSISContainer -eq $false}
            foreach($cert in $CertificateList){
                $obj = New-Object -TypeName psobject
                $obj | Add-Member -MemberType NoteProperty -Name "FriendlyName" -Value $cert.FriendlyName
                $obj | Add-Member -MemberType NoteProperty -Name "Subject" -Value $cert.Subject
                $obj | Add-Member -MemberType NoteProperty -Name "Issuer" -Value $cert.Issuer
                $obj | Add-Member -MemberType NoteProperty -Name "Thumbprint" -Value $cert.Thumbprint
                $obj | Add-Member -MemberType NoteProperty -Name "HasPrivateKey" -Value $cert.HasPrivateKey
                $obj | Add-Member -MemberType NoteProperty -Name "PrivateKey" -Value $cert.PrivateKey
                $obj | Add-Member -MemberType NoteProperty -Name "NotBefore" -Value $cert.NotBefore
                $obj | Add-Member -MemberType NoteProperty -Name "NotAfter" -Value $cert.NotAfter
                $obj | Add-Member -MemberType NoteProperty -Name "Archived" -Value $cert.Archived
                $obj | Add-Member -MemberType NoteProperty -Name "DnsNameList" -Value $cert.DnsNameList
                $obj | Add-Member -MemberType NoteProperty -Name "SerialNumber" -Value $cert.SerialNumber
                $obj | Add-Member -MemberType NoteProperty -Name "EnhancedKeyUsageList" -Value $cert.EnhancedKeyUsageList
                if($cert.PrivateKey){
                    $acl = Get-Acl -Path ("$ENV:ProgramData\Microsoft\Crypto\RSA\MachineKeys\" + $cert.PrivateKey.CspKeyContainerInfo.UniqueKeyContainerName)
                    $obj | Add-Member -MemberType NoteProperty -Name "AccesstoString" -Value $acl.AccessToString
                    $obj | Add-Member -MemberType NoteProperty -Name "Sddl" -Value $acl.Sddl
                }
                $Certificates += $obj
            }
            $DirFriendlyName = $CertLocation.Replace(":","").Replace("\","_")
            $Certificates | Export-Csv -NoTypeInformation "$DataCollectionDir\$DirFriendlyName.csv"
        }

        Write-Log "Collecting NetSetup Logs"
        # Gather files related to network setup from all nodes
        $NetSetupFiles = @(
            "$env:SystemRoot\Panther\setupact.log"
            "$env:SystemRoot\INF\setupapi.*"
            "$env:SystemRoot\logs\NetSetup\*"
        )

        New-Item "$DataCollectionDir\NetSetupLogs" -ItemType Directory | Out-Null
        foreach($file in $NetSetupFiles){
            Copy-Item -Path $file -Destination "$DataCollectionDir\NetSetupLogs"
        }

        Write-Log "Data Collection Completed"
    } -ArgumentList $Role,$DataCollectionDir
    # -AsJob -JobName ($Id = "$([guid]::NewGuid())")

    # Monitor the job status
    #Get-JobStatus -JobName $Id -ExecutionTimeOut 300 -PollingInterval 1

    # Copy the logs
    foreach($InfraNode in $InfraNodes)
    {
        Write-Log "Copying logs from $InfraNode to $OutputPath"
        $RemotePathToCopy = "\\$InfraNode\c$\Temp\CSS_SDN\*"
        New-Item -Path "$OutputPath\$InfraNode" -ItemType Directory -Force | Out-Null
        Copy-Item -Path $RemotePathToCopy -Destination "$OutputPath\$InfraNode" -Recurse | Out-null
    }

}
Function Get-SDNHostLogs([String[]]$SDNHosts,  [String]$OutputPath){

    if($SDNHosts.Count -gt 0){
        Invoke-Command -ComputerName $SDNHosts -ScriptBlock{
            New-item -Path c:\SDNHostTrace -ItemType Directory -Force
            Get-VM | ft -AutoSize > c:\SDNHostTrace\Get-VM.txt
            Get-VMNetworkAdapter *| ft -AutoSize > c:\SDNHostTrace\Get-VMNetworkAdapter.txt
            Get-VMNetworkAdapter -ManagementOS | ft -AutoSize > c:\SDNHostTrace\Get-VMNetworkAdapterMgmt.txt
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_vtep > c:\SDNHostTrace\ovsdb.txt
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_vtep | Out-File "c:\SDNHostTrace\ovsdb_vtep.txt"
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_firewall | Out-File "c:\SDNHostTrace\\ovsdb_firewall.txt"
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_service_insertion | Out-File "c:\SDNHostTrace\ovsdb_serviceinsertion.txt"
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_vtep -f json -pretty| Out-File "c:\SDNHostTrace\ovsdb_vtep.json"
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_firewall -f json -pretty | Out-File "c:\SDNHostTrace\ovsdb_firewall.json"
            ovsdb-client.exe dump tcp:127.0.0.1:6641 ms_service_insertion | Out-File "c:\SDNHostTrace\ovsdb_serviceinsertion.json"
            Get-ProviderAddress > c:\SDNHostTrace\Get-ProviderAddress.txt
            Get-PACAMapping > c:\SDNHostTrace\Get-PACAMapping.txt
            Get-VMSwitch | fl * > c:\SDNHostTrace\Get-VMSwitch.txt
            ipconfig /allcompartments /all > c:\SDNHostTrace\ipconfig_all.txt

            Tasklist /svc > C:\SDNHostTrace\tasklist.txt
            New-Item -Path C:\SDNHostTrace\EventLogs -ItemType Directory -Force
            copy c:\Windows\System32\winevt\Logs\System.evtx c:\SDNHostTrace\EventLogs
            copy c:\Windows\System32\winevt\Logs\Application.evtx c:\SDNHostTrace\EventLogs
            Get-ChildItem HKLM:System\CurrentControlSet\Services\NcHostAgent -Recurse > c:\SDNHostTrace\NcHostAgentReg.txt
            Get-ChildItem cert:\localmachine\root | %{ 
                if($_.Subject -ne $_.Issuer){
                    "CA Issued Cert Found at Root Store : $($_.Thumbprint),$($_.Subject)" >> c:\SDNHostTrace\RootCerts.txt
                }
            }


            Write-Host -ForegroundColor Green "Getting VM Network Adapter Port Info..."
            $vmAdapters = Get-VMNetworkAdapter *
            $VMAdapterPortInfos = @()
            $PortProfileFeatureId = "9940cd46-8b06-43bb-b9d5-93d50381fd56"
            foreach($vmAdapter in $vmAdapters){
                Write-Host "Getting VM Adapter Port Info for $vmAdapter"
                $PortSettings = $vmAdapter | Get-VMSwitchExtensionPortFeature -FeatureId $PortProfileFeatureId
                $portDatas = Get-VMSwitchExtensionPortData -VMNetworkAdapter $vmAdapter
                if($portDatas.Count -gt 0)
                {
                    $portid = $portDatas[0].data.deviceid
                }else
                {
                    continue
                }
                foreach($PortSetting in $PortSettings){
                    $VMAdapterPortInfo = [PSCustomObject]@{
                            VMName = $vmAdapter.VMName
                            VMAdapterName= $vmAdapter.Name;
                            PortId = $portid
                            PortProfileId = $PortSetting.SettingData.ProfileId
                            PortProfileName = $PortSetting.SettingData.ProfileName
                        
                        }
                    $VMAdapterPortInfos += $VMAdapterPortInfo
                }
            }

            $mgmtVmAdapters = Get-VMNetworkAdapter -ManagementOS
            foreach($mgmtVmAdapter in $mgmtVmAdapters)
            {
                Write-Host "Getting VM Adapter Port Info for $mgmtVmAdapter"
                $portid = (Get-VMSwitchExtensionPortData -ManagementOS -VMNetworkAdapterName $mgmtVmAdapter.Name)[0].data.deviceid
                $VMAdapterPortInfo = [PSCustomObject]@{
                    VMName = "ManagementOS"
                    VMAdapterName= $mgmtVmAdapter.Name
                    PortId = $portid
                    PortProfileId = $null
                    PortProfileName = $null
                }
                $VMAdapterPortInfos += $VMAdapterPortInfo
                
            } 
            
            $VMAdapterPortInfos | ft * > c:\SDNHostTrace\VMNetworkAdapterPort.txt

            New-Item -Path C:\SDNHostTrace\VFPRules -ItemType Directory -Force
            foreach($vmAdapterPort in $VMAdapterPortInfos)
            {
                vfpctrl.exe /port:$($vmAdapterPort.PortId) /list-rule > C:\SDNHostTrace\VFPRules\$($vmAdapterPort.PortId).txt
            }

            #netstat info to check connection state to 6640
            netstat -anob > c:\SDNHostTrace\netstat.txt
        } 

        Write-Host "Copying logs from SDN Hosts"
        foreach($SDNHost in $SDNHosts)
        {
            Write-Host "Copying logs from $SDNHost to $OutputPath"
            $RemotePathToCopy = "\\$SDNHost\c$\SDNHostTrace"
            New-Item -Path "$OutputPath\$SDNHost" -ItemType Directory -Force
            Copy-Item -Path $RemotePathToCopy -Destination "$OutputPath\$SDNHost" -Recurse
        }
    }else
    {
        Write-Error "No SDN Hosts Specified"
        return
    }
}

Function Get-OutputPath([String]$OutputPath)
{
    if([String]::IsNullOrEmpty($OutputPath))
    {
        $OutputPath = Get-Date -Format "yyyyMMddHHmmss"
        Write-Host "Creating log path $OutputPath"
        New-Item $OutputPath -ItemType Directory -Force | Out-Null
    }
    return $OutputPath
}

Function Clean-SDNHostLogs([String[]]$SDNHosts)
{
    Invoke-Command -ComputerName $SDNHosts -ScriptBlock{
        Param(
            [bool]$IncludeVfp
        )
        Write-Host "[$(HostName)]Cleanning up c:\SDNHostTrace"
        $HostLogPath = "C:\SDNHostTrace"
        if(Test-Path $HostLogPath){
            Write-Host "[$(HostName)]Log path $HostLogPath existed, remove the old logs and recreate"
            Remove-Item -Path $HostLogPath -Recurse -Force
        }
        New-Item -Path $HostLogPath -ItemType Directory -Force
        Write-Host "[$(HostName)]Log path $HostLogPath created and cleaned up"
    }
}

Function Get-RequiredModules()
{
    $feature = get-windowsfeature "RSAT-NetworkController"
    if (!$feature.Installed) {
        Write-Log "RSAT-NetworkController Not Installed"
        add-windowsfeature "RSAT-NetworkController" -Confirm
        $feature = get-windowsfeature "RSAT-NetworkController" 
    }else
    {
        Write-Log "RSAT-NetworkController Installed"
    }
    return $feature.Installed
}


Function Get-SdnVirtualServerAddress(
    [String] $NcUri,
    [String] $ResourceId
)
{
    #Write-Log "Getting Virtual Server from $NcUri with resource Id: $ResourceId"
    $virtualServerResource = Get-NetworkControllerVirtualServer -ConnectionUri $NcUri -ResourceId $ResourceId
    
    if($virtualServerResource -ne $null)
    {
        #Write-Log "Looking for Virtual Server Connections"
        if($virtualServerResource.properties.connections -ne $null)
        {
            #Write-Log "Looking for Virtual Server Connection Management Address"
            if($virtualServerResource.properties.connections[0].managementaddresses -ne $null)
            {
                return $virtualServerResource.properties.connections[0].managementaddresses[0]
            }
        }
    }

    #Write-Log "No Virtual Server resource found"
    return ""
}
Function Get-SdnInfraVMs(
    [String] $NCVMName,
    [String] $NcUri
)
{
    Write-Log "Getting SDN Infra VMs from $NcUri"
    Write-Log "Looking for SDN NC"
    $global:NcVMs = (Get-NetworkControllerNode -ComputerName $NCVMName).Server

    Write-Log "Looking for SDN MUX"
    $muxResources = Get-NetworkControllerLoadBalancerMux -ConnectionUri $NcUri
    foreach($muxResource in $muxResources)
    {
        $muxVirtualServerResourceId = $muxResource.properties.virtualserver.ResourceRef -replace "/VirtualServers/"
        $muxVirtualServerAddress = Get-SdnVirtualServerAddress -ResourceId $muxVirtualServerResourceId -NcUri $NcUri
        if($muxVirtualServerAddress -eq $null)
        {
            Write-Log "MUX $($muxResources.ResourceId) pointed to virtual server $muxVirtualServerResourceId have no management address found" -Type "Warning"
        }else
        {
            $global:MuxVMs += $muxVirtualServerAddress
        }
    }

    Write-Log "Looking for SDN Gateway"
    $gwResources = Get-NetworkControllerGateway -ConnectionUri $NcUri
    foreach($gwResource in $gwResources)
    {
        $gwVirtualServerResourceId = $gwResource.properties.virtualserver.ResourceRef -replace "/VirtualServers/"
        $gwVirtualServerAddress = Get-SdnVirtualServerAddress -ResourceId $gwVirtualServerResourceId -NcUri $NcUri
        if($gwVirtualServerAddress -eq $null)
        {
            Write-Log "Gateway $($muxResources.ResourceId) pointed to virtual server $gwVirtualServerResourceId have no management address found" -Type "Warning"
        }else
        {
            $global:GwVMs += $gwVirtualServerAddress
        }
    }
}

Function Get-SdnNcVMNameFromHost()
{
    $NCVMName = ""
    Write-Log "Trying to find RESTNAME automatically"
    if(Test-Path "HKLM:\System\CurrentControlSet\Services\NcHostAgent")
    {
        Write-Log "Getting RESTNAME from NCHOSTAGENT Registry"
        $registry = Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Services\NcHostAgent\Parameters"
        if ($regsitry.Connections)
        {
            $RestName=$registry.Connections[0].Split(":")[1]
        }
        else
        {
            #Trying with Cert CNAME
            $RestName=$registry.PeerCertificateCName
        }
        Write-Log "RestName retrieved is $RestName"
            # Getting one NC Name from DNS  
        try{
            $RestIP=(Resolve-DnsName $RestName -ErrorAction Stop).IpAddress
            Write-Log "$RestName resolved to $RestIp"
            $NCVMName=(Resolve-DnsName $RestIP -ErrorAction Stop).Namehost
            Write-Log "$RestIP resolved to $NCVMName"
        }Catch
        {
            Write-Log "$RestIP not resolved"
        }
        
    }else{
        Write-Log "This is not executing from SDN host, please specifiy the NC VM name"
    }
    return $NCVMName
}

# Install NC Cert if NC Rest Cert Not trusted by the current machine running script. Ask user's confirmation
Function Install-NCCert(
    [String] $NCVMName
)
{
    $ncConfig = Invoke-Command -ComputerName $NCVMName -ScriptBlock{
        $ncConfig = Get-NetworkController
        $ncRestName = $ncConfig.RestName
        $ncCertThumb = $ncConfig.ServerCertificate.Thumbprint
        Get-ChildItem Cert:LocalMachine\My\$ncCertThumb | Export-Certificate -Type CERT -FilePath "c:\Temp\CSS_SDN\$ncRestName" | out-null
        return $ncConfig
    }

    $ncCertThumb = $ncConfig.ServerCertificate.Thumbprint
    $ncRestName = $ncConfig.RestName
    if(Test-Path Cert:LocalMachine\Root\$ncCertThumb)
    {
        Write-Log "NC Cert $ncCertThumb trusted, continue"
        return $true
    }else{
        Write-Log "NC Cert $ncCertThumb not trusted. Need import" -Type Warning
        Import-Certificate -FilePath "\\$NCVMName\c$\Temp\CSS_SDN\$ncRestName" -certstorelocation "cert:\localmachine\root" -Confirm | out-null
        if(Test-Path Cert:LocalMachine\Root\$ncCertThumb)
        {
            Write-Log "NC Cert installed. Continue"
            return $true
        }else
        {
            return $false
        }
    }
}

$ScriptVersion = "2020.6.30"
$GetSDNHostTraceNow = $true;
$global:OutputPath = ""
# The Temp DataCollection Dir on Infra Servers
$global:DataCollectionDir = "C:\Temp\CSS_SDN"
$global:NcUri = ""

#Infra VMs
$global:NcVMs = @()
$global:GwVMs = @()
$global:MuxVMs = @()


if($StartSDNHostTrace)
{
    Clean-SDNHostLogs -SDNHosts $SDNHosts
    Start-SDNHostLogs -SDNHosts $SDNHosts -IncludeVfp $IncludeVfp
    $GetSDNHostTraceNow = $false
}

if($StopSDNHostTrace)
{
    Stop-SDNHostLogs -SDNHosts $SDNHosts -IncludeVfp $IncludeVfp
    $GetSDNHostTraceNow = $true
}


if($GetSDNHostTraceNow -and $SDNHosts.Count -gt 0)
{
    $OutputPath = Get-OutputPath -OutputPath $OutputPath
    Write-Host $OutputPath
    if(!$StopSDNHostTrace)
    {
        #if this is called during stop SDN Host trace, the cleanup already done before
        Clean-SDNHostLogs -SDNHosts $SDNHosts
    }
    Get-SDNHostLogs -SDNHosts $SDNHosts -OutputPath $OutputPath
}

if([String]::IsNullOrEmpty($NCVMName))
{
    $NCVMName = Get-SdnNcVMNameFromHost
}

if(![String]::IsNullOrEmpty($NCVMName)){
    Write-Host "Collecting Network Controller traces"
    $OutputPath = Get-OutputPath -OutputPath $OutputPath
    Write-Log "SDNLogCollect Version: $ScriptVersion"
    Write-Log "TimeZone: $(Get-TimeZone)"
   
    $RequiredModuleInstalled = Get-RequiredModules

    if(!$RequiredModuleInstalled)
    {
        Write-Log "Required Module RSAT-NetworkController not installed" -Type Error
        return 
    }

    $nc = Get-NetworkController -ComputerName $NCVMName
    $NcUri = "https://$($nc.RestName)"
    Write-Log "Retrieved the NcUri: $NcUri"
    Write-Log "Check NC Cert Trust"
    $ncCertInstalled = Install-NCCert -NCVMName $NCVMName
    if($ncCertInstalled -ne $true)
    {
        Write-Log "NC Cert not installed, exiting" -Type "Warning"
        return
    }

    Get-SdnInfraVMs -NCVMName $NCVMName -NcUri $NcUri
    Write-Log "NC: $NcVMs"
    Write-Log "MUX: $MuxVMs"
    Write-Log "Gateway: $GwVMs"

    Get-SdnInfraNodeLogs -InfraNodes $NcVMs -Role "NC" -OutputFolder $OutputPath
    Get-SdnInfraNodeLogs -InfraNodes $MuxVMs -Role "MUX" -OutputFolder $OutputPath
    Get-SdnInfraNodeLogs -InfraNodes $GwVMs -Role "GW" -OutputFolder $OutputPath
    
    Get-NCImosDump -NCVMName $NCVMName -OutputPath $OutputPath
    Get-SdnResources -NCVMName $NCVMName -OutputFolder $OutputPath -NcUri $NcUri
    Get-NCClusterInfo -NCVMName $NCVMName -OutputPath $OutputPath
}

# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDnhkykhPbAZVn4
# eY0/T0IlfZnKoBTeRGolITgli3YyDKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgpq+imd2r
# LoAZBWrFF+OTFgUoUMFrToKuhgWZFaDAbLwwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAI9+YNYLB6GxhzKtekPsRJVF4jfR22Q4UoG0Iz1GVJdSb6d/MtJMBw5e
# QHsntyr6+Wz5e81vJBtT46dka4qm7E/S/oIqtfq+yylHLcT6gZPBOjfu6xs+DuRN
# FZgz6vtbHeTH+HBZHQw6IzLHYeid6RG6xt18+YBt4WNDZDTE0yR9YtpHU4gZ990P
# 6IHkUxKN42ikNQASFcn9OOA8tXsHJ5HEVndz0TmKUWe9hM4ZNWxac/wHDyU0Mxl4
# 0td03LsB28wA3WBVeL5PwRnqYn7wfT82+UXLzCDzHq20qm74VRj6U5qdNqe5gsix
# YMVPZfCKK0tNxmDroxCCMkdOlMF5gHGhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgeY2l63RQ6I6dMan1MtbDxsD/ENFEGxp00G0iUOS+8eMCBmCJ+e5d
# IxgTMjAyMTA1MTkyMjIxNTUuMTAzWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYw
# QkMtRTM4My0yNjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFaLLluRDTLbygAAAAAAVowDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE2WhcNMjIwNDExMTkwMjE2WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0yNjM1
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsL1cHFcNrScIrvQd/4aKHo3FGXWYCHMU
# l2iTxuzfGknztMzbysR4eRkBoT4pv0aL1S9OlDfOsRbJZKkhCTLG/9Z/RwiEDWYk
# 6rK7bRM3eX3pm+DNivM7+tCU+9spbv2gA7j5gWx6RAK2vMz2FChLkFgbA+H1DPro
# G5LEf1DB7LA0FCyORWiKSkHGRL4RdIjOltrZp++dExfsst7Z6vJz4+U9eZNI58fV
# Y3KRzbm73OjplfSAB3iNSkHN0wuccK0TrZsvY87TRyYAmyK2qBqi/7eUWt93Sw8A
# LBMY72LKaUmVvaxq/COpKePlHMbhHEbqtTaLt61udBOjNHvc4cwY5QIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFGRzJT/1HI+SftAGhdk5NDzA3jFnMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAAAAbex8WBtSLDiBYxXxU7GVsgb8IgxKJyIO0hmc8vzg
# 4w3iUl5Xkt4mv4dgFyjHmu5Zmbj0rb2IGYm/pWJcy0/zWlhnUQUzvfTpj7MsiH+1
# Lnvg95awe88PRA7FDgc4zYY0+8UB1S+jzPmmBX/kT6U+7rW5QIgFMMRKIc743utq
# CpvcwRM+pEo8s0Alwo8NxqUrOeYY+WfNjo/XOin/tr3RVwEdEopD+FO+f/wLxjpv
# 4y+TmRgmHrso1tVVy64FbIVIxlMcZ6cee4dWD2y8fv6Wb9X/AhtlQookk7QdCbKh
# 3JJ4P8ksLs02wNhGkU37b10tG3HR5bJmiwmZPyopsEgwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjYwQkMtRTM4My0y
# NjM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQDMgAWYvcYcdZwAliLeFobCWmUaLqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9+kDAiGA8y
# MDIxMDUxOTE2MDk1MloYDzIwMjEwNTIwMTYwOTUyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT36QAgEAMAoCAQACAiRAAgH/MAcCAQACAhHpMAoCBQDkUNAQAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAXQVTueK27//AUfUiggXN8DDFmThP
# HNd2Le5OoEJr8qEBfMGpVZi7jF8iZSUH9l/6ETYmHoASPTTouApmAJ5Af8Xfx/vm
# oYN8YzShzD0I4L885xMWFLRy7gTvwo2wW1zaGWI8+tWW/lQpS/DEhQ15jwffKX4A
# rrUtsL3e79dlzEYxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVosuW5ENMtvKAAAAAABWjANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCBWwvqY
# au6Je+BhKXopfnuMgxPu0EpkndA/n41OWEFjYTCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIJP8qCZ0xLLkXTDDghqv1yZ/kizekzSFS4gicvltsX+wMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFaLLluRDTLbygA
# AAAAAVowIgQgOL0wIlEHhiqd5WY8M69hOFUOI1uWdoiGagbxykIYFMEwDQYJKoZI
# hvcNAQELBQAEggEAXxexqaQ80A3LB1/TVW6aM6yS+U2kNoSoMRdBBMX+BM8K9clX
# 1Lm11CbXGTigdQNG8q9iDSXxuQPvwFvsTSFYyNcU4e6B0KEoRTjvgMQPYaKKQ75X
# FkZy91OoZLyDtjt3jbJ/rr64Wicz1nBF7o4yaJei2MV/fsk4VhgnuM+95IQeCnUe
# JVSGVbeVi6GGgF4m/wpBNavxxguSlEnWj2Tq/aUquPrxzgpIsz0AUTlvUtqDaN9A
# L1tK/WcCLpejPWRSxZS+36HFjvG3fJQk5fVZn6XeTR/wOy/WDKuMx0hJEdiNVxQW
# 0rnmETpSROyH6Sj3WwO+dVV7HjfnXm1ASO0LJQ==
# SIG # End signature block
