# File: https://aka.ms/Debug-ContainerHost.ps1 

Write-Output "Checking for common problems"

$filesToDump = @{}
$currentVersion = Get-Item 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
$OSProductName = $currentVersion.GetValue('ProductName')
$OSBuildLabel = $currentVersion.GetValue('BuildLabEx')
Write-Output "Container Host OS Product Name: $OSProductName"
Write-Output "Container Host OS Build Label: $OSBuildLabel"

Describe "Windows Version and Prerequisites" {
    $buildNumber = (Get-CimInstance -Namespace root\cimv2 Win32_OperatingSystem).BuildNumber
    It "Is Windows 10 Anniversary Update or Windows Server 2016" {
        $buildNumber -ge 14393 | Should Be $true
    }
    It "Has KB3192366, KB3194496, or later installed if running Windows build 14393" {
        if ($buildNumber -eq 14393)
        {
            (Get-ItemProperty -Path 'HKLM:\software\Microsoft\Windows NT\CurrentVersion' -Name UBR).UBR | Should Not BeLessThan 351
        }
    }
    It "Is not a build with blocking issues" {
        $buildNumber | Should Not Be 14931
        $buildNumber | Should Not Be 14936
    }

    It "Has 'Containers' feature installed" {
        if (((Get-ComputerInfo).WindowsInstallationType) -eq "Client") {
            (Get-WindowsOptionalFeature -Online -FeatureName Containers).State | Should Be "Enabled"
        }
        else {
            (Get-WindowsFeature -Name Containers).InstallState | Should Be "Installed"
        }
    }

    # TODO Check on SKU support - Home, Pro, Education, ...
}

Describe "Docker is installed" {

    $services = Get-Service | Where-Object {($_.Name -eq "Docker") -or ($_.Name -eq "com.Docker.Service")}
    It "A Docker service is installed - 'Docker' or 'com.Docker.Service' " {
        $services| Should Not BeNullOrEmpty
    }
    It "Service is running" {
        $AtLeastOneRunning = $false;
        foreach ($service in $services)
        {
           #if there is more than 1 only one can be running
           if ($service.Status -eq "Running")
           {
                $AtLeastOneRunning = $true
           }
        }
        $AtLeastOneRunning | Should Be $true
    }
    It "Docker.exe is in path" {
        # This also captures 'docker info' and 'docker version' output to be shown later
        {
            Start-Process -NoNewWindow `
                        -Wait `
                        -FilePath docker.exe `
                        -ArgumentList "info" `
                        -RedirectStandardError err.txt `
                        -RedirectStandardOutput dockerinfo.txt
            $filesToDump["docker info"] = "dockerinfo.txt"
            Start-Process -NoNewWindow `
                        -Wait `
                        -FilePath docker.exe `
                        -ArgumentList "version" `
                        -RedirectStandardError err.txt `
                        -RedirectStandardOutput dockerversion.txt
            $filesToDump["docker version"] = "dockerversion.txt"
        } | Should Not Throw
    }
    It "Docker is registered in the EventLog service" {
        (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Application\docker") -or (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Application\DockerService") | Should Be $true
    }
}

Describe "User has permissions to use Docker daemon" {
    It "docker.exe should not return access denied" {
        "err.txt" | Should Not Contain "access is denied"
    }
}

Describe "Windows container settings are correct" {
     It "Do not have DisableVSmbOplock set to 1" {
         $regvalue = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\Containers" -Name VSmbDisableOplocks -ErrorAction Ignore
         if ($regvalue) {
             $regvalue.VSmbDisableOplocks | Should Be 0
         }
     }
     It "Do not have zz values set" {
         $regvalues = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\Containers"
         ($regvalues | Get-Member zz* | Measure-Object).Count | Should Be 0
     }
     It "Do not have FDVDenyWriteAccess set to 1" {
         $regvalue = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Policies\Microsoft\FVE" -Name FDVDenyWriteAccess -ErrorAction Ignore
         if ($regvalue) {
             $regvalue.FDVDenyWriteAccess | Should Be 0
         }
     }
 }

Describe "The right container base images are installed" {
    $imageListOutput = docker.exe images
    $images = $imageListOutput | Foreach-Object {
        if (($_ -match "^REPOSITORY") -eq $false) {
            $trimmed = [regex]::Replace($_, "\s{2,}"," ")
            $split = $trimmed.Split(" ")
            New-Object -Typename PSObject -Property @{Repository=$split[0];
            Tag=$split[1];
            ImageId=$split[2]}
        }
    }

    It "At least one of 'mcr.microsoft.com/windows/servercore', 'mcr.microsoft.com/windows/nanoserver', 'mcr.microsoft.com/windows' or deprecated microsoft/windowsservercore, microsoft/nanoserver should be installed" {
        $baseImages = $images | Where-Object { ($_.Repository -eq "mcr.microsoft.com/windows/servercore") `
                                                -or ($_.Repository -eq "mcr.microsoft.com/windows/nanoserver") `
                                                -or ($_.Repository -eq "mcr.microsoft.com/windows")}
        if (($baseImages | Measure-Object).Count -eq 0)
        {
            Write-Warning "No mcr.microsoft.com/* base images found. Checking for deprecated images."
            $baseImages = $images | Where-Object { ($_.Repository -eq "microsoft/windowsservercore") `
                                                -or ($_.Repository -eq "microsoft/nanoserver")}
            (Measure-Object $baseImages).Count | Should Not BeNullOrEmpty
        }
    }
}

Describe "Container network is created" {
   Start-Process -NoNewWindow `
                 -Wait `
                 -FilePath docker.exe `
                 -ArgumentList "network ls" `
                 -RedirectStandardError err.txt `
                 -RedirectStandardOutput dockernetworkls.txt
   $filesToDump["docker network ls"] = "dockernetworkls.txt"

   $networksListOutput = Get-Content .\dockernetworkls.txt

   $networks = $networksListOutput | Foreach-object {
       if (($_ -match "^NETWORK") -eq $false) {
           $trimmed = [regex]::Replace($_, "\s{2,}", " ")
           $split = $trimmed.Split(" ")
           New-Object -Typename PSObject -Property @{Driver=$split[2];
           NetName=$split[1];
           Scope=$split[3]}
       }
   }

   # Get all NAT networks
   $natNetworks = $networks | Where-Object { ($_.Driver -eq "nat")}

   # Get all Transparent networks
   $transparentNetworks = $networks | Where-Object { ($_.Driver -eq "transparent")}

   # Get all l2bridge networks
   $l2bridgeNetworks = $networks | Where-Object { ($_.Driver -eq "l2bridge")}

   $hostips = @()
   if ($natNetworks -ne $null)
   {
      # Get VMSwitch for NAT network
      if ($natNetworks[0].NetName -eq "nat")
      {
         $natVMSwitchName = "nat"
      }
      else
      {
         $natVMSwitchName = docker.exe network inspect --format="{{.Id}}" $natNetworks[0].NetName
      }

      $natGatewayIP = docker.exe network inspect --format="{{range .IPAM.Config }}{{.Gateway}}{{end}}" $natNetworks[0].NetName

      #$switchType = (Get-VMSwitch -SwitchName $natNetworks[0].NetName).SwitchType
      $switchType = (Get-VMSwitch -SwitchName $natVMSwitchName).SwitchType

      # TODO - Add checks for the case where there are no (default) nat networks, everything will need to be user-defined
      $natInternalPrefix = docker.exe network inspect --format="{{range .IPAM.Config }}{{.Subnet}}{{end}}" $natNetworks[0].NetName
      if ($natInternalPrefix.Contains("/"))
      {
         $Temp = $natInternalPrefix.Split("/")
         $Prefix = $Temp[0]
         $Length = $Temp[1]
      }
      $IPSubnet = [Net.IPAddress]::Parse($Prefix)
      $BinaryIPSubnet = [String]::Join('', $( $IPSubnet.GetAddressBytes() | %{
               [Convert]::ToString($_, 2).PadLeft(8, '0') } ))

      # Get all Host IP Addresses from Container Host
      $hostips = Get-NetIPAddress -AddressFamily IPv4 | where { $_.InterfaceAlias -notmatch "Loopback"  -And $_.InterfaceAlias -notmatch "HNS" -And $_.InterfaceAlias -notmatch "NAT" } | Select IPAddress
   }

   It "At least one local container network is available" {
      $localNetworks = $networks | Where-Object { ($_.Scope -eq "local")}
      ($localNetworks | Measure-Object).Count | Should Not BeNullOrEmpty
   }

   # Either need NAT, L2bridge, or Transparent for external network access.
   It "At least one NAT, Transparent, or L2Bridge Network exists" {
      $totalnets = 0
      if ($natNetworks -ne $null)
      {
         $totalnets += ($natNetworks | Measure-Object).Count
      }

      if ($transparentNetworks -ne $null)
      {
         $totalnets += ($transparentNetworks | Measure-Object).Count
      }

      if ($l2bridgeNetworks -ne $null)
      {
         $totalnets += ($l2bridgeNetworks | Measure-Object).Count
      }

      $totalnets | Should BeGreaterThan 0
   }

   # TODO: Need a way to skip these next two tests if no NAT networks exist on the system
   It "NAT Network's vSwitch is internal" {
      $switchType | Should Be "Internal"
   }

   It "A Windows NAT is configured if a Docker NAT network exists" {
       $winnatCount = (Get-NetNat | Measure-Object).Count
       $natCount = 0
       if ($natNetworks -ne $null)
       {
           $natCount += ($natNetworks | Measure-Object).Count
       }
       $winnatCount | Should Not BeLessThan $natCount
   }

   It "Specified Network Gateway IP for NAT network is assigned to Host vNIC" {
      $natGatewayIP | Should Not BeNullOrEmpty

      $vmnicIps = Get-NetIPAddress -AddressFamily IPv4 | where { $_.InterfaceAlias -notmatch "Loopback"  -And $_.InterfaceAlias -match "vEthernet" } | Select IPAddress

      $vmNicGatewayIPExists = $false
      $vmnicIps | Foreach-object {
         if ($_ -match $natGatewayIP) {
            $vmNicGatewayIPExists = $true
         }
      }
      $vmNicGatewayIPExists | Should Be $true

   }

   It "NAT Network's internal prefix does not overlap with external IP'" {
      if ( ($hostips | measure-object).Count -gt 0)
      {
         $hostips | Foreach-object {
             $testip = [Net.IPAddress]::Parse( ($_.IPAddress) )
             $BinaryIP = [String]::Join('', $( $testip.GetAddressBytes() | %{
                [Convert]::ToString($_, 2).PadLeft(8, '0') } ))

             $BinaryIP.Substring(0, $Length) | Should Not Be $BinaryIPSubnet.Substring(0, $Length)
         }
      }
      else
      {
        $hostips.Count | Should BeGreaterThan 0
      }
   }

   # TODO: Add a test to validate the Host vNIC exists with NAT Network's Default Gateawy IP assigned.
}

# Dump & Cleanup temporary files used during Pester tests
$filesToDump.Keys | ForEach-Object {
     if (Test-Path $filesToDump[$_]) {
         Write-Output "Showing output from: $($_)"
         Get-Content $filesToDump[$_] | Write-Output
         Remove-Item $filesToDump[$_]
         Write-Output ""
     }
}

if (Test-Path err.txt) { Remove-Item err.txt}

Write-Output "Getting Warnings & errors in the Windows event logs from the last 24 hours"
$logStartTime = (Get-Date).AddHours(-24)

$logNames = "Microsoft-Windows-Containers-Wcifs/Operational",
            "Microsoft-Windows-Containers-Wcnfs/Operational",
            "Microsoft-Windows-Hyper-V-Compute-Admin",
            "Microsoft-Windows-Hyper-V-Compute-Operational",
            "Application"
$levels = 3,2,1,0
$providers = "Docker", "Microsoft-Windows-Hyper-V-Compute"

$events = Get-WinEvent -FilterHashtable @{Logname=$logNames; StartTime=$logStartTime; Level=$levels; ProviderName=$providers} -ErrorAction Ignore

$eventCsv = "logs_$((get-date).ToString("yyyyMMdd'-'HHmmss")).csv"
$events | Format-Table
$events | Export-CSV $eventCsv
Write-Host "Logs saved to $($PWD)\$($eventCsv)`n`n"

Write-Output "Getting Docker for Windows daemon logs from the last execution"
Write-Output "    Note: More logs may be available at $($ENV:LOCALAPPDATA)\Docker. Only showing the latest 100 lines."
if (Test-Path "$($ENV:LOCALAPPDATA)\Docker\log.txt")
{
	Get-Content -Tail 100 "$($ENV:LOCALAPPDATA)\Docker\log.txt" | Select-String "WindowsDockerDaemon"
}
else {
	Write-Output "   $($ENV:LOCALAPPDATA)\Docker\log.txt does not exist."
}
# SIG # Begin signature block
# MIIjfAYJKoZIhvcNAQcCoIIjbTCCI2kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBYVue65v9hr94Q
# LMiaUpPioxwEXl9JU+g9ZuiFltDCfaCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVUTCCFU0CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgmOncfSzD
# IZMLTmY+SoLUx1dBYk/jEmVbLYK1EROYtpQwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAD3vy4xgMPVhrbtnkktkkJHSDQXFI7yxN9eV55I8ZS2qTS2KKK0Cgwtu
# 2r426i0lPNx1EANR2RdBHA8p5fHN1WHFSovwE9tVcpmqbw4sQ6u6RB7qxi7pquBK
# K20XBRPUL2DELLjP3BdCCrhlU/n6dusxwEd4Vw1vKw1vArwmVkcQDZFrdAJCczbA
# BeeAZGefUKSOV7fblGf27d9zb4Lq3pX+mEOxyhKUDdlFxT5ZSw5089vLQc2ip4nq
# VOgr56umm9m5c9sFcR0RNMtoQR9/9QfJ92q95KLSpWkQA9ZPviGNP6H6WZk2Tj3l
# W1nt/iEdRIqvlgZqrIvXSNjr98L9zG2hghLlMIIS4QYKKwYBBAGCNwMDATGCEtEw
# ghLNBgkqhkiG9w0BBwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYL
# KoZIhvcNAQkQAQSgggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgkIdC4/UCf7kncvE6cYv0M8iQBu5biKbce8/4TnLyVEcCBmCJ1lRG
# phgTMjAyMTA1MTkyMjIwNTYuNjg1WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
# ZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RDZCRC1F
# M0U3LTE2ODUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# gg48MIIE8TCCA9mgAwIBAgITMwAAAVBYotSnmwsw6wAAAAABUDANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMDExMTIxODI2
# MDNaFw0yMjAyMTExODI2MDNaMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpENkJELUUzRTctMTY4NTElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAOd6f5R7KlnDJxtWmg3zM1ICqdmXjT5GNFPHXuCw+9Vg
# 3G897o/Ou5L8nlfaY43oFG35dokBMkm+QKAe9WImqtTtDf1PSpN/TZ85NPOQFHXO
# EHaKEvddJoSlET8vbBJru+AvyOE8WLR1nyeepyP3ptUtpG8+zsA1d4MXfGlk2BRI
# ovYR6AFyZFSx773a5aT81iyPxjcQK/ao+dII0RKp1D3slLgrdHk/MdIIbbFi9FEu
# n5v3QVUjYkJCvUgCP3ZQ2R7bAodtCzlV3IkT7++CDq3Jl1rFbsBWiMirkpx8zf5B
# qE0qmx04ebfsjBiYPUt9OxvS1WFcuNuHujhPpwIqJZsCAwEAAaOCARswggEXMB0G
# A1UdDgQWBBSCVRkfGUXbrWQvQ8EAQzu3659FfjAfBgNVHSMEGDAWgBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNy
# dDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# CwUAA4IBAQBRP2h0co7+4+PTwB4vk/YeLEw6ocreg+T0kB2aWB/Ze3zEXtj0EeIV
# A1Zgwp38cjavJg67dIACze3FlpGlqW9jRHXpZYhDML0b2ipIPtA03REzGyKIIwzr
# n+er3FI8iuZiHppNcWAgy6HgYs2TuAxAXJtRuDZmUtmyf2vlHPFf/HxorXuCARYq
# aKKPWWBv/oAT5sA9S4TLLnS5rpT1mzT5uLz8e+dmzo+IzAaG1fP+xGtloBiNsu9o
# Jc6T4NtG8cGhgdBCbflCs9Qh+I1zDfSCIgxHLvFgeOKaX8jFqQwVQnnqYsTdK+dt
# IbForCmk+WQizDkeF6Z1IYezlKWtBNteMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAA
# AjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0
# aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPl
# YcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2T
# rNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFh
# E24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+c
# Bj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn
# 9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQB
# gjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB
# /zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEE
# AYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9Q
# S0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcA
# YQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZI
# hvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20Z
# MLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX
# /1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+TH
# zvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnx
# zplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjY
# lPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kW
# umGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3
# ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slva
# yA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5
# KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czm
# TfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYIC
# zjCCAjcCAQEwgfihgdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkQ2QkQtRTNFNy0xNjg1MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQAj
# DXufcvE1a0YRm1qWWaQxlh6gEqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5FAD0zAiGA8yMDIxMDUyMDA1Mzgy
# N1oYDzIwMjEwNTIxMDUzODI3WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDkUAPT
# AgEAMAoCAQACAgL9AgH/MAcCAQACAhGRMAoCBQDkUVVTAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQEFBQADgYEALTmnU76RtsG8Unlnx/v8fRLyBzh+He9c/X0FweNr/+Bl
# tXbxCms8acKVMEa2U7omSlueu4YdkZlGw1oABMm+BUXbR1O0NZW3GG7GssrxrOAi
# +OOhvjojogSBeS66anXYRxjM0sTeqdIRt+f4IaD2Gt6NQuhJMXzNwCaCZ6IVxwAx
# ggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AVBYotSnmwsw6wAAAAABUDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDnR7Sq14E7aEZy7giR9of4
# sKMDVTgkAMrQausjEzZ+qzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIGz0
# Pp8vmsJOGBcmYYiF1dLohjVmDqinjt2Qonwv8qP2MIGYMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFQWKLUp5sLMOsAAAAAAVAwIgQgJwJq
# 7Kv4gM4ttoOd4Smr9j+BpNnlYaQytX0aRRx3H/0wDQYJKoZIhvcNAQELBQAEggEA
# Me13ovr+pCo0bSVooXiheYLbAFUDjBFu03jZ2qqFLAv5USZaiwVSIBmVoiOdq8aC
# deI+xDfPtqWta6xJO9dxrxcisTAyCZ7GmghbDBLgphyB2rjHx9LgqTgPWtno1QVQ
# vetnt/RjwWvG5DBtbmSmuyoRj51RN6JBMT0RvQFyyxBHmmIJN9+Nj7A2kAfRzAdl
# B+txIcP84LyWaePMwM0mFS1Xdy281FIZyQIc1r+pD28SNeSCRKqaqrljk5YUjFeH
# gSGwuXb+Wjv43bykeMYIewzqcNKSuKwQ/fV8TC2WhW+w18Xb/OXoPVw7EE4Kef6p
# URx7WNGpkYXaumqe+Y8cIQ==
# SIG # End signature block
