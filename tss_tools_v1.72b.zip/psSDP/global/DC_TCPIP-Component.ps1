﻿#************************************************
# DC_TCPIP-Component.ps1
# Version 1.0: Collects information from the registry, netsh, arp, ipconfig, etc. 
# Version 1.1: Updated IPv6 Transition Technologies section for SKU checks to clean up exceptions.
# Version 1.2: Altered the runPS function correctly a column width issue.
# Version 1.3: Corrected the code for Get-NetCompartment (only runs in WS2012+)
# Version 1.4.09.10.14: Add additional netsh commands for Teredo and ISATAP. TFS264243
# Date: 2009-2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about TCPIP.
# Called from: Networking Diags
#*******************************************************


Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSTCPIP -Status $ScriptVariable.ID_CTSTCPIPDescription

"[info]:TCPIP-Component:BEGIN" | WriteTo-StdOut


function RunNetSH ([string]$NetSHCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSTCPIP -Status "netsh $NetSHCommandToExecute"
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $outputFile -append
	"netsh $NetSHCommandToExecute"			| Out-File -FilePath $outputFile -append
	"-" * ($NetSHCommandToExecuteLength)	| Out-File -FilePath $outputFile -append
	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $outputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
}


function RunNetCmd ([string]$NetCmd="", [string]$NetCmdArg="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSTCPIP -Status "$NetCmd $NetCmdArg"
	$NetCmdLen = $NetCmd.length
	$NetCmdArgLen = $NetCmdArg.Length
	$NetCmdFullLen = $NetCmdLen + $NetCmdArgLen + 1
	"-" * ($NetCmdFullLen)	| Out-File -FilePath $outputFile -append
	"$NetCmd $NetCmdArg"	| Out-File -FilePath $outputFile -append
	"-" * ($NetCmdFullLen)	| Out-File -FilePath $outputFile -append
	$CommandToExecute = "cmd.exe /c $NetCmd $NetCmdArg >> $outputFile"
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append	
}


function Heading ([string]$header)
{
	"=" * ($borderLen)	| Out-File -FilePath $outputFile -append
	"$header"			| Out-File -FilePath $outputFile -append
	"=" * ($borderLen)	| Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
	"`n" | Out-File -FilePath $outputFile -append
}




$sectionDescription = "TCPIP"
$borderLen = 52

# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber



####################################################
# General Information
####################################################
#-----MAIN TCPIP INFO  (W2003+)

#----------TCPIP Information from Various Tools
$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_info.TXT")
"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
"TCPIP Networking Information"						| Out-File -FilePath $OutputFile -append
"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
"Overview"											| Out-File -FilePath $OutputFile -append
"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
"TCPIP Networking Information"						| Out-File -FilePath $OutputFile -append
"   1. hostname"									| Out-File -FilePath $OutputFile -append
"   2. ipconfig /allcompartments /all"				| Out-File -FilePath $OutputFile -append
"   3. route print"									| Out-File -FilePath $OutputFile -append
"   4. arp -a"										| Out-File -FilePath $OutputFile -append
"   5. netstat -nato" 								| Out-File -FilePath $OutputFile -append
"   6. netstat -anob"								| Out-File -FilePath $OutputFile -append
"   7. netstat -es" 								| Out-File -FilePath $OutputFile -append
"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append

Heading "TCPIP Networking Information"
RunNetCmd "hostname"
# 4/17/14: If WV/WS2008, run "ipconfig /allcompartments /all". If WXP/WS2003 "ipconfig /all".
if ($bn -gt 6000)
{ RunNetCmd "ipconfig" "/allcompartments /all" }
else
{ RunNetCmd "ipconfig" "/all" }
RunNetCmd "route print"
RunNetCmd "arp" "-a"
RunNetCmd "netstat" "-nato"
RunNetCmd "netstat" "-anob"
RunNetCmd "netstat" "-es"
CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP Info" -SectionDescription $sectionDescription

	
	
	
	

#----------Registry (General)
$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_reg_output.TXT")
$CurrentVersionKeys =	"HKLM\SOFTWARE\Policies\Microsoft\Windows\TCPIP",
						"HKLM\SYSTEM\CurrentControlSet\services\TCPIP",
						"HKLM\SYSTEM\CurrentControlSet\Services\Tcpip6",
						"HKLM\SYSTEM\CurrentControlSet\Services\tcpipreg",
						"HKLM\SYSTEM\CurrentControlSet\Services\iphlpsvc"
RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -outputFile $outputFile -fileDescription "TCPIP registry output" -SectionDescription $sectionDescription







#----------TCP OFFLOAD (netsh)
$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_OFFLOAD.TXT")

"=" * ($borderLen)								| Out-File -FilePath $outputFile -append
"TCPIP Offload Information"						| Out-File -FilePath $OutputFile -append
"=" * ($borderLen)								| Out-File -FilePath $outputFile -append
"Overview"										| Out-File -FilePath $OutputFile -append
"-" * ($borderLen)								| Out-File -FilePath $outputFile -append
"TCPIP Offload Information"						| Out-File -FilePath $OutputFile -append
"  1. netsh int tcp show global"				| Out-File -FilePath $outputFile -Append
"  2. netsh int ipv4 show offload"				| Out-File -FilePath $outputFile -Append
"  3. netstat -nato -p tcp"						| Out-File -FilePath $outputFile -Append
"=" * ($borderLen)								| Out-File -FilePath $outputFile -Append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
RunNetCmd "netsh" "int tcp show global"
RunNetCmd "netsh" "int ipv4 show offload"
RunNetCmd "netstat" "-nato -p tcp"

CollectFiles -filesToCollect $outputFile -fileDescription "TCP OFFLOAD" -SectionDescription $sectionDescription




#----------Copy the Services File
$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_ServicesFile.TXT")

$servicesfile = "$ENV:windir\system32\drivers\etc\services"
if (test-path $servicesfile)
{
  Copy-Item -Path $servicesfile -Destination $outputFile
  CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP Services File" -SectionDescription $sectionDescription
}
else
{
	"$servicesfile Does not exist" | writeto-stdout
}







# W8/WS2012
if ($bn -gt 9000)
{
	"[info]: TCPIP-Component W8/WS2012+" | WriteTo-StdOut

	####################################################
	# TCPIP Transition Technologies
	####################################################
	$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_info_pscmdlets_net.TXT")


	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"TCPIP Powershell Cmdlets"							| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"Overview"											| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"   1. Get-NetCompartment (WS2012+)"				| Out-File -FilePath $OutputFile -append
	"   2. Get-NetIPAddress"							| Out-File -FilePath $OutputFile -append	
	"   3. Get-NetIPInterface"							| Out-File -FilePath $OutputFile -append
	"   4. Get-NetIPConfiguration"						| Out-File -FilePath $OutputFile -append
	"   5. Get-NetIPv4Protocol"							| Out-File -FilePath $OutputFile -append
	"   6. Get-NetIPv6Protocol"							| Out-File -FilePath $OutputFile -append
	"   7. Get-NetOffloadGlobalSetting"					| Out-File -FilePath $OutputFile -append
	"   8. Get-NetPrefixPolicy"							| Out-File -FilePath $OutputFile -append
	"   9. Get-NetRoute -IncludeAllCompartments"		| Out-File -FilePath $OutputFile -append
	"  10. Get-NetTCPConnection"						| Out-File -FilePath $OutputFile -append
	"  11. Get-NetTransportFilter"						| Out-File -FilePath $OutputFile -append
	"  12. Get-NetTCPSetting"							| Out-File -FilePath $OutputFile -append
	"  13. Get-NetUDPEndpoint"							| Out-File -FilePath $OutputFile -append
	"  14. Get-NetUDPSetting"							| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append

	if ($bn -ge 9600)
	{
		RunPS "Get-NetCompartment"							# W8/WS2012, W8.1/WS2012R2	# fl
	}
	else
	{
		$RunPScmd = "Get-NetCompartment"
		$RunPScmdLength = $RunPScmd.Length
		"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
		"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
		"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
		"The Get-NetCompartment pscmdlet is only available in WS2012R2+."	| Out-File -FilePath $OutputFile -append
	}
	RunPS "Get-NetIPAddress"							# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetIPInterface"						-ft	# W8/WS2012, W8.1/WS2012R2	# ft
	RunPS "Get-NetIPConfiguration"						# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetIPv4Protocol"							# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetIPv6Protocol"							# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetOffloadGlobalSetting"					# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetPrefixPolicy"						-ft	# W8/WS2012, W8.1/WS2012R2	# ft
	RunPS "Get-NetRoute -IncludeAllCompartments"	-ft	# W8/WS2012, W8.1/WS2012R2	# ft
	RunPS "Get-NetTCPConnection"					-ft	# W8/WS2012, W8.1/WS2012R2	# ft
	RunPS "Get-NetTransportFilter"						# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetTCPSetting"							# W8/WS2012, W8.1/WS2012R2	# fl
	RunPS "Get-NetUDPEndpoint"						-ft	# W8/WS2012, W8.1/WS2012R2	# ft
	RunPS "Get-NetUDPSetting"							# W8/WS2012, W8.1/WS2012R2	# fl

	CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP Net Powershell Cmdlets" -SectionDescription $sectionDescription
}


# W8/WS2012
if ($bn -gt 9000)
{
	####################################################
	# TCPIP IPv6 Transition Technologies
	####################################################
	$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_info_pscmdlets_IPv6Transition.TXT")
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"IPv6 Transition Technologies Powershell Cmdlets"	| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"Overview"											| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"   1. Get-Net6to4Configuration"					| Out-File -FilePath $OutputFile -append
	"   2. Get-NetDnsTransitionConfiguration"			| Out-File -FilePath $OutputFile -append
	"   3. Get-NetDnsTransitionMonitoring"				| Out-File -FilePath $OutputFile -append
	"   4. Get-NetIPHttpsConfiguration"					| Out-File -FilePath $OutputFile -append
	"   5. Get-NetIsatapConfiguration"					| Out-File -FilePath $OutputFile -append
	"   6. Get-NetNatTransitionConfiguration"			| Out-File -FilePath $OutputFile -append
	"   7. Get-NetNatTransitionMonitoring"				| Out-File -FilePath $OutputFile -append
	"   8. Get-NetTeredoConfiguration"					| Out-File -FilePath $OutputFile -append
	"   9. Get-NetTeredoState"							| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append

	#Get role, OSVer, hotfix data.
	$cs =  gwmi -Namespace "root\cimv2" -class win32_computersystem -ComputerName $ComputerName
	$DomainRole = $cs.domainrole
	
	if ($cs.DomainRole -ge 2)	
	{
		RunPS "Get-Net6to4Configuration"				# W8/WS2012, W8.1/WS2012R2	#fl
		RunPS "Get-NetDnsTransitionConfiguration"		# W8/WS2012, W8.1/WS2012R2	#fl		# server only
		RunPS "Get-NetDnsTransitionMonitoring"			# W8/WS2012, W8.1/WS2012R2	#fl 	# server only
	}
	else
	{
		"------------------------" 									| Out-File -FilePath $outputFile -append
		"Get-Net6to4Configuration"	| Out-File -FilePath $OutputFile -append
		"------------------------" 									| Out-File -FilePath $outputFile -append
		"Not running pscmdlet on non-server SKUs." | Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"---------------------------------" | Out-File -FilePath $outputFile -append
		"Get-NetDnsTransitionConfiguration" | Out-File -FilePath $OutputFile -append
		"---------------------------------" | Out-File -FilePath $outputFile -append
		"Not running pscmdlet on non-server SKUs."	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"------------------------------" | Out-File -FilePath $outputFile -append
		"Get-NetDnsTransitionMonitoring" | Out-File -FilePath $OutputFile -append
		"------------------------------" | Out-File -FilePath $outputFile -append
		"Not running pscmdlet on non-server SKUs."	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
	}
	RunPS "Get-NetIPHttpsConfiguration"					# W8/WS2012, W8.1/WS2012R2	#fl
	RunPS "Get-NetIPHttpsState"							# W8/WS2012, W8.1/WS2012R2	#fl
	RunPS "Get-NetIsatapConfiguration"					# W8/WS2012, W8.1/WS2012R2	#fl
	
	if ($cs.DomainRole -ge 2)	
	{
		RunPS "Get-NetNatTransitionConfiguration"		# W8/WS2012, W8.1/WS2012R2	#fl 	#server only
		RunPS "Get-NetNatTransitionMonitoring"		-ft	# W8/WS2012, W8.1/WS2012R2	#ft		#server only
	}
	else
	{
		"---------------------------------" 		| Out-File -FilePath $outputFile -append
		"Get-NetNatTransitionConfiguration"	| Out-File -FilePath $OutputFile -append
		"---------------------------------" 		| Out-File -FilePath $outputFile -append
		"Not running pscmdlet on non-server SKUs." | Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"------------------------------" 		| Out-File -FilePath $outputFile -append
		"Get-NetNatTransitionMonitoring"			| Out-File -FilePath $OutputFile -append
		"------------------------------" 		| Out-File -FilePath $outputFile -append
		"Not running pscmdlet on non-server SKUs."	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
		"`n"	| Out-File -FilePath $OutputFile -append
	}
	RunPS "Get-NetTeredoConfiguration"					# W8/WS2012, W8.1/WS2012R2	#fl
	RunPS "Get-NetTeredoState"							# W8/WS2012, W8.1/WS2012R2	#fl

	CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP IPv6 Transition Technology Info" -SectionDescription $sectionDescription	
}



#V/WS2008+
if ($bn -gt 6000)
{
	"[info]: TCPIP-Component WV/WS2008+" | WriteTo-StdOut
	$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_netsh_info.TXT")

	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"TCPIP Netsh Commands"								| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"Overview"											| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"TCP Netsh Commands"								| Out-File -FilePath $OutputFile -append
	"   1. netsh int tcp show global"					| Out-File -FilePath $OutputFile -append
	"   2. netsh int tcp show heuristics"						| Out-File -FilePath $OutputFile -append
	"   3. netsh int tcp show chimneyapplications"		| Out-File -FilePath $OutputFile -append
	"   4. netsh int tcp show chimneyports"				| Out-File -FilePath $OutputFile -append
	"   5. netsh int tcp show chimneystats"				| Out-File -FilePath $OutputFile -append
	"   6. netsh int tcp show netdmastats"				| Out-File -FilePath $OutputFile -append
	"   7. netsh int tcp show rscstats"					| Out-File -FilePath $OutputFile -append
	"   8. netsh int tcp show security"					| Out-File -FilePath $OutputFile -append
	"   9. netsh int tcp show supplemental"				| Out-File -FilePath $OutputFile -append
	"  10. netsh int tcp show supplementalports"		| Out-File -FilePath $OutputFile -append
	"  11. netsh int tcp show supplementalsubnets"		| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"IPv4 Netsh Commands"								| Out-File -FilePath $OutputFile -append
	"   1. netsh int show int"							| Out-File -FilePath $OutputFile -append
	"   2. netsh int ipv4 show int"						| Out-File -FilePath $OutputFile -append
	"   3. netsh int ipv4 show addresses"				| Out-File -FilePath $OutputFile -append
	"   4. netsh int ipv4 show ipaddresses"				| Out-File -FilePath $OutputFile -append
	"   5. netsh int ipv4 show compartments"			| Out-File -FilePath $OutputFile -append
	"   6. netsh int ipv4 show dnsservers"				| Out-File -FilePath $OutputFile -append
	"   7. netsh int ipv4 show winsservers"				| Out-File -FilePath $OutputFile -append
	"   8. netsh int ipv4 show dynamicportrange tcp"	| Out-File -FilePath $OutputFile -append
	"   9. netsh int ipv4 show dynamicportrange udp"	| Out-File -FilePath $OutputFile -append
	"  10. netsh int ipv4 show global"					| Out-File -FilePath $OutputFile -append
	"  11. netsh int ipv4 show icmpstats"				| Out-File -FilePath $OutputFile -append
	"  12. netsh int ipv4 show ipstats"					| Out-File -FilePath $OutputFile -append
	"  13. netsh int ipv4 show joins"					| Out-File -FilePath $OutputFile -append
	"  14. netsh int ipv4 show offload"					| Out-File -FilePath $OutputFile -append
	"  15. netsh int ipv4 show route"					| Out-File -FilePath $OutputFile -append
	"  16. netsh int ipv4 show subint"					| Out-File -FilePath $OutputFile -append
	"  17. netsh int ipv4 show tcpconnections"			| Out-File -FilePath $OutputFile -append
	"  18. netsh int ipv4 show tcpstats"				| Out-File -FilePath $OutputFile -append
	"  19. netsh int ipv4 show udpconnections"			| Out-File -FilePath $OutputFile -append
	"  20. netsh int ipv4 show udpstats"				| Out-File -FilePath $OutputFile -append
	"  21. netsh int ipv4 show destinationcache"		| Out-File -FilePath $OutputFile -append
	"  22. netsh int ipv4 show ipnettomedia"			| Out-File -FilePath $OutputFile -append
	"  23. netsh int ipv4 show neighbors"				| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"IPv6 Netsh Commands"								| Out-File -FilePath $OutputFile -append
	"   1. netsh int show int"							| Out-File -FilePath $OutputFile -append	
	"   2. netsh int ipv6 show int"						| Out-File -FilePath $OutputFile -append
	"   3. netsh int ipv6 show addresses"				| Out-File -FilePath $OutputFile -append
	"   4. netsh int ipv6 show compartments"			| Out-File -FilePath $OutputFile -append
	"   5. netsh int ipv6 show destinationcache"		| Out-File -FilePath $OutputFile -append
	"   6. netsh int ipv6 show dnsservers"				| Out-File -FilePath $OutputFile -append
	"   7. netsh int ipv6 show dynamicportrange tcp"	| Out-File -FilePath $OutputFile -append
	"   8. netsh int ipv6 show dynamicportrange udp"	| Out-File -FilePath $OutputFile -append
	"   9. netsh int ipv6 show global"					| Out-File -FilePath $OutputFile -append
	"  10. netsh int ipv6 show ipstats"					| Out-File -FilePath $OutputFile -append
	"  11. netsh int ipv6 show joins"					| Out-File -FilePath $OutputFile -append
	"  12. netsh int ipv6 show neighbors"				| Out-File -FilePath $OutputFile -append
	"  13. netsh int ipv6 show offload"					| Out-File -FilePath $OutputFile -append
	"  14. netsh int ipv6 show potentialrouters"		| Out-File -FilePath $OutputFile -append
	"  15. netsh int ipv6 show prefixpolicies"			| Out-File -FilePath $OutputFile -append
	"  16. netsh int ipv6 show privacy"					| Out-File -FilePath $OutputFile -append
	"  17. netsh int ipv6 show route"					| Out-File -FilePath $OutputFile -append
	"  18. netsh int ipv6 show siteprefixes"			| Out-File -FilePath $OutputFile -append
	"  19. netsh int ipv6 show subint"					| Out-File -FilePath $OutputFile -append
	"  20. netsh int ipv6 show tcpstats"				| Out-File -FilePath $OutputFile -append
	"  21. netsh int ipv6 show teredo"					| Out-File -FilePath $OutputFile -append
	"  22. netsh int ipv6 show udpstats"				| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"IPv6 Transition Technologies"						| Out-File -FilePath $OutputFile -append
	"   1. netsh int ipv6 show int"						| Out-File -FilePath $OutputFile -append
	"   2. netsh int 6to4 show int"						| Out-File -FilePath $OutputFile -append
	"   3. netsh int 6to4 show relay"					| Out-File -FilePath $OutputFile -append
	"   4. netsh int 6to4 show routing"					| Out-File -FilePath $OutputFile -append
	"   5. netsh int 6to4 show state"					| Out-File -FilePath $OutputFile -append
	"   6. netsh int httpstunnel show interfaces"		| Out-File -FilePath $OutputFile -append
	"   7. netsh int httpstunnel show statistics"		| Out-File -FilePath $OutputFile -append
	"   8. netsh int isatap show router"				| Out-File -FilePath $OutputFile -append
	"   9. netsh int isatap show state"					| Out-File -FilePath $OutputFile -append
	"  10. netsh int teredo show state"					| Out-File -FilePath $OutputFile -append
	"  11. netsh int ipv6 show int level=verbose"		| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"NetIO Netsh Commands"								| Out-File -FilePath $OutputFile -append
	"   1. netio show bindingfilters"					| Out-File -FilePath $OutputFile -append
	"-" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"PortProxy"	| Out-File -FilePath $OutputFile -append
	"   1. netsh int portproxy show all"	| Out-File -FilePath $OutputFile -append
	"=" * ($borderLen)									| Out-File -FilePath $outputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	

	Heading "TCP Netsh Commands"
	RunNetCmd "netsh" "int tcp show global"
	RunNetCmd "netsh" "int tcp show heuristics"
	RunNetCmd "netsh" "int tcp show chimneyapplications"
	RunNetCmd "netsh" "int tcp show chimneyports"
	RunNetCmd "netsh" "int tcp show chimneystats"
	RunNetCmd "netsh" "int tcp show netdmastats"
	RunNetCmd "netsh" "int tcp show rscstats"
	RunNetCmd "netsh" "int tcp show security"
	RunNetCmd "netsh" "int tcp show supplemental"
	RunNetCmd "netsh" "int tcp show supplementalports"
	RunNetCmd "netsh" "int tcp show supplementalsubnets"

	Heading "IPv4 Netsh Commands"
	RunNetCmd "netsh" "int show int"
	RunNetCmd "netsh" "int ipv4 show int"
	RunNetCmd "netsh" "int ipv4 show addresses"
	RunNetCmd "netsh" "int ipv4 show ipaddresses"
	RunNetCmd "netsh" "int ipv4 show compartments"
	RunNetCmd "netsh" "int ipv4 show dnsservers"
	RunNetCmd "netsh" "int ipv4 show winsservers"
	RunNetCmd "netsh" "int ipv4 show dynamicportrange tcp"
	RunNetCmd "netsh" "int ipv4 show dynamicportrange udp"
	RunNetCmd "netsh" "int ipv4 show global"
	RunNetCmd "netsh" "int ipv4 show icmpstats"
	RunNetCmd "netsh" "int ipv4 show ipstats"
	RunNetCmd "netsh" "int ipv4 show joins"
	RunNetCmd "netsh" "int ipv4 show offload"
	RunNetCmd "netsh" "int ipv4 show route"
	RunNetCmd "netsh" "int ipv4 show subint"
	RunNetCmd "netsh" "int ipv4 show tcpconnections"
	RunNetCmd "netsh" "int ipv4 show tcpstats"
	RunNetCmd "netsh" "int ipv4 show udpconnections"
	RunNetCmd "netsh" "int ipv4 show udpstats"
	RunNetCmd "netsh" "int ipv4 show destinationcache"
	RunNetCmd "netsh" "int ipv4 show ipnettomedia"
	RunNetCmd "netsh" "int ipv4 show neighbors"

	Heading "IPv6 Netsh Commands"
	RunNetCmd "netsh" "int show int"
	RunNetCmd "netsh" "int ipv6 show int"
	RunNetCmd "netsh" "int ipv6 show addresses"
	RunNetCmd "netsh" "int ipv6 show compartments"
	RunNetCmd "netsh" "int ipv6 show destinationcache"
	RunNetCmd "netsh" "int ipv6 show dnsservers"
	RunNetCmd "netsh" "int ipv6 show dynamicportrange tcp"
	RunNetCmd "netsh" "int ipv6 show dynamicportrange udp"
	RunNetCmd "netsh" "int ipv6 show global"
	RunNetCmd "netsh" "int ipv6 show ipstats"
	RunNetCmd "netsh" "int ipv6 show joins"
	RunNetCmd "netsh" "int ipv6 show neighbors"
	RunNetCmd "netsh" "int ipv6 show offload"
	RunNetCmd "netsh" "int ipv6 show potentialrouters"
	RunNetCmd "netsh" "int ipv6 show prefixpolicies"
	RunNetCmd "netsh" "int ipv6 show privacy"
	RunNetCmd "netsh" "int ipv6 show route"
	RunNetCmd "netsh" "int ipv6 show siteprefixes"
	RunNetCmd "netsh" "int ipv6 show siteprefixes"
	RunNetCmd "netsh" "int ipv6 show subint"
	RunNetCmd "netsh" "int ipv6 show tcpstats"
	RunNetCmd "netsh" "int ipv6 show teredo"
	RunNetCmd "netsh" "int ipv6 show udpstats"
	
	Heading "IPv6 Transition Technologies"
	RunNetCmd "netsh" "int ipv6 show int"
	RunNetCmd "netsh" "int 6to4 show int"
	RunNetCmd "netsh" "int 6to4 show relay"
	RunNetCmd "netsh" "int 6to4 show routing"
	RunNetCmd "netsh" "int 6to4 show state"
	RunNetCmd "netsh" "int httpstunnel show interfaces"
	RunNetCmd "netsh" "int httpstunnel show statistics"
	RunNetCmd "netsh int isatap show router"
	RunNetCmd "netsh int isatap show state"	
	RunNetCmd "netsh int teredo show state"	
	RunNetCmd "netsh" "int ipv6 show int level=verbose"

	Heading "NetIO Netsh Commands"
	RunNetCmd "netsh" "netio show bindingfilters"

	Heading "PortProxy"
	RunNetCmd "netsh" "int portproxy show all"
	
	CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP netsh output" -SectionDescription $sectionDescription

	#----------Iphlpsvc EventLog
	#----------WLAN Autoconfig EventLog
	#Iphlpsvc
	$EventLogNames = @()
	$EventLogNames += "Microsoft-Windows-Iphlpsvc/Operational"
	$EventLogNames += "Microsoft-Windows-WLAN-AutoConfig/Operational"

	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix

}
else # XP/WS2003
{
	"[info]: TCPIP-Component XP/WS2003+" | WriteTo-StdOut
	$outputFile = join-path $pwd.path ($ComputerName + "_TCPIP_netsh_info.TXT")
	
	#----------Netsh for IP (XP/W2003)
	"`n`n`n`n`n" + "=" * (50) + "`r`n[NETSH INT IP]`r`n" + "=" * (50) | Out-File -FilePath $outputFile -Append
	"`n`n"
	"`n" + "-" * (50) + "`r`n[netsh int ipv4 show output]`r`n" + "-" * (50) | Out-File -FilePath $outputFile -Append
	RunNetCmd "netsh" "int show int"
	RunNetCmd "netsh" "int ip show int"
	RunNetCmd "netsh" "int ip show address"
	RunNetCmd "netsh" "int ip show config"
	RunNetCmd "netsh" "int ip show dns"
	RunNetCmd "netsh" "int ip show joins"
	RunNetCmd "netsh" "int ip show offload"
	RunNetCmd "netsh" "int ip show wins"

	# If RRAS is running, run the following commands
	if ((Get-Service "remoteaccess").Status -eq 'Running')
	{
		RunNetCmd "netsh" "int ip show icmp"
		RunNetCmd "netsh" "int ip show interface"
		RunNetCmd "netsh" "int ip show ipaddress"
		RunNetCmd "netsh" "int ip show ipnet"
		RunNetCmd "netsh" "int ip show ipstats"
		RunNetCmd "netsh" "int ip show tcpconn"
		RunNetCmd "netsh" "int ip show tcpstats"
		RunNetCmd "netsh" "int ip show udpconn"
		RunNetCmd "netsh" "int ip show udpstats"
	}
	CollectFiles -filesToCollect $outputFile -fileDescription "TCPIP netsh output" -SectionDescription $sectionDescription
}

"[info]:TCPIP-Component:END" | WriteTo-StdOut



# SIG # Begin signature block
# MIIdvgYJKoZIhvcNAQcCoIIdrzCCHasCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUAdI4chw8P7v02BOPfUCuZy6i
# JhagghhkMIIEwzCCA6ugAwIBAgITMwAAAJvgdDfLPU2NLgAAAAAAmzANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwMzMwMTkyMTI5
# WhcNMTcwNjMwMTkyMTI5WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OjcyOEQtQzQ1Ri1GOUVCMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjaPiz4GL18u/
# A6Jg9jtt4tQYsDcF1Y02nA5zzk1/ohCyfEN7LBhXvKynpoZ9eaG13jJm+Y78IM2r
# c3fPd51vYJxrePPFram9W0wrVapSgEFDQWaZpfAwaIa6DyFyH8N1P5J2wQDXmSyo
# WT/BYpFtCfbO0yK6LQCfZstT0cpWOlhMIbKFo5hljMeJSkVYe6tTQJ+MarIFxf4e
# 4v8Koaii28shjXyVMN4xF4oN6V/MQnDKpBUUboQPwsL9bAJMk7FMts627OK1zZoa
# EPVI5VcQd+qB3V+EQjJwRMnKvLD790g52GB1Sa2zv2h0LpQOHL7BcHJ0EA7M22tQ
# HzHqNPpsPQIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFJaVsZ4TU7pYIUY04nzHOUps
# IPB3MB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBACEds1PpO0aBofoqE+NaICS6dqU7tnfIkXIE1ur+0psiL5MI
# orBu7wKluVZe/WX2jRJ96ifeP6C4LjMy15ZaP8N0OckPqba62v4QaM+I/Y8g3rKx
# 1l0okye3wgekRyVlu1LVcU0paegLUMeMlZagXqw3OQLVXvNUKHlx2xfDQ/zNaiv5
# DzlARHwsaMjSgeiZIqsgVubk7ySGm2ZWTjvi7rhk9+WfynUK7nyWn1nhrKC31mm9
# QibS9aWHUgHsKX77BbTm2Jd8E4BxNV+TJufkX3SVcXwDjbUfdfWitmE97sRsiV5k
# BH8pS2zUSOpKSkzngm61Or9XJhHIeIDVgM0Ou2QwggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TCCBhAwggP4
# oAMCAQICEzMAAABkR4SUhttBGTgAAAAAAGQwDQYJKoZIhvcNAQELBQAwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMTAeFw0xNTEwMjgyMDMxNDZaFw0xNzAx
# MjgyMDMxNDZaMIGDMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24w
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCTLtrY5j6Y2RsPZF9NqFhN
# FDv3eoT8PBExOu+JwkotQaVIXd0Snu+rZig01X0qVXtMTYrywPGy01IVi7azCLiL
# UAvdf/tqCaDcZwTE8d+8dRggQL54LJlW3e71Lt0+QvlaHzCuARSKsIK1UaDibWX+
# 9xgKjTBtTTqnxfM2Le5fLKCSALEcTOLL9/8kJX/Xj8Ddl27Oshe2xxxEpyTKfoHm
# 5jG5FtldPtFo7r7NSNCGLK7cDiHBwIrD7huTWRP2xjuAchiIU/urvzA+oHe9Uoi/
# etjosJOtoRuM1H6mEFAQvuHIHGT6hy77xEdmFsCEezavX7qFRGwCDy3gsA4boj4l
# AgMBAAGjggF/MIIBezAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wIATAd
# BgNVHQ4EFgQUWFZxBPC9uzP1g2jM54BG91ev0iIwUQYDVR0RBEowSKRGMEQxDTAL
# BgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNjQyKzQ5ZThjM2YzLTIzNTktNDdmNi1h
# M2JlLTZjOGM0NzUxYzRiNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUC
# lTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# b3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUF
# BwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1Ud
# EwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjiDGRDHd1crow7hSS1nUDWvWas
# W1c12fToOsBFmRBN27SQ5Mt2UYEJ8LOTTfT1EuS9SCcUqm8t12uD1ManefzTJRtG
# ynYCiDKuUFT6A/mCAcWLs2MYSmPlsf4UOwzD0/KAuDwl6WCy8FW53DVKBS3rbmdj
# vDW+vCT5wN3nxO8DIlAUBbXMn7TJKAH2W7a/CDQ0p607Ivt3F7cqhEtrO1Rypehh
# bkKQj4y/ebwc56qWHJ8VNjE8HlhfJAk8pAliHzML1v3QlctPutozuZD3jKAO4WaV
# qJn5BJRHddW6l0SeCuZmBQHmNfXcz4+XZW/s88VTfGWjdSGPXC26k0LzV6mjEaEn
# S1G4t0RqMP90JnTEieJ6xFcIpILgcIvcEydLBVe0iiP9AXKYVjAPn6wBm69FKCQr
# IPWsMDsw9wQjaL8GHk4wCj0CmnixHQanTj2hKRc2G9GL9q7tAbo0kFNIFs0EYkbx
# Cn7lBOEqhBSTyaPS6CvjJZGwD0lNuapXDu72y4Hk4pgExQ3iEv/Ij5oVWwT8okie
# +fFLNcnVgeRrjkANgwoAyX58t0iqbefHqsg3RGSgMBu9MABcZ6FQKwih3Tj0DVPc
# gnJQle3c6xN3dZpuEgFcgJh/EyDXSdppZzJR4+Bbf5XA/Rcsq7g7X7xl4bJoNKLf
# cafOabJhpxfcFOowMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEw
# HhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBT
# aWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# q/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2Avw
# OMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eW
# WcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1
# eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le
# 2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+
# 0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2
# zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv
# 1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLn
# JN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31n
# gOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+Hgg
# WCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAG
# CSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZ
# BgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/
# BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8E
# UzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEB
# BFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcw
# gZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwIC
# MDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBu
# AHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOS
# mUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQ
# VdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQ
# dION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive
# /DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrC
# xq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/
# E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ
# 7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANah
# Rr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3
# S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1W
# Tk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1t
# bWrJUnMTDXpQzTGCBMQwggTAAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcg
# UENBIDIwMTECEzMAAABkR4SUhttBGTgAAAAAAGQwCQYFKw4DAhoFAKCB2DAZBgkq
# hkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGC
# NwIBFTAjBgkqhkiG9w0BCQQxFgQU/AM2lbvwWaNN6aYenGAeqFFDhzwweAYKKwYB
# BAGCNwIBDDFqMGigToBMAEMAVABTAHcAaQBuAGQAbwB3AHMAcwBlAHQAdQBwAF8A
# RABDAF8AVABDAFAASQBQAC0AQwBvAG0AcABvAG4AZQBuAHQALgBwAHMAMaEWgBRo
# dHRwOi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQAqeX9h3KbgIipB
# jABFpSxGayPet15MuxmKIju78LJGBkKh/pWiO2u/Mw1X1fvP4xNmdv58+lbL5hqq
# X79WM2IoHZFuwoxIVbLWqL6zYFSVw0LrKJ+Y/3pV0LI+ZS+b/EhgMk7DCO32Ua33
# wQ6j4pqJRbQt33F7gE6aw9+No6o6NbyfNEgh2kdlsgB8yEhelV76zKxSEt7qK9d8
# 2m+6tpReUj5EsqXkidI5+zTvfBdUHQ5jo1hTB+CBPPgxbkNJtUqp4lsfBdg24xTC
# xxHBlqvMJO2o4K5D0QE5IaPP09VGWZzND4T2ryJQ6VyqVcIkiD0P2W8ndt8eoDyT
# HPEzrfuGoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQQITMwAAAJvgdDfLPU2NLgAAAAAAmzAJBgUrDgMCGgUA
# oF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTYw
# NzI4MjAwODAzWjAjBgkqhkiG9w0BCQQxFgQUtYBaobeiXhFodyYMisgo26ERdlMw
# DQYJKoZIhvcNAQEFBQAEggEAAXsrg40VtwyxksGDYtXP1Dn2dLrrnzfZBBtChS/D
# xYqad8zpboeKIfMalC7UAtu+sZw2qEof2Pph4a9MCi+p17+QscYmWQ5jLHLffEI/
# t9wAgIDkKGCMz8MNuU1eAqpm6GCLcOISiOzZqQbkkGYL+63ahqHTCCBTdoxSUoG8
# gPeO9G5nRbDmbK+N/yrD9CwSMgiXBmqCBzEu08Twf4PsxITUDuSKS0I4C6m6jzh1
# folb963h7kifPwtt9u8GHy5ykjIIEwK4yiNVtIUlnRNHMssQuT87McJA0rryLAfc
# iR8+1WC1wN2CUAUtH8SY8UBaA2f+MmR8FS/ODIvuqcD2xQ==
# SIG # End signature block
