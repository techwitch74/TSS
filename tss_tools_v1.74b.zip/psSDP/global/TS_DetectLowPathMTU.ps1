﻿#************************************************
# TS_DetectLowIpv4Mtu.ps1
# Version 1.0
# Date: 02/06/2014
# Author: BBenson
# Description:  
# Rule number:  262755
# Rule ID:  d2aaab92-c906-4b3e-a4e5-67244c49c422
# Rule URL:  https://kse.microsoft.com/Contribute/Idea/de6654f5-8b05-4f97-b67b-f9ad51bc78ab
# Purpose:
#  1. Determine which network adapters are of type Ethernet with "netsh int ipv4 show int"
#  2. RootCause detected if any Ethernet adapter has a PMTU less than 1500 in the output of "netsh int ipv4 show destinationcache"
#************************************************

Import-LocalizedData -BindingVariable ScriptStrings
Write-DiagProgress -Activity $ScriptStrings.ID_DetectLowPathMTU_Activity -Status $ScriptStrings.ID_DetectLowPathMTU_Status


#WV/WS2008+
if ($OSVersion.Build -gt 6000)
{

	$RootCauseDetected = $false
	$RootCauseName = "RC_DetectLowPathMTU"
	$InformationCollected = new-object PSObject


	# ***************************
	# Data Gathering
	# ***************************


	#-----ipv4
	$OutputFileIPv4 = "DetectLowPathMTU_netsh-int-ipv4-show-int.TXT"
	$NetSHCommandToExecute = "int ipv4 show int"
	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFileIPv4 "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false

	$netshIPv4MTUSettings = Get-Content $OutputFileIPv4
	[int]$netshIPv4MTUSettingsLen = $netshIPv4MTUSettings.length


	#==========
	# New section for detecting Ethernet adapters
	#==========
	$NetworkAdapterWMIQuery = "select * from win32_networkadapter"
	$NetworkAdapterWMI = get-wmiobject -query $NetworkAdapterWMIQuery
	$NetworkAdapterWMILen = $NetworkAdapterWMI.length
	# Creating NetAdapter psobject
		$NetAdapterObj = New-Object psobject
	$EtherAdapterNum = 0

	#==========
	# Read entire output file with contents from "netsh int ipv4 show int" into a PSObject.
	#==========

	# Creating IPv4MtuObj psobject
		$ipObj = New-Object psobject
		
	# find the line after the line of dashes
	for ($i=0;$i -le $netshIPv4MTUSettingsLen;$i++)
	{
		#lines of interest after line that starts with dashes
		$line = $null
		$line = $netshIPv4MTUSettings[$i]
		# Handling the first few lines by finding the line that starts with dashes
		if ($line -match "---")
		{
			$dashline = $i
			$i++	#increment past the line of dashes

			# all lines interesting after dash line
			for ($j=1;$j -le $netshIPv4MTUSettingsLen;$j++)
			{
				#first line of interest
				$line = $null
				$line = $netshIPv4MTUSettings[$i]
				
				if ($line -eq "")
				{
					break
				}
				
				$delimiter = " "
				$arrLine = [Regex]::Split($line, $delimiter)
				$arrLineLen = $arrLine.length			
				
				$Idx = ""
				$Met = ""
				$MTU = ""
				$State = ""
				$Name = ""
				$headerCounter = 0
				for ($k=0;$k -le $arrLineLen;$k++)
				{
					
					#if non zero value, increment counter and proceed
					if ($arrLine[$k] -ne "")
					{
						#if headerCounter has been incremented, assign it to a variable.
						if ($headerCounter -eq 0)	{ $Idx   = $arrLine[$k] }
						if ($headerCounter -eq 1)	{ $Met   = $arrLine[$k] }
						if ($headerCounter -eq 2)	{ $MTU   = $arrLine[$k] }
						if ($headerCounter -eq 3)	{ $State = $arrLine[$k] }
						if ($headerCounter -eq 4)
						{
							$Name  = $arrLine[$k]
							do
							{
								$k++
								$Name  = $Name + " " + $arrLine[$k]
							} while($k -le $arrLineLen)
						}
						$headerCounter++
					}
				}	
				# define object
					$psobj = New-Object psobject @{
					"Idx" = $Idx
					"Met" = $Met
					"MTU" = $MTU
					"State" = $State
					"Name" = $Name
					}
				
				#create object				
					New-Variable -Name ('Int' + $Idx) -Value $psobj -Force

				#add member
					Add-Member -InputObject $ipObj -MemberType NoteProperty -Name "Int$Idx" -Value (get-variable -name Int$Idx).value -Force

				#increment counter
				$i++
			}
		}

		#-----finding each interface in ipObj
		$ipObjFile = "ipObj.TXT"
		$ipObj | fl | Out-File $ipObjFile

		$ipObjTxt = Get-Content $ipObjFile
		[int]$ipObjTxtLen = $ipObjTxt.length
		# "number of interfaces: " + $ipObjTxtLen

		# loop through the lines of output, finding each interface number

		for ($i=1;$i -le $ipObjTxtLen-1;$i++)
		{
			#==========
			# Find Ethernet adapters with a LinkMTU of 1514
			#==========
			$netshIPv4PMTU = $null
			if ($ipObjTxt[$i] -ne "")
			{
				$line = $ipObjTxt[$i] 
				$delimiter = ":"
				$arrLine = [Regex]::Split($line, $delimiter)
				[string]$intID = ([string]$arrLine[0]).TrimEnd()
				[string]$intName = ($ipObj.$intID.name).TrimEnd()
			}
		}
	}


	#-----finding each interface in ipObj
	$ipObjFile = "ipObj.TXT"
	$ipObj | fl | Out-File $ipObjFile

	$ipObjTxt = Get-Content $ipObjFile
	[int]$ipObjTxtLen = $ipObjTxt.length
	# "number of interfaces: " + $ipObjTxtLen

	# loop through the lines of output, finding each interface number

	for ($i=1;$i -le $ipObjTxtLen-1;$i++)
	{
		#==========
		# Find adapters from "netsh int ipv4 show int"
		#==========
		$netshIPv4PMTU = $null
		if ($ipObjTxt[$i] -ne "")
		{
			$line = $ipObjTxt[$i] 
			$delimiter = ":"
			$arrLine = [Regex]::Split($line, $delimiter)
			#"arrLine0: " + [string]$arrLine[0]
			[string]$intID = ([string]$arrLine[0]).TrimEnd()
			[string]$intName = ($ipObj.$intID.name).TrimEnd()


		#==========
		# Find Ethernet adapters that have less than 1500 bytes
		#==========
		
		
			#==========
			# Create output file with contents from "netsh int ipv4 show destinationcache IdxNumber".
			#==========
			[int]$IdxNumber = $ipObj.$intID.Idx
			$OutputFileIPv4PMTU = "TCPIP_netsh-int-ipv4-show-destinationcache-$IdxNumber.TXT"
			#"filename: " + $OutputFileIPv4PMTU

			$NetSHCommandToExecute = "int ipv4 show destinationcache " + $IdxNumber
			$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFileIPv4PMTU "
			RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
			# "[info] Created the output for Interface$IdxNumber" | WriteTo-Stdout

			

			#==========
			# Read entire output file with contents from "netsh int ipv4 show destinationcache IdxNumber" into a PSObject.
			#==========
			$netshIPv4PMTU = Get-Content $OutputFileIPv4PMTU
			[int]$netshIPv4PMTULen = $netshIPv4PMTU.length		

		
			#==========
			# Create output file with contents from "netsh int ipv4 show destinationcache IdxNumber".
			#   	MTU reference: $ipObj.$intID.idx
			#		WMI reference: $NetworkAdapterWMI[$i].InterfaceIndex
			#		For each Ethernet adapter, detect any PMTU values below 1500.
			#==========
			
			for ($wmiAdapterCount=0;$wmiAdapterCount -le $NetworkAdapterWMILen;$wmiAdapterCount++)
			{
				if ( ($NetworkAdapterWMI[$wmiAdapterCount].AdapterType -eq "Ethernet 802.3") -and (($ipObj.$intID.idx -eq $NetworkAdapterWMI[$wmiAdapterCount].InterfaceIndex)) )
				{
					#"==========WMI output==========" 
					#$NetworkAdapterWMI[$wmiAdapterCount]
					$NetAdapterWMIID = $NetworkAdapterWMI[$wmiAdapterCount].DeviceID #Index
					# "AdapterType= Ethernet 802.3 with InterfaceIndex of  :" + $NetworkAdapterWMI[$wmiAdapterCount].InterfaceIndex
					# "                                   with Index of   :" + $NetworkAdapterWMI[$wmiAdapterCount].Index
					# "                                 with DeviceID of  :" + $NetAdapterWMIID
					
					#create array here that contains the Ethernet adapters.
					$EtherAdapterNum = $EtherAdapterNum + 1
					#"Number of Ethernet Adapters: " + $EtherAdapterNum
					Add-Member -InputObject $NetAdapterObj -MemberType NoteProperty -Name "$NetAdapterWMIID" -Value ($NetAdapterWMIID)



					
					#==========
					# Parse the output file to determine if there are any PMTU values below 1500.
					#==========
					
					# Creating IPv4MtuObj psobject
					$pmtuObj = New-Object psobject
					
					#"==========Check IPv4 DestinationCache for PMTU < 1500=========="
					#"lines in destinationcache file: " + $netshIPv4PMTULen
					
					# find the line after the line of dashes
					for ($j=0;$j -le $netshIPv4PMTULen;$j++)
					{
						#lines of interest after line that starts with dashes
						$line = $null
						$line = $netshIPv4PMTU[$j]
						# Handling the first few lines by finding the line that starts with dashes
						if ($line -match "---")
						{
							$dashline = $j
							$j++	#increment past the line of dashes

							# all lines interesting after dash line
							for ($l=1;$l -le $netshIPv4PMTULen;$l++)
							{
								#first line of interest
								$line = $null
								$line = $netshIPv4PMTU[$j]
								
								if ($line -eq "")
								{
									break
								}
								
								$delimiter = " "
								$arrLine = [Regex]::Split($line, $delimiter)	

								$PMTU = ""
								$DestAddress = ""
								$NextHop = ""
								$headerCounter = 0
								for ($k=0;$k -le $arrLineLen;$k++)
								{
									#if non zero value, increment counter and proceed
									if ($arrLine[$k] -ne "")
									{
										#if headerCounter has been incremented, assign it to a variable.
										if ($headerCounter -eq 0)	{ $PMTU = $arrLine[$k] }
										if ($headerCounter -eq 1)	{ $DestAddress = $arrLine[$k] }
										if ($headerCounter -eq 2)	{ $NextHop = $arrLine[$k] }
										if ($headerCounter -eq 3)	{ $What = $arrLine[$k] }
										$headerCounter++
									}
								}
							
								# define object
								$psobj = New-Object psobject @{
								"PMTU" = $PMTU
								"DestAddress" = $DestAddress
								"NextHop" = $NextHop
								}
								
								#create variable				
									New-Variable -Name ('PMTU' + $PMTU) -Value $psobj -Force

								#add member
									Add-Member -InputObject $pmtuObj -MemberType NoteProperty -Name "Int$Idx" -Value (get-variable -name PMTU$PMTU).value -Force
								
								if ($PMTU -lt 1500)
								{
									# Problem detected.
									$RootCauseDetected = $true
									[int]$currentInterface = $ipObj.$intID.idx
									add-member -inputobject $InformationCollected  -membertype noteproperty -name "Interface $currentInterface" -value "Low Path MTU detected for connections on this adapter"

									"[info] Root Cause Detected: Low PMTU" | WriteTo-Stdout					
									<#
									"   Interface  :  " + $NetworkAdapterWMI[$wmiAdapterCount].InterfaceIndex
									"   PMTU <1500 :  " + $PMTU
									"   DestAddress: " + $DestAddress
									# "   NextHop    : " + $NextHop
									#>
								}
								
								#increment counter
								$j++					
							}
						}	
					}				
				}
			}
		}
	}



	# **************
	# Detection Logic
	# **************

	#Check to see if rule is applicable to this computer
	if ($RootCauseDetected -eq $true)
	{
		Write-GenericMessage -RootCauseId $RootCauseName -PublicContentURL "http://support.microsoft.com/kb/314496" -InformationCollected $InformationCollected -Verbosity "Error" -Visibility 4 -SupportTopicsID 8041 -Component "Networking"  	
	}



	# *********************
	# Root Cause processing
	# *********************

	if ($RootCauseDetected)
		{
		 # Red/ Yellow Light
		 Update-DiagRootCause -id $RootCauseName -Detected $true
		}
		else
		{
		 # Green Light
		 Update-DiagRootCause -id $RootCauseName -Detected $false
		}

}

# SIG # Begin signature block
# MIIa3gYJKoZIhvcNAQcCoIIazzCCGssCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUlczJseiNNT74v6zIlueSgN/7
# aDygghV6MIIEuzCCA6OgAwIBAgITMwAAAFrtL/TkIJk/OgAAAAAAWjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTQwNTIzMTcxMzE1
# WhcNMTUwODIzMTcxMzE1WjCBqzELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# DTALBgNVBAsTBE1PUFIxJzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjpCOEVDLTMw
# QTQtNzE0NDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALMhIt9q0L/7KcnVbHqJqY0T
# vJS16X0pZdp/9B+rDHlhZlRhlgfw1GBLMZsJr30obdCle4dfdqHSxinHljqjXxeM
# duC3lgcPx2JhtLaq9kYUKQMuJrAdSgjgfdNcMBKmm/a5Dj1TFmmdu2UnQsHoMjUO
# 9yn/3lsgTLsvaIQkD6uRxPPOKl5YRu2pRbRptlQmkRJi/W8O5M/53D/aKWkfSq7u
# wIJC64Jz6VFTEb/dqx1vsgpQeAuD7xsIsxtnb9MFfaEJn8J3iKCjWMFP/2fz3uzH
# 9TPcikUOlkYUKIccYLf1qlpATHC1acBGyNTo4sWQ3gtlNdRUgNLpnSBWr9TfzbkC
# AwEAAaOCAQkwggEFMB0GA1UdDgQWBBS+Z+AuAhuvCnINOh1/jJ1rImYR9zAfBgNV
# HSMEGDAWgBQjNPjZUkZwCu1A+3b7syuwwzWzDzBUBgNVHR8ETTBLMEmgR6BFhkNo
# dHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNyb3Nv
# ZnRUaW1lU3RhbXBQQ0EuY3JsMFgGCCsGAQUFBwEBBEwwSjBIBggrBgEFBQcwAoY8
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNyb3NvZnRUaW1l
# U3RhbXBQQ0EuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBBQUA
# A4IBAQAgU4KQrqZNTn4zScizrcTDfhXQEvIPJ4p/W78+VOpB6VQDKym63VSIu7n3
# 2c5T7RAWPclGcLQA0fI0XaejIiyqIuFrob8PDYfQHgIb73i2iSDQLKsLdDguphD/
# 2pGrLEA8JhWqrN7Cz0qTA81r4qSymRpdR0Tx3IIf5ki0pmmZwS7phyPqCNJp5mLf
# cfHrI78hZfmkV8STLdsWeBWqPqLkhfwXvsBPFduq8Ki6ESus+is1Fm5bc/4w0Pur
# k6DezULaNj+R9+A3jNkHrTsnu/9UIHfG/RHpGuZpsjMnqwWuWI+mqX9dEhFoDCyj
# MRYNviGrnPCuGnxA1daDFhXYKPvlMIIE7DCCA9SgAwIBAgITMwAAAMps1TISNcTh
# VQABAAAAyjANBgkqhkiG9w0BAQUFADB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTAeFw0xNDA0MjIxNzM5MDBaFw0xNTA3MjIxNzM5MDBaMIGDMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQD
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCWcV3tBkb6hMudW7dGx7DhtBE5A62xFXNgnOuntm4aPD//ZeM08aal
# IV5WmWxY5JKhClzC09xSLwxlmiBhQFMxnGyPIX26+f4TUFJglTpbuVildGFBqZTg
# rSZOTKGXcEknXnxnyk8ecYRGvB1LtuIPxcYnyQfmegqlFwAZTHBFOC2BtFCqxWfR
# +nm8xcyhcpv0JTSY+FTfEjk4Ei+ka6Wafsdi0dzP7T00+LnfNTC67HkyqeGprFVN
# TH9MVsMTC3bxB/nMR6z7iNVSpR4o+j0tz8+EmIZxZRHPhckJRIbhb+ex/KxARKWp
# iyM/gkmd1ZZZUBNZGHP/QwytK9R/MEBnAgMBAAGjggFgMIIBXDATBgNVHSUEDDAK
# BggrBgEFBQcDAzAdBgNVHQ4EFgQUH17iXVCNVoa+SjzPBOinh7XLv4MwUQYDVR0R
# BEowSKRGMEQxDTALBgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNTk1K2I0MjE4ZjEz
# LTZmY2EtNDkwZi05YzQ3LTNmYzU1N2RmYzQ0MDAfBgNVHSMEGDAWgBTLEejK0rQW
# WAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0FfMDgtMzEtMjAx
# MC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0zMS0yMDEwLmNy
# dDANBgkqhkiG9w0BAQUFAAOCAQEAd1zr15E9zb17g9mFqbBDnXN8F8kP7Tbbx7Us
# G177VAU6g3FAgQmit3EmXtZ9tmw7yapfXQMYKh0nfgfpxWUftc8Nt1THKDhaiOd7
# wRm2VjK64szLk9uvbg9dRPXUsO8b1U7Brw7vIJvy4f4nXejF/2H2GdIoCiKd381w
# gp4YctgjzHosQ+7/6sDg5h2qnpczAFJvB7jTiGzepAY1p8JThmURdwmPNVm52Iao
# AP74MX0s9IwFncDB1XdybOlNWSaD8cKyiFeTNQB8UCu8Wfz+HCk4gtPeUpdFKRhO
# lludul8bo/EnUOoHlehtNA04V9w3KDWVOjic1O1qhV0OIhFeezCCBbwwggOkoAMC
# AQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmSJomT8ixkARkW
# A2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9z
# b2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgzMTIyMTkzMloX
# DTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAgQpl2U2w+G9Zv
# zMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn08GisTUuNpb15
# S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqelcnNW8ReU5P01
# lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQwWfjSjWL9y8lf
# RjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vXT2Pn0i1i8UU9
# 56wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJXwPTAgMBAAGj
# ggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK0rQWWAHJNy4z
# Fha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEE
# AYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGCNxQCBAweCgBT
# AHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ5KQwUAYDVR0f
# BEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEBBEgwRjBEBggr
# BgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNy
# b3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5Pn8mRq/rb0Cx
# MrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9MuqKoVpzjcLu4
# tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOlVuC4iktX8pVC
# nPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7IG9KPcpUqcW2b
# Gvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/TartSCMm78pJUT
# 5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhcyTUWX92THUmO
# Lb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zKwexwo1eSV32U
# jaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K3RDeZPRvzkbU
# 0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO7bN2edgKNAlt
# HIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdibIa4NXJzwoq6G
# aIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HOiMm4GPoOco3B
# oz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZoNAAAAAAAHDAN
# BgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkwFwYKCZImiZPy
# LGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAzMTMwMzA5WjB3
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQDExhN
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7Rp9FMrXQwIBHr
# B9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y9GccLPx754gd
# 6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYuJ6yGT1VSDOQD
# LPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdmEScpZqiX5NMG
# gUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68eeEExd8yb3zuD
# k6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAPBgNVHRMBAf8E
# BTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzALBgNVHQ8EBAMC
# AYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyCYEBWJ5flJRP8
# KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAXBgoJkiaJk/Is
# ZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8ESTBHMEWgQ6BB
# hj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9taWNy
# b3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsGAQUFBzAChjho
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jvc29mdFJvb3RD
# ZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQUFAAOCAgEA
# EJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxtYrhXAstOIBNQ
# md16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1Pq5Lk541q1YDB
# 5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxnLcVRDupiXD8W
# mIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/xTUrXqO/67x9
# C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW6J1wlGysOUzU
# 9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146SodDW4TsVxIxIm
# dgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD6Svpu/RIzCzU
# 2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9iaF2YbRuoROm
# v6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpjtHhUBdRBLlCs
# lLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J4PcBZW+JC33I
# acjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTOMIIEygIBATCBkDB5
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMwIQYDVQQDExpN
# aWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAMps1TISNcThVQABAAAAyjAJ
# BgUrDgMCGgUAoIHnMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQB
# gjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBSnwVz0G946Pd+G
# wr8HSIM6Ej6NIjCBhgYKKwYBBAGCNwIBDDF4MHagXIBaAEQASQBBAEcAXwBDAFQA
# UwBSAGUAbQBvAHQAZQBfAGcAbABvAGIAYQBsAF8AVABTAF8ARABlAHQAZQBjAHQA
# TABvAHcAUABhAHQAaABNAFQAVQAuAHAAcwAxoRaAFGh0dHA6Ly9taWNyb3NvZnQu
# Y29tMA0GCSqGSIb3DQEBAQUABIIBAGyL88l2mUV2G1fQznlgWKUh5ytHr4lQGC7X
# p9PNLeiPtoc2eTvhTzK7mljAwSKFM9Z5QL76Vz+zLExz37Q5vcbrn9cblAq/Qf1Q
# R0q2Gem6uaOf7Rvv4+6KtO1F8+U/YVj4WCbdBwvxlIBe667SFAsB7FpGkoymWTWw
# LkthrZEEepzvdjJcGwfBoy29pOAwC2E/WGVLePmOMTxCWuKGbNziy1Q8RXu080eT
# bV1UG+jJ29Ys8I2MqcWAkXA4dnqtkXAK3aR4qh51ywmgFO8Bdhk/s17X1lsG3jyK
# t2kdHfSvCltFSxnY8Vk23gwlEAgs98arKnkYpoYn8/X6QVikOzyhggIoMIICJAYJ
# KoZIhvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# AhMzAAAAWu0v9OQgmT86AAAAAABaMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMx
# CwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0xNDA5MDMyMDI5MzBaMCMGCSqG
# SIb3DQEJBDEWBBSwCUkdMRgEYgvRKdowlfZYl1bZSTANBgkqhkiG9w0BAQUFAASC
# AQA9HqEkc34uUrMsslJuTnDzLoGIMnPIxVujvzdcqzMAUhpUyOWTgp2RUwxqRdKy
# FaaErPV6s2Tmbd62HrK1nPVj0j3B5ZHB7eiE21uKK0KogxvptzaCqBi9y/GO4Y0l
# x51XS5eX3WKwG2MTAUV9nAEvfUL6gLtyrGjcaUbr1b+yoz1b7RNvBamnv9qw6VUt
# zAfi2c1Xir9EKjhc0VoyzQu9mDwfiOnyGkUGpdEcEJlbBKChMQRbkRogY9DfEFXG
# Trh55Pt98LwcQh3KR9bHf+YJorYrzMOkRvkCFCCxZ/X5Lt6fGDX9u7HzlakTVlSw
# NyRUe6jCxHIekK8GJSc7WGuF
# SIG # End signature block
