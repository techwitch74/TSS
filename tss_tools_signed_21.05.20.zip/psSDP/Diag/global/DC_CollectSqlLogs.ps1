﻿#************************************************
# DC_CollectSqllogs.ps1
# Version 1.0.0
# Date: 10-2011
#
# Description: 
#			Collects SQL Server errorlogs and SQL Server Agent logs for all installed instances passed to script via the $Instances parameter
#			Can operate in "offline" mode where errorlog files are located using the registry or "online" mode
#			where errorlogs are enmerated and collected via xp_readerrorlog.
#
# Visibility:
#			Public - You should call this script to collect SQL Server errorlogs
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Script Parameters:
#			$Instances
#				Array of instances to collect errorlogs for
#           $CollectSqlErrorlogs
#               Switch parameter that indicates whether to collect SQL Server errorlogs 
#           $CollectSqlAgentLogs
#               Switch parameter that indicates whether to collect SQL Server Agent logs
#
# NOTE: This script expects the $Instances array to have been populated by the Enumerate-SqlInstances
#		function stored in "DSD\Scripts\SQL Server\Shared\Utilities\utils_DSD.ps1" and relies upon that format 
#       to function properly
#
# Author: Dan Shaver - dansha@microsoft.com
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Eliminated $Offline switch parameter as we no longer support "online" collection
#

# This script has dependencies on utils_CTS and utils_DSD
#
param( [Object[]] $instances, [switch]$CollectSqlErrorlogs, [switch] $CollectSqlAgentLogs) 

Import-LocalizedData -BindingVariable errorlogsCollectorStrings

#
# Function : Get-SqlAgentLogPath
# ----------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is used to find the path to the SQL Server errorlog for a given instance of SQL Server
# 
# Arguments:
#			$InstanceName
#			Function will find the path to the errorlogs for the instance passed 
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#
function Get-SqlAgentLogPath([string]$SqlInstance)
{
	trap 
	{
		'[Get-SqlAgentLogPath] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error 
	}

    # Check if required parameter specified
	if ($null -ne $SqlInstance)
    {
        # Get instance folder name under SQL Root directory
        $InstanceKey = Get-SqlInstanceRootKey -SqlInstanceName $SqlInstance
    	
        if (($null -ne $InstanceKey) -and (0 -lt $InstanceKey.Length))
    	{
    		$SqlAgentKey = Join-Path -Path $InstanceKey -ChildPath '\SqlServerAgent'								
    								
    		# Test for valid Sql Agent registry key.  
    		if ($true -eq (Test-Path -Path $SqlAgentKey))
    		{	
                
                if ($false -eq (Test-RegistryValueIsNull -RegistryKey $SqlAgentKey -RegistryValueName 'ErrorLogFile'))
                {			
        			# Get the Sql Agent Errorlog path
        			$SqlAgentLogPath = [System.IO.Path]::GetDirectoryName((Get-ItemProperty -Path $SqlAgentKey).ErrorLogFile)
                                 
                    # Command Fail?
                    if ($false -eq $?)
                    {
                        "[Get-SqlAgentLogPath] : [ERROR] Failed to retrieve SQL Agent log path from [{0}\ErrorLogFile]" -f $SqlAgentKey | WriteTo-StdOut
                        Report-Error
                    }
                }
                else
                {
                    "[Get-SqlAgentLogPath] : [ERROR] Failed to retrieve SQL Agent log path from [{0}\ErrorLogFile] because the 'ErrorlogFile' registry value is null" -f $SqlAgentKey | WriteTo-StdOut
                }
    		}
    		else
    		{
    			# Report that we could not locate the SQL Agent log path
    			"[Get-SqlAgentLogPath] : Unable to locate SQL Agent log path for SQL Instance: [{0}]" -f $SqlInstance | WriteTo-StdOut
                "[Get-SqlAgentLogPath] : Registry key: [{0}] is invalid" -f $SqlAgentKey | WriteTo-StdOut
                Report-Error                            
    		}
            
    	} # if ($null -ne $InstanceKey)
    	else
    	{
    		"[Get-SqlAgentLogPath] : Failed to retrieve Instance Root key [{0}]" -f $InstanceKey | WriteTo-StdOut
    		Report-Error
    	}

    } # if ($null -eq $SqlInstance)
    else
    {
        '[Get-SqlAgentLogPath] : Required parameter: -SqlInstance was not specified' | WriteTo-StdOut
    }
    
	return $SqlAgentLogPath
}



#
# Function : Get-SqlAgentLogsOffline
# ----------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function finds and collects all Sql Agent logs for the instance passed to the function
#			This is an "offline" collector in that it does not rely on making a connection to the SQL Server instance to
#			find and collect the Sql Agent log files (via xp_readerrorlog). 
#			Finds the location of the Sql Agent logs from the registry and collects the files from the \log folder for the install
# 
# Arguments:
#			$InstanceName
#			Function will find the path to the Sql Agent errorlog for the instance passed 
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#

function Get-SqlAgentLogsOffline ([string]$InstanceToCollect )
{
	trap 
	{
		'[Get-SqlAgentLogsOffline] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error  
	}
	
    if ($null -ne $InstanceToCollect)
    {
        # Send a status message to stdout.log
    	"[Get-SqlAgentLogsOffline] : [INFO] Attempting to collect Sql Agent logs for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut

    	# Set the SectionDescription to the instance name that errorlogs were collected from
    	$SectionDescription = 'SQL Server Agent Logs for instance: ' + $InstanceToCollect

		# Get path to SQL Server Agent log files from registry
		$SqlAgentLogPath = Get-SqlAgentLogPath -SqlInstance $InstanceToCollect
    		
    	if (($null -ne $SqlAgentLogPath) -and (0 -lt $SqlAgentLogPath.Length))
    	{		
    		
            if ($true -eq (Test-Path -Path $SqlAgentLogPath))
    		{
            	
                # Enumerate and then copy the files
				$Files = @()
                $Files = Copy-FileSql -SourcePath $SqlAgentLogPath `
                         -FileFilters @('SQLAGENT.*') `
                         -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_ERRORLOGS `
                         -InstanceName $InstanceToCollect `
						 -SectionDescription $SectionDescription `
						 -LCID (Get-LcidForSqlServer -SqlInstanceName $InstanceToCollect) `
						 -RenameCollectedFiles
                 
    			if (0 -eq $Files.Count)
    			{
                    #SQL Agent Log path is valid but no SQLAget log files exists ...
                    "[Get-SqlAgentLogsOffline] : [INFO] There are no Sql Agent log files for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut
                }
    		} 
    		else 
    		# Invalid path to SQL Agent log files retrieved from registry.  
    		{
				# Does the log path reference a cluster disk that is offline from this node at this time?
                if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $InstanceToCollect -PathToTest $SqlAgentLogPath)) 
				{
    				# If above function returns true the drive is online but the path is bad
                    "[Get-SqlAgentLogsOffline] : [ERROR] Path to Sql Agent Log Files: [{0}] for instance: {1} is invalid" -f $SqlAgentLogPath, $InstanceToCollect | WriteTo-StdOut
                }              
    		}
    	} 
    	else 
    	{
    		"[Get-SqlAgentLogsOffline] : [ERROR] Could not locate errorlog path in the registry for instance: [{0}]. No Sql Agent log files will be collected. " -f $InstanceToCollect | WriteTo-StdOut
    	}
        
    } #if ($null -eq $InstanceToCollect)
    else
    {
        '[Get-SqlAgentLogsOffline] : [ERROR] Required parameter: -InstanceToCollect was not specified' | WriteTo-StdOut
    }
} 

#
# Function : Get-ErrorlogsOffline
# -------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function finds and collects all errorlogs for the instance passed to the function
#			This is an "offline" collector in that it does not rely on making a connection to the SQL Server instance to
#			find and collect the errorlog files. 
#			Finds the location of the errorlogs from the registry and collects the files from the \log folder for the install
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$IsClustered
#				This variable tells the collector whether to run an additional check if a drive appears offline preventing collection
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#

function Get-ErrorlogsOffline ([string]$InstanceToCollect)
{
	trap 
	{
		"[Get-ErrorlogsOffline] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error
	}
	
	if ($null -ne $InstanceToCollect)
    {
        # Write status message to stdout.log
        "[Get-ErrorlogsOffline] : [INFO] Attempting to collect errorlogs for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut
    	
    	$SqlErrorLogPath = Get-SqlServerLogPath -SqlInstance $InstanceToCollect
    	
    	if ($null -ne $SqlErrorLogPath)
    	{		
    		if ( $true -eq (Test-Path -Path $SqlErrorLogPath) )
    		{
    			
                # Set the SectionDescription to the instance name that errorlogs were collected from
    			$SectionDescription = 'SQL Server Errorlogs for instance: ' + $InstanceToCollect 
             
                # Enumerate and then copy the files
				$Files = @()
				$Files = Copy-FileSql -SourcePath $SqlErrorLogPath `
                         -FileFilters @('ERRORLOG*') `
                         -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_ERRORLOGS `
                         -InstanceName $InstanceToCollect `
						 -SectionDescription $SectionDescription `
						 -LCID (Get-LcidForSqlServer -SqlInstanceName $InstanceToCollect) `
						 -RenameCollectedFiles
                 
    			if (0 -eq $Files.Count)
    			{
                    "[Get-ErrorlogsOffline] : [INFO] There are no Sql errorlog files for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut
                }
                
    		} # if ( $true -eq (Test-Path -Path $SqlErrorLogPath) )
    		# Errorlog path is invalid
    		else 
    		{
    			if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $InstanceToCollect -PathToTest $SqlErrorLogPath))
    	        {
    	            "[Get-ErrorlogsOffline] : [ERROR] No SQL errorlogs will be collected. Path to errorlogs: [{0}] for instance: {1} is invalid" -f $SqlErrorLogPath, $InstanceToCollect | WriteTo-StdOut
    	        }
    		}
    	}
    	# Couldn't locate errorlog path
    	else
    	{
    		"[Get-ErrorlogsOffline] : [ERROR] No SQL errorlogs will be collected. Could not locate the errorlog path in the registry for instance: {0} is invalid" -f $InstanceToCollect | WriteTo-StdOut
    	}
    } #if ($null -ne $InstanceToCollect)
    else
    {
        "[Get-ErrorlogsOffline] : [ERROR] Required parameter -InstanceToCollect was not specified" -f $InstanceToCollect | WriteTo-StdOut
    }
} 

#
# Function : Get-ErrorlogsOnline
# -------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function finds and collects all errorlogs for the instance passed to the function
#			This is an "online" collector that utilizes SQLCMD and xp_readerrorlog to collect the SQL Server errorlogs
#			This collector uses the same exact scrip that PSSDiag uses in order to maintain compatibility with any 
#			post-processing of errorlogs performed by SqlNexus
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
#function Get-ErrorlogsOnline ( [string]$InstanceName
#                             , [string]$NetName )
#{
#	trap 
#	
#		'[Get-ErrorlogsOnline] : Trapped error ...' | WriteTo-StdOut
#		Show-ErrorDetails -ErrorRecord $error[0] 
#
#		# Now clear all errors since we reported them
#		$Error.Clear() 
#	}
#	
#	New-Variable ERRORLOG_COLLECTOR_SCRIPT -Value 'collecterrorlog.sql' -Option ReadOnly
#	
#	if (('DEFAULT' -eq $InstanceName) -or ( 'MSSQLSERVER' -eq $InstanceName))
#	{
#		$ConnectToName = $NetName
#		$ErrorlogOutFileName = "{0}__SQL_Base_Errorlog_Shutdown.out" -f $NetName
#	} else {
#		$ConnectToName = $NetName+'\'+$InstanceName
#		$ErrorlogOutFileName = "{0}_{1}_SQL_Base_Errorlog_Shutdown.out" -f $NetName, $InstanceName
#	}
#
#	Execute-SqlScript -ConnectToName $ConnectToName `
#                     -ScriptToExecute $ERRORLOG_COLLECTOR_SCRIPT `
#                      -OutputFileName $ErrorlogOutFileName `
#                      -SectionDescription ("SQL Server Errorlogs for instance: {0}" -f $ConnectToName) `
#                      -FileDescription 'ERRORLOGS'
#}

#
# Function : Get-SqlErrorlogs
# ------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is a wrapper that calls Get-ErrorlogsOffline
#           This script used to support online and offline collection modes 
#           The "online" collector utilized SQLCMD and xp_readerrorlog to collect the SQL Server errorlogs
#			However, xp_readerrorlog wraps lines and this caused issues for loading the files in UDE so we no longer collect in this format
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#
#

function Get-SqlErrorLogs ([object]$Instance)
{
	trap 
	{
		# Handle and report any exceptions that occur in this function, and then allow execution to resume 
		# Since this is only a wrapper function and doesn't do much to setup the excution of Get-ErrorlogsOffline, 
		# the called function may still succeed
		#
		'[Get-SqlErrorLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error
	}
	
    # Check if required parameter was passed
    if ($null -ne $Instance)
    {
       	# Update msdt dialog with progress message
    	Write-DiagProgress -Activity $errorlogsCollectorStrings.ID_SQL_CollectSqlErrorlogs -Status ($errorlogsCollectorStrings.ID_SQL_CollectSqlErrorlogsDesc + ": " + $instance.InstanceName)
    	
        if ($null -ne $Instance.InstanceName)
        {
        	"[Get-SqlErrorLogs] : [INFO] Collecting logs for instance {0}" -f $Instance.InstanceName | WriteTo-StdOut
        	Get-ErrorlogsOffline -InstanceToCollect $Instance.InstanceName 	
        }
        else
        {
            '[Get-SqlErrorLogs] : [ERROR] Passed instance name ($Instance.InstanceName) is null' | WriteTo-StdOut
        }
	}
    else
    {
        if ($null -eq $Instance)
        {
            '[Get-SqlErrorLogs] : [ERROR] Required parameter: -Instance was not specified' | WriteTo-StdOut
        }
    }	
	
}

#
# Function : Get-SqlAgentLogs
# ------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is a wrapper that calls Get-SqlAgentLogsOffline
#			Wrapper exists in case we want to add offline and online (via xp_readerrorlog) collection modes.  This is the function
#			
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#
#
function Get-SqlAgentLogs ([object]$Instance)
{
	trap 
	{
		'[Get-SqlAgentLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error 
	}
	
	# Update msdt dialog with progress message
	Write-DiagProgress -Activity $errorlogsCollectorStrings.ID_SQL_CollectSqlAgentlogs -Status ($errorlogsCollectorStrings.ID_SQL_CollectSqlAgentlogsDesc + ": " + $instance.InstanceName)
	
    # Check if required parameter specified
    if ($null -ne $Instance)
    {
        # Write to debug log
    	"[Get-SqlAgentLogs] : [INFO] Collecting Sql Agent logs for instance {0}" -f $Instance.InstanceName | WriteTo-StdOut
    	Get-SqlAgentLogsOffline -InstanceToCollect $Instance.InstanceName 
    }
    else
    {
        '[Get-SqlAgentLogs] : [ERROR] Required parameter -Instance was not specified' | WriteTo-StdOut
    }
}

# Clear errors at entry to script
#
$Error.Clear()           
trap 
{
	'[DC-CollectSqllogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
	Report-Error 
}

if ($true -eq $global:SQL:debug)
{
    $CollectSqlErrorlogs=$true
    $CollectSqlAgentLogs=$true
}

# Check to be sure that there is at least one SQL Server installation on target machine before proceeding
#
if ($true -eq (Check-SqlServerIsInstalled))
{
	# If $instance is null, get errorlogs for all instances installed on machine
	#

	if ($null -eq $instances)
	{
		$instances = Enumerate-SqlInstances -Offline
	}
	
	if ($null -ne $instances)
    {
    
		foreach ($instance in $instances)
		{
			if ('DEFAULT' -eq $instance.InstanceName) {$instance.InstanceName='MSSQLSERVER'}
        
			if ($true -eq $CollectSqlErrorlogs)
			{
				Get-SqlErrorlogs -Instance $instance
			}
            
			if ($true -eq $CollectSqlAgentLogs)
			{
				Get-SqlAgentLogs -Instance $instance
			}
            
		}
        
	} # if ($null -ne $instances)
    else
    {
        "[DC_CollectSqllogs] : [WARN] No sql server instances were found on: [{0}] yet SQL Server appears to be installed" -f $ComputerName | WriteTo-StdOut 
    }
} # if ($true -eq (Check-SqlServerIsInstalled))

else 
{
    "[DC_CollectSqllogs] : No sql server instances are installed on: [{0}]" -f $ComputerName | WriteTo-StdOut 
}
	
# SIG # Begin signature block
# MIIjfAYJKoZIhvcNAQcCoIIjbTCCI2kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDGFAbeKKmYa8Qf
# en4sMBLmOVkLBD06K2Y3VD4b9C58s6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVUTCCFU0CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQghqdqWDKW
# UnKRWFSAkCaSlcW6OHGLZ71GRj2REH/3n58wOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAIXyh+CFrwupgTFDfnjCcYfJxVmCfRW6KSWJg3uevFHWcE4wCMgo25nJ
# Qsc/WD2V9cpUQXa0PlAs/Jzn/TZN41eRcW5PWMq0fdtW8B12KmP/INg0HAf6Dulj
# d37d6xz1ElXgYEJq45WWeXDg8bzh5hHN6X+PW2F9FPrJAOfeMM3+Y+a5od8ntcTc
# SIjDfqf/JWEFgG0XZzoTwHSyPTbQYv8UfC8bYfmoI6IE/q31tKUf7R8Br6hYXU7I
# rbhcSjqrvKW+WyAeseTzjc5pb06PJUxl3Ld+332MqEAuujffhTYTjIqhh//klSnr
# 1jJBziIKf4PowoX9yOBhXTFCVbNP1wuhghLlMIIS4QYKKwYBBAGCNwMDATGCEtEw
# ghLNBgkqhkiG9w0BBwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYL
# KoZIhvcNAQkQAQSgggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgCb6ARHaawHXVaMz40g6Nrwa0gsBhClJT9xnBEBV7Ke0CBmCJ1nt4
# OBgTMjAyMTA1MTkyMjIzNTQuMjYyWjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
# ZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046N0JGMS1F
# M0VBLUI4MDgxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# gg48MIIE8TCCA9mgAwIBAgITMwAAAVHDUOdZbKrGpwAAAAABUTANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMDExMTIxODI2
# MDRaFw0yMjAyMTExODI2MDRaMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo3QkYxLUUzRUEtQjgwODElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ/Sh++qhK477ziJI1mx6bTJGA45hviRJs4Lsq/1cY2Y
# Gf4oPDJOO46kiT+UcR/7A8qoWLu4z0jvOrImYfLuwwV/S/CPgAfvHzz7w+LqCyg9
# tgaaBZeAfBcOSu0rom728Rje2nS9f81vrFl5Vb6Q4RDyCgyArxHTYxky4ZLX37Y3
# n4PZbpgTFASdhuP4OGndHQ70TZiojGV13vy5eEIP6D0s1wlBGKEkqmuQ/uTEYplX
# uf2Ey49I1a/IheOVdIU+1R/DiTuGCJnJ2Yaug8NRvsOgAkRnjxZjlqlvLRGdd0jJ
# jqria05MMsvM8jbVbbSQF+3YhS20dErzJWyWVitCh3cCAwEAAaOCARswggEXMB0G
# A1UdDgQWBBTFd//jaFBikzRoOjjMhOnzdUTqbTAfBgNVHSMEGDAWgBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNy
# dDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# CwUAA4IBAQAr/fXAFYOZ8dEqo7y30M5roDI+XCfTROtHbkh9S6cR2IpvS7N1H4mH
# e7dCb8hMP60UxCh2851eixS5V/vpRyTBis2Zx7U3tjiOmRxZzYhYbYMlrmAya5uy
# kMpDYtRtS27lYnvTHoZqCvoQYmZ563H2UpwUqJK7ztkBFhwtcZ2ecDPNlBI6axWD
# pHIVPukXKAo45iBRn4EszY9TCG3+JXCeRaFdTIOhcBeOQoozlx1V685IrDGfabg6
# RY4xFekwGOiDYDJIS3r/wFaMNLBfDH0M7SSJRWHRRJGeTRfyMs6AtmG/YsOGwinQ
# a3Q9wLOpr6BkjYwgupTnc+hHqyStzYRYMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAA
# AjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0
# aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPl
# YcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2T
# rNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFh
# E24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+c
# Bj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn
# 9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQB
# gjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB
# /zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEE
# AYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9Q
# S0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcA
# YQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZI
# hvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20Z
# MLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX
# /1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+TH
# zvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnx
# zplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjY
# lPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kW
# umGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3
# ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slva
# yA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5
# KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czm
# TfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYIC
# zjCCAjcCAQEwgfihgdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjdCRjEtRTNFQS1CODA4MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQCg
# oq9z8T+kQgslTCUgFaDFetcjXqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5FADyzAiGA8yMDIxMDUyMDA1Mzgx
# OVoYDzIwMjEwNTIxMDUzODE5WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDkUAPL
# AgEAMAoCAQACAhkVAgH/MAcCAQACAhFVMAoCBQDkUVVLAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQEFBQADgYEAqk9uNflrwqOMR91pqaK5YS+20j2ZqAr343jcYYMTjaiV
# t9AL4BD4Hu2zpaj4oIYavwyQh2usAaRU8THj4ncLUxHGdYr1OG2f/VmcqcwJVr4i
# ysmAWBEo2miC/4rGquA3WPRddZCclbmpEHUnAMwhTHZv6WodDEMC9Op5c3uVjGIx
# ggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AVHDUOdZbKrGpwAAAAABUTANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDV/O8lavfpoctfhnBkuQD2
# iJ+LpFqdWX3HQ56PvORT1TCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIC7N
# XJmI+NbBWQcAphb7/UnD+bbrlIcbL/7dAfVxeuVBMIGYMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFRw1DnWWyqxqcAAAAAAVEwIgQgXh3x
# EtLo7ZLQMxY+WmSph22uhPsBj8WTjk5JOpzZdUkwDQYJKoZIhvcNAQELBQAEggEA
# J6rO+o/D7vg/MrD8by2XCQYB23Z9QLnD+mfD81tnMdwljhbW2a6E13YDUShwSRsY
# WH10ILbzDBDEZn2GrXbAGB/gNbXgMeg9eMuepvmqKWuHek4oaSHMFL/OZUlZNzPx
# TIy5cXz6uWl8RmgoKUIIa1R02xS5O/dymLfUid2NXuvmITusXRDU81FlwdyYcm0Q
# /CJebD5zk+L55nOh2TwRU7wDUHGh0G56ef60WHYqvRAOXNWt2kZJSKlcrmRUwafa
# YVZHfX4H76443kmi71/Met1dvz2iF9lU4ecepM6vtSvsGW0cCyUPnLPy2ZdJsw3d
# BE7HXJixrqMiCsEdjjzpJA==
# SIG # End signature block
