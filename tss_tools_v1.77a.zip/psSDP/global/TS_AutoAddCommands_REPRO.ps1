﻿	# Basic System Information TXT output [AutoAdded]
	Run-DiagExpression .\DC_BasicSystemInformationTXT.ps1
	
<#
	# Check for ephemeral port usage [AutoAdded]
	Run-DiagExpression .\TS_PortUsage.ps1

	# SMB2ClientDriverStateCheck [AutoAdded]
	Run-DiagExpression .\TS_SMB2ClientDriverStateCheck.ps1

	# SMB2ServerDriverStateCheck [AutoAdded]
	Run-DiagExpression .\TS_SMB2ServerDriverStateCheck.ps1

	# Opportunistic Locking has been disabled and may impact performance. [AutoAdded]
	Run-DiagExpression .\TS_LockingKB296264Check.ps1

	# RC_KB2647170_CnameCheck [AutoAdded]
	Run-DiagExpression .\RC_KB2647170_CnameCheck.ps1

	# IPv6Check [AutoAdded]
	Run-DiagExpression .\TS_IPv6Check.ps1

	# RC_32GBMemoryKB2634907 [AutoAdded]
	Run-DiagExpression .\RC_32GBMemoryKB2634907.ps1

	# PMTU Check [AutoAdded]
	Run-DiagExpression .\TS_PMTUCheck.ps1

	# Checks for modified TcpIP Reg Parameters and recommend KB [AutoAdded]
	Run-DiagExpression .\TS_TCPIPSettingsCheck.ps1

	# Missing Enterprise Hotfix Rollup for Windows7/Windows2008R2 (KB2775511) [AutoAdded]
	Run-DiagExpression .\TS_KB2775511Check.ps1
#>

	# Update History [AutoAdded]
#_#	Run-DiagExpression .\DC_UpdateHistory.ps1	
<#
	# AutoRuns Information [AutoAdded]
	Run-DiagExpression .\DC_Autoruns.ps1

	# Basic System Information TXT output [AutoAdded]
	Run-DiagExpression .\DC_BasicSystemInformationTXT.ps1


	# NetworkConnections [AutoAdded]
	Run-DiagExpression .\DC_NetworkConnections-Component.ps1

	# Network Shortcuts (Network Locations) [AutoAdded]
	Run-DiagExpression .\DC_NetworkShortcuts.ps1

	# Remote File Systems Client Component [AutoAdded]
	Run-DiagExpression .\DC_RemoteFileSystemsClient-Component.ps1

	# Remote File Systems Server Component [AutoAdded]
	Run-DiagExpression .\DC_RemoteFileSystemsServer-Component.ps1

	# SMB Client Component [AutoAdded]
	Run-DiagExpression .\DC_SMBClient-Component.ps1

	# SMB Server Component [AutoAdded]
	Run-DiagExpression .\DC_SMBServer-Component.ps1

	# NetworkingDiagnostic CscClient [AutoAdded]
	Run-DiagExpression .\DC_NetworkingDiagnostic.ps1

	# Obtain pstat output [AutoAdded]
	Run-DiagExpression .\DC_PStat.ps1

	# Performance Monitor - System Performance Data Collector [AutoAdded]
	Run-DiagExpression .\TS_PerfmonSystemPerf.ps1 -NumberOfSeconds 60 -DataCollectorSetXMLName "SystemPerformance.xml"
#>
Write-Verbose "$(Get-Date -UFormat "%R:%S") ***DONE TS_AutoAddCommands_REPRO.ps1"

